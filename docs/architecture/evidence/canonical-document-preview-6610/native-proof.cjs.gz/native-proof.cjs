const fs = require('node:fs');
const crypto = require('node:crypto');
const child = require('node:child_process');
const assert = require('node:assert/strict');
const [wt, out, port] = process.argv.slice(2);
if (!wt || !out || !/^\d+$/.test(port)) throw Error('Pass owned worktree, NEW artifact prefix and owned server port');
const { chromium } = require(wt + '/node_modules/@playwright/test');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
(async () => {
 const source = child.execFileSync('git', ['rev-parse', 'HEAD'], { cwd: wt, encoding: 'utf8' }).trim();
 if (fs.existsSync(out + '-observations.json')) throw Error('Refusing to overwrite previous evidence');
 const context = await chromium.launchPersistentContext(out + '-owned-profile', { executablePath: '/usr/bin/google-chrome', headless: true, viewport: { width: 1440, height: 1040 }, acceptDownloads: true, args: ['--enable-unsafe-webgpu', '--use-angle=swiftshader'] });
 const logs = []; let page;
 try {
  page = await context.newPage();
  page.on('console', msg => { if (msg.type() === 'error' || msg.type() === 'warning') logs.push({ type: 'console', text: msg.text().slice(0, 1500) }); });
  page.on('pageerror', error => logs.push({ type: 'pageerror', text: error.message }));
  await page.goto('http://127.0.0.1:' + port + '/');
  await page.waitForFunction(() => globalThis.__ifc_lite_viewer_store__);
  const input = wt + '/apps/viewer/public/samples/building-architecture.ifc';
  await page.locator('input[type=file][accept^=".ifc"]').first().setInputFiles(input);
  await page.waitForFunction(() => [...__ifc_lite_viewer_store__.getState().models.values()].some(model => model.ifcDataStore), null, { timeout: 60000 });
  await page.waitForFunction(() => { const state = __ifc_lite_viewer_store__.getState(); return !state.loading && !state.geometryStreamingActive; }, null, { timeout: 60000 });
  const model = await page.evaluate(() => [...__ifc_lite_viewer_store__.getState().models.values()].filter(model => model.ifcDataStore).map(model => ({ id: model.id, name: model.name, fingerprint: model.sourceFingerprint, entities: model.ifcDataStore.entityCount })));
  const activate = async (doc) => page.evaluate(doc => { const state = __ifc_lite_viewer_store__.getState(); if (!state.upsertDocument(doc)) throw Error('Canonical document writer refused authored proof'); state.setActiveDocumentId(doc.id); state.floatPanel('document'); state.setFloatingPanelRect('document', { x: 16, y: 64, w: 1400, h: 950 }); }, doc);
  const ready = async () => page.waitForFunction(() => { const preview = document.querySelector('[data-document-preview]'); return preview?.getAttribute('aria-busy') === 'false' && preview.querySelector('[data-preview-section]'); });
  const capture = async name => { await ready(); const pages = page.locator('[data-preview-section]'); const count = await pages.count(); const texts = await pages.allTextContents(); for (let n = 0; n < count; n++) { await ready(); await pages.nth(n).evaluate(el => el.scrollIntoView({ block: 'center' })); await page.screenshot({ path: out + '-' + name + '-page-' + (n + 1) + '.png' }); } return { count, texts }; };
  const download = async name => { const event = page.waitForEvent('download', { timeout: 60000 }); await page.getByRole('button', { name: 'Export PDF', exact: true }).click(); const result = await event; const error = await result.failure(); if (error) throw Error(error); await result.saveAs(out + '-' + name + '.pdf'); const toast = await page.waitForFunction(() => [...document.querySelectorAll('[data-toast-seq]')].filter(row => row.textContent.includes('Document exported:')).at(-1)?.textContent || false); const toastText = await toast.jsonValue(); await toast.dispose(); if (!/^Document exported: \d+ pages?$/.test(String(toastText).trim())) throw Error('Export reported an actual problem: ' + toastText); return { toast: toastText, filename: result.suggestedFilename(), bytes: fs.statSync(out + '-' + name + '.pdf').size, sha256: hash(fs.readFileSync(out + '-' + name + '.pdf')) }; };
  const version = await page.evaluate(async () => (await import('/src/lib/document/types.ts')).DOCUMENT_VERSION);
  const body = Array.from({ length: 100 }, (_, n) => 'Inspection line ' + String(n + 1).padStart(3, '0')).join('\n');
  const overflowDoc = { version, id: '6610-overflow-proof', name: 'Public model handover', page: { size: 'A4', orientation: 'portrait' }, blocks: [{ kind: 'text', id: 'overflow', style: 'body', text: body }] };
  await activate(overflowDoc); const overflow = await capture('overflow'); assert.equal(overflow.count, 2); assert.match(overflow.texts[0], /Inspection line 001/); assert.match(overflow.texts[1], /Inspection line 100/); overflow.texts.forEach((text, n) => assert.ok(text.includes('Page ' + (n + 1) + ' / ' + overflow.count)));
  const overflowPdf = await download('overflow');
  const logo = 'data:image/png;base64,' + fs.readFileSync(wt + '/apps/viewer/public/favicon-16x16-cropped.png').toString('base64');
  const authored = await page.evaluate(async ({ wt, logo, version }) => {
   const [{ validateIDS }, { runRuleSet }, { IfcTypeEnum }, { createDataAccessor }, { evaluatorModelsFromState }, { validationReportSnapshot }, { manualReportBlockFromChecklist }] = await Promise.all([
    import('/@fs' + wt + '/packages/ids/src/index.ts'), import('/@fs' + wt + '/packages/rules/src/index.ts'), import('/@fs' + wt + '/packages/data/src/index.ts'), import('/src/hooks/ids/idsDataAccessor.ts'), import('/src/lib/model-tags/evaluator-models.ts'), import('/src/lib/validation/reports/history.ts'), import('/src/lib/document/manual-report.ts')]);
   const state = __ifc_lite_viewer_store__.getState(); const model = [...state.models.values()].find(model => model.ifcDataStore); const store = model.ifcDataStore;
   const ids = { info: { title: 'Public wall Name evidence' }, specifications: [{ id: 'wall-name', name: 'Wall Name exists', ifcVersions: ['IFC4'], applicability: { facets: [{ type: 'entity', name: { type: 'simpleValue', value: 'IFCWALL' } }] }, requirements: [{ id: 'name', optionality: 'required', facet: { type: 'attribute', name: { type: 'simpleValue', value: 'Name' } } }] }] };
   const rules = { version: 1, name: 'Public wall unique Name evidence', rules: [{ id: 'wall-names', name: 'Wall names are unique', applicability: { groups: [{ rules: [{ kind: 'ifcType', values: ['IfcWall'], op: 'in' }], combinator: 'AND' }], authoredAs: 'chips' }, requirement: { kind: 'unique', subject: { kind: 'attribute', name: 'Name' } } }] };
   const idsReport = await validateIDS(ids, createDataAccessor(store, model.id), { modelId: model.id, schemaVersion: store.schemaVersion, entityCount: store.entityCount }, { includePassingEntities: true });
   const rulesReport = await runRuleSet({ ruleSet: rules, models: evaluatorModelsFromState(state), definedModelTagIds: new Set() });
   if (idsReport.summary.totalEntitiesChecked !== 4 || rulesReport.summary.totalEntitiesChecked !== 4) throw Error('Actual public four-wall source was not evaluated');
   const manual = manualReportBlockFromChecklist({ checklist: { version: 1, name: 'Declared manual review', groups: [{ id: 'review', name: 'Document review', items: [{ id: 'heading', text: 'Check the public model heading' }, { id: 'table', text: 'Review wall Name table', description: 'A declared checklist answer, not an automatic IFC verdict.' }] }] }, answers: { heading: { status: 'pass', updatedAt: 1 }, table: { status: 'warning', comment: 'Authored demonstration observation', updatedAt: 2 } }, modelName: model.name, modelFingerprint: model.sourceFingerprint, now: new Date('2026-10-02T12:00:00Z') }, 'manual');
   state.setBcfProject({ version: '3.0', topics: new Map([['proof-topic', { guid: 'proof-topic', title: 'Declared coordination note', description: 'Review the public wall Name schedule.', comments: [], viewpoints: [] }]]) });
   const doc = { version, id: '6610-all-kinds-proof', name: 'Public model document composition', page: { size: 'A4', orientation: 'portrait' }, blocks: [
    { kind: 'text', id: 'model-heading', style: 'heading', font: 'times', fontSize: 16, width: 'half', text: 'Model: {Model.Name}' }, { kind: 'image', id: 'logo', dataUrl: logo, height: 50, align: 'left', width: 'half', caption: 'Committed project icon' },
    { kind: 'chart', id: 'chart', chart: { id: 'public-chart', title: 'Public elements by IFC class', source: 'elements', type: 'bar', dimension: 'IfcType', measure: { agg: 'count' } }, snapshot: false, height: 160, fontSize: 8 },
    { kind: 'topic', id: 'topic', guid: 'proof-topic', snapshot: false }, { kind: 'spacer', id: 'space', height: 16 },
    { kind: 'table', id: 'table', source: { kind: 'list', list: { id: 'public-wall-table', name: 'Public wall Names', createdAt: 1, updatedAt: 1, entityTypes: [IfcTypeEnum.IfcWall], groups: [], columns: [{ id: 'Name', source: 'attribute', propertyName: 'Name' }] } } },
    { kind: 'page-break', id: 'report-break' }, { ...validationReportSnapshot(idsReport, state.models, 'ids'), variant: 'compact', benchmarks: true }, { ...validationReportSnapshot(rulesReport, state.models, 'rules'), variant: 'long', benchmarks: true }, { ...manual, showStamp: false },
    { kind: 'text', id: 'continuation', style: 'body', text: Array.from({ length: 80 }, (_, n) => 'Closing review line ' + (n + 1)).join('\n') } ] };
   return { doc, reports: [idsReport.summary, rulesReport.summary], declaredManualAnswers: manual.groups, declaredTopic: 'Authored note; not imported or generated from engine findings' };
  }, { wt, logo, version });
  await activate(authored.doc); await page.waitForFunction(() => document.querySelector('[data-preview-block="chart"] svg') && document.querySelector('[data-preview-block="table"] tbody tr')); const allKinds = await capture('all-kinds'); assert.ok(allKinds.count >= 3); const allText = allKinds.texts.join('\n'); assert.match(allText, /building-architecture.ifc/); assert.match(allText, /Public wall Names/); assert.match(allText, /Closing review line 80/); const manualText = await page.locator('[data-block-manual-report]').allTextContents(); assert.ok(!/Model:|Models:|Recorded:/.test(manualText.join('\n'))); const allKindsPdf = await download('all-kinds');
  const persisted = await page.evaluate(() => __ifc_lite_viewer_store__.getState().documents.find(doc => doc.id === '6610-all-kinds-proof'));
  const parseResult = await page.evaluate(async doc => { const { parseDocumentFile } = await import('/src/lib/document/persistence.ts'); const parsed = parseDocumentFile(JSON.stringify(doc)); return { kinds: parsed.blocks.map(block => block.kind), hiddenStamp: parsed.blocks.find(block => block.kind === 'manual-report').showStamp, headingFont: parsed.blocks[0].font, headingSize: parsed.blocks[0].fontSize }; }, persisted);
  assert.equal(parseResult.hiddenStamp, false); assert.equal(parseResult.headingFont, 'times'); assert.equal(parseResult.headingSize, 16);
  fs.writeFileSync(out + '-document.json', JSON.stringify(persisted, null, 2) + '\n');
  fs.writeFileSync(out + '-observations.json', JSON.stringify({ source, capturedAt: new Date().toISOString(), chrome: await context.browser()?.version(), route: 'Owned Linux Chrome; canonical file-input load; real IDS/information engines; actual mounted DocumentPanel; canonical writer and native UI PDF downloads. SVG/PDF exporter unmodified.', limits: 'Document/data route using software WebGPU. Device/alignment errors are retained; no 3D or performance claim. Manual decisions and coordination topic are explicitly authored demonstrations.', input: { path: 'apps/viewer/public/samples/building-architecture.ifc', sha256: hash(fs.readFileSync(input)) }, model, overflow, allKinds, manualText, reports: authored.reports, declaredManualAnswers: authored.declaredManualAnswers, parseResult, downloads: [overflowPdf, allKindsPdf], logs }, null, 2) + '\n');
  console.log(JSON.stringify({ source, previewPages: [overflow.count, allKinds.count], downloads: [overflowPdf, allKindsPdf] }));
 } catch (error) { if (page) await page.screenshot({ path: out + '-failure.png' }); fs.writeFileSync(out + '-failure-logs.json', JSON.stringify(logs, null, 2)); throw error; }
 finally { await context.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
