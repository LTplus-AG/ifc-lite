import ts from '/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
const paths=['/tmp/ifclite-context-wasm-types-before.d.ts','/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361/packages/wasm/pkg/ifc-lite.d.ts'];
const printer=ts.createPrinter({removeComments:true});
function surfaces(path) {
 const source=ts.createSourceFile(path,readFileSync(path,'utf8'),ts.ScriptTarget.Latest,true);
 const high=new Map(),raw=new Map();
 for(const statement of source.statements){
  const name=statement.name?.getText(source);
  if(name==='InitOutput')for(const member of statement.members)raw.set(member.name.getText(source),printer.printNode(ts.EmitHint.Unspecified,member,source).replace(/\s+/g,' '));
  else high.set(`${ts.SyntaxKind[statement.kind]}:${name??statement.getText(source).split('\n')[0]}`,printer.printNode(ts.EmitHint.Unspecified,statement,source).replace(/\s+/g,' '));
 }
 return {high,raw};
}
function changes(a,b){return [...new Set([...a.keys(),...b.keys()])].filter(key=>a.get(key)!==b.get(key)).map(name=>({name,before:a.get(name)??null,after:b.get(name)??null}));}
const [a,b]=paths.map(surfaces);
const receipt={highLevelChanges:changes(a.high,b.high),rawInitOutputChanges:changes(a.raw,b.raw)};
writeFileSync('/tmp/ifclite-context-final-wasm-type-surface.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2));
if(receipt.highLevelChanges.length||receipt.rawInitOutputChanges.length)process.exitCode=1;
