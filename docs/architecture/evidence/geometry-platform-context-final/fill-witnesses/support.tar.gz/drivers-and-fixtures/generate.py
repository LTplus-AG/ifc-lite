from pathlib import Path
import hashlib,json,re
root=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361');out=Path('/tmp/ifclite-context-final-fill-witnesses')
sha=lambda b:hashlib.sha256(b).hexdigest()
results=[]
for path,name,const in [('rust/processing/tests/annotation_fills_4406.rs','filled-hole-mm-ifc4','FILL'),('rust/processing/tests/issue_5389_annotation_symbolic_items.rs','mixed-annotation-mm-ifc4','MIXED')]:
 data=(root/path).read_text();raw=re.search(r'const '+const+r': &str = "(.*?)";',data,re.S).group(1)
 text=json.loads('"'+raw.replace('\n','\\n').replace('\r','\\r')+'"')
 # Test fixture metadata only: no external authoring-tool attribution is asserted.
 text=re.sub(r"(FILE_NAME\('[^']*','[^']*',\('[^']*'\),\('[^']*'\),)'[^']*','[^']*'",r"\1'IFClite invariant','IFClite invariant'",text,count=1)
 cases=[(name,text)]
 if const=='FILL':cases.append(('filled-hole-mm-ifc2x3',text.replace("FILE_SCHEMA(('IFC4'))","FILE_SCHEMA(('IFC2X3'))").replace("(#23),.F.)","(#23))").replace('#25=IFCSTYLEDITEM(#22,(#24),$);','#26=IFCPRESENTATIONSTYLEASSIGNMENT((#24));#25=IFCSTYLEDITEM(#22,(#26),$);')))
 for name,text in cases:
  p=out/(name+'.ifc');p.write_text(text)
  results.append({'name':name,'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'basis_test_source':path,'basis_test_source_sha256':sha((root/path).read_bytes()),'fixture_kind':'Synthetic invariant derived from existing test, producer metadata normalized; not real-exporter evidence.'})
(out/'fixture-pins.json').write_text(json.dumps(results,indent=2)+'\n')
print('\n'.join(x['path'] for x in results))
