from pathlib import Path
import hashlib,json,math,struct,tarfile,sys
root=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361');scratch=Path('/tmp/ifclite-context-final-fill-witnesses');raw=Path('/tmp/ifclite-context-final-fill-scenes');out=root/'docs/architecture/evidence/geometry-platform-context-final/fill-witnesses';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0,str(root/'tools/smlib-evaluation/scene-comparison'));from run import compare
manifest=root/'docs/architecture/evidence/geometry-platform-context-final/source-manifest-ratchet-corrected.json';m=json.loads(manifest.read_text());assert all(sha(root/p)==h for p,h in m['source_sha256'].items())
pins=json.loads((root/'docs/architecture/evidence/geometry-platform-context-final/native-scene-library-pins.json').read_text());build=json.loads((root/'docs/architecture/evidence/geometry-platform-context-final/native-scene-build.json').read_text())
for libraries in pins['libraries'].values():
 for p in libraries.values():assert sha(Path(p['path']))==p['sha256']
for label in ['base','candidate']:assert sha(Path('/tmp/ifclite-context-final-scene-build')/('scene-'+label))==build[label+'_executable_sha256']
def f(x):
 kind,bits=x.split(':');return struct.unpack('!f' if kind=='f32' else '!d',bytes.fromhex(bits))[0]
def area(poly):return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(poly,poly[1:]+poly[:1])))/2 if len(poly)>2 else 0
# Clip each actual triangle to the open square hole. Positive intersection area
# would prove a real hole-fill error even if total triangle areas happen to agree.
def clipped(poly,axis,bound,sign):
 result=[]
 if not poly:return result
 for a,b in zip(poly,poly[1:]+poly[:1]):
  av=sign*(a[axis]-bound);bv=sign*(b[axis]-bound);ai=av>=0;bi=bv>=0
  if ai:result.append(a)
  if ai!=bi:
   t=av/(av-bv);result.append([a[i]+t*(b[i]-a[i]) for i in range(2)])
 return result
cases=[]
for old in json.loads((raw/'summary.json').read_text()):
 fixture=Path(old['fixture']);assert sha(fixture)==old['input_sha256'];case=raw/(fixture.stem+'-'+sha(fixture)[:12]+'-'+old['mode']);checks={};holes=fixture.name.startswith('filled-hole');expected=2 if holes else 1
 for label in ['base','base-repeat','candidate']:
  p=case/label/'records.jsonl';records=[json.loads(l) for l in p.open()];meshes=[r['value'] for r in records if r['channel']=='scene.mesh'];sym=next(r['value'] for r in records if r['channel']=='scene.symbolic' and r['key']=='data');assert len(meshes)==len(sym['fills'])==expected
  areas=[]
  for mesh in meshes:
   v=mesh['presented'];assert v['ifc_type']=='str:IfcAnnotation' and v['geometry_item_id']==['some',22]
   if holes:
    expected_color=[.2,.6,.8,1]
    if old['mode']=='fastfirst':
     assert 'material_name' not in v
     assert all(abs(f(a)-b)<1e-6 for a,b in zip(v['color'],[.8,.8,.8,1]))
     updates={key:color for record in records if record['channel']=='event.colors' for key,color in record['value']}
     assert all(abs(f(a)-b)<1e-6 for a,b in zip(updates[v['express_id']],expected_color))
    else:
     assert v['material_name']==['some','str:Cyan fill']
     assert all(abs(f(a)-b)<1e-6 for a,b in zip(v['color'],expected_color))
    assert all(abs(f(a)-b)<1e-6 for a,b in zip(next(fill for fill in sym['fills'] if fill['str:express_id']==v['express_id'])['str:fill_color'],expected_color))
   assert mesh['local_to_world'][0]=='some';mat=list(map(f,mesh['local_to_world'][1]));origin=list(map(f,mesh['origin']));p0=list(map(f,v['positions']));local=[]
   for i in range(0,len(p0),3):
    q=[p0[i+j]+origin[j]-mat[j*4+3] for j in range(3)];q=[sum(mat[k*4+j]*q[k] for k in range(3)) for j in range(3)];assert abs(q[2])<1e-6;assert all(-1e-6<=c<=4+1e-6 for c in q[:2]);local.append(q[:2])
   total=0.
   for i in range(0,len(v['indices']),3):
    triangle=[local[j] for j in v['indices'][i:i+3]];total+=area(triangle)
    if holes:
     intersection=triangle
     for axis,bound,sign in [(0,1,1),(0,2,-1),(1,1,1),(1,2,-1)]:intersection=clipped(intersection,axis,bound,sign)
     assert area(intersection)<1e-8
   assert abs(total-(15 if holes else 16))<1e-6;areas.append(total)
  if holes:assert {x['presented']['express_id'] for x in meshes}=={40,45}
  else:assert len(sym['texts'])>=1 and len(sym['polylines'])>=1
  checks[label]={'mesh_and_symbolic_fill_count':expected,'analytically_checked_mesh_areas_square_metres':areas,'hole_intersection_area_zero':holes,'records_sha256':sha(p),'records_bytes':p.stat().st_size}
 result=compare(case/'base',case/'candidate');repeat=compare(case/'base',case/'base-repeat');assert result['equal'] and repeat['equal']
 cases.append({'fixture':fixture.name,'fixture_sha256':sha(fixture),'mode':old['mode'],'equal':True,'baseline_repeat_equal':True,'positive_fill_invariants':checks})
assert len(cases)==12
receipt={'source_manifest':'../source-manifest-ratchet-corrected.json','source_manifest_sha256':sha(manifest),'source_count':len(m['source_sha256']),'source_hashes_verified_after_run':True,'scope':'Three synthetic annotation invariants in four actual native load modes with independent baseline repeat. No real-exporter, GPU, WASM, resource or cross-platform qualification.','fixture_provenance':json.loads((scratch/'fixture-pins.json').read_text()),'cases':cases,'case_count':len(cases),'qualified':12,'coordinate_oracle':'IFC millimetres convert to metres. Rigid local-to-world inverse restores planar local coordinates. Filled outer square4x4 minus square1x1 has area15; mixed solid square has area16. Every actual triangle clipped against hole has zero positive intersection area.','presentation_oracle':'IFC4 direct fill style and IFC2X3 presentation-style assignment yield Cyan fill/color. Fast-first intentionally retains initial gray meshes without material_name and delivers Cyan via actual color-update events; symbolic fills carry Cyan. Other modes retain Cyan mesh/material fields. Horizontal and vertical products retained; footprint-only type excluded. Mixed annotation keeps symbolic text and curves beside its mesh.','checker_correction':'Initial checker incorrectly required retained material_name in fast-first mode. Actual baseline and candidate retain initial gray mesh fields and emit the later Cyan color update. The corrected checker asserts both halves of that existing contract; no production code changed.', 'artifact_identity_receipt':'../native-scene-artifact-identity.json','limitations':['Synthetic statements are stated invariants derived from existing tests, not independent real authoring-tool models.','No hatching-pattern, general conic, material-layer, texture or instance witness is implied.','Structured semantic comparator excludes execution timing/cache records; this lane qualifies fill/presentation/frame behavior, not work-accounting or performance.']}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
archive=out/'support.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 t.add(raw,arcname='raw-scenes');t.add(scratch,arcname='drivers-and-fixtures');t.add(out/'receipt.json',arcname='receipt.json')
(out/'artifacts.json').write_text(json.dumps({'archive':archive.name,'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'receipt_sha256':sha(out/'receipt.json'),'includes':'Exact synthetic fixture bytes/generator, invariant checker, all36 raw outputs/manifests/logs and12 base/candidate/repeat comparison results. Large native executables and libraries remain local with existing pins.'},indent=2)+'\n')
print('12 structured fill cases and analytic area/hole/placement/style invariants pass; archive bytes',archive.stat().st_size)
