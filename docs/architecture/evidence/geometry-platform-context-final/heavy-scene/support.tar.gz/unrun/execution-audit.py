# SPDX-License-Identifier: MPL-2.0
# Supplemental audit of execution channels excluded by the shared comparator.
import json,hashlib,sys
from pathlib import Path
summary_path,output=map(Path,sys.argv[1:]);summary=json.loads(summary_path.read_text())
allowed={'parse_time_ms','entity_scan_time_ms','lookup_time_ms','preprocess_time_ms','geometry_time_ms','total_time_ms','faceted_brep_time_ms','point_cache_hits','point_cache_misses','from_cache'}
cases=[]
for case in summary['cases']:
 records={};pins={}
 for label in ['base','base-repeat','candidate']:
  p=Path(case['raw'][label]['records.jsonl']['path']);h=hashlib.sha256();found={}
  with p.open('rb') as f:
   for line in f:
    h.update(line)
    if b'"channel":"execution"' not in line:continue
    r=json.loads(line)
    if r['channel']=='execution':
     assert r['key'] not in found
     found[r['key']]=r['value']
  digest=h.hexdigest();assert digest==case['raw'][label]['records.jsonl']['sha256']
  assert set(found)=={'stats','csg_census_multiset'}
  records[label]=found;pins[label]={'path':str(p),'sha256':digest,'bytes':p.stat().st_size}
 differences={}
 for label in ['base-repeat','candidate']:
  assert records['base']['csg_census_multiset']==records[label]['csg_census_multiset'],(case['mode'],label,'census')
  a,b=records['base']['stats'],records[label]['stats'];assert a.keys()==b.keys()
  changed={key:{'base':a[key],label:b[key]} for key in a if a[key]!=b[key]}
  assert set(changed)<=allowed,(case['mode'],label,changed)
  differences[label]=changed
 census=records['base']['csg_census_multiset']
 cases.append({'fixture':case['fixture'],'mode':case['mode'],'csg_census_records':len(census),'csg_census_multiset_identical':True,'all_unmasked_stats_identical':True,'masked_stats_differences':differences,'raw_record_pins':pins})
assert len(cases)==4
r={'scope':'Supplemental exact execution-record audit of four actual Holter modes; raw records hash-verified against finalizer receipt.','source_manifest_sha256':summary['source_manifest_sha256'],'original_summary_sha256':hashlib.sha256(summary_path.read_bytes()).hexdigest(),'cases':cases,'case_count':len(cases),'csg_census_records_across_modes':sum(c['csg_census_records'] for c in cases),'csg_census_multisets_identical':True,'all_unmasked_stats_identical':True,'masked_stats_fields':sorted(allowed),'limitations':['Census is a sorted multiset, not execution chronology, emitter/source attribution or proof of all worker entries.','Timing and point-cache/from-cache fields are separately reported; no performance verdict.','Original shared comparison excludes execution records; this supplement checks census and every nonmasked statistics field.']}
output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'cases':len(cases),'census_records':r['csg_census_records_across_modes'],'all_census_and_unmasked_stats_match':True}))
