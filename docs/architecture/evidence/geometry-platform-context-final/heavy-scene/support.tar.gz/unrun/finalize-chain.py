# SPDX-License-Identifier: MPL-2.0
import json,subprocess,sys,hashlib
from pathlib import Path
prefix='/tmp/ifclite-context-final-scene-heavy-'
commands=json.loads(Path(prefix+'commands.json').read_text())
manifest=Path('docs/architecture/evidence/geometry-platform-context-final/source-manifest-ratchet-corrected.json')
def verify():
 d=json.loads(manifest.read_text());bad=[p for p,h in d['source_sha256'].items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not bad,bad
 assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='63bb222be30076a296d109eb6cc7d057ec3ab880f727313d62892df82d65ff93'
 return {'source_count':len(d['source_sha256']),'source_mismatches':bad,'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
before=verify()
for key in ['finalize','execution_audit']:
 with open(prefix+key+'.log','w') as f:r=subprocess.run(commands[key],stdout=f,stderr=subprocess.STDOUT)
 print(key,'exit',r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
after=verify();Path(prefix+'final-verification.json').write_text(json.dumps({'before':before,'after':after},indent=2)+'\n')
