// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! # IFC-Lite Geometry Processing
//!
//! Efficient geometry processing for IFC models using [earcutr](https://docs.rs/earcutr)
//! triangulation and [nalgebra](https://docs.rs/nalgebra) for transformations.
//!
//! ## Overview
//!
//! This crate transforms IFC geometry representations into GPU-ready triangle meshes:
//!
//! - **Profile Handling**: Extract and process 2D profiles (rectangle, circle, arbitrary)
//! - **Extrusion**: Generate 3D meshes from extruded profiles
//! - **Triangulation**: Polygon triangulation with hole support via earcutr
//! - **CSG Operations**: Full boolean operations (difference, union, intersection)
//! - **Mesh Processing**: Normal calculation and coordinate transformations
//!
//! ## Supported Geometry Types
//!
//! | Type | Status | Description |
//! |------|--------|-------------|
//! | `IfcExtrudedAreaSolid` | Full | Most common - extruded profiles |
//! | `IfcExtrudedAreaSolidTapered` | Full | Lofted extrusion between two profiles |
//! | `IfcFacetedBrep` | Full | Boundary representation meshes |
//! | `IfcTriangulatedFaceSet` | Full | Pre-triangulated (IFC4) |
//! | `IfcBooleanClippingResult` | Full | CSG operations (difference, union, intersection) |
//! | `IfcMappedItem` | Full | Instanced geometry |
//! | `IfcSweptDiskSolid` | Full | Pipe/tube geometry |
//!
//! ## Quick Start
//!
//! ```rust,ignore
//! use ifc_lite_geometry::{
//!     Profile2D, extrude_profile, triangulate_polygon,
//!     Point2, Point3, Vector3
//! };
//!
//! // Create a rectangular profile
//! let profile = Profile2D::rectangle(2.0, 1.0);
//!
//! // Extrude to 3D
//! let direction = Vector3::new(0.0, 0.0, 1.0);
//! let mesh = extrude_profile(&profile, direction, 3.0)?;
//!
//! println!("Generated {} triangles", mesh.triangle_count());
//! ```
//!
//! ## Geometry Router
//!
//! Use the [`GeometryRouter`] to automatically dispatch entities to appropriate processors:
//!
//! ```rust,ignore
//! use ifc_lite_geometry::{GeometryRouter, GeometryProcessor};
//!
//! let router = GeometryRouter::new();
//!
//! // Process entity
//! if let Some(mesh) = router.process(&decoder, &entity)? {
//!     renderer.add_mesh(mesh);
//! }
//! ```
//!
//! ## Performance
//!
//! - **Simple extrusions**: ~2000 entities/sec
//! - **Complex Breps**: ~200 entities/sec
//! - **Boolean operations**: ~20 entities/sec

// Module visibility: only 10 modules below are reached externally by sibling
// crates via a direct submodule path (`ifc_lite_geometry::<module>::...`) and
// must stay `pub`: csg, csg_capture, kernel, material_layer_index, math,
// mesh, placement, projection_outline, rect_fast, space_dcel. Everything else is internal
// wiring; external consumers reach its types through the root-level `pub use`
// re-exports below, so those modules are `pub(crate)` (see #C3.2).
pub(crate) mod alignment;
pub(crate) mod alignment_arc_length;
pub(crate) mod alignment_axis;
mod alignment_sampling;
mod alignment_sampling_curve;
mod alignment_sampling_placement;
pub mod analytic;
mod axis_projection;
mod curve_source;
mod trimmed_curve;
pub(crate) mod gradient;
pub(crate) mod curve_segment;
pub(crate) mod bool2d;
/// General 2D booleans over contour sets (union/difference/intersection),
/// keeping every disjoint output shape. Distinct from `bool2d`, which is the
/// fixed single-`Profile2D` void-subtraction path. Reached through the
/// root-level re-exports below, so it stays `pub(crate)` per #C3.2.
pub(crate) mod contour_bool2d;
mod contour_composition;
mod contour_grid_guard;
/// Deterministic Constrained Delaunay Triangulation + bounded Ruppert
/// min-angle refinement. Backs the quality triangulators in `triangulation`.
mod cdt;
mod terrain_cdt;
/// Candidate contact normals for the `clash_solid` trust gate — the directions
/// its thickness measurement is taken along. Internal to that gate, so it stays
/// private; split out only to keep `clash_solid` inside the size ratchet.
mod clash_contact_axes;
pub mod clash_solid;
pub mod csg;
pub mod document;
/// Measurement-only CSG corpus capture (off-by-default `csg_capture` feature).
#[cfg(feature = "csg_capture")]
pub mod csg_capture;
/// Deterministic near-coplanar facet weld for faceted-BREP host meshes.
/// Corrects f32 import jitter (~0.09°) so authored-coplanar roof slope facets
/// are EXACTLY coplanar before the exact-kernel opening cut (issue #1007).
pub(crate) mod facet_weld;
/// Intra-mesh vertex weld + index dedup applied at the per-element mesh source
/// (`build_mesh_data`), collapsing the faceted-brep per-face vertex duplication
/// while keeping creases (distinct normals) split.
pub mod mesh_weld;
/// Structured-diagnostics macro shims for the `observability` feature
/// (tracing when ON, the legacy eprintln fallback when OFF).
pub(crate) mod diag;
#[cfg(feature = "opening-perf-trace")]
#[doc(hidden)]
pub mod opening_perf_trace;
pub(crate) mod diagnostics;
pub(crate) mod error;
/// Total order for `f64` sort keys, NaN last (#7674). Reached through the
/// root-level re-export below.
pub(crate) mod float_order;
pub(crate) mod geom_hash;
/// Shared float-noise-tolerance quantisation constants used by more than one
/// geometry pass (single-sourced so independently-evolving passes can't drift
/// apart on the same tolerance).
pub(crate) mod grid;
pub(crate) mod extrusion;
pub(crate) mod instancing;
/// Pure-Rust exact mesh-arrangement CSG kernel — the only CSG kernel, on
/// every target (see docs/architecture/geometry-pipeline.md).
pub mod kernel;
pub mod material_layer_index;
/// Vector, matrix, frame and AABB math over arrays: the one cross-crate home
/// (`nalgebra` stays geometry's interior type). See the module docs for the
/// op-order and FMA contract.
pub mod math;
pub mod mesh;
// Closure / pairing / volume checks over triangle soups; `pub` only for the shared test oracles.
#[cfg(feature = "test-support")]
pub mod mesh_check;
#[cfg(not(feature = "test-support"))]
pub(crate) mod mesh_check;
/// Cooperative heartbeat from long geometry work to a host that must tell a
/// slow call from a hung one (see the module docs).
pub mod progress;
pub mod representation;
pub(crate) mod mesh_orient;
pub mod placement;
pub(crate) mod processors;
pub(crate) mod profile;
pub(crate) mod profile_extractor;
/// [`SkippedProfile`], split out of `profile_extractor` to keep it under
/// its module-size ratchet.
pub(crate) mod profile_skip;
pub(crate) mod profiles;
pub mod projection_outline;
pub mod rect_fast;
#[cfg(feature = "triangulation-alt")]
pub use triangulation::alt_oracle::set_alt_triangulator;
/// Scalar abstraction the extrusion mesher is generic over (`f64` in
/// production and a forward-mode dual number in scalar-adjoint tests).
pub(crate) mod scalar;
/// The extrusion mesher, generic over the scalar. `extrusion`'s public
/// functions are its `f64` instantiations.
pub(crate) mod extrusion_generic;
/// Profile triangulation / ring builders, generic over the scalar.
pub(crate) mod profile_generic;

/// Scalar-adjoint validation (test-only). Runs the production
/// extrusion mesher with a forward-mode dual scalar and grades its adjoints
/// against central finite differences.
#[cfg(test)]
#[path = "scalar_adjoint_tests.rs"]
mod scalar_adjoint;
mod telemetry_transaction;
pub use rect_fast::RectFastStats;
pub(crate) mod router;
/// Owned, explicitly partial construction batches before router publication.
pub mod construction;
/// Vector outlines traced from a slab of scan points (#6871). Reached through
/// the root-level re-exports below.
pub(crate) mod scan_outline;
/// Per-element mesh simplification for the demesher (cavity removal, grid
/// vertex-clustering decimation, bounding-box collapse).
pub mod simplify;
pub(crate) mod tessellation;
/// Test-harness helpers shared by the termination/deadlock suites (the
/// receive-and-diagnose watchdog). Never present in a shipping build; the
/// `test-support` feature exists so `ifc-lite-processing`'s integration tests
/// can reach it as well.
#[cfg(any(test, feature = "test-support"))]
pub mod test_support;
pub mod space_dcel;
pub(crate) mod transform;
pub(crate) mod triangulation;
mod union_find;
pub(crate) mod void_index;
/// World-frame test fixture corpus: far-from-origin placements whose offset
/// axis differs from the axis under test, plus the normal-projected f32
/// noise bound they demand (the #2598/#2600/#2529 defect class).
#[cfg(test)]
pub(crate) mod world_frame_fixture;
/// Cut one element into one closed solid per location zone (#2508 item 2), on
/// top of the exact kernel rather than beside it.
pub mod zone_split;

// Re-export nalgebra types for convenience
pub use nalgebra::{Matrix4, Point2, Point3, Vector2, Vector3};

pub use bool2d::{
    compute_signed_area, ensure_ccw, ensure_cw, is_valid_contour, point_in_contour, subtract_2d,
    subtract_multiple_2d, subtract_multiple_2d_counted,
};
pub use contour_composition::FixedGridComposition;
pub use contour_bool2d::{
    boolean_2d, boolean_2d_fixed_grid, ContourFillRule, resolve_2d, sanitize as sanitize_contours, BooleanOp2D, ContourSet, Ring2D,
};
pub use clash_solid::{intersection_solid, DegenerateReason, IntersectionSolid};
pub use union_find::UnionFind;
pub use csg::{calculate_normals, ClippingProcessor, GroupCut, GroupReject, Plane, Triangle};
pub use diagnostics::{BoolFailure, BoolFailureReason, BoolOp, PendingDiagnosticState};
pub use error::{Error, Result};
pub use float_order::cmp_f64_nan_last;
pub use geom_hash::{
    hash_mesh_world, GeometryClosure, GeometryHasher, DEFAULT_GEOM_HASH_TOLERANCE,
    MIN_GEOM_HASH_TOLERANCE,
};
pub use extrusion::{extrude_profile, extrude_profile_lofted, extrude_profile_with_voids};
pub use instancing::{
    bake_source_at_world, collate_and_encode, collate_instances, collate_refs,
    collate_refs_in_basis, collate_refs_verified_in, compose_instance_world_row_major, decode_instance_finishes, decode_instanced,
    encode_instanced, encode_refs, encode_refs_with_finishes, instance_rel_row_major_f32, verify_recomposition, Collated,
    DecodedInstance, DecodedInstanced, DecodedTemplate, InstanceMeshRef, InstanceOccurrence,
    InstanceTemplate, INSTANCED_MAGIC, INSTANCED_VERSION,
};
pub use material_layer_index::{
    LayerAxis, LayerBuildup, LayerInfo, MaterialLayerFlat, MaterialLayerIndex,
};
pub use mesh::{InstanceMeta, Mesh, SubMesh, SubMeshCollection};
pub use mesh_orient::{orient_mesh_outward, orient_mesh_outward_verdict, OrientVerdict};
pub use processors::{
    AdvancedBrepProcessor, BooleanClippingProcessor, ExtrudedAreaSolidProcessor,
    ExtrudedAreaSolidTaperedProcessor, FaceBasedSurfaceModelProcessor, FacetedBrepProcessor,
    binary_textures_refused, build_texture_index, embedded_raster_dimensions, MAX_TEXTURE_DIMENSION, ImageTextureRef, MeshTexture, PolygonalFaceSetProcessor,
    ResolvedTextureMap, RevolvedAreaSolidProcessor, TextureAttachment, TextureSource, SurfaceOfLinearExtrusionProcessor,
    SweptDiskSolidProcessor, TriangulatedFaceSetProcessor,
};
pub use alignment::{AlignmentCurve, AlignmentFrame};
pub use alignment_axis::locate_axis_curve;
pub use alignment_sampling::{
    sample_alignment_axes, AlignmentAxis, AlignmentSample, AlignmentSamplingDiagnostic,
    AlignmentSamplingDiagnosticCode, AlignmentSamplingOptions, AlignmentSamplingReport,
    SampledAlignmentAxis,
};
pub use analytic::{
    extract_analytic_extrusion, extract_analytic_profile, extract_swept_disk,
    AnalyticCurveSegment, AnalyticExtrusion, AnalyticProfile, AnalyticProfileLoop,
    AnalyticStatus, AnalyticSweptDisk, ProfileLoopKind,
};
pub use profile::{Profile2D, Profile2DWithVoids, ProfileType, VoidInfo};
pub use profile_extractor::{extract_profiles, extract_profiles_with_diagnostics, ExtractedProfile};
pub use profile_skip::SkippedProfile;
pub use profiles::ProfileProcessor;
pub use cdt::take_cdt_recovery_fallbacks;
pub use terrain_cdt::{
    triangulate_terrain_pslg, triangulate_terrain_pslg_with_progress, TerrainCdtError,
    TerrainCdtMesh,
};
pub use kernel::plane_weld::take_plane_weld_stats;
pub use router::take_bool2d_stats;
pub use router::{take_prism_defers, take_prism_stats};
pub use router::{ProcessorDispatchCapture, ProcessorEmitter, ProcessorEmitterOrigin};
pub use router::{
    aggregate_diagnostics, count_attributed_products, format_unsupported_breakdown,
    local_frame_set_enabled_override, meshed_representations, ClassificationStats, UNATTRIBUTED_PRODUCT_ID,
    GEOMETRY_DIAGNOSTICS_SCHEMA_VERSION, FACETED_BREP_DEDUP_FACE_LIMIT,
    ClassificationSummary, GeometryDiagnostics, GeometryProcessor, GeometryRouter,
    HostOpeningDiagnostic, ItemDedupCache, MappedInstancePlan, OpeningDiagnostic, OpeningKindDiag,
    ReasonCount, RectFastSummary, RectParam, SharedMappedItemCache, SharedBrepSignatureCache, WorstHost,
};

/// The large-coordinate threshold and its predicate, defined in
/// `ifc_lite_core::limits` so core's own bounds scan can use them too.
pub use ifc_lite_core::limits::{coord_is_large, LARGE_COORD_THRESHOLD_METERS};
pub use simplify::{simplify_mesh, SimplifyOptions, SimplifyStats};
pub use scan_outline::{
    trace_scan_outline, PlaneFrame, ScanOutline, ScanOutlineDiagnostics, ScanOutlineOptions, MAX_CELLS_LIMIT,
    MAX_GAP_LIMIT, MAX_SNAP_DISTANCE_CELLS, MAX_VERTEX_MOVE_CELLS, MIN_CELL_SIZE_LIMIT,
};
pub use tessellation::{scale_segments, TessellationQuality};
pub use transform::{
    parse_axis2_placement_3d, parse_axis2_placement_3d_from_id, parse_cartesian_point,
    parse_cartesian_point_from_id, parse_direction, parse_direction_from_id,
    rotation_angle_about_z,
};
pub use triangulation::triangulate_polygon;
pub use void_index::{
    build_aggregate_children_index, compute_parts_to_skip, propagate_voids_to_parts,
    propagate_voids_via_aggregates, VoidIndex,
};
