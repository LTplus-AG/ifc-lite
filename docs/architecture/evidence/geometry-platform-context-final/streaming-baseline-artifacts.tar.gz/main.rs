// SPDX-License-Identifier: MPL-2.0
//! Chunk snapshots must retain the established deferred-style event boundary.
use ifc_lite_processing::{process, process_geometry, Batching, Features, MeshData,
    ProcessingRequest, ProcessingSink};

#[derive(Debug, serde::Serialize, PartialEq)]
enum Event { Batch(Vec<(u32, [f32; 4], usize)>, usize), Colors(Vec<(u32, [f32; 4])>) }
#[derive(Default)]
struct Sink(Vec<Event>);
impl ProcessingSink for Sink {
    fn on_batch(&mut self, meshes: &[MeshData], processed: usize, _: usize) {
        self.0.push(Event::Batch(meshes.iter().map(|m|
            (m.express_id, m.color, m.indices.len() / 3)).collect(), processed));
    }
    fn on_color_update(&mut self, updates: &[(u32, [f32; 4])]) {
        self.0.push(Event::Colors(updates.to_vec()));
    }
}

fn main() {
    let source = include_str!("fixture.ifc")
        .replace("#23=IFCBUILDINGELEMENTPROXY", "#101=IFCSHAPEREPRESENTATION(#6,'Body','SweptSolid',());\n#102=IFCPRODUCTDEFINITIONSHAPE($,$,(#101));\n#100=IFCBUILDINGELEMENTPROXY('empty',$,'empty',$,$,#22,#102,$,$);\n#23=IFCBUILDINGELEMENTPROXY")
        .replace("ENDSEC;\nEND-ISO-10303-21;", "#200=IFCBUILDINGELEMENTPROXY('later',$,'later',$,$,#22,#19,$,$);\nENDSEC;\nEND-ISO-10303-21;");
    let request = ProcessingRequest::default().batching(Batching::new(1, 1).fast_first(true))
        .features(Features::default().presentation_layers(false));
    let mut sink = Sink::default();
    let result = process(source.as_bytes(), &request, &mut sink);
    assert_eq!(result.meshes.len(), 4);
    let [Event::Batch(first, processed), Event::Batch(second, second_processed), Event::Colors(updates), Event::Batch(later_first, total), Event::Batch(later_second, final_total)] = sink.0.as_slice()
        else { panic!("unexpected deferred-style trace: {:?}", sink.0) };
    assert_eq!((*processed,*second_processed,*total,*final_total),(2,2,3,3));
    assert_eq!(first.len(),1); assert_eq!(second.len(),1);
    assert!(first.iter().chain(second).all(|&(id,color,tris)|id==23&&color==[0.6,0.6,0.6,1.]&&tris==12));
    assert_eq!(updates,&vec![(23,[1.,0.,0.,1.])]);
    let eager=process_geometry(&source);
    let expected:Vec<_>=eager.meshes.iter().filter(|m|m.express_id==200)
        .map(|m|(m.express_id,m.color,m.indices.len()/3)).collect();
    let later:Vec<_>=later_first.iter().chain(later_second).copied().collect();
    assert_eq!(later,expected); assert_eq!(later_first.len(),1);assert_eq!(later_second.len(),1);
    assert_eq!(later[0],(200,[1.,0.,0.,1.],12)); assert_eq!(later[1],(200,[0.,1.,0.,0.25],12));
    assert_eq!(sink.0.len(),5);
    std::fs::write("derived.ifc",&source).unwrap();
    println!("{}",serde_json::to_string_pretty(&sink.0).unwrap());
}
