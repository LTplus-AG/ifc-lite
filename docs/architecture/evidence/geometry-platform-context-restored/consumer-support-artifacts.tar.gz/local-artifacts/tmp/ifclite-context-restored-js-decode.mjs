import ts from '/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361/node_modules/typescript/lib/typescript.js';
import {readFileSync,writeFileSync} from 'node:fs';
const baseline='/tmp/ifclite-smlib-base-8acd0715a/packages/wasm/pkg/ifc-lite.js';
const candidate='/home/louistrue/.t3/worktrees/ifc-lite/t3-f778e361/packages/wasm/pkg/ifc-lite.js';
const names=['processGeometryBatch','processGeometryBatchFromSource','processGeometryBatchInstanced','processGeometryBatchPartitioned','processGeometryBatchPartitionedFromSource'];
function methods(path){
 const source=ts.createSourceFile(path,readFileSync(path,'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 const cls=source.statements.find(s=>ts.isClassDeclaration(s)&&s.name?.text==='IfcAPI');
 if(!cls)throw new Error('IfcAPI class absent');
 const printer=ts.createPrinter({removeComments:true});
 return new Map(cls.members.filter(m=>ts.isMethodDeclaration(m)&&names.includes(m.name.getText(source))).map(m=>[m.name.getText(source),printer.printNode(ts.EmitHint.Unspecified,m,source).replace(/\s+/g,' ')]));
}
const [a,b]=[baseline,candidate].map(methods);
const result=names.map(name=>({name,equal:a.has(name)&&a.get(name)===b.get(name),baseline:a.get(name),candidate:b.get(name)}));
writeFileSync('/tmp/ifclite-context-restored-js-decode.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.map(({name,equal})=>({name,equal})),null,2));
if(result.some(r=>!r.equal))process.exitCode=1;
