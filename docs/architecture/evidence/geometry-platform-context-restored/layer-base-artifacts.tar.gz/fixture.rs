fn three_layer_wall(items: &str) -> String {
    format!(
        r#"ISO-10303-21;
HEADER;
FILE_DESCRIPTION(('issue-3199 layered wall'),'2;1');
FILE_NAME('wall.ifc','2026-08-25T00:00:00',(''),(''),'','','');
FILE_SCHEMA(('IFC4'));
ENDSEC;
DATA;
#1=IFCPROJECT('1234567890123456789012',$,'Test',$,$,$,$,(#10),#7);
#7=IFCUNITASSIGNMENT((#8));
#8=IFCSIUNIT(*,.LENGTHUNIT.,$,.METRE.);
#10=IFCGEOMETRICREPRESENTATIONCONTEXT($,'Model',3,1.E-5,#11,$);
#11=IFCAXIS2PLACEMENT3D(#12,$,$);
#12=IFCCARTESIANPOINT((0.,0.,0.));
#13=IFCGEOMETRICREPRESENTATIONSUBCONTEXT('Body','Model',*,*,*,*,#10,$,.MODEL_VIEW.,$);
#20=IFCLOCALPLACEMENT($,#21);
#21=IFCAXIS2PLACEMENT3D(#22,#23,#24);
#22=IFCCARTESIANPOINT((0.,0.,0.));
#23=IFCDIRECTION((0.,0.,1.));
#24=IFCDIRECTION((1.,0.,0.));
#30=IFCRECTANGLEPROFILEDEF(.AREA.,'WallA',#31,4.0,0.3);
#31=IFCAXIS2PLACEMENT2D(#32,#33);
#32=IFCCARTESIANPOINT((0.,0.));
#33=IFCDIRECTION((1.,0.));
#40=IFCEXTRUDEDAREASOLID(#30,#41,#42,3.0);
#41=IFCAXIS2PLACEMENT3D(#43,$,$);
#42=IFCDIRECTION((0.,0.,1.));
#43=IFCCARTESIANPOINT((0.,0.,0.));
#44=IFCRECTANGLEPROFILEDEF(.AREA.,'WallB',#45,2.0,0.3);
#45=IFCAXIS2PLACEMENT2D(#46,#47);
#46=IFCCARTESIANPOINT((5.,0.));
#47=IFCDIRECTION((1.,0.));
#48=IFCEXTRUDEDAREASOLID(#44,#41,#42,3.0);
#50=IFCSHAPEREPRESENTATION(#13,'Body','SweptSolid',({items}));
#51=IFCPRODUCTDEFINITIONSHAPE($,$,(#50));
#100=IFCWALL('0001234567890123456789',$,'TestWall',$,$,#20,#51,'Test',$);
#200=IFCMATERIAL('Finish',$,$);
#201=IFCMATERIAL('Core',$,$);
#210=IFCMATERIALLAYER(#200,0.05,$,'FinishOuter',$,$,$);
#211=IFCMATERIALLAYER(#201,0.2,$,'Core',$,$,$);
#212=IFCMATERIALLAYER(#200,0.05,$,'FinishInner',$,$,$);
#220=IFCMATERIALLAYERSET((#210,#211,#212),'3LayerBuildup',$);
#221=IFCMATERIALLAYERSETUSAGE(#220,.AXIS2.,.POSITIVE.,-0.15,$);
#300=IFCRELASSOCIATESMATERIAL('0001234567890123456790',$,$,$,(#100),#221);
ENDSEC;
END-ISO-10303-21;
"#
    )
}

/// The same wall with its MIDDLE layer turned into an AIR GAP: `#211`'s
/// `Material` reference is `$`, which the schema permits —
/// `IfcMaterialLayer.Material` is OPTIONAL and a ventilated cavity is the
/// canonical reason to leave it out.
///
/// `material_layer_index.rs` reads it as `layer.get_ref(0).unwrap_or(0)`, so
/// that layer reaches the slicer with `material_id == 0`. `0` is that
/// function's "no reference" sentinel, NOT an entity: STEP instance names start
/// at `#1`. Emitting it would make the slab claim to be a slice of
/// `IfcMaterial #0` and send a host following the id to nothing at all.
fn three_layer_wall_with_air_gap(items: &str) -> String {
    let s = three_layer_wall(items);
    let with_gap = s.replace(
        "#211=IFCMATERIALLAYER(#201,0.2,$,'Core',$,$,$);",
        "#211=IFCMATERIALLAYER($,0.2,$,'AirGap',$,$,$);",
    );
    assert_ne!(with_gap, s, "the air-gap substitution did not apply");
    with_gap
}

