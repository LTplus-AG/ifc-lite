// SPDX-License-Identifier: MPL-2.0
// Standalone synthetic invariant consumer; canonical production geometry only.
mod bits;
mod mesh;
include!("fixture.rs");
use ifc_lite_core::{EntityDecoder,IfcType};
use ifc_lite_geometry::{GeometryRouter,MaterialLayerIndex};
use ifc_lite_processing::element::{produce_element_meshes,ElementMeshJob,ElementJobKind,MeshProductionContext,MeshProductionOptions};
use std::sync::Arc;
fn main() {
    let mut cases=Vec::new();
    for (name,content,expected_materials,expected_items) in [
        ("three_layers",three_layer_wall("#40"),vec![Some(200),Some(201),Some(200)],vec![None,None,None]),
        ("air_gap",three_layer_wall_with_air_gap("#40"),vec![Some(200),None,Some(200)],vec![None,None,None]),
        ("unsliceable_two_items",three_layer_wall("#40,#48"),vec![None,None],vec![Some(40),Some(48)]),
    ] {
        let mut decoder=EntityDecoder::new(&content);
        let mut router=GeometryRouter::with_units(&content,&mut decoder);
        let index=MaterialLayerIndex::from_content(&content,&mut decoder);
        assert!(index.is_sliceable(100));
        router.set_material_layer_index(Arc::new(index));
        let wall=decoder.decode_by_id(100).unwrap();
        let void_index=Default::default();let geometry_style_index=Default::default();
        let indexed_colour_full=Default::default();let element_material_colors=Default::default();let texture_index=Default::default();
        let ctx=MeshProductionContext{void_index:&void_index,geometry_style_index:&geometry_style_index,
            indexed_colour_full:&indexed_colour_full,element_material_colors:&element_material_colors,
            texture_index:&texture_index,site_local_rotation:None};
        let job=ElementMeshJob{id:100,ifc_type:IfcType::IfcWall,entity:&wall,kind:ElementJobKind::Product,element_color:None,metadata:None};
        let out=produce_element_meshes(&job,&ctx,&MeshProductionOptions::default(),&mut decoder,&router);
        let materials:Vec<_>=out.meshes.iter().map(|m|m.material_id).collect();
        let items:Vec<_>=out.meshes.iter().map(|m|m.geometry_item_id).collect();
        assert_eq!(materials,expected_materials,"{name} material provenance");
        assert_eq!(items,expected_items,"{name} representation provenance");
        assert!(out.meshes.iter().all(|m|m.geometry_class==3&&!m.positions.is_empty()));
        assert!(out.meshes.iter().all(|m|m.material_id!=Some(0)));
        std::fs::write(format!("{name}.ifc"),&content).unwrap();
        let presented:Vec<_>=out.meshes.iter().map(|m|serde_json::to_value(bits::Exact(&mesh::CompleteMesh::from(m))).unwrap()).collect();
        cases.push(serde_json::json!({"name":name,"sliceable_index":true,"material_ids":materials,"geometry_item_ids":items,
            "positive_actual_material_slices":out.meshes.iter().filter(|m|m.material_id.is_some()&&m.geometry_item_id.is_none()).count(),
            "air_gap_without_material_sentinel":name=="air_gap"&&materials[1].is_none(),
            "class_three_unsliced_control":name=="unsliceable_two_items"&&items==vec![Some(40),Some(48)],"meshes":presented}));
    }
    println!("{}",serde_json::to_string_pretty(&cases).unwrap());
}
