#!/usr/bin/env python3
"""Pin rebuilt context candidate only after its coordinated profiling build."""
import argparse, hashlib, json, subprocess
from pathlib import Path

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--manifest',type=Path,required=True)
p.add_argument('--old-pins',type=Path,default=Path('/tmp/ifclite-scene-library-pins.json'))
p.add_argument('--candidate-deps',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
m=json.loads(a.manifest.read_text()); old=json.loads(a.old_pins.read_text())
mismatches=[name for name,expected in m['source_sha256'].items() if not (a.repo/name).is_file() or sha(a.repo/name)!=expected]
if mismatches: raise SystemExit('Frozen source changed: '+repr(mismatches))
if any((a.repo/name).exists() for name in m.get('deleted_source_paths',[])): raise SystemExit('A deleted frozen source exists')
compiler=subprocess.check_output(['rustc','-vV'],text=True)
if compiler!=old['rustc']: raise SystemExit('Compiler differs from old base')
libraries={'base':old['libraries']['base'],'candidate':{}}
for name,library in libraries['base'].items():
    if sha(library['path'])!=library['sha256']: raise SystemExit('Base library changed: '+name)
for name,library in old['libraries']['candidate'].items():
    path=a.candidate_deps/Path(library['path']).name
    if not path.is_file(): raise SystemExit('Expected matching-feature artifact absent: '+str(path))
    stat=path.stat()
    libraries['candidate'][name]={'path':str(path.resolve()),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'sha256':sha(path)}
if libraries['candidate']['ifc_lite_processing']['sha256']==old['libraries']['candidate']['ifc_lite_processing']['sha256']:
    raise SystemExit('Candidate processing library still equals historical226 artifact; rebuild first')
receipt={'frozen_manifest':str(a.manifest.resolve()),'frozen_manifest_sha256':sha(a.manifest),'source_count':len(m['source_sha256']),
 'source_mismatches':[],'rustc':compiler,'base_pin_receipt':str(a.old_pins.resolve()),'base_pin_receipt_sha256':sha(a.old_pins),
 'libraries':libraries,'scope':'combined mapping-control and owned model-context frozen candidate; not historical226'}
a.output.write_text(json.dumps(receipt,indent=2)+'\n')
print(str(a.output)+': '+str(receipt['source_count'])+' frozen sources verified; linked-artifact qualification still required')
