// SPDX-License-Identifier: MPL-2.0
//! Compatible synchronous Rust entry points and fallible JS bindings share
//! the same batch implementation. Source expiry is a JS exception, not empty geometry.
use crate::{api::IfcAPI, zero_copy::MeshCollection};
use super::partitioned_batch::PartitionedBatch;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
impl IfcAPI {
    #[wasm_bindgen(js_name = processGeometryBatchFromSource)]
    #[allow(clippy::too_many_arguments)]
    pub fn process_geometry_batch_from_source_binding(
        &self,
        jobs_flat: &[u32],
        unit_scale: f64,
        rtc_x: f64,
        rtc_y: f64,
        rtc_z: f64,
        needs_shift: bool,
        void_keys: &[u32],
        void_counts: &[u32],
        void_values: &[u32],
        style_ids: &[u32],
        style_colors: &[u8],
        plane_angle_to_radians: Option<f64>,
        material_element_ids: Option<Vec<u32>>,
        material_color_counts: Option<Vec<u32>>,
        material_colors_rgba: Option<Vec<u8>>,
    ) -> Result<MeshCollection, JsValue> {
        let source = self.source_bytes_arc();
        self.try_process_geometry_batch(&source, jobs_flat, unit_scale, rtc_x, rtc_y, rtc_z, needs_shift, void_keys, void_counts, void_values, style_ids, style_colors, plane_angle_to_radians, material_element_ids, material_color_counts, material_colors_rgba)
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }
    #[wasm_bindgen(js_name = processGeometryBatchPartitionedFromSource)]
    #[allow(clippy::too_many_arguments)]
    pub fn process_geometry_batch_partitioned_from_source_binding(
        &self,
        jobs_flat: &[u32],
        unit_scale: f64,
        rtc_x: f64,
        rtc_y: f64,
        rtc_z: f64,
        needs_shift: bool,
        void_keys: &[u32],
        void_counts: &[u32],
        void_values: &[u32],
        style_ids: &[u32],
        style_colors: &[u8],
        plane_angle_to_radians: Option<f64>,
        material_element_ids: Option<Vec<u32>>,
        material_color_counts: Option<Vec<u32>>,
        material_colors_rgba: Option<Vec<u8>>,
    ) -> Result<PartitionedBatch, JsValue> {
        let source = self.source_bytes_arc();
        self.try_process_geometry_batch_partitioned(&source, jobs_flat, unit_scale, rtc_x, rtc_y, rtc_z, needs_shift, void_keys, void_counts, void_values, style_ids, style_colors, plane_angle_to_radians, material_element_ids, material_color_counts, material_colors_rgba)
            .map_err(|error| JsValue::from_str(&error.to_string()))
    }
}
