# SPDX-License-Identifier: MPL-2.0
"""Package immutable source provenance; no compilation/tests or fleet requests."""
import hashlib,json,re,subprocess
from pathlib import Path
out=Path(__file__).parent
base='e26527d79c34ed98160c8104e2def7edf9e8dd32'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()
for name in ['source-manifest.json','incremental.patch','qualification.json','checkpoint.txt']:
 p=out/name
 if p.exists():
  preserve=out/(p.stem+'-checkpoint419'+p.suffix)
  if not preserve.exists():preserve.write_bytes(p.read_bytes())
sha=lambda b: hashlib.sha256(b).hexdigest() if b is not None else None
files=[]
for line in subprocess.check_output(['git','diff','--name-status',base,head],text=True).splitlines():
 status,path=line.split('\t')
 old=subprocess.run(['git','show',base+':'+path],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 new=Path(path).read_bytes() if Path(path).is_file() else None
 def blob(ref):
  result=subprocess.run(['git','rev-parse','--verify',ref+':'+path],capture_output=True,text=True)
  return result.stdout.strip() if result.returncode==0 else None
 files.append({'path':path,'status':status,'base_git_blob':blob(base),'checkpoint_git_blob':blob(head),'base_sha256':sha(old.stdout) if old.returncode==0 else None,'checkpoint_sha256':sha(new)})
(out/'source-manifest.json').write_text(json.dumps({'base':base,'checkpoint':head,'tree':tree,'worktree':str(Path.cwd()),'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(),'files':files,'deleted_files':[f['path'] for f in files if f['status']=='D']},indent=2)+'\n')
(out/'incremental.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--full-index',base,head]))
(out/'checkpoint.txt').write_text(subprocess.check_output(['git','log','--format=fuller',base+'..'+head],text=True)+'\nTree: '+tree+'\nWorktree: '+str(Path.cwd())+'\n')
qualification=json.loads((out/'qualification.json').read_text());qualification['source']=head
(out/'qualification.json').write_text(json.dumps(qualification,indent=2)+'\n')
# Preserve the earlier parser log; this is separately labelled final syntax only.
syntax=[]
for f in files:
 if not f['path'].endswith('.rs'):continue
 r=subprocess.run(['bash','/home/louistrue/build-workers/setup/projects-20261017/ifc-lite/env-exec.sh','rustfmt','--edition','2021','--config','skip_children=true','--emit','stdout',f['path']],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
 syntax.append({'path':f['path'],'exit':r.returncode,'stderr':r.stderr})
(out/'syntax-only-final.json').write_text(json.dumps({'source':head,'kind':'syntax parser only; not compilation, typechecking or tests','files':syntax},indent=2)+'\n')
r=subprocess.run(['git','diff','--check',base,head],capture_output=True,text=True)
(out/'diff-check-final.json').write_text(json.dumps({'source':head,'command':['git','diff','--check',base,head],'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n')
# Read-only source-body comparison, not a test of source text or runtime proof.
def body(text,name):
 m=re.search(r'\bfn\s+'+re.escape(name)+r'\b',text)
 if m is None:return None
 start=text.index('{',m.end());i=start;depth=0
 while i<len(text):
  if text.startswith('//',i):
   n=text.find('\n',i);i=len(text) if n<0 else n;continue
  if text.startswith('/*',i):
   n=text.find('*/',i+2);i=len(text) if n<0 else n+2;continue
  if text[i]=='"':
   i+=1
   while i<len(text):
    if text[i]=='\\':i+=2;continue
    if text[i]=='"':i+=1;break
    i+=1
   continue
  if text[i]=='{':depth+=1
  if text[i]=='}':
   depth-=1
   if depth==0:return text[start:i+1]
  i+=1
 return None
records=[]
old_audit=json.loads((out/'numerical-source-provenance.json').read_text())['functions']
for old in old_audit:
 path=old['path'];name=old['function'];candidate=Path(path).read_text()
 if path.endswith('/mod.rs'):candidate=candidate[candidate.index('impl Execution {'):]
 raw=body(candidate,name);normalized=raw
 for field,original in [('parametric','crate::rect_fast::param_enabled()'),('rectangular','crate::rect_fast::enabled()'),('prism','prism_cut::enabled()'),('coaxial_union','enabled()')]:
  if normalized is not None:normalized=normalized.replace('self.configuration.'+field,original)
 records.append({'path':path,'function':name,'base_normalized_sha256':old['base_sha256'],'candidate_raw_sha256':sha(raw.encode()) if raw is not None else None,'candidate_normalized_sha256':sha(normalized.encode()) if normalized is not None else None,'identical_after_owner_and_configuration_substitution':old['base_sha256']==(sha(normalized.encode()) if normalized is not None else None)})
path='rust/geometry/src/router/voids/prism_cut/planar_correction.rs'
old=body(subprocess.check_output(['git','show',base+':'+path],text=True),'correct_planar_overlap')
new=body(Path(path).read_text(),'correct_planar_overlap')
records.append({'path':path,'function':'correct_planar_overlap','base_normalized_sha256':sha(old.replace('super::enabled()','enabled').encode()),'candidate_raw_sha256':sha(new.encode()),'candidate_normalized_sha256':sha(new.encode()),'identical_after_owner_and_configuration_substitution':old.replace('super::enabled()','enabled')==new})
(out/'numerical-source-provenance-final.json').write_text(json.dumps({'base':base,'source':head,'qualification':'Source-body identity under declared owner/configuration substitutions only. No geometry, effect, performance or byte-output identity has been qualified.','normalization':'Base pure-helper Self owner changed to GeometryRouter as recorded in initial audit; candidate explicit captured configuration fields compared with original gate expressions. Correction takes the same captured enable input.','functions':records},indent=2)+'\n')
parent_refs=['fb913d3a5c','971a6f9acf','e81028c233']
parent_info=[]
for ref in parent_refs:
 paths=set(subprocess.check_output(['git','diff','--name-only',base,ref],text=True).splitlines())
 parent_info.append({'read_only_ref':ref,'direct_path_overlap':sorted(paths.intersection(f['path'] for f in files))})
(out/'parent-overlap.json').write_text(json.dumps({'source':head,'base':base,'read_only_inspections':parent_info,'mutable_parent':'not copied or edited','port_required':'terminal-port-audit.txt; the newest mutable-parent priority fixes remain authoritative'},indent=2)+'\n')
# Changed source files only. No caches, fixtures, build products, parent files or credentials.
subprocess.run(['git','archive','--format=tar','--output='+str(out/'changed-source.tar'),head,'--',*[f['path'] for f in files if f['status']!='D']],check=True)
status=subprocess.check_output(['git','status','--porcelain'],text=True)
(out/'worktree-status-final.json').write_text(json.dumps({'source':head,'status':status,'clean':not status},indent=2)+'\n')
# Index makes older, preserved evidence checkpoints explicit.
(out/'evidence-index.json').write_text(json.dumps({'final_source':head,'base':base,'primary':['incremental.patch','source-manifest.json','checkpoint.txt','handoff.txt','terminal-port-audit.txt','qualification.json','changed-source.tar','syntax-only-final.json','numerical-source-provenance-final.json','diff-check-final.json','metadata-commands.json','metadata-0.log','metadata-1.log','metadata-2.log','fixture-presence.json','parent-overlap.json','worktree-status-final.json'],'earlier_preserved_evidence':{'numerical-source-provenance.json':'Initial source body comparison before explicit config capture (9478876dc4). Not final-source evidence.','syntax-only.json':'Syntax-only metadata against 419519b525. Not final-source evidence.','*-checkpoint419.*':'Preserved earlier checkpoint package metadata/patch, superseded by primary final files.'}},indent=2)+'\n')
sums=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS':sums.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(out/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
print(json.dumps({'checkpoint':head,'tree':tree,'files':len(files),'syntax_errors':[x for x in syntax if x['exit']],'source_body_comparison_differences':[x for x in records if not x['identical_after_owner_and_configuration_substitution']],'diff_check_exit':r.returncode,'clean':not status,'artifact_directory':str(out)},indent=2))
