    /// Build the 2D-subtraction data for a host + its openings. Splits the
    /// openings into eligible (parallel through-cut → 2D) and residual
    /// (everything else → exact kernel). Returns `None` if the host is not a
    /// single clean extrusion or no opening is eligible (nothing to gain).
    pub(super) fn capture_bool2d(
        &self,
        element: &DecodedEntity,
        opening_ids: &[u32],
        decoder: &mut EntityDecoder,
    ) -> Option<Bool2dCut> {
        if opening_ids.is_empty() {
            return None;
        }
        let host = self.host_extruded_solid(element, decoder)?;
        let hm_inv = host.m.try_inverse()?;
        let host_rot = host.m.fixed_view::<3, 3>(0, 0).into_owned();
        let host_axis = (host_rot * Vector3::new(0.0, 0.0, host.dir_sign)).try_normalize(1e-9)?;
        // Host extrusion span in the solid's profile frame.
        let (hz_min, hz_max) = if host.dir_sign >= 0.0 {
            (0.0, host.depth)
        } else {
            (-host.depth, 0.0)
        };
        // Numerical-precision coincidence (1 ppm): near-through blind openings
        // defer to the exact kernel instead of becoming a full-depth hole.
        let z_tol = 1.0e-6 * host.depth.abs() + 1.0e-9;

        let mut footprints: Vec<Vec<Point2<f64>>> = Vec::new();
        let mut residual_ids: Vec<u32> = Vec::new();
        for &oid in opening_ids {
            let opening = match decoder.decode_by_id(oid) {
                Ok(e) if e.ifc_type == IfcType::IfcOpeningElement => e,
                // A non-opening (or undecodable) id: hand it to the exact kernel.
                _ => {
                    residual_ids.push(oid);
                    continue;
                }
            };
            // An opening is eligible only when EVERY constituent solid is a
            // parallel through-cut whose hole-free footprint lands STRICTLY
            // INTERIOR to the host profile. A footprint that touches / breaches
            // the boundary, or lands in an existing profile hole, is routed to
            // the residual so it never silently no-ops. Collect tentatively; any
            // ineligible solid sends the
            // whole opening (all its solids) to the residual so nothing is
            // double-cut.
            let mut opening_footprints: Vec<Vec<Point2<f64>>> = Vec::new();
            let eligible = self
                .opening_extruded_solids(&opening, decoder)
                .map(|solids| {
                    solids.iter().all(|op| {
                        match opening_solid_footprint(
                            op, &hm_inv, &host_axis, hz_min, hz_max, z_tol,
                        ) {
                            Some(fp) if footprint_interior(&fp, &host.profile) => {
                                opening_footprints.push(fp);
                                true
                            }
                            _ => false,
                        }
                    })
                })
                .unwrap_or(false);
            if eligible && !opening_footprints.is_empty() {
                footprints.append(&mut opening_footprints);
            } else {
                residual_ids.push(oid);
            }
        }
        if footprints.is_empty() {
            return None;
        }

        // Profile-local → world metres, RTC-relative: world = scale·(m·p) − rtc.
        // Scaling rows 0..3 (incl. their translation column) then subtracting the
        // RTC offset reproduces `center_native · s − rtc` from the rect probe.
        let s = self.unit_scale;
        let (rx, ry, rz) = self.rtc_offset;
        let mut wt = host.m;
        for i in 0..3 {
            for j in 0..4 {
                wt[(i, j)] *= s;
            }
        }
        wt[(0, 3)] -= rx;
        wt[(1, 3)] -= ry;
        wt[(2, 3)] -= rz;

        // Residual exact-kernel context for the ineligible openings (diagnostics
        // suppressed — the full opening set is already diagnosed by
        // `build_void_context`'s own `classify_openings`).
        let residual = if residual_ids.is_empty() {
            None
        } else {
            let openings = self.classify_openings_quiet(element, &residual_ids, decoder);
            if openings.is_empty() {
                None
            } else {
                let merged = Self::merge_rectangular_openings(&openings);
                Some(Box::new(VoidContext {
                    openings,
                    merged_openings: merged,
                    param: None,
                    bool2d: None,
                }))
            }
        };

        Some(Bool2dCut {
            host_profile: host.profile,
            depth: host.depth,
            dir_sign: host.dir_sign,
            wt,
            footprints,
            residual,
        })
    }

