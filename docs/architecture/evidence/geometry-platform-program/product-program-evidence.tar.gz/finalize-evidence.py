import pathlib,json,re,hashlib,subprocess,tarfile
out=pathlib.Path('/tmp/ifclite-product-program-d63e73e7')
root=pathlib.Path('/home/louistrue/.t3/worktrees/ifc-lite/t3-d63e73e7')
m=json.loads((out/'source-manifest.json').read_text())
for f,h in m['changed_file_sha256'].items():
 assert hashlib.sha256((root/f).read_bytes()).hexdigest()==h,f
for f in m['deleted_source_paths']: assert not (root/f).exists(),f
assert hashlib.sha256((out/'product-program.patch').read_bytes()).hexdigest()==m['patch_sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
r=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (out/'workspace.log').read_text())
v=json.loads((out/'validation.json').read_text())
q={
 'checkpoint_commit':'88dc838c4fa74a21968c3735e3f2e751b165c5dd',
 'checkpoint_tree':'94264976ade2fa40bf58d1fb1267fb728800b99a',
 'integration':'Apply product-program.patch against reconstructed baseline_tree from source-manifest.json. Checkpoint contains inherited overlay; do not use its entire diff as the incremental implementation.',
 'source_manifest':'source-manifest.json',
 'workspace':{'summaries':len(r),'passed':sum(int(x[1]) for x in r),'failed':sum(int(x[2]) for x in r),'ignored':sum(int(x[3]) for x in r),'exit_code':next(x['exit_code'] for x in v if x['name']=='workspace')},
 'legacy_validation':v,
 'validation_provenance':'Native pipeline, focused/Python checks, WASM builds/contracts and dependency builds began before fleet policy update on Pop. Original running graph preserved; not relabeled as fleet admission.',
 'other_completed_checks':{'focused_program_tests':21,'python_tests':6,'ratchets_passed':51,'ratchets_ignored_reseed_helpers':2,'wasm_package_tests':24,'wasm_contract_tests':223,'raw_wasm_abi':'Original five signatures and direct instanced retbuf decode passed; wasm-abi.json','refwalk':'1335 files; 29 candidate walks guarded; 12 existing fanout reviews; zero unguarded'},
 'root_typecheck':{'status':'UNKNOWN','request':'auto-9d46e5d830324e3eae373ead2f6dfbc7','job':'8d413b59-eca4-4199-90bb-01fdf2b40a98','host':'pc-wsl','command':'pnpm typecheck','fleet_wrapper_exit':1,'original_receipt':'/home/louistrue/build-workers/worker-state/jobs/8d413b59-eca4-4199-90bb-01fdf2b40a98/receipt.json','recovery':'execution host unavailable; outcome remains unknown; do not resubmit','error':'No space left on device','resubmitted':False},
 'performance':{'status':'UNQUALIFIED','benchmark_admission_job':'f597d448-ef7d-459f-affe-3e32ff19330c','reason':'Pop capacity guard refused before execution: 139.5 GiB free, 266 GiB required','samples':0,'remaining':'Paired native full-load identity and whole worker-pool ABBA5 byte identity/performance; no speed or neutrality claim'},
 'coverage_limits':['Boolean/CSG continuation remains synchronous in existing owner; optional ConstructionBatch does not replace canonical boolean control','Layer eligibility/slicing and opening classification/capture orchestration remain in existing owners; geometry calls enter common program','Full terminal resource admission/cancellation and effect receipts/finer request-reply identities remain open','Source bytes/index coherence bundle is a separate parallel integration; lifecycle labels do not authenticate coherence','No public async scheduler or active SMLib production cutover','Root pnpm test was not run for this checkpoint; parent results do not qualify this source'],
 'fixtures':'Available parent model files copied read-only into this checkout ignored tests/models. Tests retain normal absent-fixture skips; 47 ignored invocations include existing manual probes, known reproductions and unavailable local models. Harness captures successful test output, so silent skip-return tests cannot be counted as fixture coverage.',
 'history':'Initial contract run failed on absent renderer/dist; root Turbo dependency build and actual contract rerun passed. Earlier ratchet failure on obsolete allowance preserved with final successful run. Original logs retained.'
}
(out/'qualification.json').write_text(json.dumps(q,indent=2)+'\n')
clippy=next((x for x in v if x['name']=='clippy'),None)
clippy_text='passed' if clippy and clippy['exit_code']==0 else ('failed' if clippy else 'pending')
(out/'README.md').write_text(f'''# ProductProgram incremental implementation handoff

Apply `product-program.patch`, SHA-256 `{m['patch_sha256']}` ({m['patch_bytes']} bytes), to reconstructed baseline tree `{m['baseline_tree']}`. It recreates delivery tree `{m['delivery_tree']}`. `source-manifest.json` records all 63 changed-file hashes and five deleted old mapping paths. Baseline already includes the three parent qualification fixes. Patch application against the frozen parent was checked read-only. No parent source/build/evidence was changed.

Local source checkpoint: `88dc838c4fa74a21968c3735e3f2e751b165c5dd`. It includes the inherited 288-file overlay and separate inherited generated type comments; use the incremental patch for integration. `inherited-generated-types.patch` contains only those generated comment additions and is excluded from the ProductProgram patch.

The coherent layer covers representation/items in MergedProduct, StyledProduct, TypeMap, OpeningItemMeshes and OpeningItemBounds. It moves mapping frame execution into the common program, deletes the old walks, reuses selected processor owned constructor payloads (including optional ConstructionBatch roots), splits annotation admission from triangulation, and preserves the existing texture plan path. It retains mutable custom callbacks, cache/source timing, per-frame placement, diagnostics and synchronous outer ProductState work. See the implementation's `docs/architecture/geometry-platform-product-program-phase-one.md` for exact boundaries.

Completed: workspace test command exited 0 with {q['workspace']['passed']} passed and {q['workspace']['ignored']} ignored across {len(r)} summaries; four ratchet targets passed (51 passed, two ignored reseed helpers); focused program 21 passed; excluded Python crate six passed; canonical WASM build passed; root Turbo WASM package tests 24 passed; actual WASM contracts 223 passed; original five raw export signatures and actual instanced retbuf decoding passed; refwalk guard passed. All-target workspace Clippy: **{clippy_text}**. Exact commands, statuses and provenance are in qualification.json and the original logs. Available fixtures were used; inherited optional-fixture skip returns are not evidence that absent models were exercised.

Root `pnpm typecheck` on this clean checkpoint has **UNKNOWN** outcome after PC disk exhaustion. Original request `auto-9d46e5d830324e3eae373ead2f6dfbc7`, job `8d413b59-eca4-4199-90bb-01fdf2b40a98`: recovery says execution host unavailable / do not resubmit. No duplicate was submitted. No own root pnpm test result is claimed.

Performance remains **unqualified**: fleet benchmark admission refused before execution, zero samples. No paired whole-scene byte identity, worker-pool ABBA5, speed or neutrality claim is made. Original refusal receipt is preserved unchanged.

Remaining implementation: boolean continuations; layer eligibility/slicing and opening classification/capture orchestration; terminal resource admission/cancellation; effect receipts and external request/resume protocol. The parallel coherent source-bundle integration remains independent. Existing kernel, loader, borrowed Rust entrypoints and raw WASM ABI are preserved. No production SMLib cutover, PR, issue or publication was performed.

The source is clean and all 63 delivery hashes were reverified during packaging. The original pre-policy validation graph was preserved; fleet receipts were not relabeled. Targets, copied models and evidence remain outside tracked source. Parent must review and qualify this layer before integration.
''')
files=[p for p in out.iterdir() if p.is_file() and p.suffix in {'.json','.log','.patch','.txt','.py','.mjs','.md','.ts'} and p.name!='evidence-sha256.txt']
with tarfile.open(out/'product-program-evidence.tar.gz','w:gz') as tar:
 for p in sorted(files):tar.add(p,arcname=p.name)
(out/'evidence-sha256.txt').write_text(hashlib.sha256((out/'product-program-evidence.tar.gz').read_bytes()).hexdigest()+'  product-program-evidence.tar.gz\n')
print('packaged',len(files),'files; clippy',clippy_text)
