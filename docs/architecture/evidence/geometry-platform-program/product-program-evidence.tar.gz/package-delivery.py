import os,pathlib,subprocess,json,hashlib
out=pathlib.Path('/tmp/ifclite-product-program-d63e73e7')
base=(out/'baseline-tree').read_text().strip()
env=dict(os.environ,GIT_INDEX_FILE=str(out/'delivery.index'))
subprocess.run(['git','read-tree','HEAD'],env=env,check=True)
subprocess.run(['git','add','-A'],env=env,check=True)
# The canonical build reproduces the parent's three inherited doc additions.
# Keep this generated baseline-only drift separate from ProductProgram source.
dts='packages/wasm/pkg/ifc-lite.d.ts'
mode,kind,blob,path=subprocess.check_output(['git','ls-tree',base,'--',dts],text=True).split()
subprocess.run(['git','update-index','--cacheinfo',mode+','+blob+','+dts],env=env,check=True)
(out/'generated-ifc-lite.d.ts').write_bytes(pathlib.Path(dts).read_bytes())
(out/'inherited-generated-types.patch').write_bytes(subprocess.check_output(['git','diff',base,'--',dts]))
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip()
(out/'delivery-tree').write_text(tree+'\n')
patch=out/'product-program.patch'
patch.write_bytes(subprocess.check_output(['git','diff','--binary',base,tree]))
(out/'diff-stat.txt').write_text(subprocess.check_output(['git','diff','--stat',base,tree],text=True))
files=subprocess.check_output(['git','diff','--name-only','--no-renames',base,tree],text=True).splitlines()
changed={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in files if pathlib.Path(p).is_file()}
deleted=[p for p in files if not pathlib.Path(p).is_file()]
checkenv=dict(os.environ,GIT_INDEX_FILE=str(out/'patch-check.index'))
subprocess.run(['git','read-tree',base],env=checkenv,check=True)
subprocess.run(['git','apply','--cached','--whitespace=error-all',str(patch)],env=checkenv,check=True)
assert subprocess.check_output(['git','write-tree'],env=checkenv,text=True).strip()==tree
receipt=dict(base_commit='8acd0715a5ad266cd57808b9889f6549fbf93631',restored_manifest_sha256='ede5cfafab73e79657c4680398156b84cc4ce62f6fd4fb50a4ef4dba2e16207b',restored_source_hashes_verified=288,recovered_patch_sha256='8045edb3cad9a2f480d35bf4f83ad17418430bfade6da11394512339c79f9715',recovered_file_hashes_verified=42,parent_qualification_patch_sha256='3a2bebc182b577e374ce20146256749eb790ed16cd86616f6fd78201ad3f4367',baseline_tree=base,delivery_tree=tree,patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(),patch_bytes=patch.stat().st_size,patch_applies_to_baseline_and_recreates_tree=True,changed_file_sha256=changed,deleted_source_paths=deleted,inherited_generated_types='Separate generated-ifc-lite.d.ts / inherited-generated-types.patch; three parent baseline comment additions, no signature changes; excluded from ProductProgram patch')
(out/'source-manifest.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['baseline_tree','delivery_tree','patch_sha256','patch_bytes']}))
