import pathlib,subprocess,json,hashlib,time,statistics,os
out=pathlib.Path('/tmp/ifclite-product-program-d63e73e7');root=pathlib.Path.cwd()
fixtures=['tests/models/ara3d/AC20-FZK-Haus.ifc','tests/models/ara3d/ISSUE_129_N1540_17_EXE_MOD_448200_02_09_11SMC_IGC_V17.ifc']
rows=[]
for fixture in fixtures:
    for block in range(5):
        for position,side in enumerate(['base','branch','branch','base']):
            name=f'{pathlib.Path(fixture).stem}-{block}-{position}-{side}'
            cmd=[str(out/('perf-probe-'+side)),str(root/fixture),'--iters','1','--fingerprint','--json']
            proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            (out/(name+'.stdout.json')).write_text(proc.stdout)
            (out/(name+'.stderr.log')).write_text(proc.stderr)
            row=dict(fixture=fixture,block=block,position=position,side=side,exit_code=proc.returncode)
            if proc.returncode==0:row['result']=json.loads(proc.stdout)[0]
            rows.append(row);(out/'native-abba-raw.json').write_text(json.dumps(rows,indent=2)+'\n')
            if proc.returncode:raise SystemExit(proc.returncode)
summary=[]
for fixture in fixtures:
    data=[r for r in rows if r['fixture']==fixture]
    identities={(r['result']['meshes'],r['result']['vertices'],r['result']['triangles'],tuple(r['result']['meshFingerprintsFnv1a64'])) for r in data}
    phases={}
    for key in ['parseMs','geometryMs','totalMs']:
        a=[r['result'][key] for r in data if r['side']=='base'];b=[r['result'][key] for r in data if r['side']=='branch']
        am,bm=statistics.median(a),statistics.median(b)
        phases[key]=dict(base_median=am,branch_median=bm,delta=bm-am,percent=(100*(bm-am)/am if am else None),base_range=[min(a),max(a)],branch_range=[min(b),max(b)])
    summary.append(dict(fixture=fixture,fixture_sha256=hashlib.sha256((root/fixture).read_bytes()).hexdigest(),ordered_geometry_fingerprint_and_counts_identical=len(identities)==1,identities=list(identities),phases=phases))
(out/'native-abba-summary.json').write_text(json.dumps(dict(scope='native full rayon worker pool, five ABBA blocks; ordered geometry payload fingerprint excludes text metadata, material definitions, UVs, textures and instancing',results=summary),indent=2)+'\n')
