import os,pathlib,subprocess,json,time,hashlib
out=pathlib.Path('/tmp/ifclite-product-program-d63e73e7')
env=dict(os.environ,CI='1',CARGO_TARGET_DIR=str(out/'target-wasm'),IFC_WASM_BASE_JS='/tmp/ifclite-smlib-base-8acd0715a/packages/wasm/pkg/ifc-lite.js',IFC_WASM_BASE_BINARY='/tmp/ifclite-smlib-base-8acd0715a/packages/wasm/pkg/ifc-lite_bg.wasm')
paths=['packages/wasm/pkg/ifc-lite_bg.wasm','packages/wasm/pkg/ifc-lite.js','packages/wasm/pkg/ifc-lite.d.ts']
hashes=lambda:{p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths}
before=hashes();results=[]
for name,cmd in [('wasm-package',['pnpm','test','--filter=@ifc-lite/wasm','--force']),('wasm-abi',['node',str(out/'verify-wasm-abi.mjs')]),('wasm-contract',['pnpm','test:wasm-contract'])]:
    start=time.time()
    with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.time()-start))
    (out/'wasm-validation.json').write_text(json.dumps(dict(checks=results,before=before,after=hashes()),indent=2))
