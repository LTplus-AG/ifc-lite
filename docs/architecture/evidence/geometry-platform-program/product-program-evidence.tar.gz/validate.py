import os,pathlib,subprocess,json,time
out=pathlib.Path('/tmp/ifclite-product-program-d63e73e7')
env=dict(os.environ,CARGO_TARGET_DIR=str(out/'target'))
commands=[('ratchets-final',['cargo','test','-p','ifc-lite-processing','--test','positional_read_ratchet','--test','function_length_ratchet','--test','module_size_ratchet','--test','styling_parity','--no-fail-fast']),('workspace',['cargo','test','--workspace','--no-fail-fast']),('clippy',['cargo','clippy','--workspace','--all-targets','--','-D','warnings'])]
results=[]
for name,cmd in commands:
    start=time.time()
    with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    results.append(dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.time()-start))
    (out/'validation.json').write_text(json.dumps(results,indent=2))
    if name=='ratchets-final' and r.returncode:break
