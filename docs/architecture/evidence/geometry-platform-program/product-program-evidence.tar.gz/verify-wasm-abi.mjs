import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const names=['processGeometryBatch','processGeometryBatchFromSource','processGeometryBatchInstanced','processGeometryBatchPartitioned','processGeometryBatchPartitionedFromSource'];
function signatures(bytes) {
  let p=8; const u=()=>{let n=0,s=0,b;do{b=bytes[p++];n|=(b&127)<<s;s+=7}while(b&128);return n>>>0};
  const str=()=>{const n=u();const s=new TextDecoder().decode(bytes.subarray(p,p+n));p+=n;return s};
  const vec=fn=>Array.from({length:u()},fn);let types=[],functions=[],exports=[];
  while(p<bytes.length){const id=bytes[p++],end=u()+p;
    if(id===1)types=vec(()=>{assert.equal(bytes[p++],0x60);return {params:vec(()=>bytes[p++]),results:vec(()=>bytes[p++])}});
    else if(id===2)vec(()=>{str();str();assert.equal(bytes[p++],0,'expected function-only wasm-bindgen imports');functions.push(u())});
    else if(id===3)functions.push(...vec(u));
    else if(id===7)exports=vec(()=>({name:str(),kind:bytes[p++],index:u()}));
    p=end;
  }
  return Object.fromEntries(names.map(name=>{const e=exports.find(e=>e.name==='ifcapi_'+name);assert.ok(e,name);return [name,types[functions[e.index]]]}));
}
const root=process.cwd(); const base='/tmp/ifclite-smlib-base-8acd0715a/packages/wasm/pkg';const candidate=root+'/packages/wasm/pkg';
const a=signatures(readFileSync(base+'/ifc-lite_bg.wasm'));const b=signatures(readFileSync(candidate+'/ifc-lite_bg.wasm'));assert.deepEqual(b,a);
const observations=[];
for(const pkg of [base,candidate]){
 const m=await import(pathToFileURL(pkg+'/ifc-lite.js').href);const raw=m.initSync({module:readFileSync(pkg+'/ifc-lite_bg.wasm')});const api=new m.IfcAPI();
 try{
   const empty=new Uint8Array(),ints=new Uint32Array();
   const expected=api.processGeometryBatchInstanced(empty,ints,1,0,0,0,false,ints,ints,ints,ints,empty);
   const retptr=raw.__wbindgen_add_to_stack_pointer(-16);
   let wire;
   try{
     // Original 29-parameter ABI: retbuf, API, data/jobs, units/RTC,
     // five borrowed slice pairs, optional angle, three optional owned slices.
     raw.ifcapi_processGeometryBatchInstanced(retptr,api.__wbg_ptr,4,0,4,0,1,0,0,0,0,4,0,4,0,4,0,4,0,4,0,0,0,0,0,0,0,0,0);
     const view=new DataView(raw.memory.buffer);const ptr=view.getUint32(retptr,true),len=view.getUint32(retptr+4,true);
     wire=new Uint8Array(raw.memory.buffer,ptr,len).slice();
     assert.deepEqual(wire,expected,'raw retbuf decoding must reproduce high-level instanced wire');
     raw.__wbindgen_export4(ptr,len,1);
   }finally{raw.__wbindgen_add_to_stack_pointer(16)}
   observations.push({pkg,rawRetbufBytes:wire.length});
 }finally{api.free()}
}
writeFileSync('/tmp/ifclite-product-program-d63e73e7/wasm-abi.json',JSON.stringify({signatures:b,observations},null,2)+'\n');
console.log('All five original raw function signatures and actual instanced retbuf decoding match.');
