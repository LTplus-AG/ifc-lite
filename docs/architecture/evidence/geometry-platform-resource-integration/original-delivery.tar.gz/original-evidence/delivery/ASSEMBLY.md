<!-- SPDX-License-Identifier: MPL-2.0 -->
# Resource layer assembly notes

The incremental patch targets the exact supplied reconstructed overlay, not the
current moving parent. Do not cherry-pick the initial checkpoint: it includes
inherited overlay source. Apply/port only paths and hunks in files.json, including
new-files.json. Parent source/index/HEAD were not changed by this implementation.

Parent checkpoint e2e42bbfb8 moved the sole mapping implementation from
rust/geometry/src/router/mapping to rust/geometry/src/program/mapping. Port the
resource hunks in merged.rs, mod.rs, occurrence.rs, submeshes.rs and tests.rs into
that one current path; add resource_tests.rs beside those tests. Preserve the
current ProductProgram/source-free execution seams, its imports and its shared
canonical geometry algorithms. Do not restore router/mapping as a second path.
Reconcile lower module/function allowance rows against final physical files;
never raise budgets to accommodate the port.

Other overlaps: router item dispatch extraction/terminal normalization and local
hash-cache retention, core execution_owner source-borrow capability resource-only
attachment, canonical owned/borrowed producer entry wrapping, session_owner work
scopes, and session stop acceptance. The resource transport must attach to the
actual validated source capability and install before a worker-supplied fresh
account; it does not transfer kernel budgets/diagnostics/census TLS. Stops are
fixed typed records shared along the source owner chain, including Compatibility.

Do not replace decoder/index bundle ownership or model load factories with this
layer. Keep the source-owner implementation's lifecycle checks and merge its
source capability changes with the resource attachment. Preserve the original
SourceFault recovery and independent completed cache side effects.

This is a prerequisite with explicit opaque numerical/profile/decoder/raster and
consumer exclusions. Strict refuses unsupported coverage before production;
bounded outputs remain resource-unqualified. No complete cutover, performance
improvement, full-model memory bound, or browser bounded API is qualified here.
