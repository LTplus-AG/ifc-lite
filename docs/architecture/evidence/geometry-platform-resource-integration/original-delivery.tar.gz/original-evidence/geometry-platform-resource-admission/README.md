<!-- SPDX-License-Identifier: MPL-2.0 -->
# Resource admission implementation handoff

The latest implementation source is `5a4d1edd91` (resolve the full identifier in
[source identity](source-5a4d1edd91/source-identity.json)). Its
[incremental patch](source-5a4d1edd91/incremental.patch) targets the exact supplied
reconstructed source, excluding inherited overlay changes. All 45 resulting file
hashes match a separate patch-application copy; 19 paths are new. See
[all file hashes](source-5a4d1edd91/files.json),
[new file hashes](source-5a4d1edd91/new-files.json), and
[artifact checksums](source-5a4d1edd91/SHA256SUMS).

The source implements independent checked work/copy/output/occurrence/live
allowances, RAII/model permits, accumulating canonical mapping admission, owned
product terminal propagation and retained output/cache ownership. It preserves
source recovery, the permanent exact Rust kernel and ordinary signatures. It
includes the nested Compatibility refusal, real extrusion spare-capacity,
scoped-worker resource/terminal transport and foreign-active-account fixes. Typed
RTC/alignment stops bypass recoverable fallback; texture errors normalize before
Option conversion. The tests exercise real canonical producers, not mock return
values, but new test execution remains unqualified.

## Actual validation status

[Qualification record](validation-20261019/qualification.json) and immutable
receipt/log snapshots live in [validation-20261019](validation-20261019/).

The latest admitted attempt requested this exact processing preflight:

```text
cargo test -p ifc-lite-processing --test positional_read_ratchet --test function_length_ratchet --test module_size_ratchet --test styling_parity
```

Fleet request `auto-c7e0c3ae74b8472db30e8066f2b0ea36` returned exit69 before
compilation: Pop admission is disabled by guard78. A prior clean source7fb
preflight on PC returned exit101 during compilation with disk exhaustion. No
latest-source preflight test has passed. Earlier Pop focused/preflight jobs were
still queued at the initial evidence snapshot. They subsequently all returned
exit1 before compilation because the capacity guard refused admission; see the
[final original receipts](validation-20261019-admission-final/qualification.json).
No job was resubmitted. The previous source29b workspace and Clippy originals
recovered as orphaned with unknown outcomes and unsafe automatic resubmission.

The required next commands, **not run for the latest source**, remain:

```text
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
```

Run through the fleet launcher and prepared environment with an external owned
Cargo target. The native SMLib worker is local and must not be presumed on remote
hosts. Fixtures were fetched through normal `pnpm fixtures`; absent fixtures
remain explicit skips. Legacy preflight success and early compiler/test failures
are retained as history, not relabeled as current qualification. Constructor
Result handling, a missing test import, and bounded-test cache configuration were
corrected after those failures. The first new local launcher failed before code
compilation because env-exec.sh lacked execute permission; later invocations use
`bash env-exec.sh`.

No root pnpm, actual WASM, Python or performance run qualifies this layer. No
published binding/signature changed. The perf ledger records an unqualified
verdict without figures. New invariants still require actual execution and then
validation after integration with the moving parent.

## Assembly and remaining boundary

[Assembly instructions](source-5a4d1edd91/ASSEMBLY.md) identify exact overlaps.
Parent e2e42bbfb8 moved mapping into `program/mapping`; port the resource hunks
into that sole current path. Do not restore `router/mapping` as a second executor,
cherry-pick the initial inherited-overlay checkpoint, or replace source/index
bundle ownership. Parent source, index and HEAD were not changed.

[The implementation boundary](../../geometry-platform-resource-accounting.md)
inventories opaque numerical/profile/decoder/raster, assembly and later-consumer
allocations. Strict refuses unsupported coverage before production; bounded
outputs remain resource-unqualified. This handoff does not establish hard total
memory bounds, source-free numerical completion, browser lifetime coverage,
performance improvement or complete platform cutover.
