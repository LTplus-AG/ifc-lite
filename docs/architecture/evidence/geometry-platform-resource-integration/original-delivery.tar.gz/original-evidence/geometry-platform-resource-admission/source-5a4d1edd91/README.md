<!-- SPDX-License-Identifier: MPL-2.0 -->
# Resource source checkpoint 5a4d1edd91

Latest source includes source-owner precedence over foreign worker accounts,
sticky nested/worker terminals, real retained mesh capacity admission, and typed
RTC/alignment/texture fallback guards. Earlier source snapshots stay preserved.

incremental.patch applies to the exact reconstructed baseline; all 45 resulting
hashes match, including 19 new files. See SHA256SUMS and ASSEMBLY.md. Tests are
pending admitted execution; no source artifact qualifies runtime, performance,
hard memory bounds, browser admission or complete platform cutover.
