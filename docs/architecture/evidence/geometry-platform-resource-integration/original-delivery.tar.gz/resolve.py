from pathlib import Path
import re,subprocess
p=Path('rust/geometry/src/router/processing.rs'); s=p.read_text()
s=re.sub(r'<<<<<<<[^\n]*\n(.*?)=======\n(.*?)>>>>>>>[^\n]*\n',lambda m:m[1],s,flags=re.S)
s=s.replace('let mut mesh = match result {','let mut mesh = match crate::resource::observe(result) {')
start=s.index('    /// A textured `IfcTriangulatedFaceSet`'); end=s.index('    /// Run an `IfcAlignment`',start)
block=s[start:end]
# Move current parent implementations; resource changes are applied at their actual boundaries.
a=block.index('    /// Mesh one item,'); b=block.index('    /// `offset_meters`',a); rtc=block[a:b]
rtc=rtc.replace('        // Drop flags','        crate::resource::check_current()?;\n        // Drop flags',1)
rtc=rtc.replace('            None => {\n                self.record_processor_dispatch','            None => {\n                crate::resource::check_current()?;\n                self.record_processor_dispatch')
rtc=rtc.replace('let mut mesh = result?;','let mut mesh = crate::resource::observe(result)?;')
q=Path('rust/geometry/src/router/processing_items.rs'); t=q.read_text(); x=t.index('    /// Mesh one item,'); y=t.index('    /// `offset_meters`',x); t=t[:x]+rtc+t[y:]
# Current texture plan is the source of truth, with resource entry/return barriers.
tex=block[:a]; tex=tex.replace('    ) -> Option<(Mesh, Vec<f32>)> {','    ) -> Option<(Mesh, Vec<f32>)> {\n        crate::resource::check_current().ok()?;')
tex=tex.replace('let (mut mesh, uvs) = plan.evaluate(map);','let (mut mesh, uvs) = plan.evaluate(map);\n        crate::resource::check_current().ok()?;')
x=t.index('    /// A textured `IfcTriangulatedFaceSet`'); y=t.index('\n}\n',x); t=t[:x]+tex+t[y:]; q.write_text(t)
s=s[:start]+s[end:];s=s.replace('use crate::math::mat4;\n','').replace('use super::{GeometryProcessor, GeometryRouter};','use super::GeometryRouter;').replace('use crate::{Error, InstanceMeta, Mesh, Result, SubMeshCollection};','use crate::{InstanceMeta, Mesh, Result, SubMeshCollection};')
s=s.replace('    ) -> Result<Vec<Mesh>> {\n        // IfcAlignment','    ) -> Result<Vec<Mesh>> {\n        crate::resource::check_current()?;\n        // IfcAlignment')
s=s.replace('    ) -> Result<SubMeshCollection> {\n        // If a material','    ) -> Result<SubMeshCollection> {\n        crate::resource::check_current()?;\n        // If a material')
s=s.replace('        self.record_processor_dispatch(processor.as_ref());\n        let result','        crate::resource::check_current()?;\n        self.record_processor_dispatch(processor.as_ref());\n        let result');p.write_text(s)
# Cache publication remains a single current-parent helper and charges before cloning.
p=Path('rust/geometry/src/program/mapping/merged.rs');s=p.read_text();start=s.index('        match &router.shared_mapped_item_cache');end=s.index('\n    }\n    Ok((place',start);s=s[:start]+'        router.publish_mapped_source(state.id, &parts[0], state.truncated)?;'+s[end:];start=s.index('fn cache_clone(');end=s.index('fn place(',start);s=s[:start]+s[end:];s=s.replace('use std::sync::Arc;\n','').replace('use crate::{InstanceMeta, Mesh, Result,','use crate::{Error, InstanceMeta, Mesh, Result,');p.write_text(s)
p=Path('rust/geometry/src/router/mapped_item.rs');s=p.read_text();s=s.replace('mesh: &Mesh, truncated: bool) {','mesh: &Mesh, truncated: bool) -> Result<()> {\n        crate::resource::check_current()?;');s=s.replace('let source = std::sync::Arc::new(mesh.clone());','let source = self.clone_mapped_source(id, mesh)?;');s=s.replace('std::sync::Arc::new(mesh.clone())','self.clone_mapped_source(id, mesh)?');s=s.replace('    /// Process MappedItem with caching','    fn clone_mapped_source(&self, id: u32, mesh: &Mesh) -> Result<std::sync::Arc<Mesh>> {\n        if !crate::resource::is_active() { return Ok(std::sync::Arc::new(mesh.clone())) }\n        self.check_mapped_cache_coverage()?;\n        let (mesh, permit) = crate::resource::mesh::clone_mesh(mesh)?;\n        self.retain_mapped_cache_account(id)?;\n        permit.retain();\n        Ok(std::sync::Arc::new(mesh))\n    }\n\n    /// Process MappedItem with caching',1);s=s.replace('\n    }\n\n    fn clone_mapped_source','\n        Ok(())\n    }\n\n    fn clone_mapped_source',1);p.write_text(s)
p=Path('rust/geometry/src/program/mapping/tests.rs');s=p.read_text().replace('router.publish_mapped_source(30, &cached, false);','router.publish_mapped_source(30, &cached, false).unwrap();');p.write_text(s)
# Mapping now lives outside router, retaining only the necessary crate visibility.
p=Path('rust/geometry/src/router/mapped_cache_ownership.rs');p.write_text(p.read_text().replace('pub(super) fn check_mapped_cache_coverage','pub(crate) fn check_mapped_cache_coverage').replace('pub(super) fn retain_mapped_cache_account','pub(crate) fn retain_mapped_cache_account'))
