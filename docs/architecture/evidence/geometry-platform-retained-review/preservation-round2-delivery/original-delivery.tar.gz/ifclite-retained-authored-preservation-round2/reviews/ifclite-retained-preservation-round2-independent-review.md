# Retained preservation round 2: independent implementation review

Read-only inspection of `/home/louistrue/.t3/worktrees/ifc-lite/t3-32cbd056`. Requested starting point: `ca452929a3fde7b6c88eba5d45579fc533e880af`; first observed HEAD: `9ee408889f598a01039d3c9757a39980a3ef8bf1`; final committed snapshot inspected: `8fcf5fedc641e451bd227f7049d4e5053e706e23`, including `968b0e7c53` browser lifecycle witnesses and `f4db7299f0` additional SDK surface/section witnesses. The tool-permission correction was first inspected as a concurrent working change and subsequently included in this final committed snapshot. Conclusions attach to these bytes, not a future moving HEAD.

Read root/rust AGENTS, machine AGENTS/fleet policy, all three original review reports and their JSON hash records, original qualification JSON, and all four `/tmp/retained-*-interface.md` implementation responses. The original evaluator patch was applied on baseline `b99458ffd0`, against parent `0c0e5734569b19f48eedc21703cdbf75d241a313`; historical child `80f0a6a5...` and its original receipts are not current assembled qualification.

No checkout edits, commits, delegation, builds, syntax checks, tests, source-text tests, publication or heavy submissions were performed. Only the two requested review artifacts were written. Fleet status was read: Pop reachable/admission refused (78), PC reachable, Mac disabled. No foreign job, lock or evidence was altered.

## Finding: P2 — terminal native execution loses its ticket but keeps admission occupied

`rust/processing/src/authored_geometry/bound_native.rs:55-68` consumes `IssuedRetainedWork`, but each `?` failure returns without clearing the matching `self.pending` entry. That entry is cleared only on successful `accept` or explicit `cancel_pending`. Dropping an issued ticket before execution similarly leaves a strong `Arc` in the document forever, although there is then no ticket capable of completing the slot.

Concrete counterexample using the existing stated rectangle invariant and actual SDK boundary: admit a valid bound document; issue on a live worker; execute with `MeshLimits { max_bytes: 0 }`. The runtime's existing limit-cleanup test establishes the intended behavior: return ResourceLimit after releasing the unpublished solid while leaving the worker usable. In the model-bound wrapper, the issued ticket has now been consumed and no CompletedRetainedWork is returned, yet the next explicit `issue` returns `retained executor already pending`. The same failure occurs with a wrong-worker execution or invalid tessellation parameters. This is a recoverable admission/liveness defect, not a geometry result claim; manual `cancel_pending()` is currently a workaround.

Narrow fix: make terminal execution release only its matching slot, preserving a foreign/current slot on mismatched work. For example, use `&mut self` and scoped matching-slot cleanup on all owned-ticket errors, then leave the slot armed only when returning CompletedRetainedWork. For abandoned issued/completed/rejected tickets, use a weak slot reference or shared ticket state so `issue` can reclaim an entry whose external ticket owner disappeared. Preserve retryable acceptance rejection returning the exact work intact; do not automatically clear a slot merely because another document rejects foreign work. Explicit cancellation remains valid and no automatic replay is needed.

Meaningful regression: actual valid source + SDK, zero-byte mesh limit -> expected ResourceLimit -> immediate fresh explicit issue and successful receipt/publication without a manual cancel call. Separately drop issued work and require fresh issue; foreign work must not clear a different pending slot. These tests were NOT RUN here.

## Qualification command defect: worker path disagrees with the default build directory

The preserved local request `/home/louistrue/build-workers/worker-state/automatic-requests/auto-5049ad4327104721832dd92ea474724d.json` records source `d4446f7a30948e11bf599dd3556104d0b8d10260` and this sequence:

```sh
bash native/smlib-adapter/qualify.sh native && export IFCLITE_SMLIB_WORKER="/tmp/ifclite-public-sdk-c9c5979/build-$(git rev-parse HEAD)-native/ifclite_smlib_worker" && cargo test --workspace
```

`qualify.sh` defaults to `$cache/build-$mode`, hence `/tmp/ifclite-public-sdk-c9c5979/build-native`, not `build-<commit>-native`. Without an independently supplied `IFCLITE_ADAPTER_BUILD` override, a successful native build would be followed by Rust tests pointing at a nonexistent executable (or a stale artifact in the separately named directory). Fix a future command by setting and reusing one explicit build directory for both qualification and IFCLITE_SMLIB_WORKER, preferably commit-specific. Check actual executable/source identity before claiming a pass. Do not alter/retry the existing unknown request to fix this.

Parent reports dispatch Errno28, a zero-length original remote request, request-status JSON parse failure, PC disk100%/239MiB and Pop guard78. These are supplied observations; this reviewer only read the preserved local request. Its outcome remains UNKNOWN, not a passed run or permission to resubmit.

## Candidate resolved during review: extracted CTest execute permission

Committed `4fbbe29447` extracted wheel contents with ZipFile and chmodded only the executables named cmake/ninja. Python extraction does not restore Unix execute bits; qualify.sh subsequently invokes ctest. On the intended machine without system CMake tools, that could prevent CTest from executing even after compilation. The concurrently inspected correction chmods every regular file in each tool `data/bin` directory, covering ctest/cpack as well, and is now included in the final inspected commit. This candidate is RESOLVED IN INSPECTED COMMITTED SOURCE; execution remains unrun. The downloader also now pins the exact wheel filenames and SHA256 values. No reviewer source edit was made.

## Original runtime corrections: statically addressed

- `Envelope` arms an actual ProcessControl for Solid/Retained success. Failed send destroys it; successful-send/unread-receiver destruction also destroys it. Both terminate/reap the captured Child. The Pending/Claimed/Cancelled CAS makes cancel-before-claim refuse success, and claimed PendingCommand destruction cannot change the claimed state. Queue admission is released before waking consumers.
- Shared ProcessControl observes Child::try_wait, reaps an observed exit and invalidates the shared lifecycle. RuntimeOwner owns that capability, not a PID. Old-envelope cleanup cannot target a replacement Child. Both controller cache insertion and reuse inspect liveness independently of returned error class.
- `worker_mesh::tessellate` retires on either mesh-release failure, including a simultaneous primary read/limit failure; it preserves that primary error. The retained-solid cleanup remains separate. Retained result publication checks process liveness.
- RetainedRealization has private fields, immutable completion access, no Clone/public constructor, and an actual RuntimeOwner. The explicit `into_host_trusted_parts` escape consumes the seal; those mutable standalone parts cannot be supplied to the canonical acceptance API.

The new deterministic failed-send/unread/cancel/cache/mesh-cleanup/spontaneous-exit/receipt tests are substantive source coverage. Their SDK cases are environment gated; they are UNRUN in this review. A test peer's invented geometry is not SDK evidence. No additional definite runtime leak or new compile error was identified by static inspection. This is not a compiler verdict.

## Browser corrections: statically addressed

Commit submission now lies inside the upload cleanup domain. A known unsent commit attempts abort; uncertain commit delivery retires the captured incarnation without retrying; reported commit domain failure is treated as consumed. `retire(incarnation)` and cleared poison incarnation prevent old upload cleanup from killing/advertising a replacement. Malformed successful handles use the same scoped retirement.

The shared sweep contract now destroys its session in finally, covering failed assertions and intermediate solid/mesh ownership; the bare Node adapter supplies an incarnation and retirement methods. The actual-worker lifecycle witness added at `968b0e7c53` deliberately occupies maxPending1 before commit, verifies same-session subsequent upload, restarts after an in-flight chunk and exercises the replacement. I inspected its source and runner wiring; it has NOT been executed here. Protocol fault tests or CTest source presence alone do not qualify browser SDK geometry.

## Processing source authority and receipt barrier

`OwnedMeshProductionContext::admit_authored_plan` validates its actual SourceBundle/trusted decoder, acquires the decoder execution lease, reuses that decoder and caches immutable BoundAuthoredPlan once per snapshot. A caller-editable standalone AuthoredGeometryPlan has no binding constructor. Plan inspection yields only a shared reference. Source validity is checked again after planning.

The lifecycle token contains copied ProductionContextId plus Arc<ModelState>, not source bytes/index/maps/decoder. Bound source admission, request preparation, native issue/execute and acceptance validate it. Explicit invalidation expires it; model drop alone preserves the documented snapshot contract. Source/model retention is not smuggled into numerical completion packets.

Native tickets are private and pointer-identity checked; acceptance requires CompletedRetainedWork holding the exact private runtime receipt. It borrows that immutable completion, validates the actual owner and publishes through the existing display assembly. Wrong/unsupported acceptance returns the receipt intact. This addresses the original public-completion substitution gap for this explicit bound executor. The pending-slot finding above concerns terminal state cleanup, not the authenticity barrier.

## Metadata and region consumption: implemented but intentionally not broadly admitted

The existing CurveWalk now captures owned SourceRecord/SourceValue metadata while interpreting reached curves: original typed Trim1/Trim2 selectors, MasterRepresentation, SenseAgreement, composite Transition/SameSense/order, basis IDs, point/vector/placement coefficients and plane-angle scale. Parameterized rectangle/circle profiles also carry original dimensions/placement. Interpreted line/arc geometry remains separate. Fixed-rank iterative coefficient capture and bounded nested value conversion are present. This metadata reaches AnalyticProfileLoop and the cached authored plan; it is not an unused alternate IFC parser.

C++ recipe consumption now reads ordered outer/inner loop headers and line/circle/partial-arc records, converts derived radians to SDK degrees, reverses traversal and applies the circular frame. Source includes actual SDK bounds/section/surface/volume witnesses for both traversal directions, negative normal, holes and oblique extrusion. These witnesses are source, not executed qualification.

Current Rust validate_source still refuses circles, arbitrary curved/line regions and holes with typed gates. Native lower still emits one rectangle loop and its derived line coefficients. Therefore original trim metadata is retained/inspectable but is NOT yet consumed to admit a general IFC region into the SDK; this is the documented gate, not permission to remove it. Rectangle lowering does not need original trim selectors. No blanket source-only waiver or geometry claim follows.

Late inspected changes box canonical rejection ownership, narrow the walker entry visibility, and deduplicate scanned product IDs while still resolving through the authenticated decoder. The browser publishes a new incarnation only after Worker construction succeeds (`8fcf5fedc6`). Additional C++ witnesses inspect actual SDK cylinder kinds and sample section points against independent line/arc boundaries; they remain unrun. No new definite compile issue was identified in these changes.

The source agent's disclosed nonunit IfcLine DirectionRatios limitation is in the pre-existing shared curve reader; this round's raw metadata capture does not correct it. Arbitrary line admission remains refused, so it is not a newly admitted SDK regression. Do not use the revised unit-direction fixture as evidence that the general reader limitation is solved.

Final-net transformed booleans/openings, complete presentation/UV/material/persistent-face preservation, general families, full application binding, memory/performance limits and retained USD remain intentionally incomplete. No new scope is requested by this review and exact/default geometry is not waived.

## Validation verdict

Current assembled Rust/native compile, Clippy, actual SDK native/WASM/browser execution and consumer regressions: UNRUN/UNQUALIFIED here. Original five protocol checks and reported newer ten fixture-only checks have narrower historical scope; this review did not rerun or relabel them. No performance or geometric correctness verdict. Resolve terminal ticket cleanup, keep the tool-permission correction and align future qualification artifact paths before collecting new evidence when admission/source outcomes permit it.
