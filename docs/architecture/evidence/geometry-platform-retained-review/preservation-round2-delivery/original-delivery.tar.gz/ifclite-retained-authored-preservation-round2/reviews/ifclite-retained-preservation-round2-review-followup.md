# Retained preservation round 2: independent follow-up review

Read-only source review of `/home/louistrue/.t3/worktrees/ifc-lite/t3-32cbd056`. Requested correction checkpoint `29c7de40f9c1f1fff68b9953e4915906acee1330`; first observed HEAD `606347cd48b2aea0f0cd9ce97e74121b2e646447`; final inspected source `33c27f48275eaf19ccd3da4c269f8e9ebb3d815d`, including `aa1d41c8bc` immediate expiry retirement and concurrent admission-test commits `eff16ae60d`/`33c27f4827`. Exact inspected hashes and committed-byte comparisons accompany this report. Conclusions attach to those bytes.

Read root/rust AGENTS, machine AGENTS/fleet policy, the three original reviews and their JSON hash records, original delivery README/qualification, four implementation responses, and the previous independent review/hash record. The SDK/browser hash record is named `/tmp/ifclite-retained-sdk-browser-review.json`, not `-hashes.json`.

No checkout mutation, commit, delegation, build, syntax check, test, heavy submission, publication or job retry was performed. Only the two requested `/tmp` review artifacts were written. Fleet status: Pop reachable but admission refused (guard78), PC reachable, Mac disabled. PC disk100%/239MiB and the zero-byte remote request/outcome UNKNOWN are supplied observations, not newly measured storage or execution results. The original `auto-5049ad4327104721832dd92ea474724d` was not modified or retried; no foreign job, lock, receipt or source was altered.

## P2 — expiry rejection retires a foreign receipt before authenticating its ticket

`rust/processing/src/authored_geometry/bound_native.rs:77-85` checks this document's source lifecycle and calls `work.realization.owner().retire()` on expiry before checking the private pending-ticket identity. Thus the new `aa1d41c8bc` correction does immediately retire an owned expired realization, but the stated foreign-ownership preservation does not hold when the receiving document is expired.

Concrete counterexample: admit documents A and B from separate ProductionModels; issue and complete valid work B on a live SDK worker; invalidate only model A; call A.accept(work_B, ...). A returns the intact numerical packet, but first retires B's actual process. Returning that work to B now fails live-receipt acceptance, although B's source and pending ticket remain valid. The failure can also invalidate other handles in B's captured worker domain. A need not have any pending ticket for this to happen. Existing foreign-acceptance coverage exercises a live receiving document, and the new immediate-expiry assertion exercises its own work, so neither detects their intersection.

Authenticate the exact pending ticket before applying retirement based on this document's lifecycle, or explicitly guard that retirement with matching-ticket identity. A foreign receipt should return intact and live even if the receiver is expired; a matching expired receipt should still retire immediately and return its immutable numerical packet. Preserve both slots on foreign rejection.

Required behavioral regression, UNRUN: create independent model lifecycles A/B; complete B on an actual worker; expire A; reject B through A; assert B's owner remains live and B can accept the returned work successfully. Keep the existing matching-expired-owner-absent assertion. This is an ownership defect found by source inspection, not an executed SDK result.

## Previous stranded-slot finding: addressed in inspected source

`29c7de40f9` changes pending from a strong Arc to `Weak<()>`. Only IssuedRetainedWork or CompletedRetainedWork retains the strong ticket. `issue` refuses a live strong owner and replaces a dead weak slot; both execute and accept upgrade and compare exact Arc pointer identity. Distinct allocations remain distinct capabilities, including cancellation/reissue; no public ticket constructor or Clone is exposed.

An early execute error consumes/drops its issued ticket. This includes source expiry, foreign execution, wrong worker and runtime failures. With no other strong ticket, the original document's next explicit issue can reclaim its weak slot. A foreign execute cannot drop the other document's separately held strong ticket. Successful execution transfers the same ticket into completed work, keeping admission occupied through a retryable acceptance rejection; dropping that work releases admission and retires only its captured domain. Successful acceptance clears pending while PublishedBoundSource owns the completed receipt. No automatic replay is introduced.

The new actual-SDK test covers abandoned issued work, a real zero-byte MeshLimits ResourceLimit followed by fresh issue, foreign execution preserving another pending slot, and successful publication. Source presence is meaningful coverage, but this test is environment gated and was NOT RUN. Dropped-completed/rejected behavior follows the inspected ownership graph; this review supplies no execution evidence for it.

## Canonical receipt barrier and source lifetime

BoundAuthoredPlan remains privately constructed through `OwnedMeshProductionContext::admit_authored_plan`: validate the actual decoder/source pairing, acquire its execution lease, use the existing decoder and cache one immutable plan per snapshot, then validate again. A mutable standalone AuthoredGeometryPlan cannot construct bound authority. Cached admission still requires the actual decoder and lease.

ProductionLifecycle contains copied ProductionContextId plus Arc<ModelState> (load/epoch/revision counters), with no SourceBundle, byte allocation, decoder, appearance map or context back-reference. Bound numerical documents and work own derived source coefficients/metadata and small tokens rather than the original model/source allocation. Explicit invalidation is observed; dropping ProductionModel alone preserves the documented snapshot contract. No reference cycle or new source-retention path was identified in these inspected types. The concurrent tests also exercise canonical last-duplicate selection with an actually populated transferred point cache, and require cached admission to reject a later changed trusted-input revision; those tests remain UNRUN.

RetainedRealization still has private fields, no public constructor/Clone/mutable completion access, and the actual RuntimeOwner. CompletedRetainedWork privately couples it to the issued ticket. Canonical accept borrows its exact immutable completion for display publication, with document/revision/frame validation; a host-created RetainedCompletion cannot enter this API. The explicit `into_host_trusted_parts` escape consumes the seal. RuntimeOwner retirement captures the actual Child through ProcessControl and invalidates/reaps that domain; it does not resolve a numeric PID or target a replacement process.

No additional definite compile defect was identified in the inspected correction paths. This is static inspection, not a compiler or race-execution verdict. The new foreign-expiry ordering defect above remains open.

## Tool correction, command identity and qualification

Current `acquire-tools.py` checks exact wheel filenames and SHA256 pins and chmods every regular file in each extracted data/bin directory, covering ctest/cpack as well as cmake/ninja. The previously reported fresh-extraction ctest permission defect is addressed in this source. No acquisition, extraction or CTest execution was run here.

`qualify.sh` still defaults to `$cache/build-$mode`. The `606347cd48` documentation now explicitly exports IFCLITE_ADAPTER_BUILD, runs native qualification, then sets IFCLITE_SMLIB_WORKER from that same directory and checks executability before workspace tests/Clippy. That future command resolves the previously inconsistent path by construction; it does not retroactively repair or qualify the preserved unknown request. An actual future run must verify source/artifact identity and use fleet admission without nesting.

Native CMake/CTest, assembled Rust/workspace tests, Clippy, actual SDK native/WASM/browser execution, Python and exact/default consumer regressions remain UNRUN/UNQUALIFIED in this review. Historical protocol-only results are not reclassified as SDK geometry evidence. Source-only review is no waiver. Circle/hole/general-region admission remains explicitly refused in current validate_source; SDK bounds/volume/section/surface witnesses must execute before those gates change. Performance/memory, complete application/ProductProgram binding, final-net booleans/openings and appearance/UV/persistent-face/retained-USD qualification remain outside this narrow correction's completed claims.

Verdict: previous weak-ticket liveness fix and fresh tool-extraction correction are statically addressed; one new P2 ownership objection remains in immediate expiry retirement. All execution qualification remains outstanding.
