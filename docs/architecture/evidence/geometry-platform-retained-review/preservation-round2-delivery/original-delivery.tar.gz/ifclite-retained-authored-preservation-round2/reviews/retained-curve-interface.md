# Native numerical sweep interface (implementation in progress)
Owner: native/smlib-adapter only, shared checkout t3-32cbd056.
Protocol/ABI version 1 and opcodes 12..16 preserved. Recipe format 1 retained.
Existing header: u32 format=1,loops,total_segments,reserved=0; f64 unit direction XYZ,depth.
Ordered loop headers: u32 role (0=outer, 1=inner), segment_count, immediately followed by curves.
Exactly one outer first, then holes; 1..128 loops, 1..8192 total segments, <=1MiB.
Curve record remains u32 kind,reserved=0 + 12 f64 (104 bytes).
Line kind1: start XYZ,end XYZ,6 zeros.
Circle kind2: center XYZ,normal XYZ,x-axis XYZ,radius,start radians,signed sweep radians (full +/-2pi).
Arc kind3: same fields, partial signed sweep radians; XY basis normal +/-Z, unit XY x axis. Numerical SDK degree conversion occurs here only. Traversal uses normal cross x-axis and sweep sign.
Outer CCW and holes CW in XY. No source IFC trim-selector conventions are inferred in C++.
Exact declaration bytes=48+8*loops+104*total_segments.
New curves/multiple loops remain UNQUALIFIED until actual SDK witnesses; source admission must retain gates pending receipts. No general splines/ellipse support implied.

## Fleet/source receipts (preserve submitted jobs)
- auto-d82281aaf8394a9f91bc056198b5f207: source-preparation failure (unadvertised local commit40ca013047); `ifc-fleet job` says accepted, dispatch returned, safeToResubmitAutomatically=false. NOT retried.
- auto-4b8122e4321f4e45893dc5e8b849de7d -> PC job a7c05d69-ce9b-4f27-a5ad-aaee6895721d; `/home/louistrue/build-workers/worker-state/jobs/a7c05d69-ce9b-4f27-a5ad-aaee6895721d/receipt.json`: actual public pinned SDK acquired; exited127 before configure because cmake absent. Source19f6d0837414a69721ab272b958c96b12b336fe8.
- auto-f54b4db448d74a69bdf1aa6bb022c871 -> PC job5d2e0bac-55c4-4ced-a378-72588a040b29; `/home/louistrue/build-workers/worker-state/jobs/5d2e0bac-55c4-4ced-a378-72588a040b29/receipt.json`; queued as last observed; source4927e78f180263b3b931d75e6ca7a41b7c869bec. Added reproducible pinned CMake/Ninja bootstrapping. Preserve job; no retry.
- Both successful private source transfers used existing source_transfer.py/import-source; refs/ifc-fleet/<commit>, verified bundle SHA19f6=a40dbec92496ec7d225dd98c5328c0e79e04a5597c09cc2c20ea615c88f50ab7 and4927=ccca9189cb1722e70abc7cdd3b6d573e5fd3cc2af31fb2171c52a438d0365395.
- Before latest steering, an owned manual validation-only checkout was created at `/tmp/ifclite-adapter-validation-32cbd056` to dispatch while shared source was dirty. No further use; remove after submitted command returns. No user/foreign checkout modified.
- Native source includes actual SDK witnesses: rectangle, circle both traversals, arc+line both traversals, negative normal, rectangular/circular/multiple holes, oblique sweep; independent volume, tight SDK bounds, planar/curved surface counts and midplane section length. These are UNQUALIFIED until execution passes.
- Browser protocol/lifecycle tests10/10 pass locally (small fixture-only); NO SDK geometry conclusion.

## Exact non-secret private source transfer invocation
Run from shared checkout; only commit Git objects enter remote private refs (no push/publication):
```sh
python3 - <<'PY'
import sys, subprocess, json
sys.path.insert(0, '/home/louistrue/build-workers/worker-current')
from source_transfer import transfer_source
cwd = '/home/louistrue/.t3/worktrees/ifc-lite/t3-32cbd056'
commit = subprocess.check_output(['git', '-C', cwd, 'rev-parse', 'HEAD'], text=True).strip()
def remote(args, stream):
    return subprocess.run([
        'ssh', 'ifc-pc-worker',
        '/home/louistrue/build-workers/worker-python',
        '/home/louistrue/build-workers/worker-current/worker.py',
        '--state', '/home/louistrue/build-workers/worker-state', *args
    ], stdin=stream, capture_output=True, check=True).stdout
print(json.dumps(transfer_source(cwd, commit, remote)))
PY
```
This helper first calls remote `source-status --commit SHA`, then verified `import-source --commit SHA --sha256 BUNDLE_SHA256`, streaming its temporary incremental Git bundle on stdin. It preserves the controller's private ref and source-transfer receipt. Do not manually copy credentials/source envs or publish branches.

Adapter checkpoint ca452929a3 contains all current native edits and10/10 local fixture-only JS tests. Root source397a2318a7 and sibling resource/source edits preserved. Shared tree was clean immediately after checkpoint (subject to concurrent sibling edits). Native SDK job5d2e0bac-55c4-4ced-a378-72588a040b29 original queued receipt re-inspected; no resubmission. Validation checkout remains preserved until terminal receipt as requested.

SDK acquisition on PC is verified read-only: `/tmp/ifclite-public-sdk-c9c5979/usd-brep` HEAD c9c5979f04cea8c38213004d4f04df0dcfb40d05, empty git status, LICENSE Apache-2.0 sha25683ab8ebac4587a65c32ed2dbdba3c00a86c315a6562929ddff3ec17a175e6065; THIRD_PARTY_NOTICES sha2569fcacebdd1d3e2559959cc504331b0f58d3b3f460b9da5caea4efc84fd20eb7b; SmApiCurves.h sha2560dfd139e35adcc01324668b7377f70dadc5e093dbfff1ac12c43842db46a6b27; SmApiBrep.h sha256ca08db54ad2211c4c98eb229bb875573e799fe731b9226288737181705fb4296. Public fetch from https://github.com/NVIDIA-Omniverse/usd-brep.git exact pin, performed inside native qualification job a7c05d69-ce9b-4f27-a5ad-aaee6895721d before missing-cmake exit127. No proprietary/absence claim.

## Original job5d2 terminal result
Inspected original receipt and original command output: FAILED exit1 before configure/build. PC Python3.14 lacks ensurepip; `python3 -m venv` fails, even though SDK acquisition remains verified. Source unchanged true; outputSHA2569c1efff2feadd36abb5edc3653e7105cc897ecaa1a43fb13ab5ed15f26fe3f62. NO RETRY of this request. New `acquire-tools.py` uses Python stdlib to acquire exact public CMake3.31.6/Ninja1.11.1.4 Linux wheels, checks PyPI's SHA256 and writes acquisition.json without pip/venv. Root may run corrected final combined source as a distinct validation, not a retry of the failed source. No compiled SDK witness yet.

Additional committed actual browser runner lifecycle witnesses are in968b0e7c53: same-session begin after unsent commit overload and restart during in-flight chunk followed by successful real SDK sweep on replacement. Only syntax checked locally; browser execution still pending. Header/docs updated2646a49690. Root combined validation should use current shared HEAD.

## Final corrected-source attempt: no disk capacity
Source4fbbe29447ae3f974253bfcab9b88892c1585f7d private transfer verified (bundleSHA25673f36f2d79f51fb6e2d4c53883880f862cfb56b0c7cbbabd21a6099645fef749). New request auto-55e088ec0448425fb1239a5be7407913 failed during fleet-owned checkout preparation: `No space left on device`. Original job query remains accepted/dispatch returned/safeToResubmitAutomatically=false; no heavy adapter command, no retry. Do not clean any foreign checkouts or active jobs. Public acquisition JSON receipt: `/tmp/retained-native-sdk-source.json`.
Final bootstrap correction pins exact manylinux wheel filenames and SHA256s (CMake has two manylinux variants), and restores executable bits for ctest/cpack as well as cmake/ninja. Read-only PyPI metadata confirmed exact filenames/hashes; no local installation/build bypass. Shared tree checkpoint follows this note; root may inspect current HEAD.
Native CMake/CTest, Emscripten/Node actual module and actual browser execution all remain UNRUN on this new implementation due to preparation/tooling/capacity failures. Existing original tests/protocol decoder remain; extended numerical geometry is implemented but source gates MUST remain. No SDK absence/proprietary assertion, performance claim, durable analytic face provenance, full consumer or production activation claim.

Final adapter checkpoints:3c1451a190 pins exact tool digests/modes; f4db7299f0 adds actual SDK cylinder/extrusion class observations and independent midplane boundary point witnesses; latest browser construction publication checkpoint follows. All edits only native/smlib-adapter/**.10/10 fixture-only JS tests re-run PASS; shell/Python/Node syntax and git diff --check PASS. C++/SDK geometry and WASM/browser execution remain unrun due reported fleet failures, not passes. Parent can start combined validation from shared clean HEAD. No manual checkout cleanup performed because original accepted source-preparation request lacks terminal execution receipt; preserve `/tmp/ifclite-adapter-validation-32cbd056` as instructed.
