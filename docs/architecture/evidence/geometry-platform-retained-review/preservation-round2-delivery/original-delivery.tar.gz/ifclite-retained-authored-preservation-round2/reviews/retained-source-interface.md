# Source implementation coordination (implementation agent)
Assigned: rust/geometry/src/analytic/** and document/retained*.rs only.
At startup /tmp/retained-curve-interface.md was absent; SDK agent please write its
recipe/witness contract there. Circle, partial-arc and hole admission stays gated
until qualified actual SDK witnesses. No protocol layout changes planned without it.
Implementing owned source provenance alongside existing ordered analytic loops:
original trim selector forms, MasterRepresentation, SenseAgreement, basis IDs and
placement/coefficients, composite traversal/continuity, plane-angle unit scale.
Existing CurveWalk remains the sole curve interpreter. Source stays raw f64 IFC
units; derived segment radians are separate. Existing rectangle frame math stays.

Contract now read: recipe-v1 roles/counts and kind3 partial arcs agreed. Source
provenance implemented on AnalyticProfileLoop.source: Option<AnalyticBoundarySource>.
It owns root_entity_id, plane_angle_to_radians and EXPRESS-named SourceRecord graph
with SourceValue (including typed selectors and original Cartesian point refs).
Existing CurveWalk captures records during its existing traversal; raw basis and
placement dependencies captured at fixed EXPRESS dependency ranks. Parameterized
rectangle/circle dimensions and placements are also retained. Derived ordered
segments and signed_area remain separate. No SDK qualification receipt yet;
retained::validate_source continues rectangle-only and now reports UnqualifiedRegion
for supported arbitrary originals instead of claiming missing trim metadata.

Local checkpoint e6ae5561dc created (8 assigned files only). Reference-walk guard
passes: 0 unguarded, existing 12 fan-out notes. New source capture is iterative
and bounded; no second curve interpreter. Initial fleet cargo-test request
1de6e7a2-03e3-4241-a099-b834bc196cd9 was refused before execution by local disk
reserve (dirty shared source); not resubmitting that request. Preparing a clean
isolated checkout at this commit for eligible PC validation. Other source changes
in the shared checkout remain untouched and unstaged.

Steering received: no manually isolated checkouts. I had already created
/tmp/ifclite-retained-source-check at e6ae5561dc and submitted auto-9ef57bcc6bfa4a92a78eaf0572d0ee35
before receiving that steering. Both source and submitted work are preserved;
no cleanup/retry/new checkout. Root will own combined validation now.
Assigned checkpoints present in shared history:
- e6ae5561dc original curve metadata + bounded existing-walk capture + typed gates
- 9f80a658a2 independent cap-corner/frame invariants, nonidentity profile+solid
  rotations, oblique extrusion, survey origins, metre/millimetre, source immutability.
No new multi-loop numerical lowering/admission before SDK witnesses. Current
SDK contract still explicitly says UNQUALIFIED. Source loops already contain
ordered original metadata + separate derived f64 line/arc/circle geometry,
outer/inner role and signed winding; original metadata is not geometry evidence.
Root combined tests should include cargo test -p ifc-lite-geometry --lib analytic
and --lib document (or normal workspace tests), with source provenance tests.

Final added source tests commit d4446f7a30 covers line original trim conventions
and confirms actual original metadata alone never enables circle/arc/hole SDK
admission. Follow-up corrects invariant fixture to unit DirectionRatios.
Static inspection discovered an existing common-layer limitation, NOT changed:
curve_source::line_basis multiplies raw DirectionRatios by Magnitude without
normalizing the direction first (lines105..126). A nonunit line direction could
therefore give wrong interpreted endpoints. Original raw coefficients are retained
correctly by this work, but source line SDK admission remains refused anyway.
Root/common owner should decide a separate shared-reader correction with real IFC
semantics tests; do not claim arbitrary line curves qualified from this change.
Docs original delivery at docs/architecture/evidence/geometry-platform-retained-review/
authored-evaluator-round1.md is immutable historical evidence and still describes
that original snapshot accurately; no edits made. Current metadata is newer and
not yet compile/runtime-qualified. Perf remains UNQUALIFIED.
Assigned implementation final checkpoint 9ee408889f (follow-ups9f80a658a2,
d4446f7a30); shared checkout has no uncommitted edits from this source agent.
Original retained_sweep numerical path and rectangle frame math are unchanged;
only the new invariant tests were added to that module. No push/PR/issue, no
original evidence rewrites, no exact/common/resource edits, no foreign job action.
Combined compile/tests, actual SDK circle/holes/mixed-arc witnesses, WASM consumer
coverage and perf verdict remain root qualification gates. The already-submitted
isolated e6ae5561dc analytic test source/job is preserved, never retried/cleaned.

Submitted isolated analytic run is now TERMINAL, exit101: job
ad478fc1-55b8-48c7-ae12-c810e1b20c00, automatic request
auto-9ef57bcc6bfa4a92a78eaf0572d0ee35, source e6ae5561dc.
Rust compilation reached final geometry lib-test linking; rust-lld crashed with
signal7 Bus error / LLVM stack dump. No tests executed; this is NOT a test pass
or source-typecheck qualification. Fleet printed remote receipt path
/home/louistrue/build-workers/worker-state/jobs/ad478fc1-55b8-48c7-ae12-c810e1b20c00/receipt.json.
No retry or cleanup performed; original job source/evidence preserved. Later
assigned commits containing frame/additional trim tests were not in that run.
