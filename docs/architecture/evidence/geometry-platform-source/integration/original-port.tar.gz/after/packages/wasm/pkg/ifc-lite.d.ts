/* tslint:disable */
/* eslint-disable */

/** Every field is optional; absent or `undefined` means the default. Unknown fields and non-finite numbers are refused. Lengths in metres; pass plane coordinates local to the slab (f32 input). */
export interface ScanOutlineOptionsJs {
    /** Fixed cell edge; omit to pick it from the point density between minCellSize and maxCellSize. */
    cellSize?: number;
    /** Default 0.02, at least 0.001. */ minCellSize?: number;
    /** Default 0.05. */ maxCellSize?: number;
    /** Adaptive cells grow until the median occupied cell holds this many points. Default 6. */
    targetPointsPerCell?: number;
    /** Cell budget for the padded grid, from (2·pad + 1)² (81 with the defaults) up to 67108864. Default 16777216; hitting it sets diagnostics.cellCapHit. */
    maxCells?: number;
    /** Default 1. */ minPointsPerCell?: number;
    /** A cell is occupied from this fraction of the median occupied-cell count. Default 0.25. */
    noiseFraction?: number;
    /** Widest gap the closing bridges, about a wall thickness; clamped to 0.5. Default 0.3. */
    maxGap?: number;
    /** Speckle opening radius in cells (0 disables). Default 1. */ openRadiusCells?: number;
    /** Solid components below this area (m²) are dropped. Default 0.02. */ minComponentArea?: number;
    /** Enclosed holes below this area (m²) are filled. Default 0.5. */ minHoleArea?: number;
    /** Douglas-Peucker tolerance in cells. Default 1.5. */ simplifyToleranceCells?: number;
    /** Refit edges to the points. Default true. */ snap?: boolean;
    /** Evidence band beside an edge, in cells (at most 16). Default 3. */ snapDistanceCells?: number;
    /** Fewest points to refit an edge. Default 8. */ minSnapPoints?: number;
    /** Largest squaring move, in cells (at most 32). Default 4. */ maxVertexMoveCells?: number;
    /** Square edges to the dominant direction. Default true. */ square?: boolean;
    /** Default 3. */ squareAngleToleranceDeg?: number;
    /** Squares edges whose ends move at most this far. Default 0.03. */ squareOffsetTolerance?: number;
}
/** world = origin + u * uAxis + v * vAxis */
export interface ScanOutlinePlaneFrameJs {
    origin: [number, number, number];
    uAxis: [number, number, number];
    vAxis: [number, number, number];
}
export interface ScanOutlineDiagnosticsJs {
    inputPoints: number; usedPoints: number; nonFinitePoints: number; outlierPoints: number;
    cellSize: number; gridWidth: number; gridHeight: number;
    cellCapHit: boolean; maxGapClamped: boolean; countThreshold: number;
    /** f32 step at the largest input coordinate; `coordinatePrecisionDegraded` when above a tenth of a cell. Pass coordinates local to the slab. */
    coordinateSpacingMetres: number; coordinatePrecisionDegraded: boolean;
    occupiedCells: number; solidCells: number; componentsDropped: number; holesFilled: number;
    ringCount: number; outerRingCount: number; holeRingCount: number; vertexCount: number;
    simplifyReinsertions: number; snappedEdges: number;
    /** Degrees in [0, 90); absent when no edge was long enough to tell. */
    dominantAngleDeg?: number;
    squaredEdges: number; revertedMoves: number;
}



/** Exact browser mesh RTC frame, in IFC Z-up metres. */
export interface RtcFrame {
    x: number;
    y: number;
    z: number;
    needsShift: boolean;
}



export interface LandXmlTerrainOptionsJs {
    /** `YYYY-MM-DD`, the required `LandXML@date`; the caller owns the clock. */
    date: string;
    /** `HH:MM:SS`, the required `LandXML@time`. */
    time: string;
    /** Default `'metre'`. US survey feet write elevations in international feet (LandXML 1.2 has no US-survey-foot elevation unit); both are declared. */
    linearUnit?: 'metre' | 'internationalFoot' | 'usSurveyFoot';
    /** Decimal places in the written unit, 0 to 9. Default 6. */
    decimals?: number;
    /** `Surface@name` per product; a blank name keeps the IFC name. */
    surfaceNames?: { productId: number; name: string }[];
}



export interface LandXmlTinDocumentJs {
    format: "landxml";
    schema: "LandXML-1.0" | "LandXML-1.1" | "LandXML-1.2";
    capabilities: { renderable_tin: boolean; preserved_only_surfaces: number; unknown_extensions: number };
    version: string;
    /** serde_wasm_bindgen omits an absent Rust Option field rather than serializing null. `assumed` is true only when these units came from `LandXmlParseOptionsJs.assumedLinearUnit`, never from a declared LandXML/Units element (#5175). */
    units?: { linear_unit: string; elevation_unit: string; linear_scale_to_meters: number; elevation_scale_to_meters: number; assumed: boolean };
    surfaces: LandXmlSurfaceJs[];
    pipe_networks?: LandXmlPipeNetworkDocumentJs;
    extensions: LandXmlExtensionJs[];
    warnings: string[];
    alignments: LandXmlAlignmentSummaryJs[]; profiles: LandXmlProfileJs[];
    cross_sections: LandXmlCrossSectionJs[]; cross_section_surfaces: LandXmlCrossSectionSurfaceJs[];
    roadways: LandXmlRoadwayJs[]; capability_diagnostics: LandXmlCapabilityDiagnosticJs[];
    preserved_only_extensions: LandXmlPreservedOnlyExtensionJs[];
    /** COGO, parcel and plan-feature records from the same source bytes. */
    plan: LandXmlPlanDocumentJs;
}
export interface LandXmlPlanDocumentJs {
    schema: "LandXML-1.0" | "LandXML-1.1" | "LandXML-1.2"; version: string;
    capability_diagnostics: LandXmlCapabilityDiagnosticJs[];
    area_unit?: string; area_scale_to_square_meters?: number;
    cogo_points: LandXmlCgPointJs[]; monuments: LandXmlMonumentJs[];
    plan_features: LandXmlPlanFeatureJs[]; parcels: LandXmlParcelJs[]; warnings: string[];
    source_batches: LandXmlPlanSourceBatchJs[]; parcel_probes: LandXmlParcelProbeJs[];
    resolved_monuments: LandXmlResolvedMonumentJs[]; resolved_geometry: LandXmlResolvedGeometryJs[];
}
export interface LandXmlPlanSourceBatchJs { source_ids: string[]; }
export interface LandXmlParcelProbeJs { source_id: string; state: { kind: "analytic" } | { kind: "preserved_only"; reason: string }; perimeter_in_declared_linear_units?: number; area_in_declared_square_units?: number; declared_area?: number; declared_perimeter?: number; perimeter_in_meters?: number; area_in_square_meters?: number; }
export interface LandXmlResolvedMonumentJs { source_id: string; point?: LandXmlPlanPointJs; }
export interface LandXmlResolvedGeometryJs { source_id: string; start?: LandXmlPlanPointJs; end?: LandXmlPlanPointJs; center?: LandXmlPlanPointJs; pi?: LandXmlPlanPointJs; }
export interface LandXmlPlanPointJs { northing: number; easting: number; elevation?: number; }
export interface LandXmlCgPointJs { source_id: string; scope_id: string; ordinal: number; name?: string; code?: string; description?: string; point?: LandXmlPlanPointJs; pnt_ref?: string; properties: Record<string, string>; }
export interface LandXmlMonumentJs { source_id: string; point_scope_id?: string; ordinal: number; name?: string; code?: string; description?: string; pnt_ref?: string; point?: LandXmlPlanPointJs; properties: Record<string, string>; }
export interface LandXmlPlanFeatureJs { source_id: string; ordinal: number; name?: string; code?: string; description?: string; properties: Record<string, string>; locations: LandXmlPlanPointLocationJs[]; geometry: LandXmlPlanGeometryJs[]; }
export interface LandXmlParcelJs { source_id: string; ordinal: number; name?: string; code?: string; description?: string; title?: string; declared_area?: number; declared_perimeter?: number; declared_area_unit?: string; properties: Record<string, string>; loops: LandXmlPlanGeometryJs[][]; preservation_reason?: string; }
export interface LandXmlPlanGeometryJs { source_id: string; ordinal: number; kind: "line" | "curve" | "irregular_line"; point_scope_id?: string; start: LandXmlPlanPointLocationJs; end: LandXmlPlanPointLocationJs; center?: LandXmlPlanPointLocationJs; pi?: LandXmlPlanPointLocationJs; intermediate_points: LandXmlPlanPointJs[]; rotation?: string; radius?: number; declared_length?: number; properties: Record<string, string>; }
export type LandXmlPlanPointLocationJs = { kind: "coordinates"; point: LandXmlPlanPointJs; pnt_ref?: string } | { kind: "point_reference"; pnt_ref: string };
export interface LandXmlSurfaceJs {
    source_id: string; ordinal: number; source_path: string;
    properties: Record<string, string>; definition_properties: Record<string, string>;
    name: string; kind: "tin" | "grid" | "volume" | "other";
    render_state: "rendered" | "preserved_only" | "unsupported";
    topology_origin: "authored_faces" | "constrained_triangulation" | "preserved_only";
    terrain_diagnostic?: { code: "missing_outer_boundary" | "unsupported_boundary_semantics" | "unsupported_breakline_semantics" | "missing_elevation" | "conflicting_elevation" | "intersecting_constraints" | "degenerate_constraints" | "work_limit_exceeded" | "cancelled"; message: string };
    points: LandXmlPointJs[]; canonical_vertices: LandXmlCanonicalVertexJs[]; source_data_points: LandXmlSourcePointJs[];
    faces: [string, string, string][]; face_source_ids: string[]; face_visibility: boolean[];
    hidden_face_count: number; boundaries: LandXmlPolylineJs[]; breaklines: LandXmlPolylineJs[]; contours: LandXmlPolylineJs[];
}
export interface LandXmlPointJs { source_id: string; id: string; northing: number; easting: number; elevation: number; }
export interface LandXmlCanonicalVertexJs { id: string; northing: number; easting: number; elevation: number; contributor_source_ids: string[]; }
export interface LandXmlSourcePointJs { source_id: string; ordinal: number; source_path: string; coordinate_dimension: 2 | 3; coordinates: number[]; }
/** serde_wasm_bindgen omits absent Rust Option fields rather than serializing null. */
export interface LandXmlPolylineJs { source_id: string; ordinal: number; name?: string; kind?: string; source_path: string; properties: Record<string, string>; coordinate_dimension: 2 | 3; points: number[][]; point_source_ids: string[]; }
export interface LandXmlExtensionJs { namespace: string; local_name: string; path: string; }
export interface LandXmlSourceDocumentJs { tin: LandXmlTinDocumentJs; alignments: LandXmlAlignmentDocumentJs; alignment_render_spans: LandXmlAlignmentRenderSpanJs[]; alignment_render_refusals: LandXmlAlignmentRenderRefusalJs[]; alignment_render_truncated: boolean; }
export interface LandXmlAlignmentRenderSpanJs { source_id: string; points: LandXmlPlanPointJs[]; }
export interface LandXmlAlignmentRenderRefusalJs { source_id: string; message: string; }
export interface LandXmlAlignmentDocumentJs {
    schema: "LandXML-1.0" | "LandXML-1.1" | "LandXML-1.2"; version: string;
    capability_diagnostics: LandXmlCapabilityDiagnosticJs[];
    units?: LandXmlUnitsJs; alignments: LandXmlAlignmentJs[]; warnings: string[];
}
/** `assumed` is true only when these units came from `LandXmlParseOptionsJs.assumedLinearUnit`, never from a declared LandXML/Units element (#5175). */
export interface LandXmlUnitsJs { linear_unit: string; elevation_unit: string; linear_scale_to_meters: number; elevation_scale_to_meters: number; assumed: boolean; }
/** Terrain-parser alignment linkage; use LandXmlAlignmentDocumentJs for complete alignment semantics. */
export interface LandXmlAlignmentSummaryJs { source_id: string; ordinal: number; name: string; length: number; sta_start: number; profile_source_ids: string[]; cross_section_source_ids: string[]; }
export interface LandXmlAlignmentJs { source_id: string; ordinal: number; name: string; length: number; sta_start: number; start?: LandXmlPointLocationJs; align_pis: LandXmlAlignmentPiJs[]; segments: LandXmlAlignmentSegmentJs[]; station_equations: LandXmlStationEquationJs[]; cant?: LandXmlCantJs; superelevations: LandXmlSuperelevationJs[]; unsupported_transitions: LandXmlUnsupportedTransitionJs[]; }
export type LandXmlPointLocationJs = { kind: "coordinates"; point: LandXmlPlanPointJs } | { kind: "point_reference"; pnt_ref: string };
export interface LandXmlAlignmentPiJs { source_id: string; location: LandXmlPointLocationJs; }
export type LandXmlAlignmentSegmentJs = { source_id: string; ordinal: number; primitive: LandXmlAlignmentPrimitiveJs };
export interface LandXmlSpiralJs { start: LandXmlPointLocationJs; pi: LandXmlPointLocationJs; end: LandXmlPointLocationJs; spi_type: string; radius_start: LandXmlRadiusJs; radius_end: LandXmlRadiusJs; rotation: "clockwise" | "counter_clockwise"; declared_length: number; }
export type LandXmlAlignmentPrimitiveJs = { kind: "line"; start: LandXmlPointLocationJs; end: LandXmlPointLocationJs; declared_length?: number } | { kind: "irregular_line"; start: LandXmlPointLocationJs; end: LandXmlPointLocationJs; points: LandXmlPlanPointJs[]; declared_length?: number } | { kind: "curve"; start: LandXmlPointLocationJs; center: LandXmlPointLocationJs; end: LandXmlPointLocationJs; pi?: LandXmlPointLocationJs; rotation: "clockwise" | "counter_clockwise"; radius?: number; declared_length?: number } | ({ kind: "spiral" } & LandXmlSpiralJs) | ({ kind: "unsupported_spiral" } & LandXmlSpiralJs);
export type LandXmlRadiusJs = { finite: number } | "infinite";
export interface LandXmlStationEquationJs { source_id: string; sta_internal: number; sta_ahead: number; sta_back?: number; sta_increment?: string; }
export interface LandXmlCantJs { source_id: string; name: string; gauge: number; rotation_point?: string; equilibrium_constant?: number; applied_cant_constant?: number; stations: LandXmlCantStationJs[]; speed_stations: LandXmlSpeedStationJs[]; }
export interface LandXmlCantStationJs { source_id: string; station: number; applied_cant: number; equilibrium_cant?: number; curvature: "clockwise" | "counter_clockwise"; cant_deficiency?: number; cant_excess?: number; rate_of_change_of_applied_cant_over_time?: number; rate_of_change_of_applied_cant_over_length?: number; rate_of_change_of_cant_deficiency_over_time?: number; cant_gradient?: number; speed?: number; transition_type?: string; adverse?: boolean; }
export interface LandXmlSpeedStationJs { source_id: string; station: number; speed: number; }
export interface LandXmlSuperelevationJs { source_id: string; sta_start?: number; sta_end?: number; events: LandXmlSuperelevationEventJs[]; }
export interface LandXmlSuperelevationEventJs { source_id: string; kind: string; value?: string; }
/** `spiral` is the Rust LandXmlSpiral payload, not a tagged primitive enum. */
export interface LandXmlUnsupportedTransitionJs { source_id: string; spi_type: string; spiral: LandXmlSpiralJs; reason: string; }
export interface LandXmlAlignmentProbeJs { alignment_source_id: string; segment_source_id: string; geometric_distance: number; station: { geometric_distance: number; displayed_back: number; displayed_ahead: number; is_equation_boundary: boolean }; northing: number; easting: number; tangent_northing: number; tangent_easting: number; }
export type LandXmlAlignmentProbesJs = LandXmlAlignmentProbeJs[];
/** Neighbouring authored CantStation records; values are never interpolated. */
export interface LandXmlAlignmentInspectionJs { cant?: { internal_station: number; station: { geometric_distance: number; displayed_back: number; displayed_ahead: number; is_equation_boundary: boolean }; previous?: LandXmlCantStationJs; next?: LandXmlCantStationJs }; superelevations: LandXmlSuperelevationJs[]; superelevation_block_count: number; superelevation_event_count: number; superelevation_truncated: boolean; }
/** `assumedLinearUnit`: see #5175. Accepts the same tokens a declared `<Units linearUnit="...">` accepts (e.g. `"meter"`, `"foot"`, `"USSurveyFoot"`); an unknown token refuses rather than defaulting to meters. Ignored, with a warning, when the source declares its own `<Units>`. */
export interface LandXmlParseOptionsJs { maxBytes?: number; maxDepth?: number; maxTextBytes?: number; maxPoints?: number; maxFaces?: number; maxWork?: number; maxAlignments?: number; maxAlignmentSegments?: number; maxAlignmentPoints?: number; maxStationEquations?: number; maxCantStations?: number; maxSuperelevationEvents?: number; assumedLinearUnit?: string; cancelled?: boolean; }
export interface LandXmlProfilePointJs { source_id: string; station: number; elevation?: number; }
export interface LandXmlGradeLineJs { source_id: string; parent_profile_source_id: string; ordinal: number; points: LandXmlProfilePointJs[]; }
export interface LandXmlVerticalCurveJs { source_id: string; parent_profile_source_id: string; kind: "parabolic" | "unsymmetrical_parabolic" | "circular"; station: number; elevation?: number; length?: number; length_in?: number; length_out?: number; radius?: number; }
export interface LandXmlProfileJs { source_id: string; parent_alignment_source_id: string; ordinal: number; name: string; kind: "design" | "sampled"; pvis: LandXmlProfilePointJs[]; vertical_curves: LandXmlVerticalCurveJs[]; grade_lines: LandXmlGradeLineJs[]; }
export interface LandXmlCrossSectionJs { source_id: string; parent_alignment_source_id: string; ordinal: number; station: number; surface_source_ids: string[]; }
export interface LandXmlCrossSectionPointJs { source_id: string; data_format: "offset_elevation" | "slope_distance"; offset?: number; elevation?: number; slope?: number; distance?: number; pnt_ref?: string; alignment_ref?: string; align_ref_station?: number; alignment_source_id?: string; plan_feature_ref?: string; plan_feature_ref_station?: number; parcel_ref?: string; parcel_ref_station?: number; }
export interface LandXmlCrossSectionSegmentJs { source_id: string; parent_surface_source_id: string; ordinal: number; points: LandXmlCrossSectionPointJs[]; }
export interface LandXmlCrossSectionSurfaceJs { source_id: string; parent_cross_section_source_id: string; kind: "sampled" | "design"; name?: string; segments: LandXmlCrossSectionSegmentJs[]; points: LandXmlCrossSectionPointJs[]; }
export interface LandXmlRoadwayJs { source_id: string; ordinal: number; name: string; alignment_refs: string[]; alignment_source_ids: string[]; surface_refs: string[]; surface_source_ids: string[]; grade_model_refs: string[]; }
export interface LandXmlCapabilityDiagnosticJs { code: string; source_id?: string; source_path: string; message: string; }
export interface LandXmlPreservedOnlyExtensionJs { source_id: string; parent_source_id?: string; local_name: string; source_path: string; kind: "corridor" | "string_line"; }
/** `assumed` is true only when these units came from `LandXmlParseOptionsJs.assumedLinearUnit` because the source declares no root LandXML/Units element, never from a declared one (#5175, #7693). */
export interface LandXmlPipeUnitsJs { linear_unit: string; elevation_unit: string; diameter_unit: string; width_unit: string; height_unit: string; flow_unit?: string; linear_scale_to_meters: number; elevation_scale_to_meters: number; diameter_scale_to_meters: number; width_scale_to_meters: number; height_scale_to_meters: number; assumed: boolean; }
export interface LandXmlPipeNetworkDocumentJs {
    schema: "LandXML-1.0" | "LandXML-1.1" | "LandXML-1.2"; version: string;
    capability_diagnostics: LandXmlCapabilityDiagnosticJs[];
    root_units?: LandXmlPipeUnitsJs; collections: LandXmlPipeCollectionJs[];
    features: LandXmlPipeFeatureJs[]; networks: LandXmlPipeNetworkJs[]; refusals: LandXmlPipeRefusalJs[];
}
export interface LandXmlPipeCollectionJs { source_id: string; source_path: string; properties: Record<string, string>; }
export interface LandXmlPipeFeatureJs { source_id: string; source_path: string; owner_source_id: string; properties: Record<string, string>; }
export interface LandXmlPipeRefusalJs { source_id: string; source_path: string; code: string; message: string; }
export interface LandXmlPipeMeasureJs { value: number; unit: string; meters: number; }
export interface LandXmlPipePositionJs { northing: number; easting: number; northing_meters: number; easting_meters: number; elevation?: LandXmlPipeMeasureJs; }
export interface LandXmlPipeFlowJs { source_id: string; source_path: string; unit?: string; flow_in?: number; loss_in?: number; loss_out?: number; properties: Record<string, string>; }
export interface LandXmlPipeInvertJs { source_id: string; source_path: string; pipe_source_id: string; flow_direction: string; elevation: LandXmlPipeMeasureJs; properties: Record<string, string>; }
export interface LandXmlPipePartJs { kind: "circular" | "elliptical" | "egg" | "rectangular"; properties: Record<string, string>; diameter?: LandXmlPipeMeasureJs; span?: LandXmlPipeMeasureJs; width?: LandXmlPipeMeasureJs; height?: LandXmlPipeMeasureJs; thickness?: LandXmlPipeMeasureJs; material?: string; }
export interface LandXmlStructurePartJs { kind: "circular" | "rectangular" | "inlet" | "outlet" | "connection"; properties: Record<string, string>; diameter?: LandXmlPipeMeasureJs; length?: LandXmlPipeMeasureJs; width?: LandXmlPipeMeasureJs; thickness?: LandXmlPipeMeasureJs; material?: string; }
export interface LandXmlPipeNetworkJs { source_id: string; source_path: string; name: string; pipe_network_type: string; properties: Record<string, string>; features: LandXmlPipeFeatureJs[]; structure_units?: LandXmlPipeUnitsJs; pipe_units?: LandXmlPipeUnitsJs; structures: LandXmlPipeStructureJs[]; pipes: LandXmlPipeJs[]; }
export interface LandXmlPipeStructureJs { source_id: string; source_path: string; name: string; properties: Record<string, string>; units: LandXmlPipeUnitsJs; center: LandXmlPipePositionJs; part: LandXmlStructurePartJs; rim_elevation?: LandXmlPipeMeasureJs; sump_elevation?: LandXmlPipeMeasureJs; inverts: LandXmlPipeInvertJs[]; flow?: LandXmlPipeFlowJs; }
export interface LandXmlPipeJs { source_id: string; source_path: string; name: string; properties: Record<string, string>; units: LandXmlPipeUnitsJs; connectivity: { start_structure_source_id: string; end_structure_source_id: string }; part: LandXmlPipePartJs; geometry: { kind: "straight" | "pass_through"; point?: LandXmlPipePositionJs }; length?: LandXmlPipeMeasureJs; flow?: LandXmlPipeFlowJs; }



export type AnalyticStatusJs = { type: "complete" } | { type: "unsupported"; reason: string };
export type AnalyticSourceContextJs =
| { kind: "direct"; representation_id: number }
| { kind: "mapped"; representation_map_path: number[] };
export interface AnalyticSourceKeyJs {
    model_sha256: string; schema: string | null; length_unit_scale_bits: string;
    context: AnalyticSourceContextJs; solid_id: number;
}
export type AnalyticCurveSegmentJs =
| { type: "line"; start: number[]; end: number[] }
| { type: "arc"; center: number[]; normal: number[]; x_axis: number[];
radius: number; start_angle: number; sweep_angle: number };
export interface AnalyticProfileLoopJs {
    kind: "outer" | "inner"; segments: AnalyticCurveSegmentJs[];
    signed_area: number; perimeter: number;
}
export interface AnalyticProfileJs {
    profile_id: number; ifc_type_name: string; ProfileType: string | null;
    Position: number | null; profile_position: number[] | null;
    loops: AnalyticProfileLoopJs[]; status: AnalyticStatusJs;
}
export interface AnalyticExtrusionJs {
    solid_id: number; SweptArea: number | null; profile: AnalyticProfileJs | null;
    Position: number | null; position_matrix: number[] | null;
    ExtrudedDirection: number | null; DirectionRatios: number[] | null;
    axis_unit_vector: number[] | null; Depth: number | null; status: AnalyticStatusJs;
}
export interface ExtrusionNominalQuantitiesJs {
    profile_area: number; projected_height: number; nominal_volume: number;
}
export interface ExtrusionDefinitionJs {
    key: AnalyticSourceKeyJs; source: AnalyticExtrusionJs;
    /** Squared/cubed IFC file-length units; null for unsupported or invalid sources. */
    nominal_quantities: ExtrusionNominalQuantitiesJs | null;
}
export interface ExtrusionInstanceJs {
    ordinal: number; source: AnalyticSourceKeyJs; product_id: number;
    solid_id: number; mapping_path: number[]; source_modified: boolean;
    world_from_source: number[] | null; status: AnalyticStatusJs;
}
export interface ExtrusionDefinitionsJs {
    up_axis: "Z"; source_units: "ifc_file_length_units"; world_units: "m";
    coordinate_space: "absolute_ifc_world"; model_sha256: string;
    schema: string | null; length_unit_scale: number;
    sources: ExtrusionDefinitionJs[];
    instances: Record<number, ExtrusionInstanceJs[]>; diagnostics: string[];
}



export class AlignmentAxisJs {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * [horizontal distance, IFC Z-up point XYZ, normalized world tangent XYZ].
     * Coordinates remain f64 absolute metres; no renderer origin is applied.
     */
    evaluate(distance_m: number): Float64Array;
    constructor(content: string, express_id: number);
    readonly GlobalId: string | undefined;
    readonly Name: string | undefined;
    readonly approximate: boolean;
    readonly expressId: number;
    readonly geometricHorizontalLengthMeters: number;
}

/**
 * The overlap solid of one clashing pair, or the reason there is none.
 */
export class ClashIntersectionSolidJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * `""` when `isSolid`, otherwise one of:
     * - `"malformed-operand"` — any of FOUR malformations, all rejected
     *   before the boolean runs, because computing on them would silently
     *   drop the offending triangle (or worse) rather than report the true
     *   operand:
     *   1. `positionsA`/`positionsB` is not a flat `[x, y, z, …]` triple
     *      (length not a multiple of 3);
     *   2. `indicesA`/`indicesB` has a length that is not a multiple of 3,
     *      so it does not describe whole triangles;
     *   3. `indicesA`/`indicesB` references a vertex past the end of its own
     *      operand's positions;
     *   4. a position is **non-finite** (NaN or infinity). This one is worth
     *      calling out to callers: a NaN coordinate is caught by neither
     *      length check, and left alone it can be absorbed into a
     *      normal-looking answer or corrupt a face enough to report a
     *      genuinely overlapping pair as `"no-overlap"`. So if you are
     *      debugging an unexpected `"no-overlap"`, check your inputs for
     *      NaN — it surfaces here, not there.
     * - `"empty-operand"` — an operand had no triangles.
     * - `"no-overlap"` — the exact intersection is empty. Covers a disjoint
     *   pair AND a *touching* pair, including any graze below the kernel's
     *   `2^-16 m ≈ 15.26 µm` snap grid (both faces snap flush).
     * - `"below-kernel-resolution"` — the pair overlaps, but too shallowly for
     *   the kernel to resolve as a solid rather than a coplanar contact. See
     *   `thicknessM` / `requiredM`.
     * - `"budget-exhausted"` — the escalation budget tripped; the arrangement
     *   is partial and nothing about it is trustworthy.
     */
    readonly degenerateReason: string;
    /**
     * Triangle indices into `positions / 3`.
     */
    readonly indices: Uint32Array;
    /**
     * True when a trustworthy overlap solid was produced. When false, every
     * geometry getter is empty and `degenerateReason` says why.
     */
    readonly isSolid: boolean;
    /**
     * World-space vertex positions, flat `[x, y, z, …]`, f64.
     *
     * f64 rather than the f32 the rest of the mesh pipeline uses because the
     * caller reports this solid's volume: the f32 round-trip costs ~1e-7
     * relative, a thousand times the exactness the kernel actually delivers.
     * Downcast to f32 at the GPU upload if the renderer wants it.
     */
    readonly positions: Float64Array;
    /**
     * For `"below-kernel-resolution"`: the depth this pair would have needed
     * for the kernel to resolve a solid, in metres. `0` otherwise. Grows with
     * distance from the world origin, as the kernel's own tolerance does.
     */
    readonly requiredM: number;
    /**
     * For `"below-kernel-resolution"`: the overlap's measured thinnest extent,
     * in metres. `0` otherwise. Useful to tell the user how shallow the clash
     * is even though no solid can be drawn.
     */
    readonly thicknessM: number;
    /**
     * Triangle count of the solid; `0` when degenerate.
     */
    readonly triangleCount: number;
    /**
     * Enclosed volume in m³. `0` when not a solid — check `isSolid` first;
     * "no measurable overlap" and "an overlap of zero" are different claims.
     */
    readonly volumeM3: number;
}

/**
 * Packed result of one rule run. Parallel arrays, one entry per clash record;
 * `points` has 3 per record and `bounds` has 6 per record.
 */
export class ClashRunResult {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly a: Uint32Array;
    readonly b: Uint32Array;
    readonly bounds: Float64Array;
    readonly depthFloor: Float64Array;
    readonly distance: Float64Array;
    readonly distanceKind: Uint8Array;
    readonly points: Float64Array;
    readonly status: Uint8Array;
}

/**
 * A clash session: ingest element geometry once, then run rules repeatedly.
 */
export class ClashSession {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Ingest N elements from flat arenas.
     *
     * - `positions`: concatenated per-element vertex coords (x,y,z,...)
     * - `pos_ranges`: 2 per element = [float_offset, float_len]
     * - `indices`: concatenated per-element LOCAL (0-based) triangle indices
     * - `idx_ranges`: 2 per element = [idx_offset, idx_len]
     * - `aabbs`: 6 per element = [minx,miny,minz,maxx,maxy,maxz]
     */
    ingest(positions: Float32Array, pos_ranges: Uint32Array, indices: Uint32Array, idx_ranges: Uint32Array, aabbs: Float32Array): void;
    constructor();
    /**
     * Run one rule. `group_a`/`group_b` are GLOBAL element indices.
     * OMIT `group_b` (pass `undefined`/`null`) for a self-clash within
     * `group_a`; pass an array -- INCLUDING an empty one -- for a two-sided
     * rule. An empty array is a B side that matched nothing and yields no
     * clashes, which is why this is nullable rather than "empty means
     * self" (#5354). `mode`: 0 = hard, 1 = clearance. Records carry GLOBAL
     * element indices.
     */
    runRule(group_a: Uint32Array, group_b: Uint32Array | null | undefined, mode: number, tolerance: number, clearance: number, report_touch: boolean): ClashRunResult;
}

/**
 * A set of closed 2D rings, grouped into disjoint shapes.
 *
 * Rings carry no duplicated closing vertex (connect the last point back to
 * the first). Winding is meaningful: a counter-clockwise ring covers area, a
 * clockwise one removes it, so an outer boundary and its holes are
 * distinguishable without any extra tagging — the property
 * `meshOutline2d`'s flattened contour list relies on too.
 */
export class Contours2D {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Axis-aligned bounds as `[minX, minY, maxX, maxY]`, or `undefined` when
     * empty. Cheap enough to gate the boolean itself: an accumulated occluder
     * whose bounds miss the next element needs no difference at all.
     */
    bounds(): Float64Array | undefined;
    /**
     * Every ring's coordinates concatenated. Paired with `ringLengths()` this
     * reconstructs the set through the constructor, and reads a whole result
     * back in one boundary crossing instead of one per ring. It round-trips the
     * constructor's *sanitised* rings — degenerate rings and explicit closing
     * vertices are dropped at construction, so those are not echoed back.
     */
    coords(): Float64Array;
    /**
     * Adopt the rings of a `meshOutline2d` result, widening its f32
     * coordinates to the f64 the boolean engine works in.
     *
     * The outline's `axisMin`/`axisMax` are dropped — they describe the cut
     * axis, which a 2D boolean has no notion of; keep them on the JS side if
     * the caller still needs them for band classification.
     */
    static fromMeshOutline(outline: MeshOutlineJs): Contours2D;
    /**
     * Build a contour set from flat coordinates plus per-ring vertex counts.
     *
     * `coords` is `[x0, y0, x1, y1, …]` with every ring concatenated in order;
     * `ringLengths[i]` is the VERTEX count (not the float count) of ring `i`.
     * Throws when the counts do not add up to `coords.length / 2`.
     *
     * Shape grouping is a property of boolean *results*: a set built here is
     * an unstructured ring soup, so `shapeCount` reports 0 until it has been
     * through an operation (`resolve2d` alone is enough). Degenerate rings
     * (under 3 vertices, non-finite, or exactly collinear) are dropped at
     * construction, so `isEmpty`/`bounds()` report the same rings a later
     * boolean would keep rather than exposing an unsanitised soup.
     */
    constructor(coords: Float64Array, ring_lengths: Uint32Array);
    /**
     * Ring `index` as a flat `[x0, y0, x1, y1, …]` array, or `undefined` when
     * out of range.
     */
    ring(index: number): Float64Array | undefined;
    /**
     * Vertex count of each ring, in the same order as `coords()`.
     */
    ringLengths(): Uint32Array;
    /**
     * Ring index at which each shape starts. Entry `s` is shape `s`'s OUTER
     * ring; the rings up to the next entry (or `ringCount`) are its holes.
     */
    shapeOffsets(): Uint32Array;
    /**
     * True when the set holds no rings. Degenerate rings are dropped at
     * construction and never emitted by an operation, so this also means the
     * set covers no area.
     */
    readonly isEmpty: boolean;
    /**
     * Total number of boundary rings across every shape.
     */
    readonly ringCount: number;
    /**
     * Number of disjoint shapes, or 0 for a set that has not been through an
     * operation yet (see the constructor).
     */
    readonly shapeCount: number;
}

/**
 * A collection of resolved grid axes.
 */
export class GridAxisCollection {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get the axis at `index`. Returns `undefined` for out-of-bounds index.
     */
    getAxis(index: number): GridAxisJs | undefined;
    /**
     * Whether the collection is empty.
     */
    readonly isEmpty: boolean;
    /**
     * Number of grid axes.
     */
    readonly length: number;
}

/**
 * One grid axis: tag + endpoints in renderer Y-up world space (metres).
 */
export class GridAxisJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Express ID of the `IfcGridAxis`.
     */
    readonly axisId: number;
    /**
     * End endpoint `[x, y, z]` in renderer Y-up world space (metres).
     */
    readonly end: Float32Array;
    /**
     * Express ID of the owning `IfcGrid`.
     */
    readonly gridId: number;
    /**
     * Start endpoint `[x, y, z]` in renderer Y-up world space (metres).
     */
    readonly start: Float32Array;
    /**
     * Axis tag (e.g. `"A"`, `"1"`); empty string when unauthored.
     */
    readonly tag: string;
}

/**
 * Main IFC-Lite API
 */
export class IfcAPI {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Admit this worker's installed bytes/index pair once before geometry.
     * Full canonical span validation is required across worker realms. This
     * does not authenticate arbitrary later data-taking compatibility calls.
     */
    bindSourceModel(): void;
    /**
     * Run the pre-pass ONCE and return serialized results for worker distribution.
     * Takes raw bytes (&[u8]) to avoid TextDecoder overhead.
     */
    buildPrePassOnce(data: Uint8Array): any;
    /**
     * Streaming pre-pass: emits geometry jobs in chunks via a JS callback
     * instead of waiting for the full file scan to complete.
     *
     * Single linear walk over the file:
     *   1. Builds the entity index incrementally from the same scan that
     *      collects geometry jobs (a separate index scan would double
     *      wall-clock).
     *   2. As soon as `IFCPROJECT` has been seen, the unit scale and the
     *      first ~50 geometry jobs have been collected, resolves
     *      `unitScale` + `rtcOffset` and emits a `meta` callback so the
     *      JS host can spin up geometry process workers.
     *   3. Emits `jobs` callbacks every `chunk_size` jobs (or fewer if
     *      the meta phase already buffered some).
     *   4. Emits `complete` with the total job count at end of scan.
     *
     * On a 986 MB / 14 M-entity file this drops time-to-first-geometry
     * from ~17 s (full pre-pass + worker spawn + first batch) to ~3 s
     * (first 100 K bytes scanned + meta + first chunk).
     *
     * The callback receives a single `JsValue` argument shaped as one of:
     *   `{ type: "meta", unitScale, rtcOffset: [x,y,z], needsShift, buildingRotation? }`
     *   `{ type: "jobs", jobs: Uint32Array }`     // [id, start, end] triples
     *   `{ type: "complete", totalJobs }`
     */
    buildPrePassStreaming(data: Uint8Array, on_event: Function, chunk_size: number, disabled_type_names: string[] | null | undefined, skip_type_geometry: boolean): any;
    /**
     * Sharded pre-pass variant: same scan/discovery/jobs/columns pipeline as
     * `buildPrePassStreaming`, but
     *  1. the entity index is PREBUILT from the host's stitched shard columns
     *     (file order; see `scanEntityIndexShard`) — the scan skips its inline
     *     index build, the meta RTC ladder resolves against the FULL index
     *     (no partial-ladder full-rescan detour), and the post-scan
     *     `entity-index` event is skipped (the host already delivered it), and
     *  2. styles resolution is EXTERNAL: the styled-item spans are resolved as
     *     shard slices on the geometry workers (`resolveStyledItemsShard`);
     *     this call stashes the SUPPORT spans + plane-angle scale, and the
     *     follow-up `finalizePrepassStyles` merges + flattens into the exact
     *     styles payload the serial path emits. NO `styles` event is emitted
     *     here.
     */
    buildPrePassStreamingSharded(data: Uint8Array, on_event: Function, chunk_size: number, disabled_type_names: string[] | null | undefined, skip_type_geometry: boolean, index_ids: Uint32Array, index_starts: Uint32Array, index_lengths: Uint32Array, index_classes: Uint8Array): any;
    /**
     * Existing sharded prepass plus an exact full-source key in complete.
     */
    buildPrePassStreamingShardedWithSourceFingerprint(data: Uint8Array, on_event: Function, chunk_size: number, disabled_type_names: string[] | null | undefined, skip_type_geometry: boolean, index_ids: Uint32Array, index_starts: Uint32Array, index_lengths: Uint32Array, index_classes: Uint8Array): any;
    /**
     * Existing streaming prepass plus an exact full-source key in complete.
     */
    buildPrePassStreamingWithSourceFingerprint(data: Uint8Array, on_event: Function, chunk_size: number, disabled_type_names: string[] | null | undefined, skip_type_geometry: boolean): any;
    /**
     * Calibrate one raster plane from native-source landmarks and a measured
     * world span. Returns UTF-8 CalibratedPlane JSON. Constant bounded work;
     * does not read IFC, decode image pixels or mutate a model.
     */
    calibrateAppearancePlane(request_json: string): Uint8Array;
    /**
     * Catalog effective IfcProduct classes and IfcRelDefinesByType membership.
     * JSON input is AppearanceCatalogRequest; output is AppearanceCatalog JSON.
     * Run in a worker and validate sourceRevision before using the selectors.
     */
    catalogAppearance(content: Uint8Array, request_json: string): Uint8Array;
    /**
     * Clear the cached entity index (call between loads when reusing
     * the same `IfcAPI` instance — e.g. the parser worker keeps one
     * `IfcAPI` alive across multiple `parse` requests).
     *
     * Recovers a poisoned cache Mutex instead of panicking; see `mod_tests.rs`.
     */
    clearPrePassCache(): void;
    /**
     * Starts one owned raw-byte LandXML session. The caller must free or abort
     * the session on every cancellation path.
     *
     * `options` is the same shape `parseLandXmlSourceBytesWithOptions`
     * accepts (see `LandXmlParseOptionsJs`) and is optional so every
     * existing single-argument call site keeps working unchanged. A bad
     * `assumedLinearUnit` token (or any other invalid option) refuses here,
     * at session construction, never partway through a stream (#5175).
     */
    createLandXmlTinStreamSession(max_bytes: number, options?: LandXmlParseOptionsJs | null): LandXmlTinStreamSession;
    /**
     * Run geometry extraction on `content` and return its typed CSG / opening
     * diagnostics (the `GeometryDiagnostics` contract) as a JS object, or
     * `undefined` when nothing diagnostic-worthy happened (no openings, no
     * failures). Takes the raw IFC bytes (`Uint8Array`) so there is no input-size
     * cap. The produced meshes are dropped; only the diagnostics are returned.
     */
    diagnoseGeometry(content: Uint8Array): any;
    /**
     * Export tabular **CSV**. `mode` ∈ {`"entities"`, `"properties"`, `"quantities"`,
     * `"spatial"`}. `delimiter` defaults to `,` when empty; `include_properties` adds
     * flattened `Pset_Prop` columns to the entities view.
     */
    exportCsv(content: Uint8Array, mode: string, delimiter: string, include_properties: boolean): Uint8Array;
    /**
     * Export the `IfcSpace` volumes in `content` as a Dragonfly **DFJSON** string.
     *
     * Each space becomes an extruded `Room2D` (floor polygon + floor-to-ceiling height)
     * grouped into stories — the simpler Ladybug Tools target for mostly-vertical-wall
     * models. Loads via `dragonfly.model.Model.from_dfjson`.
     *
     * ```javascript
     * const api = new IfcAPI();
     * const dfjson = api.exportDfjson(ifcContent, "my_model");
     * ```
     */
    exportDfjson(content: Uint8Array, name: string): string;
    /**
     * Export the render geometry in `content` as a binary **GLB** (`Uint8Array`).
     *
     * `hidden` / `isolated` are express-id visibility filters; `hidden_types_csv` is a
     * comma-separated list of IFC type names whose class toggle is off (e.g.
     * `"IfcOpeningElement,IfcSpace"`). `isolated` carries the isolation allowlist's
     * null-vs-empty distinction across the wasm boundary: omit it (`undefined`) for
     * "no isolation filter" (every mesh is a candidate); pass an empty `Uint32Array`
     * for "isolation is ACTIVE and currently matches nothing" (every mesh is
     * excluded). Collapsing the two — as a bare `Uint32Array` parameter would force a
     * caller to do — silently exports the whole model when a filter matches nothing
     * (#4328 follow-up: reachable by filtering the Class tab to a type present only
     * in a federated model's secondary member, then exporting "Visible Only"). A
     * non-empty `Uint32Array` is the ordinary allowlist. `include_metadata` attaches
     * counts + per-node `expressId`. Per-mesh RTC origin rides the node translation
     * (precision-safe).
     * `lit` emits standard PBR materials that shade from normals; omitted or
     * `true` ⇒ lit (the default), `false` ⇒ flat `KHR_materials_unlit` (the
     * historical look — #1321). Optional at the boundary so older 5-arg callers
     * keep lit-by-default behaviour.
     * `emissive` self-illuminates each material at its base colour (core glTF
     * `emissiveFactor`) so renderers without ambient/IBL — Google Earth — don't
     * render the model near-black (#1427); omitted or `false` ⇒ off.
     *
     * Fails CLOSED: when the visible mesh set is empty this throws an `Error`
     * whose message starts with `NO_RENDER_GEOMETRY`, instead of returning a
     * structurally valid but empty GLB. #1438 put that guard only in the TS
     * CLI/MCP wrappers; making the boundary itself refuse means SDK/viewer/
     * direct callers inherit it too (the TS guards stay as defense-in-depth).
     */
    exportGlb(content: Uint8Array, include_metadata: boolean, hidden: Uint32Array, isolated: Uint32Array | null | undefined, hidden_types_csv: string, lit?: boolean | null, emissive?: boolean | null): Uint8Array;
    /**
     * Assemble a **GLB** from already-produced meshes (the viewer's `MeshData`, flattened)
     * — no re-meshing. Per mesh `i`: `vertex_counts[i]` verts + `index_counts[i]` indices
     * taken in order from the concatenated `positions`/`normals`/`indices`; `colors` is
     * RGBA per mesh, `origins` xyz per mesh, `express_ids` labels each mesh (indices are
     * per-mesh local). The caller passes exactly the meshes it wants emitted.
     *
     * Fails CLOSED: if the declared vertex/index counts run past the flattened
     * `positions` / `indices`, there are fewer `index_counts` than meshes, `normals`
     * is empty or too short to cover every vertex, a mesh's index block is not a
     * whole number of triangles, or an index names a vertex its own mesh does not
     * have (glTF 2.0 3.7.2.1), this throws an `Error` whose message starts with
     * `MALFORMED_MESH_INPUT` — instead of silently emitting a GLB with those meshes
     * dropped, a TRIANGLES primitive whose count is not a multiple of 3, or the
     * out-of-range index copied into the BIN chunk. (The viewer always passes
     * fully-backed, normal-covered, whole-triangle, in-range arrays, so this only
     * fires on a caller bug.)
     *
     * `world_matrix` is the frame the meshes were baked in (#7734): 16 finite
     * numbers, a column-major 4x4 in IFC Z-up metres with `world = M * baked`
     * (the viewer builds it from `CoordinateInfo`). The GLB root carries it, so
     * a georeferenced model exports where the from-bytes `exportGlb` puts it
     * instead of in the render frame. Omit it (`undefined`) for an unshifted
     * model; a matrix that is not 16 finite numbers throws
     * `MALFORMED_MESH_INPUT`.
     */
    exportGlbFromMeshes(positions: Float32Array, normals: Float32Array, indices: Uint32Array, vertex_counts: Uint32Array, index_counts: Uint32Array, colors: Float32Array, origins: Float64Array, express_ids: Uint32Array, include_metadata: boolean, lit?: boolean | null, emissive?: boolean | null, world_matrix?: Float64Array | null): Uint8Array;
    /**
     * Export the `IfcSpace` volumes in `content` as Honeybee **HBJSON** UTF-8 bytes.
     *
     * Returned as UTF-8 bytes (`Uint8Array`) so output is not capped by the
     * V8 max-string ceiling (~512 MB); decode with `TextDecoder` when a string
     * is genuinely needed.
     *
     * Rooms are built analytically from extruded-area profiles (watertight by construction);
     * faces are typed Floor / RoofCeiling / Wall with outward normals. The result loads via
     * `honeybee.model.Model.from_hbjson` and is ready for Ladybug Tools / Pollination.
     *
     * ```javascript
     * const api = new IfcAPI();
     * const hbjson = api.exportHbjson(ifcContent, "my_model");
     * ```
     */
    exportHbjson(content: Uint8Array, name: string): Uint8Array;
    /**
     * Like [`Self::export_hbjson`], but also returns the export's coverage stats
     * (`HbjsonStats`: spaces seen, rooms emitted, spaces skipped as degenerate, plus
     * apertures / doors / shades / constructions / interior adjacencies) so a caller
     * can tell whether the "success" result silently dropped input.
     *
     * Returns a plain JS object `{ content: Uint8Array, stats: HbjsonStats }`; `content`
     * is UTF-8 HBJSON bytes (same encoding rationale as [`Self::export_hbjson`] — not
     * capped by the V8 max-string ceiling). Runs the export once — `content` and `stats`
     * come from the same pass, not two separate exports.
     *
     * ```javascript
     * const api = new IfcAPI();
     * const { content, stats } = api.exportHbjsonWithStats(ifcContent, "my_model");
     * if (stats.skipped > 0) console.warn(`${stats.skipped} spaces skipped as degenerate`);
     * ```
     */
    exportHbjsonWithStats(content: Uint8Array, name: string): any;
    /**
     * Export **IFC5 / IFCX** (the USD-style node graph). `only_known_properties` keeps
     * only properties with an official IFC5 schema.
     */
    exportIfcx(content: Uint8Array, only_known_properties: boolean, pretty: boolean): Uint8Array;
    /**
     * Export structured **JSON** (array of entity objects with typed property values).
     */
    exportJson(content: Uint8Array, pretty: boolean, include_properties: boolean, include_quantities: boolean): Uint8Array;
    /**
     * Export **JSON-LD** (`@graph` of `ifc:` nodes). Empty `context` ⇒ buildingSMART
     * IFC4 OWL default.
     *
     * `included` is an express-id isolation filter mirroring `exportObj` /
     * `exportGlb`, and carries the same null-vs-empty distinction across the wasm
     * boundary: omit it (`undefined`) for "no isolation filter" (every entity is
     * emitted); pass an empty `Uint32Array` for "isolation is ACTIVE and currently
     * matches nothing", which emits an empty `@graph`. Collapsing the two — as a
     * bare `Uint32Array` parameter would force a caller to do — silently exported
     * the whole model when a filter matched nothing (#4659, the JSON-LD twin of
     * #4483/#4484). A non-empty `Uint32Array` is the ordinary allowlist.
     */
    exportJsonld(content: Uint8Array, context: string, include_properties: boolean, include_quantities: boolean, pretty: boolean, included?: Uint32Array | null): Uint8Array;
    /**
     * Build a Google-Earth-ready **KMZ** (`Uint8Array`) straight from the viewer's
     * already-produced meshes — the working path (#1427). The model is embedded as
     * **COLLADA** (`model.dae`), the only `<Model>` format Google Earth loads (a GLB
     * raises "Unsupported element: Model"), with emission-lit double-sided materials
     * placement. Mesh arrays match `exportGlbFromMeshes`;
     * `latitude`/`longitude`/`altitude` + `x_axis_abscissa`/`x_axis_ordinate`
     * (grid-north, `undefined` ⇒ heading 0) place + orient the model.
     * `altitude_mode` (`"clampToGround"` default ⇒ rest on terrain, ignoring
     * `altitude`; `"absolute"` ⇒ place at `altitude` metres MSL) selects the
     * KML vertical placement (#1427).
     *
     * Fails CLOSED: when no triangle survives (an empty visible set, or meshes
     * whose only triangles are degenerate and collapse in the vertex dedup)
     * this throws an `Error` whose message starts with `NO_RENDER_GEOMETRY`;
     * a declared vertex/index count running past its buffer, an index block
     * that is not whole triangles, or an index outside its mesh throws
     * `MALFORMED_MESH_INPUT`, exactly as `exportGlbFromMeshes` does. These used
     * to ship as a "successful" archive: an empty one around a COLLADA
     * document the 1.4.1 schema rejects, or one with meshes or faces missing.
     */
    exportKmzFromMeshes(positions: Float32Array, normals: Float32Array, indices: Uint32Array, vertex_counts: Uint32Array, index_counts: Uint32Array, colors: Float32Array, origins: Float64Array, latitude: number, longitude: number, altitude: number, x_axis_abscissa: number | null | undefined, x_axis_ordinate: number | null | undefined, name: string, altitude_mode?: string | null): Uint8Array;
    /**
     * Export the terrain products `product_ids` (express ids) of `content` as
     * one LandXML 1.2 document, one `<Surface>` each.
     *
     * Returns JSON `{ xml, crsName, surfaces: [{ productId, globalId, name,
     * points, faces }] }`. A selection that is not an authored triangulated
     * terrain, or whose georeferencing is missing or ambiguous, throws an
     * `Error` whose message starts with `TERRAIN_REFUSED:` and names the
     * reason.
     */
    exportLandXmlTerrain(content: Uint8Array, product_ids: Uint32Array, options: LandXmlTerrainOptionsJs): string;
    /**
     * Merge several IFC models into one STEP/IFC UTF-8 byte buffer (`Uint8Array`).
     * `concatenated` is every model's
     * bytes laid end-to-end; `lengths[i]` is the byte length of model `i`. The first model
     * keeps its ids; later models are id-offset and their project unified to the first.
     */
    exportMerged(concatenated: Uint8Array, lengths: Uint32Array, schema: string): Uint8Array;
    /**
     * Export the render geometry in `content` as Wavefront **OBJ** UTF-8 bytes.
     *
     * Returned as UTF-8 bytes (`Uint8Array`) so output is not capped by the
     * V8 max-string ceiling (~512 MB); decode with `TextDecoder` when a string
     * is genuinely needed.
     *
     * `hidden` is an express-id filter mirroring the viewer's visibility state.
     * `isolated` carries the isolation allowlist's null-vs-empty distinction across
     * the wasm boundary: omit it (`undefined`) for "no isolation filter" (every mesh
     * is a candidate); pass an empty `Uint32Array` for "isolation is ACTIVE and
     * currently matches nothing" (every mesh is excluded). Collapsing the two — as a
     * bare `Uint32Array` parameter would force a caller to do — silently exports the
     * whole model when a filter matches nothing (the OBJ twin of #4328/#4364, fixed
     * for GLB in `export_glb`). A non-empty `Uint32Array` is the ordinary allowlist.
     * Instanced type-library shapes are skipped regardless of the filter.
     *
     * Fails CLOSED like `exportGlb`: when no mesh is written this throws an
     * `Error` whose message starts with `NO_RENDER_GEOMETRY`, instead of
     * returning a header-only OBJ (#7695).
     *
     * ```javascript
     * const obj = api.exportObj(ifcContent, true, new Uint32Array(), undefined);
     * ```
     */
    exportObj(content: Uint8Array, include_normals: boolean, hidden: Uint32Array, isolated?: Uint32Array | null): Uint8Array;
    /**
     * Re-serialize the model in `content` to STEP/IFC UTF-8 bytes.
     *
     * Returned as UTF-8 bytes (`Uint8Array`) so output is not capped by the
     * V8 max-string ceiling (~512 MB); decode with `TextDecoder` when a string
     * is genuinely needed.
     *
     * `schema` is the FILE_SCHEMA label to write (empty ⇒ preserve the source schema).
     *
     * `included` is an express-id allowlist carrying the same null-vs-empty
     * distinction as `exportObj` / `exportGlb`: omit it (`undefined`) for "no
     * isolation filter" (whole model); pass an empty `Uint32Array` for "isolation
     * is ACTIVE and currently matches nothing", which writes a header-only file
     * with an empty `DATA;` section. Collapsing the two — as a bare `Uint32Array`
     * parameter would force a caller to do — silently exported the whole model
     * when a filter matched nothing (#4659, the STEP twin of #4483/#4484). When
     * set, the forward `#`-reference closure is added so the subset never dangles
     * a reference.
     * `mutations_json` carries `MutablePropertyView` edits; empty ⇒ none. It is
     * either the mutation log `MutablePropertyView.exportMutations()` returns
     * (an object with a `mutations` array, optionally `newEntities` and
     * `georefMutations`), written with byte parity to the TypeScript
     * `StepExporter` (#5941), or the older pre-serialized
     * `{ attributeUpdates, propertyMutations }` shape. A log does not combine
     * with `included`. See `export_step_json` for both shapes.
     * A non-empty but malformed `mutations_json` throws rather than silently
     * exporting the model with none of the caller's edits applied — mirrors
     * `exportGlb`'s and `exportMerged`'s fail-closed contract on this same API.
     */
    exportStep(content: Uint8Array, schema: string, included: Uint32Array | null | undefined, mutations_json: string): Uint8Array;
    /**
     * Export **OpenUSD** (`.usda` ASCII): a real Z-up USD stage — spatial hierarchy of
     * `Xform` prims, `UsdGeomMesh` geometry, `UsdPreviewSurface` materials, IFC
     * metadata as custom attributes. Whole-model (geometry-backed).
     *
     * Fails CLOSED like `exportGlb`: a model with no render geometry throws an
     * `Error` whose message starts with `NO_RENDER_GEOMETRY`, instead of
     * returning a stage with nothing to look at (#7695).
     */
    exportUsd(content: Uint8Array): Uint8Array;
    /**
     * Extract raw profile polygons from all building elements with `IfcExtrudedAreaSolid`
     * representations.
     *
     * Returns a [`ProfileCollection`] whose entries each carry:
     * - A 2D polygon (outer + holes) in local profile space (metres)
     * - A 4 × 4 column-major transform in WebGL Y-up world space
     * - Extrusion direction (world space) and depth (metres)
     *
     * Use [`ProfileProjector`] (TypeScript) to convert these into `DrawingLine[]`
     * for clean projection without tessellation artifacts.
     *
     * ```javascript
     * const api = new IfcAPI();
     * const profiles = api.extractProfiles(ifcContent, 0);
     * console.log('Profiles:', profiles.length);
     * for (let i = 0; i < profiles.length; i++) {
     *   const p = profiles.get(i);
     *   console.log(p.ifcType, 'depth:', p.extrusionDepth);
     * }
     * ```
     */
    extractProfiles(content: string, model_index: number): ProfileCollection;
    /**
     * Return authored swept-disk occurrences, including exact line/arc
     * directrices and derived measurements, in absolute IFC Z-up metres.
     * `ids` contains product STEP IDs; omit it for all products or pass an
     * empty `Uint32Array` for none. Unsupported records keep their status and
     * a null `directrix_metrics`; malformed representation walks report a
     * diagnostic and omit that product atomically.
     */
    extractSweptDiskDescriptions(content: Uint8Array, ids?: Uint32Array | null): any;
    /**
     * `ids` is an optional product STEP-ID filter; `None` selects all and
     * `Some([])` selects no products, matching the Rust and Python APIs.
     * Matrices are column-major f64; profile_position and position_matrix are
     * applied before world_from_source. No mesh is decoded on this path.
     */
    extrusionDefinitions(content: Uint8Array, ids?: Uint32Array | null): ExtrusionDefinitionsJs;
    /**
     * Sharded pre-pass: merge the shard-resolved styled-item columns with the
     * SUPPORT spans (extracted host-side from the shard classes) and run the
     * CANONICAL styles flatten. Returns the exact `styles` event payload the
     * serial path emits. Runs on any worker with `setEntityIndex` installed.
     * Span arguments are `[id, start, len]` triples; `plane_angle_to_radians`
     * comes from the meta event. `orphanColors` / `geomColors` carry exactly
     * four floats per id in `orphanIds` / `geomIds`; any other length throws
     * before either column is read. The payload's `styleFinishes` come from
     * the geometry finishes a preceding `setPrepassGeometryFinishes` stashed
     * (consumed here); without that call they are all NaN.
     */
    finalizePrepassStyles(data: Uint8Array, orphan_ids: Uint32Array, orphan_colors: Float32Array, geom_ids: Uint32Array, geom_colors: Float32Array, colour_map_spans: Uint32Array, material_def_spans: Uint32Array, rel_material_spans: Uint32Array, void_spans: Uint32Array, fills_spans: Uint32Array, aggregate_spans: Uint32Array, plane_angle_to_radians: number): any;
    /**
     * Finalize prepass styles against the installed source and entity index.
     */
    finalizePrepassStylesFromSource(orphan_ids: Uint32Array, orphan_colors: Float32Array, geom_ids: Uint32Array, geom_colors: Float32Array, colour_map_spans: Uint32Array, material_def_spans: Uint32Array, rel_material_spans: Uint32Array, void_spans: Uint32Array, fills_spans: Uint32Array, aggregate_spans: Uint32Array, plane_angle_to_radians: number): any;
    /**
     * Get WASM memory for zero-copy access
     */
    getMemory(): any;
    /**
     * Structured pipeline diagnostics accumulated across every
     * `processGeometryBatch*` call since the last load reset
     * (`clearPrePassCache` / `setEntityIndex`), as a JS object with a
     * `schemaVersion` field — or `undefined` when no batch has run yet.
     * Includes per-batch summed geometry wall time, mesh/triangle counts,
     * the degenerate-backstop drop count, and the CSG failure aggregates.
     */
    getPipelineDiagnostics(): any;
    /**
     * Inspect authored cant and superelevation records at a physical distance.
     * Cant exposes bracketing source records only; no transition value is
     * fabricated. Superelevation blocks preserve their authored bounds.
     */
    inspectLandXmlAlignmentAtDistance(data: Uint8Array, alignment_source_id: string, distance: number): LandXmlAlignmentInspectionJs;
    /**
     * Create and initialize the IFC API
     */
    constructor();
    /**
     * Parse the file and return every `IfcAlignment` directrix as a flat
     * `Float32Array` of 3D line-list vertices `[x0,y0,z0, x1,y1,z1, …]` in
     * the renderer's Y-up world space (RTC-subtracted, metres). Consecutive
     * samples form line segments. Feed straight to
     * `renderer.setLineOverlay('alignment', ...)`.
     *
     * Returns an empty array when the file has no alignments (or none with a
     * resolvable Axis curve), so the caller can clear the overlay cheaply.
     */
    parseAlignmentLines(content: string): Float32Array;
    /**
     * Parse alignments in the exact RTC frame selected by the mesh pre-pass.
     */
    parseAlignmentLinesInFrame(content: string, frame: RtcFrame): Float32Array;
    /**
     * Parse the file and return structured per-axis data (tag + endpoints) in
     * the renderer's Y-up world space (RTC-subtracted, metres). Use this when
     * you also need the axis tags (to render grid bubbles / labels).
     */
    parseGridAxes(content: string): GridAxisCollection;
    /**
     * Parse structured grid axes in the exact frame selected by the mesh pre-pass.
     */
    parseGridAxesInFrame(content: string, frame: RtcFrame): GridAxisCollection;
    /**
     * Parse the file and return every `IfcGridAxis` as a flat `Float32Array`
     * of 3D line-list vertices `[x0,y0,z0, x1,y1,z1, …]` (one segment per
     * axis) in the renderer's Y-up world space (RTC-subtracted, metres). Feed
     * straight to a line pipeline (e.g. `renderer.setLineOverlay('grid', …)`).
     *
     * Returns an empty array when the file has no grids, so the caller can
     * clear the overlay cheaply.
     */
    parseGridLines(content: string): Float32Array;
    /**
     * Parse grid line vertices in the exact frame selected by the mesh pre-pass.
     */
    parseGridLinesInFrame(content: string, frame: RtcFrame): Float32Array;
    /**
     * Parse all currently supported LandXML source families from the original
     * bytes. Terrain-only and alignment-only sources both return an honest
     * empty sibling collection, allowing the viewer's single load path to
     * handle either form and mixed documents uniformly.
     */
    parseLandXmlSourceBytes(data: Uint8Array): LandXmlSourceDocumentJs;
    /**
     * Parse a source with explicit hostile-input bounds. Passing
     * `cancelled: true` refuses before entering WASM; in-flight browser
     * cancellation is performed by terminating the worker that owns this
     * synchronous operation.
     */
    parseLandXmlSourceBytesWithOptions(data: Uint8Array, options: any): LandXmlSourceDocumentJs;
    /**
     * Parse a supported LandXML TIN document from its original bytes.
     *
     * The object is an owned serialization of the semantic document. Errors
     * deliberately use `LandXmlError::Display`, including its stable LXML code.
     */
    parseLandXmlTinBytes(data: Uint8Array): LandXmlTinDocumentJs;
    /**
     * Parse IFC file and extract symbolic representations (Plan,
     * Annotation, FootPrint, Axis). These are 2D curves used for
     * architectural drawings instead of sectioning 3D geometry.
     *
     * This standalone entry point detects an RTC frame from the whole source.
     * Use `parseSymbolicRepresentationsInFrame` when the symbols accompany
     * meshes produced by a streaming pre-pass or federation override.
     *
     * Example:
     * ```javascript
     * const api = new IfcAPI();
     * const symbols = api.parseSymbolicRepresentations(ifcData);
     * console.log('Found', symbols.totalCount, 'symbolic items');
     * for (let i = 0; i < symbols.polylineCount; i++) {
     *   const polyline = symbols.getPolyline(i);
     *   console.log('Polyline for', polyline.ifcType, ':', polyline.points);
     * }
     * ```
     */
    parseSymbolicRepresentations(content: string): SymbolicRepresentationCollection;
    /**
     * Parse symbolic representations in the exact RTC frame selected by the
     * browser mesh pre-pass rather than detecting a second frame from the
     * whole source.
     */
    parseSymbolicRepresentationsInFrame(content: string, frame: RtcFrame): SymbolicRepresentationCollection;
    /**
     * Create a calibrated image annotation through canonical native geometry.
     * Input is AnnotationPlaneRequest; output UTF-8 AnnotationPlanePlan JSON.
     * Does not mutate the IFC snapshot or decode the host-owned image.
     */
    planAnnotationPlane(content: Uint8Array, request_json: string): Uint8Array;
    /**
     * Plan image/UV edits against an effective IFC snapshot without mutating it.
     * JSON input uses AppearanceRequest; output is UTF-8 AppearancePlan JSON.
     * Call from a worker, then validate sourceRevision and allocator before an
     * atomic host commit. Preview UVs describe an unsplit canonical mesh item.
     */
    planAppearance(content: Uint8Array, request_json: string): Uint8Array;
    /**
     * Create a captured textured surface through canonical native geometry.
     * Input is CapturedMeshRequest; output UTF-8 CapturedMeshPlan JSON.
     * Does not mutate the IFC snapshot or decode the host-owned image.
     */
    planCapturedMesh(content: Uint8Array, request_json: string): Uint8Array;
    /**
     * Plan opt-in map similarity normalization on a completed STEP export.
     * Returns entity patches, allocated IDs and atomic refusal warnings as JSON.
     */
    planMapConversionNormalization(content: Uint8Array): string;
    /**
     * Registered mesh observations over canonical target albedo. Host verifies
     * original GLB identity against decoded source mesh/image and freezes frames.
     * Run in an owned cancellable worker. IFPA output adds `transfer` coverage;
     * `plan` is null when no sample is observed. Never infer accuracy approval.
     */
    planMeshTransfer(content: Uint8Array, request_json: string, rgba: Uint8Array): Uint8Array;
    /**
     * Finite-page composition over original canonical albedo. RGBA is supplied
     * separately from the bounded JSON request. Result: IFPA magic, little-endian
     * u32 JSON byte length, metadata JSON, then PNG bytes addressed by metadata.
     * Run in a cancellable worker; atomically adopt every item asset and IFC edit.
     */
    planPageAppearance(content: Uint8Array, request_json: string, rgba: Uint8Array): Uint8Array;
    /**
     * Plan an opaque polygonal PDF fill page as canonical IfcAnnotation
     * geometry with a provenance property set. An exact page plans directly; a
     * page with visible omissions needs the accepted fidelity report digest.
     */
    planPdfFillAnnotation(source: Uint8Array, request_json: string): Uint8Array;
    /**
     * Registered RGB point-cloud observations (#4381). `request_json.source`
     * is `{kind:'points', …}`; `positions` (3n f64, source-frame metres) and
     * `colors` (3n RGB8) are the payload, `normals` (3n f32, oriented) and
     * `stations` (n indices into `source.viewpoints`) are empty when absent.
     * `rgba` carries only the target's existing rasters. Same output as
     * `planMeshTransfer`; `transfer.source` records the orientation used.
     */
    planPointTransfer(content: Uint8Array, request_json: string, rgba: Uint8Array, positions: Float64Array, colors: Uint8Array, normals: Float32Array, stations: Uint32Array): Uint8Array;
    /**
     * Prepare bounded ordered PDF vector graphics states and the page fidelity
     * report (convertible paths, omissions with extent, exact/raster-only).
     */
    preparePdfVectorPage(request_json: string): Uint8Array;
    /**
     * Evaluate one supported horizontal-alignment source span at an exact
     * f64 distance. The binding reuses the native validator, so malformed
     * deserialized records, discontinuities, unresolved references, and
     * unsupported transition domains are rejected rather than approximated.
     */
    probeLandXmlAlignmentAtDistance(data: Uint8Array, alignment_source_id: string, distance: number, offset_right: number): LandXmlAlignmentProbeJs;
    /**
     * Evaluate a bounded set of physical locations carrying a displayed
     * station label. A duplicate label is real, never collapsed; an
     * excessive number is refused rather than allocated synchronously.
     */
    probeLandXmlAlignmentAtStation(data: Uint8Array, alignment_source_id: string, station: number, offset_right: number): LandXmlAlignmentProbesJs;
    /**
     * Process geometry for a subset of pre-scanned entities → flat
     * MeshCollection. Takes raw bytes + pre-pass data from buildPrePassOnce.
     * Thin wrapper over [`IfcAPI::produce_batch`]; converts each produced mesh
     * to MeshDataJs (the IFC Z-up→WebGL Y-up rotation with preserved winding happens
     * there). Flat indices preserve source order through this proper rotation.
     * Synchronous Rust compatibility entry; this call creates its own live snapshot.
     */
    processGeometryBatch(data: Uint8Array, jobs_flat: Uint32Array, unit_scale: number, rtc_x: number, rtc_y: number, rtc_z: number, needs_shift: boolean, void_keys: Uint32Array, void_counts: Uint32Array, void_values: Uint32Array, style_ids: Uint32Array, style_colors: Uint8Array, plane_angle_to_radians?: number | null, material_element_ids?: Uint32Array | null, material_color_counts?: Uint32Array | null, material_colors_rgba?: Uint8Array | null): MeshCollection;
    /**
     * Like [`IfcAPI::process_geometry_batch`] but reads the source bytes held by
     * [`IfcAPI::set_source_bytes`] instead of taking `data`. Byte-for-byte
     * identical output — it delegates to the legacy twin with the held slice.
     */
    processGeometryBatchFromSource(jobs_flat: Uint32Array, unit_scale: number, rtc_x: number, rtc_y: number, rtc_z: number, needs_shift: boolean, void_keys: Uint32Array, void_counts: Uint32Array, void_values: Uint32Array, style_ids: Uint32Array, style_colors: Uint8Array, plane_angle_to_radians?: number | null, material_element_ids?: Uint32Array | null, material_color_counts?: Uint32Array | null, material_colors_rgba?: Uint8Array | null): MeshCollection;
    /**
     * Like [`IfcAPI::process_geometry_batch`] but collates the batch's meshes
     * into a GPU-instancing shard (IFNS wire format) instead of a flat
     * MeshCollection. Repeated geometry collapses to one template + per-
     * occurrence transforms; non-instanceable meshes ride as flat singleton
     * templates so nothing is dropped. The shard stays in the producer-native
     * (IFC Z-up) frame — the renderer composes the constant Z-up→Y-up swap at
     * upload. Each batch shard renders independently: affinity routing already
     * co-locates identical geometry on one worker, so per-batch collation
     * captures ~all the dedup and no cross-batch merge is needed. Returns empty
     * bytes only when the batch produced zero non-empty meshes.
     * Synchronous Rust compatibility entry; this call creates its own live snapshot.
     */
    processGeometryBatchInstanced(data: Uint8Array, jobs_flat: Uint32Array, unit_scale: number, rtc_x: number, rtc_y: number, rtc_z: number, needs_shift: boolean, void_keys: Uint32Array, void_counts: Uint32Array, void_values: Uint32Array, style_ids: Uint32Array, style_colors: Uint8Array, plane_angle_to_radians?: number | null, material_element_ids?: Uint32Array | null, material_color_counts?: Uint32Array | null, material_colors_rgba?: Uint8Array | null): Uint8Array;
    /**
     * Produce a batch ONCE and PARTITION it (the instanced-ONLY path): opaque
     * ordinary occurrences (colour alpha >= 0.99 AND geometry_class == 0) are
     * collated into the instanced shard; everything else (transparent glass,
     * type-product geometry) goes to the flat MeshCollection. Each mesh takes
     * exactly ONE route, so produce_batch runs once (no emit-both 2× meshing)
     * and the renderer draws opaque occurrences via instancing instead of flat.
     * Partition mirrors the renderer gates: INSTANCED_ALPHA_CUTOFF (0.99 =
     * OPAQUE_ALPHA_CUTOFF) for transparency, geometry_class for the Model/Types
     * split.
     *
     * NOTE: the renderer must be instanced-feature-complete (picking / selection
     * / lens overlays on instanced geometry) before the worker calls this in
     * place of processGeometryBatch — otherwise those features break for the
     * opaque bulk. See the instanced-only follow-ups.
     * Synchronous Rust compatibility entry; this call creates its own live snapshot.
     */
    processGeometryBatchPartitioned(data: Uint8Array, jobs_flat: Uint32Array, unit_scale: number, rtc_x: number, rtc_y: number, rtc_z: number, needs_shift: boolean, void_keys: Uint32Array, void_counts: Uint32Array, void_values: Uint32Array, style_ids: Uint32Array, style_colors: Uint8Array, plane_angle_to_radians?: number | null, material_element_ids?: Uint32Array | null, material_color_counts?: Uint32Array | null, material_colors_rgba?: Uint8Array | null): PartitionedBatch;
    /**
     * Like [`IfcAPI::process_geometry_batch_partitioned`] but reads the source
     * bytes held by [`IfcAPI::set_source_bytes`] instead of taking `data`.
     * Byte-for-byte identical output — it delegates to the legacy twin.
     */
    processGeometryBatchPartitionedFromSource(jobs_flat: Uint32Array, unit_scale: number, rtc_x: number, rtc_y: number, rtc_z: number, needs_shift: boolean, void_keys: Uint32Array, void_counts: Uint32Array, void_values: Uint32Array, style_ids: Uint32Array, style_colors: Uint8Array, plane_angle_to_radians?: number | null, material_element_ids?: Uint32Array | null, material_color_counts?: Uint32Array | null, material_colors_rgba?: Uint8Array | null): PartitionedBatch;
    /**
     * Propose IFC walls, slabs, columns and pipes from a scan segmentation
     * report (#6894). `report_json` is the JSON `segmentScanPoints`
     * returned; `options_json` is a camelCase `ScanProposalOptions` object
     * (`{}` for the defaults; `scanToModel` maps the report's frame into the
     * IFC model frame). Returns the UTF-8 JSON `ScanProposalReport` in the
     * model frame (Z up, metres). Pure: loads and changes nothing.
     */
    proposeScanElements(report_json: string, options_json: string): Uint8Array;
    /**
     * Fit bounded manual correspondences in source metres -> IFC world Z-up
     * metres, reporting held-out errors separately. Does not load or move models.
     */
    registerScanCorrespondences(request_json: string): Uint8Array;
    /**
     * Sharded pre-pass: resolve ONE contiguous (file-ordered) slice of the
     * styled-item span list on this worker, against the entity index installed
     * by `setEntityIndex`. Returns raw resolved maps as flat columns:
     * `{ orphanIds, orphanColors (f32 rgba per id), geomIds, geomColors,
     * geomFinishes }`, where `geomFinishes` is the #5582 `[metallic,
     * roughness]` pair per `geomIds` entry (NaN when unauthored), from
     * `resolve_geometry_finishes` over this slice.
     * The host merges shard results IN SHARD ORDER with first-wins per
     * geometry id, reproducing the serial resolver's file-order precedence,
     * then hands the merged columns to `finalizePrepassStyles`.
     * `spans` is `[id, start, len]` triples.
     */
    resolveStyledItemsShard(data: Uint8Array, spans: Uint32Array): any;
    /**
     * Resolve styled-item spans against the installed source and entity index.
     */
    resolveStyledItemsShardFromSource(spans: Uint32Array): any;
    /**
     * Fast entity scanning using SIMD-accelerated Rust scanner
     * Returns array of entity references for data model parsing
     * Much faster than TypeScript byte-by-byte scanning (5-10x speedup)
     *
     * The returned array also carries two own properties describing what the
     * scan refused (#7393): `oversizedIdCount` (records skipped because their
     * express id does not fit u32, #3395) and `malformedRecordCount` (0 or 1:
     * whether a record was dropped for having no terminating `;`, #3695).
     */
    scanEntitiesFast(content: string): any;
    /**
     * Fast entity scanning from raw bytes (avoids TextDecoder.decode on JS side).
     * Accepts Uint8Array directly — saves ~2-5s for 487MB files by skipping
     * JS string creation and UTF-16→UTF-8 conversion.
     *
     * Carries the same `oversizedIdCount` / `malformedRecordCount` array
     * properties as `scanEntitiesFast` (#7393).
     */
    scanEntitiesFastBytes(data: Uint8Array): any;
    /**
     * SPIKE (sharded pre-pass): scan the entity index over a single byte range.
     *
     * Each idle browser geometry worker calls this on its `[range_start,
     * range_end)` shard; the main thread stitches the returned columns into the
     * full entity index (byte-identical to the single-threaded
     * `build_entity_index`) by binary-searching each shard for the previous
     * shard's `handoff`. Delegates to
     * `ifc_lite_processing::scan_shard_classified_with_refusals` — a
     * separately-maintained loop over the same `EntityScanner` primitive as
     * `scan_shard` (the one the native `build_entity_index_parallel` fans across
     * cores), plus a per-record class column this sharded path also needs. The
     * two loops' records/handoff are kept in parity by a dedicated test
     * (`rust/processing/tests/issue_2053_shard_scan_parity.rs`), not by
     * delegation — edit one without the other and that test catches the drift.
     *
     * Byte offsets returned are GLOBAL (relative to file start), so shards
     * concatenate without rewriting. Returns a plain object:
     *   `{ ids: Uint32Array, starts: Uint32Array, lengths: Uint32Array,
     *      classes: Uint8Array, handoff: number,
     *      oversizedIdStarts: Uint32Array }`
     * where `classes` is the parallel per-record prepass class byte
     * (`PREPASS_CLASS_*`: named code in the low bits plus the geometry-job /
     * type-candidate flags) the host filters on to rebuild pre-pass span
     * lists, and `handoff` is the global start of the first entity at/after
     * `range_end` (the next shard's first real entity), or `-1` at EOF.
     *
     * `oversizedIdStarts` carries the global start byte of every record this
     * shard refused for an express id above `u32::MAX` (#3395). Offsets, not
     * a count, and deliberately NOT reported from here: a shard begins at an
     * arbitrary byte, so it can start inside a quoted value and refuse a
     * string literal shaped like `#4294967297=IFCWALL(` — text no file
     * declared. Reporting per shard would warn "skipped N records" on a file
     * that is fine. The host's stitch keeps only the offsets at/after the
     * retained boundary it computed for this shard and reports once, which is
     * what makes the number attributable to a record the stitch retained
     * (#3430).
     */
    scanEntityIndexShard(data: Uint8Array, range_start: number, range_end: number): any;
    /**
     * Scan a shard of the source installed by `setSourceBytes`.
     */
    scanEntityIndexShardFromSource(start: number, end: number): any;
    /**
     * Fast geometry-only entity scanning
     * Scans only entities that have geometry, skipping 99% of non-geometry entities
     * Returns array of geometry entity references for parallel processing
     * Much faster than scanning all entities (3x speedup for large files)
     */
    scanGeometryEntitiesFast(content: string): any;
    /**
     * Detect planes and cylinders (columns, pipes) in a point cloud (#6870). `positions` are xyz f32 metres
     * (at most 100,000,000 points); `options_json` is a camelCase
     * `ScanSegmentationOptions` object (`{}` for the defaults). Returns the
     * UTF-8 JSON `ScanSegmentationReport`. Pure: loads and changes nothing.
     */
    segmentScanPoints(positions: Float32Array, options_json: string): Uint8Array;
    /**
     * Enable or disable per-entity geometry fingerprinting in
     * `processGeometryBatch`, used by the viewer's revision-diff feature.
     *
     * Pass a positive `tolerance` (metres) to enable — the quantization grid
     * positions snap to (larger tolerates more float noise, smaller catches
     * finer edits; below the `f32` precision floor of model-local coordinates,
     * ~1 mm, mostly hashes noise). Finer than
     * `ifc_lite_geometry::MIN_GEOM_HASH_TOLERANCE` (1e-6 m) is clamped up to it
     * — see that constant's doc for why (an `i128` overflow surface, not a
     * precision win). `null`/`undefined`/non-positive disables. Default: off.
     */
    setComputeGeometryHashes(tolerance?: number | null): void;
    /**
     * Populate `cached_entity_index` from pre-extracted column arrays.
     *
     * Used by the streaming pre-pass to share its already-built entity
     * index across worker realms via SAB-backed Uint32Arrays — every
     * process worker would otherwise re-scan the entire file in
     * `processGeometryBatch`'s lazy build path (~5 s on a 1 GB IFC),
     * even though the pre-pass worker built the same index minutes
     * earlier.
     *
     * Adopts the three binding-owned columns into a compact [`ColumnarEntityIndex`]
     * (sorted `u32` columns + binary search) instead of a per-worker
     * `FxHashMap` — ~229 MB vs ~436 MB on a 19.1 M-entity model (#1682).
     * [`ColumnarEntityIndex::from_owned_columns`] verifies the id ordering once
     * (O(n)) and only argsorts if the producer did not emit sorted columns.
     *
     * `lengths[i]` is the byte length of entity `ids[i]`, so lookup returns
     * `(start, start + length)` to match the existing `(start, end)` layout.
     *
     * Idempotent in the sense that repeated calls REPLACE the cache —
     * supports the parser-worker pattern of reusing one IfcAPI across
     * multiple loads with different files.
     *
     * Throws when the three columns disagree in length. Every call is a
     * content swap, a rejected one included: the previous file's index,
     * content-scoped caches and pipeline diagnostics are dropped before the
     * error is raised, and a rejected or empty index leaves no index, so the
     * next batch scans the bytes it is given.
     */
    setEntityIndex(ids: Uint32Array, starts: Uint32Array, lengths: Uint32Array): void;
    /**
     * Install the pre-computed set of type ids that an `IfcRelDefinesByType`
     * instantiates (#957 follow-up), so the worker's first type-product batch
     * skips the per-worker [`Self::get_or_build_instantiated_type_ids`]
     * full-file walk. Same injection contract as [`Self::set_referenced_repmaps`].
     */
    setInstantiatedTypeIds(ids: Uint32Array): void;
    /**
     * Install the pre-computed #1623 Phase 3 don't-bake plan: the flat list of
     * `IfcRepresentationMap` ids that an `IfcMappedItem` instantiates >= 2 times.
     * The streaming pre-pass tallies it in the SAME scan that builds the referenced-
     * repmap set (`styling::build_mapped_instance_plan_from_spans`) and ships the id
     * list here. The batch path arms its router with it (batch-local template mode),
     * so a repeated single-solid mapped source materializes ONCE per batch and the
     * rest ride as instances in the IFNS shard.
     *
     * Same injection contract as [`Self::set_referenced_repmaps`]: installed after
     * `setEntityIndex` (which clears it on content swap), and a no-op absence leaves
     * the batch path materializing every occurrence (byte-identical). Each id is
     * stored as `(2, id)` — the batch-local router only needs the eligibility set
     * (count >= 2); the min-id template slot is unused in batch-local mode.
     */
    setMappedInstancePlan(source_ids: Uint32Array): void;
    /**
     * Install the pre-computed [`ifc_lite_geometry::MaterialLayerIndex`] (#563)
     * from its flat SoA encoding, so the worker's first batch skips the
     * per-worker [`Self::get_or_build_material_layer_index`] full-file decode
     * scan (the dominant first-batch cost on layered architectural models,
     * which run this on the DEFAULT view). The streaming pre-pass built the
     * index once from the `IfcRelAssociatesMaterial` spans it already scanned
     * (`MaterialLayerIndex::from_spans`) and flat-encoded it here; the flat
     * encoding round-trips bit-for-bit (proven in `material_layer_index` tests),
     * so the injected index equals each worker's `from_content` result.
     *
     * Same injection contract as [`Self::set_referenced_repmaps`]: installed
     * after `setEntityIndex`, and a no-op absence leaves the lazy build intact.
     */
    setMaterialLayerIndex(element_ids: Uint32Array, axis: Uint32Array, layer_counts: Uint32Array, direction_sense: Float64Array, offset: Float64Array, layer_material_ids: Uint32Array, layer_thicknesses: Float64Array): void;
    /**
     * Toggle the "render multilayer walls as a single solid" mode (issue #540).
     *
     * When `enabled` is `true`, every subsequent `processGeometryBatch` call
     * will suppress geometry emission for `IfcBuildingElementPart` entities
     * whose `IfcRelAggregates` parent wall is sliceable (has an
     * `IfcMaterialLayerSetUsage`) AND has its own `Representation`. The
     * parent wall keeps its per-layer sub-mesh colouring, so the visual
     * result is the same as the layered render but with one mesh per wall
     * instead of one per layer part — much cheaper for both CPU and GPU.
     *
     * Default is `false`. Pass `true` before calling `processGeometryBatch`.
     */
    setMergeLayers(enabled: boolean): void;
    /**
     * Sharded pre-pass (#5582): stash the shard-merged geometry finishes —
     * the `geomFinishes` columns `resolveStyledItemsShard` returns, merged
     * first-wins like `geomColors` — for the next `finalizePrepassStyles` /
     * `finalizePrepassStylesFromSource` call on this instance, which consumes
     * them and emits the aligned `styleFinishes`. Without this call that
     * finalize emits NaN finishes, as it always emitted colours only.
     */
    setPrepassGeometryFinishes(geom_ids: Uint32Array, geom_finishes: Float32Array): void;
    /**
     * Enable or disable the PARAMETRIC rectangular-opening fast path (the
     * placement-frame, ground-truth-exact analytic cut) for `processGeometryBatch`.
     *
     * DEFAULT ON (corpus-validated; native defaults ON too, and wasm has no env to
     * read `IFC_LITE_RECT_PARAM`, so both targets default in LOCKSTEP -- the
     * byte-identical native==wasm contract requires both take the same path). This
     * toggle is the wasm-side escape hatch mirroring `IFC_LITE_RECT_PARAM=0`.
     * The path subtracts rectangular openings as exact parametric boxes in the host's
     * own placement frame (rotated walls included), deferring any non-clean case to
     * the exact kernel. Pass `false` before `processGeometryBatch` to opt out.
     */
    setRectParamFastPath(enabled: boolean): void;
    /**
     * Install the pre-computed set of `IfcRepresentationMap` ids referenced by
     * an `IfcMappedItem` (issue #957), so the worker's first type-product batch
     * SKIPS the per-worker [`Self::get_or_build_referenced_repmaps`] full-file
     * walk. The streaming pre-pass built the same set once from the
     * `IfcMappedItem` spans it already scanned (see
     * `styling::build_referenced_representation_maps_from_spans`) and ships the
     * id list here — bit-identical to what each worker would compute, since a
     * set's membership is order-invariant and consumers only call `.contains`.
     *
     * Installed AFTER `setEntityIndex` (which clears this cache on content
     * swap), so the injected value survives. When this setter is never called
     * (native path, non-streaming callers), the lazy build path is unchanged.
     */
    setReferencedRepmaps(ids: Uint32Array): void;
    /**
     * Toggle the tier-independent small-cut skip (#1286). When `true`,
     * `processGeometryBatch` drops `IfcBooleanResult` differences whose cutter is
     * tiny relative to its host (steel copes/notches) while keeping the
     * tessellation tier — so curves stay full-density. The viewer enables this for
     * the on-screen load; exports/drawings leave it off so their geometry keeps
     * every cut. Default off ⇒ byte-identical to before.
     *
     * Set BEFORE processing — meshes already emitted are not regenerated.
     */
    setSkipSmallCuts(on: boolean): void;
    /**
     * Store the whole IFC source file ONCE per load so the `*FromSource` batch
     * variants can read it from the wasm heap instead of re-copying it per call.
     *
     * Mirrors the `setEntityIndex` lifecycle: called once per worker per load,
     * and REPLACES the previous file wholesale (repeated calls swap the bytes),
     * so a parser/geometry worker reusing one `IfcAPI` across loads is safe.
     * The bytes must be the exact source the batch jobs' byte spans index into
     * (the same buffer passed as `data` to the legacy `processGeometryBatch*`),
     * or the decoded entities won't match — the JS worker installs its own
     * session buffer, so this holds by construction.
     *
     * Taking `Vec<u8>` (by value) means wasm-bindgen hands us ownership of the
     * single JS→wasm copy directly; we wrap it in `Arc` with no second copy.
     */
    setSourceBytes(data: Uint8Array): void;
    /**
     * Install the prepass's authored metallic/roughness per style (#5582):
     * `styleFinishes` carries two floats per `styleIds` entry,
     * `[metallic, roughness]`, NaN for an unauthored field — the
     * `styleFinishes` array every prepass result carries beside `styleColors`.
     * Call it with the same `styleIds` later passed to `processGeometryBatch*`;
     * finishes set for a different style wire are ignored. Empty arrays clear
     * them. Malformed lengths never throw: a style without a complete pair
     * simply gets no finish.
     *
     * The batch stamps each returned `MeshDataJs` (`metallic` / `roughness`)
     * from these, taking each mesh's finish from the style its colour came
     * from (#5984). Occurrences that ride the instanced (IFNS) shard carry
     * theirs in the shard's per-instance finish field (v3).
     */
    setStyleFinishes(style_ids: Uint32Array, style_finishes: Float32Array): void;
    /**
     * Select the tessellation detail level applied by every subsequent
     * `processGeometryBatch` call (issue #976, step 4).
     *
     * `level` is one of `"lowest" | "low" | "medium" | "high" | "highest"`
     * (case-insensitive). `"medium"` is the default and reproduces the
     * engine's historical hardcoded densities byte-for-byte; lower levels
     * trade curved-surface smoothness for throughput, higher levels reduce
     * faceting on pipes / cylinders / NURBS at a triangle-count cost.
     * Pass `null`/`undefined` to reset to the default.
     *
     * Set BEFORE processing — meshes already emitted are not regenerated.
     * Throws on an unrecognized level so typos fail loudly instead of
     * silently rendering at the wrong density.
     */
    setTessellationQuality(level?: string | null): void;
    /**
     * Simplify already-produced element meshes at per-element demesher
     * levels (1-4 = cavity removal + clustering at 0.5/0.25/0.10/0.03
     * triangle ratio, 5 = bounding box).
     *
     * One RECORD per input `MeshData` entry (an element may span several
     * records — per-material submeshes; pass all of them, grouped or not).
     * Per record `i`: `vertexCounts[i]` vertices from `positions` (and
     * `normals` when non-empty), `indexCounts[i]` indices from `indices`
     * (per-record local), `origins[i*3..]`, `localToWorld[i*16..]` valid
     * only when `localToWorldPresent[i] != 0`, level `levels[i]` (records
     * of one element must agree). Arrays are the boundary Y-up convention
     * when `yUp` is true (the browser/SDK case).
     *
     * `rtcX/Y/Z` = `coordinateInfo.originShift` (IFC Z-up metres);
     * `unitScale` = metres per project length unit.
     */
    simplifyMeshes(express_ids: Uint32Array, levels: Uint8Array, positions: Float32Array, normals: Float32Array, indices: Uint32Array, vertex_counts: Uint32Array, index_counts: Uint32Array, origins: Float64Array, local_to_world: Float64Array, local_to_world_present: Uint8Array, rtc_x: number, rtc_y: number, rtc_z: number, unit_scale: number, y_up: boolean): SimplifiedMeshes;
    /**
     * Check if API is initialized
     */
    readonly is_ready: boolean;
    /**
     * Get version string
     */
    readonly version: string;
}

export class LandXmlTinStreamSession {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(): void;
    advanceChunk(data: Uint8Array): void;
    /**
     * Drain only after the renderer has credited this many transport bytes.
     */
    drain(max_bytes: number): any;
    finish(): any;
    /**
     * Start the resumable metadata cursor. Consumers must continue draining
     * until [`Self::output_pending`] is false, then abort/free the session.
     */
    finishCursor(): void;
    header(): any;
    /**
     * Whether the host must grant more credited output drain capacity.
     */
    outputPending(): boolean;
    /**
     * Exact serialized transport bytes currently retained by the Rust queue.
     */
    queuedBytes(): number;
    /**
     * Complete credited transport records currently retained by the Rust queue.
     */
    queuedEvents(): number;
}

/**
 * Collection of mesh data for returning multiple meshes
 */
export class MeshCollection {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get mesh at index (clones — non-destructive). Prefer `takeMesh` on the
     * hot streaming path; this stays for callers that read meshes more than once.
     */
    get(index: number): MeshDataJs | undefined;
    /**
     * Check if an RTC offset was applied to these meshes (any non-zero
     * component). It can be inside 10 km: the placement-bounds fallback
     * re-bases on the bbox centre when a corner is past 10 km (#4643).
     */
    hasRtcOffset(): boolean;
    /**
     * #1097 perf: MOVE the mesh at `index` out of the collection (the Vec
     * buffers are `std::mem::take`-n, leaving an empty stub). The streaming
     * worker reads each mesh exactly once, so moving avoids the full vertex-
     * data clone `get` pays — one fewer copy of positions/normals/indices/uvs/
     * texture per mesh (the JS getters still do the single Rust→JS copy). Calling
     * it twice for the same index yields the second call a DEFAULT mesh:
     * `expressId` 0 and every buffer empty, rather than the metadata-bearing
     * husk the hand-written copy used to leave. The method is read-once by
     * contract and the wasm-contract test pins this.
     */
    takeMesh(index: number): MeshDataJs | undefined;
    /**
     * Get building rotation angle in radians (from IfcSite placement)
     * Returns None if no rotation was detected
     */
    readonly buildingRotation: number | undefined;
    /**
     * The batch's typed CSG / opening diagnostics as a JS object (the
     * `GeometryDiagnostics` contract), or `undefined` if none were recorded. The
     * worker merges these across batches. One serialized value keeps the rich
     * nested shape as a single FFI crossing instead of dozens of getters.
     */
    readonly diagnostics: any;
    /**
     * Per-entity world-space AABBs as a `Float64Array`, SIX values per entry
     * (`minx, miny, minz, maxx, maxy, maxz`), in the same order as
     * [`Self::geometry_hash_ids`] — entry `i` spans `[6*i, 6*i+6)`. Empty
     * unless geometry hashing was enabled; the same
     * `IfcAPI.setComputeGeometryHashes` switch gates both, so nothing is
     * computed when the diff feature is off.
     *
     * Unquantized world `f64` (the file's RTC folded back in), so two
     * revisions that chose different RTC offsets report the same box. This is
     * what lets a consumer say "MOVED" honestly instead of inferring it from a
     * changed hash, which also fires on reshape and on retriangulation.
     *
     * **Frame: WebGL Y-up**, like every other box, position, origin and
     * placement that crosses this boundary (see `MeshDataJs::local_bounds`).
     * The hasher accumulates in the producer's IFC Z-up frame, so the swap
     * `(x,y,z) -> (x,z,-y)` is applied here, on the way out. Unconverted, the
     * boxes would not enclose the very meshes `processGeometryBatch` returns
     * alongside them. Positions are RTC-relative and this box is absolute, so
     * a consumer comparing the two folds `rtcOffset*` in — itself Y-up-swapped.
     *
     * Present for every hashed entity. Its companion
     * [`Self::geometry_volume_values`] is not — see there.
     */
    readonly geometryAabbValues: Float64Array;
    /**
     * Per-entity topology verdict as a `Uint8Array`, one packed byte per entry
     * in [`Self::geometry_hash_ids`] order:
     *
     * * bit 0 (`1`) — every segment closed (no boundary / non-manifold edge)
     * * bit 1 (`2`) — every segment orientable
     * * bit 2 (`4`) — every segment a single connected component
     * * bit 3 (`8`) — the entity produced exactly one segment
     *
     * `0x0F` is exactly the set that carries a volume in
     * [`Self::geometry_volume_values`]. The individual bits are the diagnosis:
     * a model checker can distinguish "this wall is an open shell" (bit 0
     * clear) from "this door is a multi-item assembly whose parts may overlap"
     * (bit 3 clear), which are different findings with different fixes.
     */
    readonly geometryClosureFlags: Uint8Array;
    /**
     * Number of per-entity geometry fingerprints recorded.
     */
    readonly geometryHashCount: number;
    /**
     * Express ids for the per-entity geometry fingerprints, parallel to
     * [`Self::geometry_hash_values`]. Empty unless geometry hashing was
     * enabled via `IfcAPI.setComputeGeometryHashes`.
     */
    readonly geometryHashIds: Uint32Array;
    /**
     * Per-entity geometry fingerprints as a `BigUint64Array`, parallel to
     * [`Self::geometry_hash_ids`]. `u64` is exposed (not hex strings) so JS
     * can compare with `===` and key maps without allocation. Empty unless
     * geometry hashing was enabled.
     */
    readonly geometryHashValues: BigUint64Array;
    /**
     * Per-entity enclosed volume in CUBIC METRES as a `Float64Array`, one
     * value per entry in [`Self::geometry_hash_ids`] order. `NaN` means NO
     * TRUSTWORTHY VOLUME — the same absent convention as
     * [`Self::geometry_aabb_values`] — and it is `NaN` for roughly a third of
     * entities by design, not by failure.
     *
     * A value is emitted only when that entity's produced geometry was
     * PROVABLY a single closed, orientable, single-component solid, as decided
     * by the mesher's own orientation pass. Read
     * `ifc_lite_geometry::GeometryHasher::volume` before treating a `NaN` as a
     * bug: an open `SurfaceModel`, a material-layered wall (whose slices are
     * open bands by construction), and any element assembled from more than one
     * representation item all correctly report nothing rather than a plausible
     * wrong number. [`Self::geometry_closure_flags`] says which.
     *
     * This is NOT a substitute for an IFC `BaseQuantities` `GrossVolume`: it is
     * the volume of the geometry that was actually meshed, after opening cuts,
     * and it says nothing about whether a CSG degradation left the host uncut
     * (see the `diagnostics` getter).
     */
    readonly geometryVolumeValues: Float64Array;
    /**
     * Get number of meshes
     */
    readonly length: number;
    /**
     * Get RTC offset X (for converting local coords back to world coords)
     * Add this to local X coordinates to get world X coordinates
     */
    readonly rtcOffsetX: number;
    /**
     * Get RTC offset Y
     */
    readonly rtcOffsetY: number;
    /**
     * Get RTC offset Z
     */
    readonly rtcOffsetZ: number;
    /**
     * Get total triangle count across all meshes
     */
    readonly totalTriangles: number;
    /**
     * Get total vertex count across all meshes
     */
    readonly totalVertices: number;
}

/**
 * Individual mesh data with express ID and color (matches MeshData interface)
 *
 * `Clone` is derived so the three sites that used to enumerate all 21 fields
 * by hand -- `get`, `takeMesh` and `MeshCollection`'s own `Clone` -- reduce to
 * `.cloned()`, `mem::take` and `.clone()`. Adding a field to #3199 meant
 * editing three literals in lockstep; the allowlist row for this file records
 * exactly that cost.
 *
 * To be precise about what this does and does not buy, because the obvious
 * claim is wrong: an exhaustive struct literal that OMITS a field is a compile
 * error, so those literals were never silently lossy. What they were is three
 * places to edit for one field, and `..Default::default()` is the shortcut a
 * hurried author reaches for when the compiler complains -- which WOULD be
 * silently lossy. `Default` is what makes `takeMesh` a one-liner, so the rule
 * is: TWO literals remain, `new` and `Default` below (both spelled
 * `Self { .. }`, which is why a grep for `MeshDataJs {` finds neither). Both
 * must stay exhaustive AND must agree on every field `new` does not take as an
 * argument. The compiler catches an omitted field in either; it cannot catch
 * the two DISAGREEING, which is the failure the pair exists to prevent, so
 * `default_agrees_with_new_on_the_fields_new_does_not_take` covers that.
 * Never spread `Default` into `new` -- `new` is the only place a field's
 * initial value is decided, so a field defaulted there is inert everywhere.
 */
export class MeshDataJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get color as [r, g, b, a] array
     */
    readonly color: Float32Array;
    /**
     * Get express ID
     */
    readonly expressId: number;
    /**
     * Geometry provenance for the viewer's Model/Types switch (#957 follow-up):
     * 0 = occurrence, 1 = orphan type geometry (no occurrence), 2 = instanced
     * type geometry (hidden in Model mode, shown in Types mode).
     */
    readonly geometryClass: number;
    /**
     * Source `IfcRepresentationItem`, or `undefined` where identity is merged
     * away. Never set alongside `materialId` (#3199).
     */
    readonly geometryItemId: number | undefined;
    /**
     * True when this mesh carries a surface texture (#961).
     */
    readonly hasTexture: boolean;
    /**
     * Get IFC type name (e.g., "IfcWall", "IfcSpace")
     */
    readonly ifcType: string;
    /**
     * Get indices as Uint32Array (copy to JS)
     */
    readonly indices: Uint32Array;
    /**
     * Local (pre-placement, object-space) AABB (issue #1474), WebGL Y-up,
     * `[minX,minY,minZ,maxX,maxY,maxZ]`. `undefined` when not captured
     * (wasm-bindgen maps `Option::None` to `undefined`, not `null`).
     */
    readonly localBounds: Float32Array | undefined;
    /**
     * The resolved `IfcLocalPlacement` chain for this mesh (issue #1474),
     * row-major 4×4, WebGL Y-up. `undefined` when not captured (see
     * `local_bounds` above).
     */
    readonly localToWorld: Float64Array | undefined;
    /**
     * `IfcMaterial` layer sliced, or `undefined` (#3199).
     */
    readonly materialId: number | undefined;
    /**
     * IFC-authored metallic/roughness (#5582). `undefined` when unauthored.
     */
    readonly metallic: number | undefined;
    /**
     * Get normals as Float32Array (copy to JS)
     */
    readonly normals: Float32Array;
    /**
     * Per-element local-frame origin (Float64Array[3], WebGL Y-up, metres):
     * world position of vertex i = `origin + positions[3i..3i+3]`. Returns
     * [0,0,0] when positions are absolute (legacy / local frame off).
     */
    readonly origin: Float64Array;
    /**
     * Get positions as Float32Array (copy to JS)
     */
    readonly positions: Float32Array;
    readonly roughness: number | undefined;
    /**
     * Optional SurfaceColour for the "Shading" GLB-export choice — only
     * present when the file authored a distinct DiffuseColour. JS sees
     * `undefined` when absent (most files).
     */
    readonly shadingColor: Float32Array | undefined;
    readonly textureHeight: number;
    /**
     * Stable texture dedup key (`IfcSurfaceTexture` express id, #1781).
     * 0 when the mesh is untextured.
     */
    readonly textureId: number;
    /**
     * Sampler wrap for the S axis (`IfcSurfaceTexture.RepeatS`): true = repeat.
     */
    readonly textureRepeatS: boolean;
    /**
     * Sampler wrap for the T axis (`IfcSurfaceTexture.RepeatT`): true = repeat.
     */
    readonly textureRepeatT: boolean;
    /**
     * Decoded RGBA8 texture bytes (`width*height*4`). Empty when untextured.
     */
    readonly textureRgba: Uint8Array;
    /**
     * External image reference (`IfcImageTexture.URLReference`, #1781) for the
     * host to resolve — e.g. a sibling image inside the `.ifcZIP`. `undefined`
     * for untextured meshes and Rust-decoded blob/pixel textures.
     */
    readonly textureUrl: string | undefined;
    readonly textureWidth: number;
    /**
     * Get triangle count
     */
    readonly triangleCount: number;
    /**
     * Per-vertex texture coordinates as Float32Array (u, v pairs). Empty when
     * the mesh is untextured.
     */
    readonly uvs: Float32Array;
    /**
     * Get vertex count
     */
    readonly vertexCount: number;
}

/**
 * A mesh's projected footprint outline.
 *
 * Contours are closed rings in drawing 2D space (same basis as `projectTo2D`
 * in `@ifc-lite/drawing-2d`), WITHOUT a duplicated closing vertex.
 * `axisMin`/`axisMax` are the element's extent along the cut axis (world
 * units, not flip-adjusted) for band classification on the TS side.
 */
export class MeshOutlineJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Ring `i` as a flat `[u0, v0, u1, v1, …]` array, or `undefined` if out of
     * range. The ring is closed implicitly (connect the last point to the
     * first).
     */
    contour(index: number): Float32Array | undefined;
    /**
     * Element extent (max) along the cut axis, world units.
     */
    readonly axisMax: number;
    /**
     * Element extent (min) along the cut axis, world units.
     */
    readonly axisMin: number;
    /**
     * Number of boundary rings (outer + holes).
     */
    readonly contourCount: number;
}

/**
 * Result of [`IfcAPI::process_geometry_batch_partitioned`]: the flat
 * MeshCollection (transparent + type geometry) and the instanced IFNS shard
 * (opaque ordinary occurrences) from ONE produce_batch. Take-once accessors so
 * the JS side moves each out without a clone.
 */
export class PartitionedBatch {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The flat MeshCollection (transparent glass + type-product geometry).
     * Moves out — call once.
     */
    takeMeshes(): MeshCollection | undefined;
    /**
     * The instanced IFNS shard bytes (opaque ordinary occurrences). Moves out.
     */
    takeShard(): Uint8Array;
    /**
     * Number of occurrences routed into the instanced shard this batch. The viewer
     * folds this into its total mesh count so the count reflects ALL rendered
     * geometry (flat + instanced), not just the flat MeshCollection.
     */
    readonly instancedOccurrences: number;
}

/**
 * A collection of extracted profiles.
 */
export class ProfileCollection {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get profile at `index`.  Returns `undefined` for out-of-bounds index.
     */
    get(index: number): ProfileEntryJs | undefined;
    /**
     * Number of profiles.
     */
    readonly length: number;
    /**
     * Express IDs of elements that had an `IfcExtrudedAreaSolid` (direct or
     * mapped) but whose profile could not be extracted, so they are MISSING
     * from this collection. Empty on a clean model.
     */
    readonly skippedExpressIds: Uint32Array;
}

/**
 * A single profile entry – raw 2D polygon + world transform.
 *
 * Profile points are in **local 2D profile space** (metres).
 * Apply `transform` to `[x, y, 0, 1]` to get WebGL Y-up world coordinates.
 */
export class ProfileEntryJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Express ID of the building element.
     */
    readonly expressId: number;
    /**
     * Extrusion depth (metres).
     */
    readonly extrusionDepth: number;
    /**
     * Extrusion direction `[dx, dy, dz]` in WebGL Y-up world space (unit vector).
     */
    readonly extrusionDir: Float32Array;
    /**
     * Number of points per hole.
     */
    readonly holeCounts: Uint32Array;
    /**
     * All hole points concatenated: `[x0, y0, x1, y1, …]` (metres).
     */
    readonly holePoints: Float32Array;
    /**
     * IFC type name (e.g., `"IfcWall"`).
     */
    readonly ifcType: string;
    /**
     * Model index for multi-model federation.
     */
    readonly modelIndex: number;
    /**
     * Outer boundary: flat `[x0, y0, x1, y1, …]` in local profile space (metres).
     */
    readonly outerPoints: Float32Array;
    /**
     * 4 × 4 column-major transform in WebGL Y-up world space.
     * `M * [x, y, 0, 1]ᵀ` gives the world position.
     */
    readonly transform: Float32Array;
}

/**
 * The traced outline. Owns wasm memory: call `free()`.
 */
export class ScanOutlineJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Every ring's plane coordinates concatenated, `[u0, v0, u1, v1, …]`.
     */
    coords(): Float64Array;
    /**
     * What the run did: cell size, cap hits, ring counts, repairs.
     */
    diagnostics(): ScanOutlineDiagnosticsJs;
    /**
     * Vertex count of each ring, in `coords()` order.
     */
    ringLengths(): Uint32Array;
    /**
     * The ring directly containing each ring (a hole's outer boundary, an
     * island's hole), or `-1` at top level.
     */
    ringParents(): Int32Array;
    /**
     * Ring index at which each shape starts; entry `s` is shape `s`'s outer
     * ring and the rings up to the next entry are its holes.
     */
    shapeOffsets(): Uint32Array;
    /**
     * Every ring mapped through the plane frame, `[x0, y0, z0, …]` in
     * `coords()` order, or `undefined` when no frame was given.
     */
    worldCoords(): Float64Array | undefined;
    /**
     * Total number of rings (outer boundaries and holes).
     */
    readonly ringCount: number;
    /**
     * Number of outer boundaries.
     */
    readonly shapeCount: number;
}

/**
 * Flat result of `simplifyMeshes`: per surviving element `i`,
 * `vertexCounts[i]` vertices and `indexCounts[i]` indices taken in order
 * from the concatenated arrays (mirrors the `exportGlbFromMeshes` wire
 * convention). `localPositions` is 1:1 with `renderPositions` (f64, file
 * units, element object frame); `localIndices` is 1:1 with `renderIndices`
 * but in the IFC frame's winding. Skipped elements are reported in
 * `skippedIds` / `skippedReasons` and must keep their original geometry.
 */
export class SimplifiedMeshes {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly cavitiesDropped: Uint32Array;
    readonly elementIds: Uint32Array;
    readonly indexCounts: Uint32Array;
    readonly levels: Uint8Array;
    readonly localIndices: Uint32Array;
    readonly localPositions: Float64Array;
    readonly renderIndices: Uint32Array;
    readonly renderNormals: Float32Array;
    /**
     * xyz per element (frame matches the render positions' convention).
     */
    readonly renderOrigins: Float64Array;
    readonly renderPositions: Float32Array;
    readonly skippedIds: Uint32Array;
    /**
     * Skip reason per `skippedIds` entry (stable slugs:
     * `no-geometry` / `missing-placement` / `singular-placement` /
     * `empty-result` / `invalid-unit-scale`).
     */
    readonly skippedReasons: any[];
    readonly trisAfter: Uint32Array;
    readonly trisBefore: Uint32Array;
    readonly vertexCounts: Uint32Array;
}

/**
 * A persistent, editable floor-plate topology. See the module docs.
 */
export class SpacePlateHandle {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Author a new room from a flat ring `[x0, y0, x1, y1, …]` (no repeated
     * closing vertex). `source` `-1` marks a user-drawn room. Winding is
     * normalised to CCW; returns the new room patch. The room is its own
     * connected component — it does not merge into existing topology.
     */
    addFace(coords: Float64Array, source: number): any;
    /**
     * Bounding half-edges of a face paired with their source element —
     * `[{ edge, source }, …]` — for `IfcRelSpaceBoundary` at bake.
     */
    boundingElements(face: number): any;
    /**
     * Dissolve a degree-2 vertex, welding its two edges into one straight
     * edge between the neighbours — the inverse of `splitEdge`, and the
     * "delete this corner / node" affordance. Returns the rooms it changed.
     * Rejects a wall junction (degree ≥ 3) or a weld that would duplicate an
     * edge.
     */
    dissolveVertex(v: number): any;
    /**
     * Move a vertex; returns the rooms it changed. A shared wall is one edge
     * whose endpoints are shared vertices, so one drag updates both rooms.
     */
    dragVertex(v: number, x: number, y: number): any;
    /**
     * Deep-copy the plate for an undo/redo snapshot. The clone owns its own
     * heap; the caller must `.free()` it like any handle.
     */
    duplicate(): SpacePlateHandle;
    /**
     * Absolute area (m²) of a face.
     */
    faceArea(face: number): number;
    /**
     * Flat outline `[x0, y0, x1, y1, …]` of a face (no repeated closing vertex).
     */
    faceOutline(face: number): Float64Array;
    /**
     * Nearest live vertex id to `(x, y)` within `tol`, or `undefined`.
     */
    findVertexNear(x: number, y: number, tol: number): number | undefined;
    /**
     * FACE-BASED build: rooms are the gaps between wall footprint rectangles.
     * `rectCoords` is flat `[x0, y0, x1, y1, x2, y2, x3, y3, …]` — 8 f64 per wall
     * (its 4 plan-rectangle corners, CCW). A bounded arrangement face is a room
     * only if its centroid is outside every rectangle (a gap, not a wall
     * interior). The room outline IS the net (inner-face) area; `gapBoundary`
     * gives the centre axis (½ thickness) and the gross outer face.
     */
    static fromWallRects(rect_coords: Float64Array, snap_tolerance: number, min_area: number): SpacePlateHandle;
    /**
     * Face-based gap-room boundary as flat `[x0, y0, …]`: each edge pushed
     * OUTWARD (into the wall) by `factor × the source wall's half-thickness`.
     * `0` → net (the gap / inner faces); `1` → centre axis (½ thickness, the
     * editable node line on the wall mid); `2` → gross outer face.
     */
    gapBoundary(face: number, factor: number): Float64Array;
    /**
     * Remove a shared wall, unioning the two rooms it separated. Returns the
     * surviving room.
     */
    mergeFaces(edge: number): any;
    /**
     * The room on the far side of a half-edge (its twin's face), or
     * `undefined`. O(1) — the "who's across this wall" query.
     */
    neighborAcross(edge: number): number | undefined;
    /**
     * The face outline offset to a wall boundary, as flat `[x0, y0, …]`: each
     * edge is moved by its own wall's half-thickness — inward when `inset`
     * (the net / inner face), outward otherwise (the gross / outer face).
     * Shared room↔room edges are pinned when pushing outward. Falls back to the
     * centreline outline when no offset applies — so it's always a sane ring.
     * (For a `center` boundary just use `faceOutline`.)
     */
    netOutline(face: number, inset: boolean): Float64Array;
    /**
     * Build a plate from flat wall-axis segments.
     *
     * `segCoords`: `[ax, ay, bx, by, …]` (length a multiple of 4).
     * `segSources`: one `i32` per segment, `-1` for none.
     * `segHalfThickness`: one `f64` per segment — half the wall's thickness in
     * metres, carried onto the derived edges for `netOutline`. Pass an empty
     * array (or all zeros) when thickness is unknown (centreline only).
     * `snapTolerance` / `minArea`: pass `<= 0` to take the defaults.
     */
    constructor(seg_coords: Float64Array, seg_sources: Int32Array, seg_half_thickness: Float64Array, snap_tolerance: number, min_area: number);
    /**
     * Sweep the whole plate clean: remove dangling spur walls, isolated nodes,
     * and redundant collinear nodes — the "clean up orphans" / eraser action.
     * Area-neutral and idempotent. Returns how many topology elements were
     * pruned (0 = the plate was already clean); the caller re-renders via
     * `snapshot` like any other edit.
     */
    prune(): number;
    /**
     * Remove a wall edge, choosing the right semantics from its two faces:
     * two real rooms → union them; a bridge / spur / outer-only wall → delete
     * it and auto-clean the orphaned inner lines and nodes it leaves; a real
     * enclosing wall (room ↔ exterior) → rejected (`BordersExterior`). This is
     * the "remove this wall and tidy up" affordance for the orphan cruft the
     * non-destructive wall arrangement leaves behind. Returns the rooms it
     * changed (empty if the edge bounded no room).
     */
    removeEdge(edge: number): any;
    /**
     * Face ids of every live room.
     */
    roomIds(): Uint32Array;
    /**
     * Set a face's floor / ceiling planes (the vertical dimension that turns a
     * 2D face into a prismatic space at bake).
     */
    setFaceHeight(face: number, floor_z: number, ceiling_z: number, non_planar: boolean): void;
    /**
     * All live rooms as `{ face, area, simple, outline }` patches.
     */
    snapshot(): any;
    /**
     * Insert a new vertex at `(x, y)` on edge `edge`, subdividing it (no new
     * face). Returns the new vertex id — use it as a `splitFace` endpoint to
     * cut between points that weren't existing corners. Project `(x, y)` onto
     * the edge to keep areas unchanged.
     */
    splitEdge(edge: number, x: number, y: number): number;
    /**
     * Subdivide a face with a partition between two of its vertices. `source`
     * `-1` marks a brand-new partition (materialised as a fresh wall at bake).
     * Returns the kept face and the new face.
     */
    splitFace(face: number, va: number, vb: number, source: number): any;
    /**
     * Number of live rooms.
     */
    readonly roomCount: number;
}

/**
 * A 2D circle/arc for symbolic representations
 */
export class SymbolicCircle {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly centerX: number;
    readonly centerY: number;
    readonly endAngle: number;
    readonly expressId: number;
    readonly ifcType: string;
    /**
     * Check if this is a full circle
     */
    readonly isFullCircle: boolean;
    readonly radius: number;
    readonly repIdentifier: string;
    readonly startAngle: number;
    /**
     * World-Y elevation captured from the placement chain.
     */
    readonly worldY: number;
}

/**
 * A 2D filled region (IfcAnnotationFillArea / IfcAnnotationFillAreaOccurrence).
 *
 * Stores one outer ring of 2D points plus an offset table indexing inner
 * rings (holes). Both rings are stored flat in `points` so the JS side can
 * view the buffer as one Float32Array. The optional `hatch_*` fields encode
 * IfcFillAreaStyleHatching (line spacing, primary/secondary angles, line
 * width) when the IfcStyledItem chain resolves to a hatching style; absent
 * styles render as a solid fill.
 *
 * `holes_offsets` is an inclusive-prefix array describing where each hole
 * begins. The outer ring is implicitly at `points[0..holes_offsets[0]]`
 * (or all points if `holes_offsets` is empty). Each `holes_offsets[i]` is a
 * vertex index, not a byte offset.
 */
export class SymbolicFillArea {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly expressId: number;
    readonly fillA: number;
    readonly fillB: number;
    readonly fillG: number;
    readonly fillR: number;
    readonly geometryItemId: number | undefined;
    readonly hasHatching: boolean;
    readonly hatchAngle: number;
    readonly hatchAngleSecondary: number;
    readonly hatchLineWidth: number;
    readonly hatchSpacing: number;
    readonly holeCount: number;
    /**
     * Vertex indices marking the start of each hole. Empty = no holes.
     */
    readonly holesOffsets: Uint32Array;
    readonly ifcType: string;
    readonly pointCount: number;
    /**
     * Flattened ring vertices.
     */
    readonly points: Float32Array;
    readonly repIdentifier: string;
    readonly worldY: number;
}

/**
 * A single 2D polyline for symbolic representations (Plan, Annotation, FootPrint)
 * Points are stored as [x1, y1, x2, y2, ...] in 2D coordinates
 */
export class SymbolicPolyline {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get express ID of the parent element
     */
    readonly expressId: number;
    /**
     * Get IFC type name (e.g., "IfcDoor", "IfcWindow")
     */
    readonly ifcType: string;
    /**
     * Check if this is a closed loop
     */
    readonly isClosed: boolean;
    /**
     * Get number of points
     */
    readonly pointCount: number;
    /**
     * Get 2D points as Float32Array [x1, y1, x2, y2, ...]
     */
    readonly points: Float32Array;
    /**
     * Get representation identifier ("Plan", "Annotation", "FootPrint", "Axis")
     */
    readonly repIdentifier: string;
    /**
     * World-Y elevation captured from the placement chain (or first 3D
     * point's Z component). JS uses this as the canonical bucket key.
     */
    readonly worldY: number;
}

/**
 * Collection of symbolic representations for an IFC model
 */
export class SymbolicRepresentationCollection {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Get circle at index
     */
    getCircle(index: number): SymbolicCircle | undefined;
    /**
     * Get all express IDs that have symbolic representations
     */
    getExpressIds(): Uint32Array;
    /**
     * Get fill area at index.
     */
    getFill(index: number): SymbolicFillArea | undefined;
    /**
     * Get polyline at index
     */
    getPolyline(index: number): SymbolicPolyline | undefined;
    /**
     * Get text annotation at index.
     */
    getText(index: number): SymbolicText | undefined;
    /**
     * Get number of circles/arcs
     */
    readonly circleCount: number;
    /**
     * Get number of fill areas
     */
    readonly fillCount: number;
    /**
     * Check if collection is empty. A TRUNCATED result never is, even with no
     * primitives; the reasoning and the parity test are in `symbolic_truncation.rs`.
     */
    readonly isEmpty: boolean;
    /**
     * Get number of polylines
     */
    readonly polylineCount: number;
    /**
     * Get number of text annotations
     */
    readonly textCount: number;
    /**
     * Get total count of all symbolic items
     */
    readonly totalCount: number;
    /**
     * Primitive count at which extraction stopped, else `undefined`.
     */
    readonly truncatedAt: number | undefined;
    /**
     * The bound's numeric value, when the reason has one, else `undefined`.
     * Absent for the per-item reasons, whose bound is per item and not
     * comparable with `truncatedAt`.
     */
    readonly truncatedLimit: number | undefined;
    /**
     * Which bound stopped extraction, else `undefined`. One of
     * `element-count`, `output-bytes`, `item-depth`, `item-revisits`,
     * `item-cycle` — the same kebab-case strings the JSON path emits, so a
     * consumer reading either surface reads one vocabulary.
     */
    readonly truncatedReason: string | undefined;
}

/**
 * A 2D text annotation (IfcTextLiteral / IfcTextLiteralWithExtent).
 *
 * Position is in the same 2D coordinate space as `SymbolicPolyline` (i.e. the
 * floor-plan / annotation overlay's local frame after applying placement +
 * RTC). The text-orientation pair `(cos, sin)` rotates the baseline from the
 * `+x` axis. Height is the IFC font height in model units, scaled by the
 * project's length-unit factor so the renderer can convert directly to world
 * units. Alignment is the IFC `BoxAlignment` string verbatim
 * (`top-left`, `center`, `bottom-right`, …) — the renderer can interpret it.
 */
export class SymbolicText {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly alignment: string;
    readonly colorA: number;
    readonly colorB: number;
    readonly colorG: number;
    readonly colorR: number;
    readonly content: string;
    readonly dirX: number;
    readonly dirY: number;
    readonly expressId: number;
    readonly height: number;
    readonly ifcType: string;
    readonly repIdentifier: string;
    readonly targetPx: number;
    readonly worldY: number;
    readonly x: number;
    readonly y: number;
}

/**
 * One closed solid of a split element.
 */
export class ZonePieceJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Flat triangle indices into `positions`.
     */
    readonly indices: Uint32Array;
    /**
     * Flat `[x, y, z, ...]` in the caller's frame.
     */
    readonly positions: Float64Array;
    /**
     * Enclosed volume of this piece, cubic units of the caller's frame.
     */
    readonly volume: number;
    /**
     * Index into the zone array that was passed in, or `-1` for the part of
     * the element inside no zone.
     */
    readonly zoneIndex: number;
}

/**
 * The result of splitting one element.
 */
export class ZoneSplitJs {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Piece `index`, or `undefined` when out of range. Each call COPIES the
     * piece out, matching the rest of this API surface.
     */
    piece(index: number): ZonePieceJs | undefined;
    readonly pieceCount: number;
    /**
     * The part of the element inside NO zone could not be built.
     *
     * Separate from `sumErrorRel` because the two have opposite fixes: a
     * raised sum means the zones overlap and want redrawing, while this means
     * real volume is MISSING from the result. A caller must refuse the split
     * outright rather than publish the zone pieces alone.
     */
    readonly remainderFailed: boolean;
    /**
     * How far the pieces are from summing to the whole, relative.
     *
     * The invariant #2508 puts above everything else here. Exposed rather than
     * enforced: the caller decides what to do with a split that does not add
     * up (the expected cause is zones that overlap each other), and a number
     * it can show beats a silent refusal.
     */
    readonly sumErrorRel: number;
    /**
     * Enclosed volume of the input element.
     */
    readonly wholeVolume: number;
}

/**
 * Compute the intersection solid of one clashing pair.
 *
 * `positionsA` / `positionsB` are flat world-space XYZ; `indicesA` /
 * `indicesB` are flat triangle indices into their own operand.
 *
 * ```javascript
 * const solid = clashIntersectionSolid(posA, idxA, posB, idxB);
 * if (solid.isSolid) {
 *   draw(solid.positions, solid.indices, solid.volumeM3);
 * } else {
 *   keepContactMarker(solid.degenerateReason); // e.g. "no-overlap"
 * }
 * solid.free();
 * ```
 */
export function clashIntersectionSolid(positions_a: Float32Array, indices_a: Uint32Array, positions_b: Float32Array, indices_b: Uint32Array): ClashIntersectionSolidJs;

/**
 * `a - b`, keeping EVERY disjoint remnant.
 *
 * This is the operation the existing `subtract_2d` could not stand in for: it
 * returns one shape per island, where `subtract_2d` collapses to the largest
 * (correct for a single extrusion profile, silent geometry loss anywhere else).
 *
 * `b` may hold any number of rings; they subtract as their union, so there is
 * no separate "difference against many" entry point.
 */
export function difference2d(a: Contours2D, b: Contours2D): Contours2D;

/**
 * Get WASM memory to allow JavaScript to create TypedArray views
 */
export function get_memory(): any;

/**
 * Initialize the WASM module.
 *
 * This function is called automatically when the WASM module is loaded.
 * It sets up panic hooks for better error messages in the browser console,
 * and points core's scan diagnostics at that console too.
 */
export function init(): void;

/**
 * `a ∩ b`.
 */
export function intersection2d(a: Contours2D, b: Contours2D): Contours2D;

/**
 * Compute the winding-robust 2D footprint outline of a triangle mesh.
 *
 * `positions` is flat XYZ; `indices` is flat triangle indices. `axis` is
 * 0/1/2 = x/y/z (the cut axis, WebGL Y-up). Returns `undefined` when the mesh
 * has no triangles or projects to nothing: the element has no footprint.
 *
 * THROWS when the outline was not computed: an `axis` outside 0..=2, or a
 * mesh with more valid projected triangles than the overlay budget (50 000).
 * The viewer's outline provider catches the throw and draws its TypeScript
 * silhouette for that mesh.
 *
 * ```javascript
 * const outline = meshOutline2d(positions, indices, 1, false); // axis 1 = y
 * if (outline) {
 *   for (let i = 0; i < outline.contourCount; i++) {
 *     const ring = outline.contour(i); // Float32Array of [u0, v0, u1, v1, ...]
 *   }
 *   outline.free();
 * }
 * ```
 */
export function meshOutline2d(positions: Float32Array, indices: Uint32Array, axis: number, flipped: boolean): MeshOutlineJs | undefined;

/**
 * Resolve a ring soup into disjoint outer/hole shapes without changing the
 * area it covers (a self-union). Use it to give a hand-built set — or a
 * `meshOutline2d` result — the shape grouping the operations produce.
 */
export function resolve2d(a: Contours2D): Contours2D;

/**
 * Install (or, with `undefined`, remove) the callback invoked at most once a
 * second while geometry work is in progress inside a WASM call. It runs
 * synchronously inside that call, so it must only do something cheap such as
 * `postMessage`, and must not call back into this module.
 */
export function setGeometryProgressCallback(callback?: Function | null): void;

/**
 * Split a mesh into one closed solid per zone, plus the remainder.
 *
 * `positions` is flat XYZ (f64, caller's frame), `indices` flat triangle
 * indices. `zones` is flat, SEVEN numbers per zone:
 * `[cx, cy, cz, sx, sy, sz, rotationY]`, where the sizes are FULL extents
 * (matching the viewer's `Zone.size`) and the rotation is radians about the
 * vertical axis. A trailing partial zone is ignored rather than guessed at.
 *
 * A zone becomes a PRISM (#2508 item 4) when `footprint_counts[i]` is at
 * least 3: it then takes that many `[x, z]` pairs from `footprints`, in order,
 * and uses the 7-tuple only for its vertical extent (`cy +/- sy/2`). The
 * footprint must be CONVEX; the viewer gates that on import, because a concave
 * polygon fans into overlapping triangles and would cut wrong rather than
 * fail. A count of 1 or 2 is not a polygon: it still consumes its pairs, so
 * later zones stay aligned, and leaves that zone a box. Passing empty arrays
 * keeps every zone a box.
 *
 * The caller must have established that the mesh is a closed orientable solid
 * first, exactly as it must before quoting a volume at all (#1891/#1993): a
 * clip of an open shell produces pieces whose volumes are arbitrary rather
 * than approximate.
 *
 * A triangle with an out-of-range index or a non-finite coordinate is DROPPED
 * rather than reported, matching `kernel::mesh_bridge::mesh_to_tris`, which is
 * panic-free for the same reason: the alternative is a crash deep in the
 * predicates. It does mean a malformed caller can open the surface and get
 * meaningless volumes with a plausible `sumErrorRel`, so the closure proof
 * above is the caller's responsibility and not a formality.
 *
 * Returns `undefined` when a zone parameter is non-finite, or a mesh vertex
 * or zone corner lies past ±2^128, the exact kernel's coordinate bound
 * (#7677): such a split is refused rather than answered wrongly.
 *
 * Returns `undefined` when the mesh encloses no volume (no triangles survive
 * the filter above, or the shell is degenerate): there is nothing to split,
 * and a result for it would report `pieceCount` 1, `sumErrorRel` 0 and
 * `remainderFailed` false, a perfect split of nothing. A caller that gates
 * on those numbers must treat `undefined` as "no split", not as "no error".
 *
 * ```javascript
 * const split = splitMeshByZones(positions, indices, new Float64Array([
 *   0, 0, 0, 10, 10, 10, 0,
 * ]));
 * if (!split) return; // the mesh encloses no volume
 * for (let i = 0; i < split.pieceCount; i++) {
 *   const piece = split.piece(i);
 *   // piece.zoneIndex, piece.positions, piece.indices, piece.volume
 *   piece.free();
 * }
 * split.free();
 * ```
 */
export function splitMeshByZones(positions: Float64Array, indices: Uint32Array, zones: Float64Array, footprints?: Float64Array | null, footprint_counts?: Uint32Array | null): ZoneSplitJs | undefined;

/**
 * Trace closed outlines from slab points given in plane coordinates.
 *
 * THROWS on invalid options or plane frame (unknown field, non-finite or
 * out-of-range value). Points that are not finite are skipped and counted.
 */
export function traceScanOutline(plane_xy: Float32Array, options?: ScanOutlineOptionsJs | null, plane_frame?: ScanOutlinePlaneFrameJs | null): ScanOutlineJs;

/**
 * `a ∪ b`.
 */
export function union2d(a: Contours2D, b: Contours2D): Contours2D;

/**
 * Get the version of IFC-Lite.
 *
 * # Returns
 *
 * Version string (e.g., "0.1.0")
 *
 * # Example
 *
 * ```javascript
 * console.log(`IFC-Lite version: ${version()}`);
 * ```
 */
export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_alignmentaxisjs_free: (a: number, b: number) => void;
    readonly __wbg_clashintersectionsolidjs_free: (a: number, b: number) => void;
    readonly __wbg_clashrunresult_free: (a: number, b: number) => void;
    readonly __wbg_clashsession_free: (a: number, b: number) => void;
    readonly __wbg_contours2d_free: (a: number, b: number) => void;
    readonly __wbg_gridaxiscollection_free: (a: number, b: number) => void;
    readonly __wbg_gridaxisjs_free: (a: number, b: number) => void;
    readonly __wbg_ifcapi_free: (a: number, b: number) => void;
    readonly __wbg_landxmltinstreamsession_free: (a: number, b: number) => void;
    readonly __wbg_meshcollection_free: (a: number, b: number) => void;
    readonly __wbg_meshdatajs_free: (a: number, b: number) => void;
    readonly __wbg_meshoutlinejs_free: (a: number, b: number) => void;
    readonly __wbg_partitionedbatch_free: (a: number, b: number) => void;
    readonly __wbg_profilecollection_free: (a: number, b: number) => void;
    readonly __wbg_profileentryjs_free: (a: number, b: number) => void;
    readonly __wbg_scanoutlinejs_free: (a: number, b: number) => void;
    readonly __wbg_simplifiedmeshes_free: (a: number, b: number) => void;
    readonly __wbg_spaceplatehandle_free: (a: number, b: number) => void;
    readonly __wbg_symboliccircle_free: (a: number, b: number) => void;
    readonly __wbg_symbolicfillarea_free: (a: number, b: number) => void;
    readonly __wbg_symbolicpolyline_free: (a: number, b: number) => void;
    readonly __wbg_symbolicrepresentationcollection_free: (a: number, b: number) => void;
    readonly __wbg_symbolictext_free: (a: number, b: number) => void;
    readonly __wbg_zonepiecejs_free: (a: number, b: number) => void;
    readonly __wbg_zonesplitjs_free: (a: number, b: number) => void;
    readonly alignmentaxisjs_GlobalId: (a: number, b: number) => void;
    readonly alignmentaxisjs_Name: (a: number, b: number) => void;
    readonly alignmentaxisjs_approximate: (a: number) => number;
    readonly alignmentaxisjs_evaluate: (a: number, b: number, c: number) => void;
    readonly alignmentaxisjs_expressId: (a: number) => number;
    readonly alignmentaxisjs_geometricHorizontalLengthMeters: (a: number) => number;
    readonly alignmentaxisjs_new: (a: number, b: number, c: number, d: number) => void;
    readonly clashIntersectionSolid: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly clashintersectionsolidjs_degenerateReason: (a: number, b: number) => void;
    readonly clashintersectionsolidjs_indices: (a: number, b: number) => void;
    readonly clashintersectionsolidjs_isSolid: (a: number) => number;
    readonly clashintersectionsolidjs_positions: (a: number, b: number) => void;
    readonly clashintersectionsolidjs_requiredM: (a: number) => number;
    readonly clashintersectionsolidjs_thicknessM: (a: number) => number;
    readonly clashintersectionsolidjs_triangleCount: (a: number) => number;
    readonly clashintersectionsolidjs_volumeM3: (a: number) => number;
    readonly clashrunresult_a: (a: number, b: number) => void;
    readonly clashrunresult_b: (a: number, b: number) => void;
    readonly clashrunresult_bounds: (a: number, b: number) => void;
    readonly clashrunresult_depthFloor: (a: number, b: number) => void;
    readonly clashrunresult_distance: (a: number, b: number) => void;
    readonly clashrunresult_distanceKind: (a: number, b: number) => void;
    readonly clashrunresult_points: (a: number, b: number) => void;
    readonly clashrunresult_status: (a: number, b: number) => void;
    readonly clashsession_ingest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => void;
    readonly clashsession_new: () => number;
    readonly clashsession_runRule: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => number;
    readonly contours2d_bounds: (a: number) => number;
    readonly contours2d_coords: (a: number) => number;
    readonly contours2d_fromMeshOutline: (a: number) => number;
    readonly contours2d_isEmpty: (a: number) => number;
    readonly contours2d_new: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly contours2d_ring: (a: number, b: number) => number;
    readonly contours2d_ringCount: (a: number) => number;
    readonly contours2d_ringLengths: (a: number) => number;
    readonly contours2d_shapeCount: (a: number) => number;
    readonly contours2d_shapeOffsets: (a: number) => number;
    readonly difference2d: (a: number, b: number) => number;
    readonly gridaxiscollection_getAxis: (a: number, b: number) => number;
    readonly gridaxiscollection_isEmpty: (a: number) => number;
    readonly gridaxiscollection_length: (a: number) => number;
    readonly gridaxisjs_axisId: (a: number) => number;
    readonly gridaxisjs_end: (a: number) => number;
    readonly gridaxisjs_gridId: (a: number) => number;
    readonly gridaxisjs_start: (a: number) => number;
    readonly gridaxisjs_tag: (a: number, b: number) => void;
    readonly ifcapi_bindSourceModel: (a: number, b: number) => void;
    readonly ifcapi_buildPrePassOnce: (a: number, b: number, c: number) => number;
    readonly ifcapi_buildPrePassStreaming: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly ifcapi_buildPrePassStreamingSharded: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number) => void;
    readonly ifcapi_buildPrePassStreamingShardedWithSourceFingerprint: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number) => void;
    readonly ifcapi_buildPrePassStreamingWithSourceFingerprint: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly ifcapi_calibrateAppearancePlane: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_catalogAppearance: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_clearPrePassCache: (a: number) => void;
    readonly ifcapi_createLandXmlTinStreamSession: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_diagnoseGeometry: (a: number, b: number, c: number) => number;
    readonly ifcapi_exportCsv: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly ifcapi_exportDfjson: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_exportGlb: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number) => void;
    readonly ifcapi_exportGlbFromMeshes: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number) => void;
    readonly ifcapi_exportHbjson: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_exportHbjsonWithStats: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly ifcapi_exportIfcx: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_exportJson: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly ifcapi_exportJsonld: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => void;
    readonly ifcapi_exportKmzFromMeshes: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number, a1: number) => void;
    readonly ifcapi_exportLandXmlTerrain: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly ifcapi_exportMerged: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_exportObj: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly ifcapi_exportStep: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => void;
    readonly ifcapi_exportUsd: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_extractProfiles: (a: number, b: number, c: number, d: number) => number;
    readonly ifcapi_extractSweptDiskDescriptions: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_extrusionDefinitions: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_finalizePrepassStyles: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number) => void;
    readonly ifcapi_finalizePrepassStylesFromSource: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number) => void;
    readonly ifcapi_getMemory: (a: number) => number;
    readonly ifcapi_getPipelineDiagnostics: (a: number) => number;
    readonly ifcapi_inspectLandXmlAlignmentAtDistance: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly ifcapi_is_ready: (a: number) => number;
    readonly ifcapi_new: () => number;
    readonly ifcapi_parseAlignmentLines: (a: number, b: number, c: number) => number;
    readonly ifcapi_parseAlignmentLinesInFrame: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_parseGridAxes: (a: number, b: number, c: number) => number;
    readonly ifcapi_parseGridAxesInFrame: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_parseGridLines: (a: number, b: number, c: number) => number;
    readonly ifcapi_parseGridLinesInFrame: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_parseLandXmlSourceBytes: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_parseLandXmlSourceBytesWithOptions: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_parseLandXmlTinBytes: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_parseSymbolicRepresentations: (a: number, b: number, c: number) => number;
    readonly ifcapi_parseSymbolicRepresentationsInFrame: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_planAnnotationPlane: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_planAppearance: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_planCapturedMesh: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_planMapConversionNormalization: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_planMeshTransfer: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_planPageAppearance: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_planPdfFillAnnotation: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_planPointTransfer: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number) => void;
    readonly ifcapi_preparePdfVectorPage: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_probeLandXmlAlignmentAtDistance: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_probeLandXmlAlignmentAtStation: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_processGeometryBatch: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number, a1: number, b1: number) => number;
    readonly ifcapi_processGeometryBatchFromSource: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number) => number;
    readonly ifcapi_processGeometryBatchInstanced: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number, a1: number, b1: number, c1: number) => void;
    readonly ifcapi_processGeometryBatchPartitioned: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number, a1: number, b1: number) => number;
    readonly ifcapi_processGeometryBatchPartitionedFromSource: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number) => number;
    readonly ifcapi_proposeScanElements: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_registerScanCorrespondences: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_resolveStyledItemsShard: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_resolveStyledItemsShardFromSource: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_scanEntitiesFast: (a: number, b: number, c: number) => number;
    readonly ifcapi_scanEntitiesFastBytes: (a: number, b: number, c: number) => number;
    readonly ifcapi_scanEntityIndexShard: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly ifcapi_scanEntityIndexShardFromSource: (a: number, b: number, c: number) => number;
    readonly ifcapi_scanGeometryEntitiesFast: (a: number, b: number, c: number) => number;
    readonly ifcapi_segmentScanPoints: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly ifcapi_setComputeGeometryHashes: (a: number, b: number, c: number) => void;
    readonly ifcapi_setEntityIndex: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
    readonly ifcapi_setInstantiatedTypeIds: (a: number, b: number, c: number) => void;
    readonly ifcapi_setMappedInstancePlan: (a: number, b: number, c: number) => void;
    readonly ifcapi_setMaterialLayerIndex: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number) => void;
    readonly ifcapi_setMergeLayers: (a: number, b: number) => void;
    readonly ifcapi_setPrepassGeometryFinishes: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_setRectParamFastPath: (a: number, b: number) => void;
    readonly ifcapi_setReferencedRepmaps: (a: number, b: number, c: number) => void;
    readonly ifcapi_setSkipSmallCuts: (a: number, b: number) => void;
    readonly ifcapi_setSourceBytes: (a: number, b: number, c: number) => void;
    readonly ifcapi_setStyleFinishes: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly ifcapi_setTessellationQuality: (a: number, b: number, c: number, d: number) => void;
    readonly ifcapi_simplifyMeshes: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number, v: number, w: number, x: number, y: number, z: number, a1: number) => void;
    readonly ifcapi_version: (a: number, b: number) => void;
    readonly intersection2d: (a: number, b: number) => number;
    readonly landxmltinstreamsession_abort: (a: number) => void;
    readonly landxmltinstreamsession_advanceChunk: (a: number, b: number, c: number, d: number) => void;
    readonly landxmltinstreamsession_drain: (a: number, b: number, c: number) => void;
    readonly landxmltinstreamsession_finish: (a: number, b: number) => void;
    readonly landxmltinstreamsession_finishCursor: (a: number, b: number) => void;
    readonly landxmltinstreamsession_header: (a: number, b: number) => void;
    readonly landxmltinstreamsession_outputPending: (a: number) => number;
    readonly landxmltinstreamsession_queuedBytes: (a: number) => number;
    readonly landxmltinstreamsession_queuedEvents: (a: number) => number;
    readonly meshOutline2d: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly meshcollection_buildingRotation: (a: number, b: number) => void;
    readonly meshcollection_diagnostics: (a: number) => number;
    readonly meshcollection_geometryAabbValues: (a: number) => number;
    readonly meshcollection_geometryClosureFlags: (a: number) => number;
    readonly meshcollection_geometryHashCount: (a: number) => number;
    readonly meshcollection_geometryHashIds: (a: number) => number;
    readonly meshcollection_geometryHashValues: (a: number) => number;
    readonly meshcollection_geometryVolumeValues: (a: number) => number;
    readonly meshcollection_get: (a: number, b: number) => number;
    readonly meshcollection_hasRtcOffset: (a: number) => number;
    readonly meshcollection_length: (a: number) => number;
    readonly meshcollection_rtcOffsetX: (a: number) => number;
    readonly meshcollection_rtcOffsetY: (a: number) => number;
    readonly meshcollection_rtcOffsetZ: (a: number) => number;
    readonly meshcollection_takeMesh: (a: number, b: number) => number;
    readonly meshcollection_totalTriangles: (a: number) => number;
    readonly meshcollection_totalVertices: (a: number) => number;
    readonly meshdatajs_color: (a: number, b: number) => void;
    readonly meshdatajs_expressId: (a: number) => number;
    readonly meshdatajs_geometryClass: (a: number) => number;
    readonly meshdatajs_geometryItemId: (a: number) => number;
    readonly meshdatajs_hasTexture: (a: number) => number;
    readonly meshdatajs_ifcType: (a: number, b: number) => void;
    readonly meshdatajs_indices: (a: number) => number;
    readonly meshdatajs_localBounds: (a: number, b: number) => void;
    readonly meshdatajs_localToWorld: (a: number, b: number) => void;
    readonly meshdatajs_materialId: (a: number) => number;
    readonly meshdatajs_metallic: (a: number) => number;
    readonly meshdatajs_normals: (a: number) => number;
    readonly meshdatajs_origin: (a: number) => number;
    readonly meshdatajs_positions: (a: number) => number;
    readonly meshdatajs_roughness: (a: number) => number;
    readonly meshdatajs_shadingColor: (a: number, b: number) => void;
    readonly meshdatajs_textureHeight: (a: number) => number;
    readonly meshdatajs_textureId: (a: number) => number;
    readonly meshdatajs_textureRepeatS: (a: number) => number;
    readonly meshdatajs_textureRepeatT: (a: number) => number;
    readonly meshdatajs_textureRgba: (a: number) => number;
    readonly meshdatajs_textureUrl: (a: number, b: number) => void;
    readonly meshdatajs_textureWidth: (a: number) => number;
    readonly meshdatajs_triangleCount: (a: number) => number;
    readonly meshdatajs_uvs: (a: number) => number;
    readonly meshdatajs_vertexCount: (a: number) => number;
    readonly meshoutlinejs_axisMax: (a: number) => number;
    readonly meshoutlinejs_axisMin: (a: number) => number;
    readonly meshoutlinejs_contour: (a: number, b: number) => number;
    readonly partitionedbatch_instancedOccurrences: (a: number) => number;
    readonly partitionedbatch_takeMeshes: (a: number) => number;
    readonly partitionedbatch_takeShard: (a: number, b: number) => void;
    readonly profilecollection_get: (a: number, b: number) => number;
    readonly profilecollection_length: (a: number) => number;
    readonly profilecollection_skippedExpressIds: (a: number) => number;
    readonly profileentryjs_expressId: (a: number) => number;
    readonly profileentryjs_extrusionDepth: (a: number) => number;
    readonly profileentryjs_extrusionDir: (a: number) => number;
    readonly profileentryjs_holeCounts: (a: number) => number;
    readonly profileentryjs_holePoints: (a: number) => number;
    readonly profileentryjs_ifcType: (a: number, b: number) => void;
    readonly profileentryjs_modelIndex: (a: number) => number;
    readonly profileentryjs_outerPoints: (a: number) => number;
    readonly profileentryjs_transform: (a: number) => number;
    readonly resolve2d: (a: number) => number;
    readonly scanoutlinejs_coords: (a: number) => number;
    readonly scanoutlinejs_diagnostics: (a: number, b: number) => void;
    readonly scanoutlinejs_ringCount: (a: number) => number;
    readonly scanoutlinejs_ringLengths: (a: number) => number;
    readonly scanoutlinejs_ringParents: (a: number) => number;
    readonly scanoutlinejs_shapeCount: (a: number) => number;
    readonly scanoutlinejs_shapeOffsets: (a: number) => number;
    readonly scanoutlinejs_worldCoords: (a: number) => number;
    readonly setGeometryProgressCallback: (a: number) => void;
    readonly simplifiedmeshes_cavitiesDropped: (a: number, b: number) => void;
    readonly simplifiedmeshes_elementIds: (a: number, b: number) => void;
    readonly simplifiedmeshes_indexCounts: (a: number, b: number) => void;
    readonly simplifiedmeshes_levels: (a: number, b: number) => void;
    readonly simplifiedmeshes_localIndices: (a: number, b: number) => void;
    readonly simplifiedmeshes_localPositions: (a: number, b: number) => void;
    readonly simplifiedmeshes_renderIndices: (a: number, b: number) => void;
    readonly simplifiedmeshes_renderNormals: (a: number, b: number) => void;
    readonly simplifiedmeshes_renderOrigins: (a: number, b: number) => void;
    readonly simplifiedmeshes_renderPositions: (a: number, b: number) => void;
    readonly simplifiedmeshes_skippedIds: (a: number, b: number) => void;
    readonly simplifiedmeshes_skippedReasons: (a: number, b: number) => void;
    readonly simplifiedmeshes_trisAfter: (a: number, b: number) => void;
    readonly simplifiedmeshes_trisBefore: (a: number, b: number) => void;
    readonly simplifiedmeshes_vertexCounts: (a: number, b: number) => void;
    readonly spaceplatehandle_addFace: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly spaceplatehandle_boundingElements: (a: number, b: number, c: number) => void;
    readonly spaceplatehandle_dissolveVertex: (a: number, b: number, c: number) => void;
    readonly spaceplatehandle_dragVertex: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly spaceplatehandle_duplicate: (a: number) => number;
    readonly spaceplatehandle_faceArea: (a: number, b: number) => number;
    readonly spaceplatehandle_faceOutline: (a: number, b: number, c: number) => void;
    readonly spaceplatehandle_findVertexNear: (a: number, b: number, c: number, d: number) => number;
    readonly spaceplatehandle_fromWallRects: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly spaceplatehandle_gapBoundary: (a: number, b: number, c: number, d: number) => void;
    readonly spaceplatehandle_mergeFaces: (a: number, b: number, c: number) => void;
    readonly spaceplatehandle_neighborAcross: (a: number, b: number) => number;
    readonly spaceplatehandle_netOutline: (a: number, b: number, c: number, d: number) => void;
    readonly spaceplatehandle_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => void;
    readonly spaceplatehandle_prune: (a: number) => number;
    readonly spaceplatehandle_removeEdge: (a: number, b: number, c: number) => void;
    readonly spaceplatehandle_roomCount: (a: number) => number;
    readonly spaceplatehandle_roomIds: (a: number, b: number) => void;
    readonly spaceplatehandle_setFaceHeight: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly spaceplatehandle_snapshot: (a: number, b: number) => void;
    readonly spaceplatehandle_splitEdge: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly spaceplatehandle_splitFace: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
    readonly splitMeshByZones: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => number;
    readonly symboliccircle_centerX: (a: number) => number;
    readonly symboliccircle_centerY: (a: number) => number;
    readonly symboliccircle_endAngle: (a: number) => number;
    readonly symboliccircle_expressId: (a: number) => number;
    readonly symboliccircle_ifcType: (a: number, b: number) => void;
    readonly symboliccircle_isFullCircle: (a: number) => number;
    readonly symboliccircle_radius: (a: number) => number;
    readonly symboliccircle_repIdentifier: (a: number, b: number) => void;
    readonly symboliccircle_startAngle: (a: number) => number;
    readonly symboliccircle_worldY: (a: number) => number;
    readonly symbolicfillarea_expressId: (a: number) => number;
    readonly symbolicfillarea_fillA: (a: number) => number;
    readonly symbolicfillarea_fillB: (a: number) => number;
    readonly symbolicfillarea_fillG: (a: number) => number;
    readonly symbolicfillarea_fillR: (a: number) => number;
    readonly symbolicfillarea_geometryItemId: (a: number) => number;
    readonly symbolicfillarea_hasHatching: (a: number) => number;
    readonly symbolicfillarea_hatchAngle: (a: number) => number;
    readonly symbolicfillarea_hatchAngleSecondary: (a: number) => number;
    readonly symbolicfillarea_hatchLineWidth: (a: number) => number;
    readonly symbolicfillarea_hatchSpacing: (a: number) => number;
    readonly symbolicfillarea_holeCount: (a: number) => number;
    readonly symbolicfillarea_holesOffsets: (a: number) => number;
    readonly symbolicfillarea_ifcType: (a: number, b: number) => void;
    readonly symbolicfillarea_pointCount: (a: number) => number;
    readonly symbolicfillarea_points: (a: number) => number;
    readonly symbolicfillarea_repIdentifier: (a: number, b: number) => void;
    readonly symbolicfillarea_worldY: (a: number) => number;
    readonly symbolicpolyline_expressId: (a: number) => number;
    readonly symbolicpolyline_ifcType: (a: number, b: number) => void;
    readonly symbolicpolyline_isClosed: (a: number) => number;
    readonly symbolicpolyline_pointCount: (a: number) => number;
    readonly symbolicpolyline_points: (a: number) => number;
    readonly symbolicpolyline_repIdentifier: (a: number, b: number) => void;
    readonly symbolicrepresentationcollection_circleCount: (a: number) => number;
    readonly symbolicrepresentationcollection_fillCount: (a: number) => number;
    readonly symbolicrepresentationcollection_getCircle: (a: number, b: number) => number;
    readonly symbolicrepresentationcollection_getExpressIds: (a: number, b: number) => void;
    readonly symbolicrepresentationcollection_getFill: (a: number, b: number) => number;
    readonly symbolicrepresentationcollection_getPolyline: (a: number, b: number) => number;
    readonly symbolicrepresentationcollection_getText: (a: number, b: number) => number;
    readonly symbolicrepresentationcollection_isEmpty: (a: number) => number;
    readonly symbolicrepresentationcollection_polylineCount: (a: number) => number;
    readonly symbolicrepresentationcollection_textCount: (a: number) => number;
    readonly symbolicrepresentationcollection_totalCount: (a: number) => number;
    readonly symbolicrepresentationcollection_truncatedAt: (a: number) => number;
    readonly symbolicrepresentationcollection_truncatedLimit: (a: number) => number;
    readonly symbolicrepresentationcollection_truncatedReason: (a: number, b: number) => void;
    readonly symbolictext_alignment: (a: number, b: number) => void;
    readonly symbolictext_content: (a: number, b: number) => void;
    readonly symbolictext_ifcType: (a: number, b: number) => void;
    readonly symbolictext_repIdentifier: (a: number, b: number) => void;
    readonly symbolictext_x: (a: number) => number;
    readonly symbolictext_y: (a: number) => number;
    readonly traceScanOutline: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly union2d: (a: number, b: number) => number;
    readonly version: (a: number) => void;
    readonly zonepiecejs_indices: (a: number) => number;
    readonly zonepiecejs_positions: (a: number) => number;
    readonly zonepiecejs_zoneIndex: (a: number) => number;
    readonly zonesplitjs_piece: (a: number, b: number) => number;
    readonly zonesplitjs_pieceCount: (a: number) => number;
    readonly zonesplitjs_remainderFailed: (a: number) => number;
    readonly meshoutlinejs_contourCount: (a: number) => number;
    readonly get_memory: () => number;
    readonly symbolicpolyline_worldY: (a: number) => number;
    readonly symbolictext_colorA: (a: number) => number;
    readonly symbolictext_colorB: (a: number) => number;
    readonly symbolictext_colorG: (a: number) => number;
    readonly symbolictext_colorR: (a: number) => number;
    readonly symbolictext_dirX: (a: number) => number;
    readonly symbolictext_dirY: (a: number) => number;
    readonly symbolictext_expressId: (a: number) => number;
    readonly symbolictext_height: (a: number) => number;
    readonly symbolictext_targetPx: (a: number) => number;
    readonly symbolictext_worldY: (a: number) => number;
    readonly zonepiecejs_volume: (a: number) => number;
    readonly zonesplitjs_sumErrorRel: (a: number) => number;
    readonly zonesplitjs_wholeVolume: (a: number) => number;
    readonly init: () => void;
    readonly __wbindgen_export: (a: number, b: number) => number;
    readonly __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export3: (a: number) => void;
    readonly __wbindgen_export4: (a: number, b: number, c: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
