<!-- This Source Code Form is subject to the terms of the Mozilla Public
     License, v. 2.0. If a copy of the MPL was not distributed with this
     file, You can obtain one at https://mozilla.org/MPL/2.0/. -->

# Performance diagnosis kit

One place to answer "where does load time go, and what is the biggest lever?"
for both the **native** Rust pipeline (CLI/server/exporter) and the **WASM**
viewer path. The two run the *same* Rust code (`process_geometry` ->
`produce_element_meshes`), so native profiling finds the algorithmic hotspots
that also dominate in the browser; the WASM-only concerns (per-worker file
re-decode, no threads, memory bandwidth) are orchestration-level and are read
off the viewer's own telemetry (below).

## TL;DR

```bash
# per-phase parse-vs-geometry attribution across the heavy fixtures on disk:
scripts/perf/probe.sh --suite --census

# one fixture, more iterations, JSON for diffing runs:
scripts/perf/probe.sh tests/models/ara3d/schependomlaan.ifc --iters 5 --json > /tmp/a.json

# symbolized flamegraph (opens Firefox profiler) to see WHICH function:
scripts/perf/flame.sh tests/models/ara3d/schependomlaan.ifc

# deterministic per-phase instruction counts (callgrind, single thread):
scripts/perf/instructions.sh tests/models/ara3d/AC20-FZK-Haus.ifc --json
```

Fetch a fixture first if missing: `pnpm fixtures ara3d/schependomlaan.ifc`.

`ab-report.mjs` accepts input rows only with literal `side` values `base` and
`branch`; `--base` and `--branch` set display labels and do not select rows.
It refuses empty, incomplete, or unpaired comparisons before printing a
verdict. Optional phases may be absent for a whole fixture; once supplied in
any sample, they must be present in every base and branch sample for that
fixture. Equal mesh/vertex/triangle counts remain a count check, not proof of
byte identity.

A zero baseline has no defined relative delta or noise floor. Both native and
browser reporters preserve those values as `null`: zero on both sides is inconclusive (below
timer resolution), while an increase from zero blocks a no-regression verdict.
Positive-baseline noise and real-change thresholds are unchanged. The JSON
verdict exposes `inconclusive` and `zeroBaselineIncrease`; each phase records
its direction when the relative delta is defined. Reporter regression tests use
synthetic input, not new performance measurements (#7912).

The browser reporter retains descriptive partial metrics but requires every
sample's metric to be present for a noise-based verdict. A metric absent
everywhere remains optional. Unknown sides, invalid fixture/round/count
identity and invalid supplied timings cannot produce a trusted comparison.
Existing readiness, failed-sample and GPU-loss rules remain binding.

**Instruction ceilings gate kernel and parse work only (#6982).** The
`native-instructions` ratchet (`tests/perf-ratchets/native-instructions*.json`,
0.05% tolerance, FZK-Haus per PR, ISSUE_129 daily) is a blocking check for
per-element kernel, decode and caching changes: callgrind counts follow them
to ~0.1% with run-to-run variance <= 1e-6. It runs `--single-thread` natively,
so it does not see scheduling, threading, WASM or browser-only effects (worker
fan-out, memory bandwidth, GPU); a change in those still needs an end-to-end
A/B (`ab.sh`, the browser rigs below), and a green ratchet is no evidence for it.


## Accepted eager viewer JS growth (#7759)

The maintainer approved resetting only the eager viewer JS ceiling to the
measurement from [main's ccf60b6bc0 build](https://github.com/LTplus-AG/ifc-lite/actions/runs/38927644281).
The `perf-ratchet-measured` artifact supplies the size and timestamp recorded in
`tests/perf-ratchets/bundle.json`; the independent builds for #7757 and #7758
reproduced the same raw JS sizes. Summing the eager scripts from #7758's hosted
viewer artifact independently reproduced the measurement. The existing tolerance,
entry JS ceiling and approved WASM ceiling stay unchanged.

This accepts accumulated eager-load growth, with no runtime speed claim. Record
acceptance against raw bytes: timestamp-sensitive JS Brotli sizes remain
informational, as documented by the measurer (#7007).

## Accepted engine bundle growth (#7756)

The maintainer approved resetting only the engine WASM transfer-size ceiling to
the measurement from [main's d8c110166a build](https://github.com/LTplus-AG/ifc-lite/actions/runs/38912543766).
That build includes the recent Rust correctness changes; its `perf-ratchet-measured`
artifact supplies the size and timestamp recorded in `tests/perf-ratchets/bundle.json`.
Recompressing the same build's WASM locally with Brotli quality 11 reproduced the
measurement. The existing tolerance and both viewer JS ceilings stay unchanged.
This accepts accumulated bundle growth, with no runtime performance claim.

Treat transfer-size acceptance separately from runtime performance and output
correctness: a size-ceiling update supplies evidence for neither. Future growth
still requires its own measured acceptance or a reduction.

## Published worker asset closure (#7648)

A Node geometry consumer passed while a fresh Vite consumer failed: the geometry
worker pool retained a TypeScript URL absent from its npm tarball. Package build
metadata now uses the same all-module rewrite and independent verification as the
parser; geometry and point-cloud verification checks script targets while their
WASM assets resolve through declared packages. Turbo hashes the shared scripts.

This is a packaging correction, with no runtime speed claim. The baseline browser
artifact cannot bundle, so it supplies no valid browser timing comparison. Real
Node consumer runs before and after produced identical mesh/triangle counts and
byte-identical GLB exports for the committed wall and ArchiCAD FZK fixtures. See
`tests/evidence/packed-workflows/worker-packaging.json`. Keep the external Vite
bundle in acceptance: a Node-only WASM pass cannot prove worker asset closure.

## Several cutting planes: caps and clip cost (#7545)

Browser A/B of `main` against the branch on a real GPU (Chrome 155, NVIDIA Blackwell, WebGPU), production
`vite build` of each side, a **fresh Chrome per sample** on a unique CDP port and throwaway profile, the six
variants (main at 0 and 1 plane, branch at 0, 1, 4 and 8 planes) in a **random order per round** (seeded,
`ab-order.mjs`'s generator), 4 rounds on AC20-FZK-Haus and 3 on a 29 MB heavy fixture of the repo. Each
sample loads the model, sets the planes through the store (Section tool open, 3D cut overlay on), waits for
every cap, then orbits for 370 frames counting what the frame submits.

| model | variant | draws / frame | writeBuffer / frame | submit-to-done median (ms, per sample) | caps ready after (ms) |
| --- | --- | --- | --- | --- | --- |
| AC20 | main, no plane | 26 | 25 | 2.17 (2.26 2.08 2.06 2.44) | - |
| AC20 | branch, no plane | 26 | 25 | 2.44 (2.61 2.42 2.46 2.35) | - |
| AC20 | main, 1 plane | 29 | 26 | 2.54 (2.48 2.03 2.59 2.68) | 40-64 |
| AC20 | branch, 1 plane | 29 | 27 | 2.63 (2.62 2.63 2.66 2.55) | 55-81 |
| AC20 | branch, 4 planes | 39 | 33 | 2.62 (2.86 2.25 2.73 2.51) | 59-119 |
| AC20 | branch, 8 planes | 52 | 42 | 2.71 (3.07 2.60 2.27 2.83) | 107-175 |
| heavy | main, no plane | 302 | 302 | 2.56 (2.56 2.44 2.85) | - |
| heavy | branch, no plane | 302 | 302 | 2.75 (2.75 3.25 1.92) | - |
| heavy | main, 1 plane | 305 | 303 | 2.48 (2.48 2.52 2.43) | 86-122 |
| heavy | branch, 1 plane | 305 | 304 | 2.74 (2.73 3.14 2.74) | 111-164 |
| heavy | branch, 4 planes | 315 | 311 | 3.12 (3.12 3.27 2.31) | 216-265 |
| heavy | branch, 8 planes | 328 | 319 | 2.84 (3.00 2.84 2.64) | 464-712 |

Reading it:

- **No plane and one plane draw exactly what main draws** (draws per frame identical on both models; one more
  `writeBuffer` per frame with a plane). The legacy 96-float uniform block is byte-identical; the per-mesh
  uniform is 128 floats larger, which is the only per-frame cost of the clip with no extra plane.
- Submit-to-done latency (how long the GPU takes after the frame is submitted) is within about 0.1-0.3 ms of
  main at 0 and 1 plane. Branch is at or above main in most pairs; with 3-4 samples per cell, a spread of
  +-0.3 ms inside a cell and a 2-3 ms baseline this is the edge of the noise, so it is recorded as a possible
  small cost of the larger uniform, not as "no change".
- **Each extra plane costs about three more draws per frame** (its cap fill, outline and line passes): 4 planes
  +10 draws, 8 planes +23 on both models, and +0.1-0.4 ms of GPU latency.
- The caps of the planes that are not active are cut on the CPU, off the render path: all caps are ready in
  under 0.2 s on AC20 and 0.5-0.7 s on the heavy fixture with 8 planes.
- What this does NOT measure: frame pacing. The hosted display ran rAF at 30 Hz, so every variant shows a
  33.3 ms frame; only GPU latency and the per-frame counts discriminate. Absolute numbers drift between
  sessions on this machine; only these interleaved pairs compare.

Verdict: no fallback needed. The caps layer ships with every enabled plane capped.

## Printable ASCII STEP escaping (#7363)

Campaign Group worker profiling attributed substantial work to rebuilding
already escaped printable ASCII Names character by character. The canonical
TypeScript escaper now returns its native quote/backslash replacement result
when no control or non-ASCII directive is needed. Shared cross-language vectors
and exact byte/roundtrip controls cover the unchanged directive path. This is
a native authoring/export workload correction, not a browser model-load speed
claim. A worker profile attributes work; isolated native acceptance under the
original deadlines is still required before a qualification verdict.

## Workbench preset controls load on demand (#6926)

The U03 preset controls initially exceeded the eager bundle allowance when
combined with the U02 activity tray, although each branch fit separately.
Loading the sidebar customizer only when opened reduced eager startup code,
but did not by itself clear the combined allowance. The subsequent shared
editor-state chunk separation on main restored headroom for the complete
campaign snapshot without another ceiling increase or tolerance change.
The real activity-bar regression opens the customizer, previews and applies
the coordinator preset, then restores the original layout and keyboard focus.
Reset also retires the saved preset through a small startup gateway instead
of importing the optional preview and placement controls. The mounted
regression reopens customization after Reset and confirms Restore is gone.
This is a bundle-size verdict; it makes no model-load speed claim.
Lesson: measure queued viewer features together, and keep optional editor
surfaces behind their actual entry point.

## Structural counters and long frames per load (#6957)

Sender-side accounting (#6993) now distinguishes actual worker transfer lists
from the host's received-buffer estimate. Both worker trace factories use the
same message meter and publish increments before data messages, so a terminal
transport survives immediate host termination. Parser phase traces also carry
WASM ingress; a successful entity-index handoff avoids that scan. The
[real-model receipt](evidence/worker-accounting-6993/README.md) records both
the canonical load and a separate actual parser scan. Lesson: receiving an
ArrayBuffer does not prove it was transferred, and flushing before constructing
the terminal message cannot account for that message. This is instrumentation
qualification, with no throughput verdict; GPU count repeatability remains open.

The bounded count cohort (#6993) uses one streaming fragment per mesh, with
mesh-count and index-volume bounds. Actual production FZK/Snowdon pairs
[repeat allocation and static-upload totals](evidence/count-uploads-6993/README.md)
despite different drain/finalization boundaries. Mutable table writes still
vary, so the shared static-buffer uploader has a distinct counter instead of
classifying all non-uniform writes as structural. Count-mode samples carry a
different workload and are refused by timing/baseline consumers. Lesson:
removing the clock budget does not make arbitrary fragment grouping or mutable
GPU writes structural. This is count qualification, not a throughput win.

The recovery replay qualification (#6993, folded #7164) found a correctness
hole after device replacement: geometry arriving while the device was absent
was never uploaded if the source stopped changing. The streaming hook now
observes the existing recovery epoch and retains a missed stream completion.
The same publication retries queued moves, rotations, colours, removals and
remeshed slots across the extracted renderer drains.
A subsequent normal entity-move allocation refusal exposed a sibling-effect
hole: rebatching was contained, but the annotation line upload still escaped
React and unmounted the viewport. Independent symbolic line/fill/text effects
now use the same upload guard and recovery epoch. Resource owners release
unregistered allocations before propagating failure. This is failure
containment and resource ownership, with no throughput claim.
The [native GPU receipt](evidence/recovery-replay-6993/README.md) compares the
exact base, healthy control and candidate through the canonical file loader.
The candidate restores the healthy scene's geometry and appearance identity;
the base remains empty after the same controlled loss. Lesson: replacing a
device does not wake source-driven effects by itself. Forced-loss samples
remain contaminated for performance measurement, and this does not explain
the original unforced SwiftShader loss.

Under `?perfTrace=1` and in every benchmark run, each load's span tree also
carries counters (`LoadTraceSnapshot.counters`): full source copies, worker
messages and their clone/transfer/shared bytes per direction, typed-array
bytes handed to wasm per worker and method, GPU buffers and uploaded bytes,
`mergeGeometry` calls and vertices, finalize rebuilds, store writes and
subscriber notifications, the per-append model-index re-spread, and a
LoAF/longtask summary attributed to the innermost open span. The benchmark
pins 4 geometry workers (`VIEWER_BENCHMARK_GEOM_WORKERS`) and records them in
`loadCounters`, split in two. `structural` (copies, messages, wasm ingress)
repeated exactly across runs on FZK and Snowdon, except for a few bytes of
parser diagnostic strings that carry elapsed times, so a diff there means
the load did different work. `scheduling` (GPU uploads and merges, React
commits, store churn) moves with frame timing. `flushPending` slices its
upload queue by a time budget, and SwiftShader loses and re-creates the
device mid-load, which re-uploads everything, so compare those as a spread.
Lesson: the benchmark's old 2D canvas probe could claim the viewport canvas
before the renderer did. After that `getContext('webgpu')` returns null, the
renderer logs "Failed to get WebGPU context", and the run measures no GPU work
at all. The probe now checks only the canvas size, and the counters are read
once they stop moving, not when the load root ends.

React commits per load are the `react.commits` counter, taken from the
DevTools global hook's `onCommitFiberRoot`: React's production build compiles
`<Profiler onRender>` out, so a root Profiler would count zero in the build
the benchmark and users run. `node scripts/perf/hook-census.mjs` counts hook
call sites and `useViewerStore` subscriptions on the viewport, properties,
hierarchy and streaming paths statically (minified component names make a
runtime fiber census unattributable, and mounted counts move with UI state).

## GPU point-pick depth candidate held (#6881)

The [same-submission GPU oracles](evidence/bounded-depth-readback-6881/README.md)
qualify single-texel extraction against a full-depth copy on hardware, including
concurrent maps and target replacement. Production family, ID/item/model and georeferenced world-coordinate controls
match the original renderer, and device destruction retires pending picks. The candidate shares ID/depth staging and keeps per-pick inputs immutable.
Four complete interleaved fresh-document public-model viewer pairs retain unchanged geometry and hit provenance, reduced mapped bytes, and mixed interaction timings. One pair has unresolved world-coordinate differences without camera/frame receipts; a fifth attempt lost the native browser. Cold-load provenance remains unverified. Real federated viewer qualification is outstanding. No speedup or shipping verdict is accepted. Lesson: a bounded readback and exact
GPU sample establish neither complete picking parity nor interaction throughput.

Independent Linux qualification adopted the existing readback cleanup repair;
inverse fault controls demonstrate the ownership defects and the repaired paths
release their buffers. Source-matched base/candidate viewer runtimes were built
and pinned. T3 navigation refused before the declared model phase, with the
earlier RAF refusal preserved. The subsequent current-main integration passed
root renderer tests, full serial root typecheck with both postchecks, lint and
source gates. Current real-model comparisons, federation and focused physical
performance remain held; CPU integration and cleanup qualification do not
replace them. No browser or GPU cohort ran for the integration update.

A subsequent normal main integration includes merged #7361 without copying its
classification workaround. Identical actual-main and candidate CPU controls
reproduce obsolete-picker results and delayed standalone teardown cleanup. One
shared pending-readback owner and a picker-installation epoch repair that class;
corrected root tests, full serial typecheck and source gates pass. Diagnostic
method retirement also preserves later owners. These are lifecycle invariants,
not native GPU acceptance. The current app/observer pair must be rebuilt and
frozen before the separate T3 correctness session. Original coordinates,
deadlines, refusals and the focused-performance hold remain.

Mounted base and original-draft hover controls also reproduce stale hits and
misses after newer input, pointer exit/cancel, unmount and ownership changes.
The [CPU hover archive](evidence/bounded-depth-readback-6881/hover-ownership-cpu-20261010.json.gz)
retains those inverses and the corrected shared viewport validity contract.
Selection and hover retain independent request generations. The diagnostic
recorder now retains resolved IFC identity and source provenance; serialization
controls do not establish native picked identities. No additional performance
claim follows from either repair.


## Prepass terminal trace publication (#6993)

The host terminates the prepass worker on its completion event. Draining only
finished spans at that point preserved counters but lost the active scan
span, whose handler had not returned. The worker now completes that named
span before publishing completion, using the shared trace host. Behavioral
controls observe the scan and counters before the terminal event, preserve
unrelated in-flight spans, and reject duplicate publication on handler return.
Verdict: diagnostic correctness, with no model-load speed claim. The disabled
trace returns before scanning active spans, and geometry production is
unchanged. Lesson: flush-before-termination must close the work represented
by the terminal event; a drain alone cannot preserve an open span. Other M2b
transfer, interaction, deterministic-upload and device-loss obligations remain
open.

## Worker warm-up candidate held (#7036)

The resumed [cold-load captures](evidence/worker-warmup-7036/README.md) show
earlier worker readiness but mixed first-visible and total-load results. No
end-to-end speedup is accepted. The candidate creates fresh workers beside the
file read and still terminates them after each load; it does not satisfy the
original persistent-reuse requirement. Geometry counts match, but an ordered
geometry hash was not collected. Repeat/federation measurements during takeover
overlapped validation builds and need an idle-machine repeat. Lesson: moving
worker initialization earlier is an opportunity screen, not a performance
verdict. Keep the measurement and memory constraints before changing the rollout.

The experiment defaults off on both the viewer and worker paths. Repeated cache
hits cannot extend an unused worker's expiry, and memory-pressure retries drain
the pool without refilling it. These are lifecycle corrections, not an accepted
performance win; the end-to-end verdict above remains held.

## Single-model appends cost O(new meshes) in the viewport (#7021)

**Shipped.** While one model streamed in, `geometryWithModelIndex` copied
every accumulated mesh on each viewport render to stamp `modelIndex`. The
copy gave the merged array a new identity, so the "incremental" type
filter, the type/occurrence scans and `Viewport`'s appearance-source list
started over each time, and that list copied every mesh a second time.
Measured with `loadCounters` (4 pinned workers, viewer-benchmark-ci): on
Holter each JS-side mesh was copied about 13 times, filtered 13 times and
copied 13 more times for appearance sources per load. Fix: a single model
renders its own mesh array, with `modelIndex` stamped in place by
`stampModelIndex`. It remembers per array how far it has stamped, so the
array keeps its identity and the existing incremental scans stay
incremental. One model's appearance list is that same array, and the index
allocator returns one shared map until an assignment changes. After the
fix, `viewer.modelIndexStamp` and `viewer.filterScan` each equal the JS
mesh count, and `viewer.modelIndexRespread` and `viewer.appearanceSource`
are 0 on single-model loads. Mesh and draw counts are unchanged.
`useFederatedGeometry.streaming.test.tsx` guards the per-append cost.

**Kept, deliberately:** the store still clones `models` per append. About
125 selectors read `s.models`, and its identity is how they hear about an
append to a non-active model, so dropping the clone would freeze them. The
clone itself is O(models). The cost was in what rescanned downstream.
**Still open:** several models keep wrapper copies (O(new) per append) and
build the appearance list in O(total) on every `models` change.
`store.notifications` (about 680 subscribers per write) is untouched.
**Lesson:** a cache keyed on array identity is only as incremental as its
least stable upstream producer. Count the visits (`viewer.filterScan`)
instead of trusting the "incremental" comment.

## Federated appearance-source rebuilding candidate (#6537 / #7021)

**Merged in #7369; end-to-end performance held.** The
[real FZK/Snowdon mounted controls](evidence/federated-appearance-6537/README.md)
demonstrate repeated accumulated/peer mesh visits and ownership wrapper copies
in the remaining multi-model appearance list. Canonical producer stamping and
a retained ordered list remove that repeated source work; replacement, content,
visibility, removal/readdition and CPU-release controls pass with unchanged
ordered geometry. Earlier-model appends still move suffix references to retain
model order, counted separately. No load-time or peak-memory improvement is
accepted: actual worker-pool federation A/B and focused GPU acceptance remain
outstanding. Lesson: borrowing producer objects removes wrapper allocation,
but grouped ordering still has a movement cost; qualify the real federation
journey instead of a single-model cold load.
The [removal gate and idle admission](evidence/federated-appearance-6537/gate-and-admission-20261010/README.md)
are recorded separately: global Knip failed with unrelated source findings
adjudicated by the campaign root; the timing cohort stopped at actual CPU,
paging and swap admission before any model or probe ran. Lesson: a campaign
reservation does not establish host-wide idle across other project owners.

## Frame-time rigs (#6960)

Two rigs measure viewer frames; neither is a PR gate. Both inject the same
in-page probe (`tests/benchmark/frames/frame-probe.ts`): rAF callback time,
rendered vs idle frames (a frame that called `getCurrentTexture`), and
`GPUQueue.submit` / `draw*` / `writeBuffer` per frame.

- **Deterministic, CI-capable**: `pnpm test:benchmark:frames` (needs a built
  viewer and `pnpm exec playwright install chromium-headless-shell`).
  chrome-headless-shell is driven frame by frame over CDP
  `HeadlessExperimental.beginFrame` on an exact 8.333 ms grid (new-headless
  Chrome lacks that command). Scenarios on FZK and Snowdon: streaming load,
  Home plus scripted orbit, hover sweep. Records main-thread task time per
  frame, frames over budget, missed vsyncs (load only) and rendered vs idle
  frames as `browser-frames` rows in `test-results/browser-frames.json`. GPU
  time is excluded by construction (SwiftShader). Runs nightly in
  `.github/workflows/browser-frames.yml`. Within one build, scripted
  orbit/hover counts repeat, but streaming-load frame, draw and submit counts
  do not, and millisecond metrics move with machine load. Compare spreads,
  not single runs (see "Frame ratchet: only load upload volume repeats" below).
- **Real GPU, local only**: `scripts/perf/frame-gpu-rig.mts` drives Windows
  Chrome from WSL (random CDP port, throwaway profile killed by path and
  deleted), serves a production build same-origin, loads `?model=`, presses
  Home and replays the same orbit and hover at 120 Hz of wall time. Reports
  rAF delta p50/p95/max, submits and draws per rendered frame and
  `onSubmittedWorkDone` latency. Absolute frame time drifts between sessions,
  so pass `--dist-base <base build>` for counterbalanced base/branch pairs and
  read the paired ratio. Serialise timed runs:
  `flock /tmp/ifclite-perf.lock npx tsx scripts/perf/frame-gpu-rig.mts tests/models/ara3d/AC20-FZK-Haus.ifc --pairs 3 --branch-revision <built-revision>`.
  With `--dist-base`, also pass `--base-revision <base-built-revision>`. Both
  revisions must include #6979 and are recorded before host/browser work. This
  checks source ancestry; retain independent build/hash receipts binding each
  dist to its declared revision. Offline `--plan` and `--summarize` need no revisions.
- **Real GPU structural counts, local only (#6993)**:
  `scripts/perf/native-count-driver.mts` reuses the frame rig's Windows
  Chrome lifecycle, host/physical-session admission and static server, and
  `ViewerBenchmarkPage` for the load itself. Two fresh loads each of FZK and
  Snowdon, one fresh owned profile per sample, at exactly
  `?perfTrace=1&geomWorkers=4&meshCache=0&perf.benchmarkUploads=1&perf.batchSizing=%7B%22targetMs%22%3A8000%2C%22minJobs%22%3A64%2C%22maxJobs%22%3A64%7D`,
  through the canonical file input (`useIfcLoader.loadFile`, never `?model=`).
  A sample is healthy only with a finished metadata completion (parser or
  canonical cache), `geometry.streamComplete`, an ended root, a finished
  `scene.finalize`, count-mode flushes, settled counters, the GPU
  allocation/static-upload and sender transfer vectors, zero device loss or
  replacement, zero page errors and every interaction-commit step measured.
  Unhealthy samples are kept, with their refusals. Receipts: fixture, dist
  `index.html` and served WASM SHA-256s, branch revision, Chrome version,
  host admission before/after, per-sample JSON and `summary.json` (exit 0
  only when every sample is healthy and both vectors repeat per fixture):
  `flock /tmp/ifclite-perf.lock npx tsx scripts/perf/native-count-driver.mts --branch-revision <built-revision> --require-host-idle --require-physical-display`.
  `--plan` prints the samples and URL without launching anything. It does NOT
  prove latency or throughput (count uploads are a different workload and are
  refused by timing consumers), CPU mesh byte identity, schedule-independent
  aggregate `gpu.writeBytes`, or device-loss recovery
  (`evidence/recovery-replay-6993` covers that separately); `--branch-revision`
  checks source ancestry only, so the served-file hashes are the build binding.

## Deterministic frame evidence admission (#6975)

The [historical artifact audit](evidence/gpu-frame-timing-6975/frame-admission/historical-artifact-audit.json)
found changing streaming counts and main-thread totals across actual hosted
runs. Those builds differed, so they do not establish same-build repeatability;
no frame ceiling is justified by this audit. The workflow's former scenario
count also admitted incomplete metrics and retained no GPU-health witness.
The rig now preserves per-fixture completion, page errors and the shared
session-counter/console health classification, and admission requires every
expected metric and healthy completion. Canonical metadata/root/finalization
readiness and health are checked after the original scenario windows. Raw
failed evidence remains uploaded. Enabling trace counters makes this a new
instrumented cohort; its rows must not be pooled with older unobserved runs.
Lesson: scenario coverage alone does not prove complete or uncontaminated
measurements. Physical-display nights and calibrated thresholds remain
outstanding; for which rows now carry ceilings, see the next section.

## Frame ratchet: only load upload volume repeats (#6975)

Verdict: the `browser-frames` ratchet family gates one row, the Snowdon
streaming-load `gpu_write_kib`. All other rows stay informational. The
evidence is [repeatability.json](evidence/gpu-frame-timing-6975/frame-ratchet/repeatability.json):
hosted runs of two builds (current `main`, which seeds the ceiling, and the
#7601 retry head), with raw per-run values, run ids, artifact sha256s,
per-build stats and a verdict for each of the 96 rows.
`frame-ratchet-evidence.test.mjs` recomputes that verdict. The criteria were
fixed before the `main` runs were downloaded and were not changed afterwards.

- The #6975 expectation was "load counts and main-thread totals repeat". The
  data refutes it. Within ONE build, main-thread totals, percentiles and load
  frame/draw/submit counts move by tens of percent on hosted SwiftShader. Load
  length in frames depends on main-thread speed, and draws and submits follow
  the frames rendered during the load. None of them can hold a ceiling whose
  band means anything.
- Load upload volume is the one row that is close to stable. On Snowdon it
  stays far inside the cap. On FZK it moves with the number of frames rendered
  during the load and lands just over the 1% cap on `main`, so it stays
  informational. Do not loosen the cap after the fact to admit it.
- Orbit/hover render, draw, submit and upload counts were identical in every
  run of each build, but #6975 rules them out: they follow the adaptive render
  throttle, which a slower runner engages with no code change. Note that they
  are sensitive. The FZK orbit upload volume differs between the two builds.
  This is informational only; the two builds are not in an ancestor relation,
  so no regression is claimed. Revisit with physical-GPU nights, not by
  relaxing the rule.
- Contamination is real and handled. On hosted SwiftShader, Dawn sometimes
  loses its instance mid-load (mostly on Snowdon), and the renderer then
  re-uploads the whole scene. Before #7601 that failed the run outright
  (two of the five pre-retry runs in the evidence, Snowdon both times; #7601
  saw about two in six).
  #7601 replaces such an attempt with a fresh browser, at most twice, and
  retains each refusal in `refusedAttempts`. Every post-#7601 run in the
  evidence was admitted. The tally per fixture is in the evidence file. The
  ratchet consumes only admitted artifacts: the measurer re-runs admission and
  refuses rather than evaluating, and the daily lowering reads only the
  latest *successful* `main` run of the lane.
- Not proven: real-GPU frame cost (SwiftShader only), and behaviour on another
  runner image or Chrome version. The pre-#7601 artifacts lack attempt
  receipts, so they are counted for contamination but not admitted.

## Real-GPU nightly trend and alert (#6975)

`frame-gpu-night-trend.mts append` turns one real-GPU rig run directory into
one row of an append-only JSONL trend: the night, the hash of the raw
`runs.jsonl`, the night-profile hash, per-metric medians and a status. A night
is `ok` only when every sample carries the strict admission witnesses the rig
records under `--require-host-idle`, `--require-physical-display` and
`--require-gpu-timing` (quiet host before and after, one physical console
session, held foreground, a hardware adapter, per-pass GPU timing). A run
without them is kept as `failed` and an admission refusal as `refused`, so
both interrupt the seven-night calendar instead of vanishing. Rows are refused
when the run finished more than 24 h before the append, when the receipt is
already present or when the run started before the last row: no backfill.

`evaluate` prints a verdict for one night and, with `--report-issue`, opens
the regression issue or comments on the open one through `gh`. No threshold
ships: without a thresholds file every verdict is `uncalibrated`. A thresholds
file is admitted only when it names seven consecutive `ok` nights of the trend
under one profile and no maximum is below a value those nights measured.
Nothing installs a scheduler; whatever runs a night calls the rig, then
`append`, then `evaluate`. Zero genuine nights are recorded as of this entry.

## Viewer JS is gated on raw bytes, not brotli (#7007)

The viewer build is byte-reproducible apart from `__BUILD_DATE__` (the build
timestamp `vite.config.ts` bakes into the entry chunk and `analytics`). Module
order was NOT the cause: three clean builds of one tree kept all 304 JS files'
raw sizes and, chunk hashes stripped, every file's content except those two;
both CI attempts of one commit kept the entry's raw size and the eager file
order. Brotli-11 of the entry chunk is still noisy, because a
same-length timestamp swap alone is enough to jump it by ~0.5% (bimodal over
48 dates, matching the 4.3 KB CI re-run swing). Pinning the timestamp would
only make one tree repeat; every other edit perturbs the compressor the same
way. **Lesson:** gate the JS on raw bytes, report brotli, and don't try to
make a brotli number on a multi-megabyte JS chunk stable to better than ~0.5%.

## Instruction counts track kernel and parse work, not scheduling (#6958)

Replay before any gate: `instructions-replay.mjs` rebuilt both sides of 12
ledger entries in throwaway worktrees (every side built and ran on today's pinned
toolchain; none had to be skipped) and counted one single-threaded `process_geometry` call per fixture
under callgrind, 3 runs per side. A direction is read only outside a flat band
of max(0.01%, combined run-to-run spread of the two sides). Raw runs:
`evidence/instruction-replay-6958/results.json`. Inputs, refs and claims:
`candidates.json`.

| entry | ledger end-to-end verdict | fixture (claimed) | Ir delta | flat band | verdict |
|---|---|---|---:|---:|---|
| CDT scan kill (46dcdeec2) | ISSUE_129 geometry 991 -> 651 ms | ISSUE_129 | -47.12% | ±0.011% | tracks |
| #1916 squash (seam conform + CDT) | 979 -> 646 ms | ISSUE_129 | -27.17% | ±0.040% | tracks (output changed) |
| #1568 point-cache hoist | win on shared-point steel models | #1572 shared-point fixture | -3.17% | ±0.017% | tracks |
| #1572 cache across chunks/splits | win on shared-point steel models | #1572 shared-point fixture | -0.34% | ±0.021% | tracks |
| #1184 cheap-hash BREP dedup | win on steel/Tekla | #1572 shared-point fixture | -2.46% | ±0.010% | tracks |
| #1130 content dedup | 20-30% slower net | FZK / ISSUE_129 / shared-point | +9.98% / +0.33% / +87.0% | <= ±0.031% | tracks |
| #1177 dedup off | revert of that loss | FZK / ISSUE_129 / shared-point | -12.31% / -0.51% / -43.45% | <= ±0.017% | tracks |
| #4061 vertex reuse (rejected) | native -1.17% / -1.27%; rejected in the browser | FZK / ISSUE_129 | -0.11% / -1.08% | ±0.010% | tracks the native direction |
| #1909 dedup gate | no corpus fixture crosses the gate; A/B was noise | FZK / ISSUE_129 | +0.22% / +0.03% | ±0.045% / ±0.076% | FZK does not track: real cost |
| #1431 worker sizing (TS only) | -21% peak memory, 0 regression | FZK | +0.01% | ±0.058% | tracks (flat) |
| #1255 threads bundle (feature off) | #1429 dead end | FZK / ISSUE_129 | -0.00% / -0.00% | <= ±0.036% | tracks (flat) |
| #4054 parity BVH (rejected) | no native number recorded | FZK / ISSUE_129 | -0.21% / -5.74% | ±0.010% | no claim to compare |

Not every fixture had a ledger claim; unclaimed ones are recorded as context
in `results.json`. Notable ones: #1184 and #1568 cost +1.3% / -0.12% on FZK,
and #1572 is flat on FZK and ISSUE_129. The #1916 squash costs +1.5% on FZK,
with changed output.

- **Where counts apply.** Every claimed direction for a kernel, decode or
  memoization change came back with the ledger's sign, with one exception:
  #1909 on FZK-Haus, where the ledger expected flat and the count rose +0.22%
  (see below). The agreeing set includes both
  content-dedup flips and the CDT kill, which the ledger measured only by
  instrumented slot counts and wall time. Magnitudes are not wall-clock
  proportional: the CDT kill is -47% Ir against -34% geometry ms, the #1916
  squash -27% against -34%. Use counts to detect and size a change in work, not
  to predict milliseconds.
- **Where they do not.** Scheduling, threading and memory policy are invisible
  by construction: the run is one thread and counts no stalls. #1431 and #1255
  are flat because they do not change the native work, and #1572's multi-thread
  amplification fix shows only its small single-thread part (-0.34%). Browser
  verdicts are invisible too. #4061's native direction tracks, but it was
  rejected on browser readiness and output gates, and #4054's -5.7% on ISSUE_129
  says nothing about the browser screen that rejected it. A count win is not a
  ship verdict.
- **What counts saw that wall-clock missed.** #1909's gate decodes the shell's
  face list for every faceted BREP. On FZK-Haus, where no BREP crosses the
  gate, that is +0.22% work, about 5x outside the band. The wall-clock A/B
  recorded for it swung ±10% with run order.
- **Determinism caveat for history.** Today's code repeats to ~1e-6.
  Historical binaries repeat only to ~1e-3 on a single run, because glibc
  `_int_malloc`/`unlink_chunk` path lengths vary between runs. The first
  single-run replay (`results-single-run.json`) produced false "flat/more" reads
  inside that spread. Always run several times per side and take the band from
  the measured spread.
- **Verdict for #6958.** Counts track kernel and parse work, so per-phase
  FZK-Haus and ISSUE_129 counts are now M4 ceilings (seeded by #6995 for
  #6982, FZK-Haus per PR and ISSUE_129 daily). Scheduling-only and
  browser-only levers still need the end-to-end harnesses.

## Load-trace spans replace console scraping (#6956)

Viewer load milestones are now named spans (`@ifc-lite/load-trace`): one tree
per load across the main thread and the geometry workers, mirrored into User
Timing as `ifc:<name>` and readable as `window.__IFC_LITE_LOAD_TRACE__` under
`?perfTrace=1`. The viewer benchmark reads its timing metrics from that tree
exclusively after the follow-up release (#7005). The transitional console
regexes and agreement comparator have been removed. Mesh/entity counts and
render diagnostics remain available, but no console timing/completion enters
a sample. Use the span tree for any new load-time metric. Tracing off is not a lever: the disabled
trace is a no-op object, about 2 ns per instrumented call in Node, against
roughly 25 calls per load.

## Pending picking survives redundant viewport synchronization (#6882)

Native-GPU navigation qualification exposed a shared correctness defect before
the resolution-cap candidate could receive a performance verdict. A queued pick
was discarded when `Camera.setAspect` repeated its current ratio, although its
projection, camera pose and CSS viewport were unchanged. Preserve that snapshot
with an exact no-op in the aspect setter; do not suppress equal relative-to-eye
frames globally, since scene republication intentionally invalidates picks.

A proportional resize can preserve the aspect while changing pick coordinates.
Check the original CSS-to-texel mapping after every asynchronous picking path,
including rectangle selection and its readback-error fallback. Physical drawing
buffer changes with unchanged CSS mapping remain valid. This is a correctness
prerequisite, not a measured speed improvement or an explanation of the earlier
spontaneous miss. Keep functional qualification separate from timing admission.
[Original actual-GPU observations and compiled qualification](evidence/redundant-aspect-pick-6882/README.md)
preserve the source identities and evidence boundaries.

## Historical CSG job observations (#6516)

Use the existing ordered CSG census for a small feature-gated diagnostic before
adding geometry hooks or porting newer algorithms into historical releases.
Complete public-model loads preserve the ordinary output within each release,
and individual job replays reproduce their canonical batches. Matching original
source tuples localizes the public slab's changed output and larger later host
operands, consistent with the source's retained-hole correction. This does not
establish the private reported regression's cause or a performance improvement.

Interpret these as positive wrapper observations only. Existing recording can
precede empty checks, silently return empty on a poisoned lock, and retain an
unbounded vector within a call. Do not infer zero work, complete invocation
counts or causal workload ratios. Preserve the earlier validator refusal: the
old streaming helper performs a separate verification load, so its aggregate
log counts cannot be compared directly with a single-load diagnostic. Compare
ordinary logs within the same load boundary. Delivery and private-file output
checks are documented in [stream-diagnostic.md](stream-diagnostic.md).

The isolated Actions bundle also passed complete public-model checks on Linux
and Windows, including the uploaded and downloaded file inventory. Both
platforms preserve the same per-release output and original-job replay results.
Fresh source builds still differ from the published engines and earlier local
builds; the qualified delivery does not establish byte-equivalent engines,
timings or private-model compatibility. Keep those identities separate and
require the same-release output checks on the reporter's model. The committed
[delivery summary](csg-work-delivery-qualification.json) pins the actual run.

## Bundled main-first module sharing: scoped SDK result (#6537)

Bundled initialization removes the second observed WASM request before the
default SDK worker pool. Both completed historical candidates retain equal
CPU-channel output and full unnormalized diagnostics across the fixed public
families, but elapsed observations remain small or mixed with all outliers kept.
They do not establish an all-model win. Separately fresh engines differ in code
and data despite equal captured Rust/build inputs, including absolute checkout
paths; their elapsed differences do not isolate the JavaScript mechanism.

Starting shared acquisition exposes failure semantics that merely joining an
optional promise did not exercise. Preserve original rejection inside canonical
retry, optional callers' null fallback, and the same response for permitted MIME
fallback. Fatal bytes must not cause refetches; successful streaming must not
leave a cloned body. Public glue also returns its initialized engine before
reading options: eager acquisition broke warm-engine offline compatibility.
Prepare lazy public-init options so that only a cold engine acquires a module.
Actual generated-loader controls preserve the predecessor assertion failure,
the intermediate cross-realm harness refusal, and the corrected warm-engine proof.

The corrected lazy source now has its own qualified fresh default-worker SDK
comparison, with equal produced CPU-channel identity and untouched diagnostics,
passing preceding noise controls, resource gates, final freeze and cleanup.
The house and heavy CSG observations consistently improve; the CSG and large
architecture pairs are mixed. Every observation remains, including high baseline
values. The second observed request is removed, but independently fresh engine
bytes still differ, so elapsed results do not isolate JavaScript's contribution.
This is a scoped SDK result, not a universal speed, RSS or full-viewer verdict.
The lesson is to share cold acquisition without breaking public glue's warm
fast path, preserve failure contracts, and qualify actual worker-pool completion
separately from cached-artifact functional proofs. [All raw cohorts, compatibility
failures, corrected proofs and limits](evidence/bundled-wasm-init-6537/README.md)
remain available without replacing or pooling earlier evidence.

## Direct vertex packing: do not ship the current candidate (#6537)

The candidate removes an intermediate vertex buffer for eligible quantized
batches. Regression controls establish the allocation reduction and preserve
the original GPU upload bytes, including float rounding and fallback cases.
That resource improvement did not establish an end-to-end speed improvement:
fresh native-GPU worker-pool pairs were slightly slower on the house model,
mostly slower on Holter, and mixed on the larger architectural model. The
Revit cohort was interrupted by detected background activity before its last
pair completed. No replacement sample was inserted and no full-corpus verdict
is claimed. The current candidate stays out of production.

The complete house, Holter and architectural pair groups retain identical CPU
geometry and appearance fingerprints. Heavy-scene GPU batch sizes and images
varied even between baseline loads, so those runs do not prove heavy-scene
GPU byte or pixel identity. Sampled JavaScript heap is not physical peak
memory. The separate admission-scheduling attempt stopped during its first
baseline A/B sample and establishes no candidate comparison.

Lesson: fewer staging bytes are a hypothesis about cost, not a speed verdict.
Measure eligible vertex volume, float-fallback work and renderer completion
before revisiting this candidate. Preserve interrupted runs, their exclusion
reasons and unchanged output witnesses. Source controls, the unshipped patch,
all raw attempts and paired derivations are in
[`evidence/packing-verdict-6537/`](./evidence/packing-verdict-6537/README.md).

## Affinity admission and compact worker packets: defer (#6537)

The sticky-key admission pilot has meaningful pool/recovery and inverse
controls, but both full-load cohorts stopped on detected background work.
They retain their original contaminated rows without substitutes. A later
O-S1 diagnostic explains flat/instance redistribution and preserves occurrence
counts, while reconstructed positions and normals still differ. This does not
qualify byte identity, canonical precision, GPU picking or a complete throughput
verdict. Do not ship the pilot from worker-only or flat-only evidence.

Compact worker source packets remain a feasibility question. The canonical
forward-reference census measures reached record bytes, not every direct,
inverse, setup and recovery access. Original offsets still reach near the file
end. Establish conservative dependency completeness and offset addressability
before introducing any producer; then measure construction, copies and whole
load. A sparse reference list is not a safe packet or physical-memory result.

Lesson: separate scheduling credit, dependency completeness and geometry
representation from the final load metric. Preserve true sticky keys and the
canonical parser; defer mechanisms whose correctness or end-to-end verdict
remains incomplete. [Raw dispositions and prerequisites](evidence/deferred-worker-mechanisms-6537/README.md)
retain source attribution and the excluded attempts.

## Known-explicit orientation: rejected, do not ship (#6537 / #6788)

The private known-explicit helper preserved adaptive arithmetic and passed the
predicate/workspace correctness controls. Earlier default-worker SDK results
showed a scoped ISSUE129 benefit; the separate native comparison remained mixed.
The fresh integrated default-worker SDK comparison retained CPU output identity
and complete diagnostics, but every observed Holter pair was slower. Haus and
O-S1 were mixed. The heavy-family regression blocks shipment under the project's
no-regressions requirement; the orientation implementation is removed. Freshly
built WASM artifacts differ between arms, so this rejects the candidate
combination without isolating dispatch as the cause of the Holter slowdown.

Lesson: a scoped CSG signal cannot justify a regression on a heavy public model.
Instruction attribution and avoided dispatch do not establish consumer benefit.
Stop this candidate, preserve every pair and refusal, and keep the rejected patch
as data so the mechanism is not proposed again without genuinely new evidence.
The [lossless rejection record](evidence/explicit-orientation-6537/README.md)
retains immutable sources, correctness controls, historical SDK/native cohorts
and the new integrated comparison. No universal, full-viewer, physical-memory or
complete IFC fidelity benefit is claimed.

## Checked-magnitude products: native benefit, SDK mixed (#6537 / #6764)

Bounding provably-fitting checked products by their actual magnitude widths
reduces arithmetic work while preserving the full overflow/fallback paths.
The qualified canonical warm/prepared native comparison improves on the
void-heavy CSG model; Holter remains neutral and the house result is noisy.
Counts and ordered mesh fingerprints agree within the fingerprint's declared
coverage. The separate default-worker SDK cohort remains mixed, and full-viewer
performance is unqualified. This is no universal worker-pool speedup claim.

Lesson: real arithmetic opportunity and native instruction reductions do not
establish browser throughput. Preserve exact overflow, sign and row-carry
oracles, then measure the actual consumer and disclose identity exclusions.
The [lossless native evidence and audit history](
evidence/checked-magnitude-native-6537/README.md) retain all original pairs,
the corrected checker-status refusal, prior instruction/correctness evidence,
and scope limits. Available-memory guards exist in the frozen producer, but
missing numeric readings prevent reconstruction of the admission floor.

## Initial index reservation: no attributable default-pool benefit (#6537)

The PR #6730 source inspection found no changed reservation request in its
four default SDK fixture routes. The house remains below activation; the three
larger models use sharded, prebuilt indexes that bypass the changed constructors.
Their unused prepass staging map already reserves zero on the base revision.
The bounded captures retain equal produced CPU output and complete diagnostics,
including known kernel failures. They establish neither faithful IFC output nor
an affected-path speed or physical-memory verdict. The earlier resource refusal
remains preserved separately from the larger-budget inspection.

Lesson: verify that the default load actually executes the changed allocation
before assigning it an end-to-end benefit. This finite corpus does not rule out
an affected input between cap activation and default sharding, and does not
qualify the candidate for merge. [Source eligibility and complete raw evidence](
evidence/default-pool-reservation-6537/README.md) retain the unshipped attribution.

## Ring neighbour searches: do not infer a general hotspot (#6537)

Opt-in canonical work counts and feature-off output controls do not support
linked-neighbour indices as a broad performance fix. The public slab has little
searching beyond adjacent live vertices; Holter has none. House and Revit CSG
contain additional probes, but no profile establishes time dominance or that
constructing neighbour arrays would pay back. A synthetic collinear ring proves
the quadratic worst case, not its relevance to these models. The diagnostic
preserves the algorithm and its output; it is not an optimization or speed claim.

Lesson: count actual post-weld searches before replacing their representation.
Saved raw-ring lengths cannot reconstruct cleaned-ring work. Preserve exact
sweep order, predicates, coordinates and topology if profiling later warrants
a prototype, then qualify the ordinary end-to-end worker pool.
[Complete native work census, source identities and output controls](
evidence/ring-search-opportunity-6537/README.md) retain the bounded public screen
and its exclusions.

## Opt-in map geometry compatibility export (#6587)

The qualified comparison uses the actual main-based package prerequisite and
the frozen ownership-corrected implementation, before the later mapped-depth
preflight correction. Native loads, real browser worker-pool loads,
and the default asynchronous STEP API retained byte-identical payloads,
including browser instances. Their interleaved timings showed no consistent
regression within the bounded cohort. Fresh tabs used distinct origins in a
shared native browser runtime; DOM visibility was recorded, but physical panel
foreground and cold-process performance were not established. Unrelated user
applications remained open, so this is not a claim of an idle operating system.

Earlier cohorts are retained as diagnostics: a later audit found continuous
GPU work in validation tabs. Those timings are not pooled with the replacement
cohort or used to establish the verdict. Agent-controlled builds, uploads and
GPU evidence work were held during the qualified replacement measurements.

The opt-in export has an explicit cost: it parses the mutation-resolved emitted
model and produces canonical placement/representation patches. Its first call
also imports and initializes the geometry backend. The WASM binary grows to
carry the planner. These measurements establish bounded default-path evidence,
not an optimization or a universal zero-cost claim. Raw witnesses and supported
mutation proofs are under `scripts/perf/evidence/map-normalization-6587/`.

The subsequent opt-in depth correction reserves a mapped wrapper and terminal
leaf before serialization. Its new binary was rebuilt and behaviorally checked,
but was not timed in that frozen cohort. The default mesh-production path is
unchanged; the earlier measurements are evidence for their recorded binaries.

Lesson: benchmark the real export API as well as the untouched load path.
Keep unit conversion separate from physical map scale, reuse the strict Rust
placement resolver, and settle changed entity IDs through the existing export
ledger. Removing strict target-unit validation or reversing affine/placement
order is detected by actual behavioral regressions, rather than merely making
the new API disappear at import time. Audit background render loops before
granting a timing window; stopping new actions alone does not stop old loops.

## Planar conic handedness (#6597)

Interleaved base-versus-branch native full-load runs on the house fixture and
void-heavy ISSUE_129 fixture showed no consistent total-load slowdown beyond
local variation. Both retained byte-identical ordered mesh payloads and counts.
This is a correctness fix: no throughput improvement or browser worker-pool
performance claim is made. The downward-axis synthetic extrusion intentionally
changes shape, with an independent pinned IfcOpenShell oracle confirming its
bounds, surface area and volume.

Lesson: RefDirection gives the local X direction, while Axis determines the
handedness of local Y. Reuse the canonical placement frame rather than adding
another direction decoder, and test both forward conic sampling and Cartesian
trim inversion; either half alone leaves a mirrored or incorrectly trimmed arc.

## In-call geometry heartbeat replaces wall-clock element skips (#4884 follow-up)

Field signature: one mid-size model opened by about ten people stalled for most
of them; when it loaded, the median `total_elapsed_ms` was about 145 s while
first geometry appeared within seconds, and loads with the same mesh roster
reported flat triangle totals varying almost fourfold. 145 s is the hung-call recovery budget:
45 s until a silent multi-job call is replaced, a one-job-per-call replay, then
90 s more until the slow element is skipped. A synthetic file with one wall
carrying 200 tilted circular openings reproduced it exactly in the browser
(143 s, wall skipped, identical on every run), and adding CPU load changed which
calls were replayed and therefore the reported mesh and triangle counts.

The worker could not speak while inside one WASM call, so a slow element and a
hung call looked identical. The kernel now calls `ifc_lite_geometry::progress::tick`
at coarse points of every long path (each boolean, analytic prism cut,
consolidation bucket and region, conform loop, strided CDT and exact-predicate
work). The binding rate-limits that to one JS callback a second, and the worker
forwards it as its existing liveness message only while a batch call runs. A
call that stops reporting is still recovered exactly as before, and every call
keeps an absolute 10-minute bound (`MAX_GEOMETRY_CALL_MS`) however often it
reports: past it the pool recovers the call like a silent one, and with
recovery off it stops counting heartbeats as liveness so the stream watchdog
still fires. With no hook
installed (every native target) a tick is one atomic load; ordered native mesh
fingerprints are unchanged on AC20, ISSUE_129 and Holter.

Coverage was measured, not assumed: a native hook recording the longest gap
between ticks found 7-8 s single-call stretches on the synthetic walls (a
quadratic conform candidate scan and one large constrained triangulation)
before those loops were covered; after, the longest gap is about 1.3 s natively
on the synthetic walls and under 0.5 s on the heavy corpus models. Result on the
synthetic file: 88 s with the wall present instead of 143 s with it skipped, the
same 483 meshes and 548,428 triangles idle and under load, and no recovery.

Lesson: never let a wall-clock budget decide WHAT geometry is produced. A
recovery timer is legitimate for a call that has stopped making progress, but
it needs a progress signal to tell that apart from a slow call. Open follow-ups:
the analytic prism route spends most of such a wall's time before deferring to
the exact kernel, and the flat/instanced split still follows call composition.

## Shared-buffer retries after a WASM trap (#6542)

A compatibility retry must distinguish a rejected shared view from a WASM
runtime trap. Replaying a trapped handle with a materialized file copy adds
memory pressure and can replace the original error. Worker contract tests
verify that streaming prepasses and shard operations stop before that retry;
batch processing retains its existing per-entity recovery. Successful mesh
production is unchanged. No end-to-end throughput measurement or improvement
is claimed. Lesson: restrict copying compatibility fallbacks to non-trap
failures rather than interpreting every WASM exception as a view refusal.

## Caller-supplied rebar precheck (#5797)

On the Revit Snowdon fixture, interleaved base/branch Python schedule calls
produced byte-identical default reports and no measurable runtime change within
local run spread. Interleaved calls on the branch likewise showed no measurable
added cost for the opt-in policy. The policy reuses schedule decoding and exact
directrix metrics, so a worker-pool geometry probe would not exercise it.
Lesson: time the export API that owns an opt-in check and verify default output
identity; a general geometry load number cannot establish its overhead.

## Streaming-time panel refresh (#6411)

On a 127K-element, ~1 GB MEP model, the geometry workers were ~100% busy and
then went idle up to ~10 s before stream completion, while the main thread was
0-3% idle for the whole stream. Cause: the hierarchy tree, the status-bar count
and the model statistics each re-derived whole-model data on every streaming
geometry publish (every 500 ms for files over 300 MB). The hierarchy alone took
45-58% of the main thread for over a minute. Holding their geometry-derived
inputs to a 4 s cadence while streaming (exact at stream end) cut readiness to
0.53-0.62x in interleaved cold-load pairs on a loaded machine. A small-to-
large corpus showed no regression. Lessons:

- Check whether the MAIN thread is the drain before touching workers. Here
  `?geomWorkers=2` beat the default 4 and 8, because more workers only
  queued more batches behind a saturated main thread.
- Main-thread waste costs most when the machine is busy: the same build
  varied 42-116 s with host load, and the gain grew with it.
## Post-stream upload drain slice (#6436)

After a large stream completes, the renderer cannot finalize until the upload
queue drains. The queue drained in the 12 ms per-frame slice that exists for
the worker pump during streaming. Allowing 32 ms once the stream has ended and
nobody navigates cut the drain on a 1 GB MEP model from 5.2-6.3 s to 3.2-4.5 s
in interleaved pairs. The streaming phase is unchanged by construction: the
budget is the default whenever geometry streams. Lesson: a time slice sized
for one phase silently carries into the next. Timestamp phase boundaries
(`Stream complete`, `Streaming ended`, `finalizeStreamingAsync complete`)
before assuming the tail is finalize work.
## One full-source hash per load, beside the critical path (#7022)

The loader awaited the placement identity (SHA-256 in 1 MiB chunks) before the
cache lookup, then hashed the same bytes again for the cache write or for a
warm hit's background revalidation. The identity now starts once the bytes are
in hand and is awaited only by finalize (so a complete model still carries it),
the cache write (which stores it) and the revalidation (which compares against
it). A cache entry holding a bare whole-file hash from an older viewer is a
miss, purged and rewritten by the reparse. Each full-source pass now counts as
`hash.fullSource` in the structural counters.

Interleaved real-GPU pairs (Windows Chrome over CDP, five rounds, FZK, Snowdon,
a 54 MB and a 327 MB model, cold and warm) gave identical mesh counts and
identity values. The cache lookup now starts up to ~0.4 s earlier on the 327 MB
model, but first geometry, first visible and load total stayed within the base
spread on every fixture. The pass was never the gate: engine init (cold) and
the IndexedDB read (warm) end at the same time either way. Verdict: structural
win (one loader pass instead of two, none on the critical path), no end-to-end
speed claim.

Lesson: count passes before timing them. The counter showed a second pass per
primary load that the issue never listed: the drawing-markup restore
(`useDrawing2DPersistence`) re-reads the whole Blob and hashes it, because its
localStorage key is a bare SHA-256. Sharing it needs a key migration, so it is
the next lever, not part of this change. Freeing a span from the critical path
only helps if nothing parallel ends at the same moment; check the next span's
end, not just this one's start.

## Drawing persistence keyed by the load's identity (#7035)

The second full-source pass #7022 found is gone. 2D-drawing persistence
(markup and sheet in localStorage, DXF underlays in IndexedDB) was keyed by a
bare whole-file SHA-256 that `useDrawing2DPersistence` computed by re-reading
the file. It is now keyed by the placement identity already on the model
record, so a primary load makes one `hash.fullSource` pass and the FZK
benchmark pins that at 1.

Entries saved under the old key are moved, not dropped. A bare 64-hex key can
be told from an identity key by its shape, so a load pays for the old hash
only when some old-shaped entry is stored, only after the model has finished
loading, and once per file: an identity that has been checked is remembered.
Activations recheck for newly written legacy entries without rereading a successfully hashed File. Failed byte or IndexedDB reads leave the move unchecked and retryable.
That pass is counted as `hash.drawingLegacyKey`, apart from `hash.fullSource`.
Each move writes under the identity key, reads it back and only then removes
the old entry. When a quota failure prevents that write, restore still uses
the readable merged entry while retaining the original and retrying the move
on the next activation. A cleared sheet is an explicit stored choice, so a
legacy sheet cannot revive it.

Verdict: structural win (one pass per load instead of two), no timing claim.
The removed pass ran beside the load, not in front of it.

Lesson: one key served three stores. The issue named the markup; the same
hash also keyed the sheet and the DXF underlays, and re-keying only the markup
would have kept the whole-file hash alive for the other two. Before removing a
derived value, list every store keyed by it.

Bundle: the key resolver, the legacy-key move and the IndexedDB underlay store
are imported on demand, so the change lowers the eager bytes instead of adding
to them. Two things cost more than the code they moved. A first dynamic import
in a chunk brings a preload table that lists every file the imported chunk
depends on. And the bundler groups modules by the set of entries that reach
them, so an on-demand entry that reaches only part of an eager chunk splits
that chunk: importing the underlay store alone (it reaches
`dxfReferencePlane` but not the rest of the store chunk) cut the store chunk
in two. One entry for both, with the eager functions it needs handed over
rather than imported, left every eager chunk as it was. Lesson: after moving
code behind a dynamic import, compare the per-chunk sizes and the eager file
count against the base build, not just the total.

## Placement identity from memory (#6431)

Before parsing, the loader awaited a full-content SHA-256 identity (1 MiB chunks)
that it computed by re-reading the file through `Blob.slice().arrayBuffer()`,
although the file was already in memory. Hashing the in-memory bytes with the
same chunking gives an identical identity. On a 1 GB file, file-read to
parse-start went from 3.9-5.1 s to 0.9-1.1 s, and the gap shrank on every
corpus model. Lesson: look at the gap BEFORE `loadFile` too. Whole-file work
that runs before parsing delays everything behind it, and a profile window that
starts at "first geometry" never shows it.

## Mixed near/far items keep separate frame parts (#6349)

The single-mesh router path (`process_element`, the void host, opening
cutters, and the `produce_element_meshes` fallback chain) now keeps body
items whose f64 frames lie at least 1 km apart as separate meshes instead of
rounding one of them into a shared f32 buffer. Ordinary products never take
the new branch: over the 120-file fixture corpus, 0 of 138,381 geometric
products or openings produced a second frame part, with the local frame off
and on. `perf_probe --iters 1 --fingerprint` over the same corpus matched
base `67efe572b` byte for byte on every file (261,623 meshes, ordered FNV
per file) in both frame modes.

An interleaved native A/B (`ab.sh`, seven rounds) on AC20, ISSUE_129 and
Holter reported only deltas inside the host's own noise; the shared host was
too noisy for a verdict below that noise. A browser worker-pool comparison
of the stream-complete time on fresh Chromium processes (SwiftShader, so the
harness canvas check fails and the worker-pool time comes from the console
log) gave AC20 medians of 596 ms (base) and 496 ms (branch) over seven pairs.
For ISSUE_129, eleven pairs gave 3,110 ms (base) and 3,053 ms (branch). Mesh
counts were identical. Verdict: no measurable cost and no speedup claim.

The lesson: a guard that only diverges on rare input can be shown to be
output-neutral by counting how often the new branch fires across the corpus
and fingerprinting every file on both sides. The guard itself is one origin
comparison per item, which does not show up in timing.

## Mapped-source items keep separate frame parts too (#6446)

The same 1 km frame rule now applies one level down, inside one
`IfcRepresentationMap`'s own items (`mapped_item.rs`, `textured.rs`). A
multi-frame source is never cached or instanced. Over the 120-file fixture
corpus, 0 of 46,339 representation maps and 0 of 33,809 mapped items produced
a second frame part. `perf_probe --iters 1 --fingerprint` matched base
`216453b4e` byte for byte on every file in both frame modes.

Paired native runs on a shared host (load average about 10 on 24 cores) put
the branch-minus-base median deltas inside each fixture's own spread. With 20
alternating pairs per fixture, ISSUE_129 geometry was +0.9%, AC20 total -11%
and Holter total -4%. Verdict: no measurable cost and no speedup claim. Per
item, the only new work is one `Vec` per mapped or opening item on the
fallback and cutter paths, plus one origin comparison. The cache now clones a
source only when it actually inserts it.

## Instanced RTE deltas: one upload per template (#6393, PR #6399)

On a large MEP model with ~45K GPU-instanced occurrences, a browser run
(interleaved base vs branch, same wasm) showed the frame was bound by
`queue.writeBuffer` COUNT, not by shading or fill. The old path wrote each
occurrence's 32-byte camera-relative delta separately, once per pass. Moving
the deltas into a per-template stream that is packed on the CPU (the f64
contract is unchanged) and uploaded once per template, cached per camera,
brought orbit, pan and wheel zoom to vsync. The screenshot stayed
pixel-identical. The lessons:

- Count queue operations per frame before optimising shaders. On this model,
  switching off AO, edges or dropping DPR moved nothing measurable.
- A per-object `writeBuffer` in a per-frame path is a GPU-process IPC cost
  that the main-thread profile shows only as `(program)` time.

## Renderer colour override table (#6076, PR #6148)

A base-versus-branch browser run on a real Archicad architectural IFC, followed
by a 55-file federation of distinct real IFCs from the same test-model folder,
showed that the colour table removes the overlay draw and allocation cost in
both cases. The coloured images stayed visually consistent with the base.
This is a positive end-to-end verdict for those models; the original larger
55-model federation, alpha/emphasis/X-Ray states, and coloured streaming
still need their own acceptance run. The lesson is to measure both draw calls
and GPU-process private memory after applying a lens: the renderer's resident
geometry counter alone omits the allocation that dominated the old path.
See the [browser evidence](evidence/color-overrides-6148/README.md).

## Reusable swept-disk source definitions (#5785)

The source/instance API is opt-in. Its bounded walk reuses decoded raw
solids within one extraction; the default mesh pipeline remains separate.
Five alternating fresh-process native AC20-FZK-Haus pairs compared merged
main `80d1ba901` with the #5810 source head `55109fdbd`, each with five
inner iterations and ordered mesh fingerprints. Counts and fingerprints were
identical throughout; parse, geometry, and total timing ranges overlapped.
Verdict: no supported default full-load speed change on this fixture. The
lesson is to measure cache benefits in opt-in extraction and browser worker
pools rather than infer them from a default mesh probe. The PR records the
numeric measurements, binary hashes, and fixture provenance.

## Opt-in swept-disk WASM bridge (#5770)

The geometry bridge exposes a new explicit extraction call; ordinary mesh
loading does not call it. For the #5770 control, native `perf_probe` builds
from base `724674528` and bridge head `6e454b771` were byte-identical
(SHA-256 `b5681610450366214773ddaaf808d4fa8ea8fd00894f9ffec5a81ffdc32c9bb4`).
The base is an ancestor of the PR's main parent `f06d11798`, with no intervening
changes under `rust/core`, `rust/geometry`, or `rust/processing`. Both builds used
`cargo build --profile profiling -p ifc-lite-processing --example perf_probe`.
On AC20-FZK-Haus (fixture SHA-256 `ea6f04eaf92fac4d7ad0038bc3d2dfea4c094dd3f516ecc33c50bf1835ca108d`),
`perf_probe <fixture> --iters 1 --json --fingerprint` returned the same ordered
mesh FNV-1a64 `c4d504b83ff698ea`, 285 meshes, 35,940 vertices, and 20,322
triangles from each binary. Verdict: the normal **native** load executes the
same binary, so a noisy timing comparison of those binaries would add no evidence.
After the checker merged, a new five-pair, balanced fresh-process AC20 control
compared a profiling binary from checker source `cdbefec6e` (Rust/Cargo identical
to merged main `80d1ba901`) with bridge source `b72d706de` (identical native
source to the final comment-only head). Each process ran five iterations with
ordered mesh fingerprints. Every run kept the same mesh counts and ordered FNV;
parse, geometry, and total ranges overlapped. Verdict: the bridge preserves
ordinary native-load output, with no supported default-path speed change.
After #5810 advanced main to `ba85514d3`, those timings remain prior-base
evidence. The bridge's current-base diff has no changes under `rust/core`,
`rust/geometry`, `rust/processing`, Cargo manifests/lockfile, the native probe,
or the fixture manifest. Both sides therefore compile the same native default
path; #5810's own control above preserved the ordered mesh fingerprint. This
source-equivalence check supports no new native-load work from the bridge, but
does not turn the earlier timings into a measurement against `ba85514d3`.
The added WASM export's browser startup and opt-in extraction cost were not
measured; this result does not establish a browser worker-pool speed change.
For an opt-in bridge, prove the default path is unchanged separately from
measuring the new call when a frequent caller exists.

## Exact extrusion source profiles (#5784)

Five interleaved fresh-process native pairs compared merged #5810 main
`ba85514d3` with the exact-profile branch on AC20-FZK-Haus, using five inner
iterations and ordered mesh fingerprints per process. The default load emitted
identical mesh payloads on both sides; parse timings matched, while geometry
and total ranges overlapped. Verdict: no measurable ordinary-load cost or mesh
change on this fixture. The profile decoder is opt-in; the default-load probe
does not measure its extraction cost. The lesson is to keep the source read
separate from renderer geometry and measure opt-in extraction on authored
profile models when that workflow becomes a performance target. The PR records
the numeric measurements and binary/fixture provenance.

## Arbitrary-profile topology validation (#6316)

Five interleaved fresh-process native pairs compared merged #6263 main with
the topology validator on AC20-FZK-Haus, with five inner iterations and ordered
mesh fingerprints per process. Parse, geometry, and total ranges overlapped;
every run emitted identical mesh counts and ordered mesh fingerprints. Verdict:
no measurable default-load cost or mesh change on this fixture. Validation
runs only for an opt-in analytic read of an arbitrary profile, so the ordinary
mesh probe cannot measure its extraction cost. If nominal-quantity callers make
that read frequent, measure it on authored profiles with many line/arc edges and
holes. Keeping validation outside mesh production preserves the normal load;
the PR records paired timings and binary/fixture provenance.

## Opt-in authored and analytic quantity join (#5787)

The authored/analytic quantity join in #6283 runs only when callers request
quantity analysis; normal mesh production does not enter it. An idle-host
native control compared #6272 parent `3e554e841` with join source
`af84e4d2d` in five balanced, interleaved AC20-FZK-Haus pairs, using fresh
probe processes and five iterations per process. After the shared Cargo lock
updated `smallvec` and `thiserror`, a [GitHub-hosted control](https://github.com/LTplus-AG/ifc-lite/actions/runs/36469927760)
repeated the same paired method on exact current-lock parent `185ccf276` and
join head `f278a70a3`. The later viewer/TypeScript merges left the native
probe inputs unchanged. Both controls retained identical mesh counts and all
ordered mesh fingerprints; parse, geometry and total variation overlapped.
Verdict: no supported default-load speed change or mesh-output difference.
The lesson is that a native load probe cannot establish the opt-in join's
latency; measure that through its caller on representative authored-quantity
models if it becomes material.

## Opt-in reinforcing-bar schedule inputs (#5759)

The schedule reuses bounded analytic source views only when a Rust or Python
caller requests it; ordinary mesh loading does not enter this path. A
[GitHub-hosted current-lock control](https://github.com/LTplus-AG/ifc-lite/actions/runs/36475446893)
compared a synthetic parent containing the reviewed quantity join and mapped
source cache with a patch-identical #5801 child on AC20-FZK-Haus. Five balanced,
interleaved fresh-process pairs used five iterations each. Entity, mesh, vertex,
and triangle counts and every ordered mesh fingerprint were identical, while
paired parse, geometry, and total timings varied within noise. Verdict: no
supported default-load timing or mesh-output change. The native source closure
must still be checked against the eventual parent squashes before treating this
as the exact final-base control. The ordinary load probe cannot measure the
opt-in schedule call; measure that on representative authored bars if needed.
The PR carries the paired numbers and fixture/source provenance.

## Opt-in nominal source quantities (#5787)

Nominal swept-disk and extrusion quantities are computed only when the analytic
source API is requested; ordinary mesh production does not call them. After
the #6319 topology parent, five balanced fresh-process AC20-FZK-Haus pairs
compared source-matched profiling binaries with five iterations per process.
All 50 ordered mesh fingerprints and mesh/triangle counts matched. The child
median total was 2 ms higher (30 to 32 ms), but paired total differences ran
from 2 ms faster to 3 ms slower, with overlapping phase ranges. Verdict: no
meaningful default-load regression or speedup is demonstrated. The default
probe does not measure opt-in quantity extraction or browser worker-pool
latency, which need separate caller-level evidence if they become hot paths.
The PR carries paired results, binary/fixture hashes, and source provenance.

## Opt-in extrusion source definitions (#5784)

The extrusion source/instance walk is requested separately from ordinary mesh
production. The final-parent control compared main `888a9a72` (Rust tree
`0997415df1603d5c802bbf658b1dc12001c39990`) with the #6271 source
(Rust tree `88e3c3a26f1e7e4dde087c65cab81ec7d0e9c046`) in five interleaved,
fresh-process AC20-FZK-Haus pairs with five inner iterations each. All 50
ordered mesh fingerprints, mesh counts, vertex counts, and triangle counts
matched. The paired timings varied in both directions, so no supported
default-load speedup or meaningful regression is demonstrated. This control
does not measure opt-in extraction or browser worker-pool latency; measure
those directly if their caller-visible cost becomes material. Paired results
and source provenance are recorded in [PR #6271](https://github.com/LTplus-AG/ifc-lite/pull/6271);
base/head binary SHA-256 values are `a2f586ce7f5c38d1bcd24275e5f1fef4d00b45fcf3b0041cd6d6492b8d389640`
and `2b20fdad11da01f6c4cc9a531509b921347aaa343736488d3658f184b9f3cf9e`,
and the fixture SHA-256 is `ea6f04eaf92fac4d7ad0038bc3d2dfea4c094dd3f516ecc33c50bf1835ca108d`.

## Derived swept-disk metrics (#5754)

The length/bend calculations run only when an analytic description is
requested or serialized, outside normal mesh production. Verdict: default mesh
output is byte-identical (same ordered mesh hash on both revisions); a
default-load probe cannot measure this code's cost, and timing on a contested
host was unresolved. Measure opt-in analytic extraction on representative
swept-disk models separately from ordinary mesh loading.

## Swept-disk source-geometry checks (#5758)

The checker is opt-in and consumes the analytic description without entering
normal mesh production. After #6265 changed the Rust base, five balanced,
interleaved fresh-process native pairs compared main `0c7481ff6` with checker
source `cdbefec6e`, built with the same `profiling` profile and probed on
AC20-FZK-Haus (`--iters 5 --json --fingerprint`). The later main `41825cb48`
changes only workflow/test-script files, so this is also source-matched to that
base. An earlier pair set measured during concurrent compilation was discarded;
the cited set ran after other builds and browser tests stopped. The host still
had background load; parse medians matched, geometry and total ranges
overlapped, and the small median difference is run variation, not a speed
claim. Every run on both sides emitted 285 meshes, 35,940 vertices and
20,322 triangles with the same ordered mesh FNV-1a64 `c4d504b83ff698ea`.

Verdict: no ordinary-load mesh-output difference or measurable cost from this
opt-in checker. The lesson is to measure the checker through an explicit
extraction call on repeated mapped bars if its own latency becomes important;
the default mesh load cannot measure code it never calls. The earlier single
absolute Snowdon observation is not a base/branch comparison.

## Opt-in swept-disk source descriptions (#5559)

The analytic reader runs only when called explicitly; normal mesh loading does
not traverse a directrix through this path. On AC20-FZK-Haus, five interleaved
base/feature pairs of `perf_probe --iters 5 --json --fingerprint` (base
`337aab4f4`, final feature stack) gave median parse/geometry/pipeline-total
times of 6/20/27 ms versus 7/22/29 ms. The base's pipeline-total samples
spanned 23–34 ms and the feature's 24–31 ms; the machine had other builds
running, so the small median difference is not evidence of a speed change.
Every run on both sides emitted 285 meshes, 35,940 vertices and 20,322
triangles with ordered mesh FNV-1a64 `c4d504b83ff698ea`.

Verdict: no mesh-output regression on this ordinary load, and no reliable
performance claim from the contested host. The opt-in extraction's own cost
needs a caller-level measurement on representative swept-disk models if it
becomes a frequent operation; the default pipeline cannot measure that cost.

## Raw-world RTC before f32 narrowing (#5698)

Every built-in raw-coordinate processor now removes the model RTC offset in
f64 through `process_in_rtc_frame`, and element walkers express that offset in
the item frame. Interleaved native probes on a loaded host showed no stable
timing change on AC20-FZK-Haus, ISSUE_129, ISSUE_098 or Holter: run-to-run
spread exceeded any base-versus-branch difference. Only the output of
`860_solid_stratum` changed across the fetched corpus: its national-grid TIN
now keeps its surveyed vertices instead of a 0.5 m f32 grid. The rebase costs
one extra first-vertex probe per raw-coordinate item on models with an RTC
offset; the f64 coordinate parse runs only for items that are actually rebased.
Measure A/B on a shared host by process CPU time and minima, not wall medians:
wall medians swung 10-20% between identical binaries under load.
Element-frame rebasing must go through the cached item path, keyed by its
offset: a bespoke path silently drops content dedup and instancing.

## LV95 site-local vertices and RTC frames (#5684)

Interleaved base-versus-branch native probes on AC20-FZK-Haus and ISSUE_129
showed no stable timing change across run orders. Both fixtures kept identical
mesh, vertex and triangle counts and ordered mesh fingerprints. A private bridge
IFC reproduced the intended geometry change: a site-local thin
member recovered faces lost when the old path subtracted the national-grid RTC
offset from already-f32 vertices. The lesson is to rebase early only when doing
so reduces object-space coordinate magnitude. For genuine raw-world coordinates
in millimetre files, the guarded subtraction must still precede f32 unit
scaling or a small face can quantize at national-grid magnitude. Items
processed in different RTC frames must receive placement before they are merged.

## LandXML credited-stream acceptance (#5050)

The native, generated-source acceptance harness is deliberately independent of
fixture downloads and browser scheduling:

```bash
cargo test --release --package ifc-lite-landxml \
  --test landxml_streaming_bench_5050 -- --ignored --nocapture
```

It generates and validates four production-shaped documents: a 90,000-point /
178,802-face TIN, 20,000 references to one high-valence vertex, 256 small
surfaces, and a TIN with one boundary plus 24 breaklines and 24 contours. Each
document also has 32 COGO points, so final non-terrain metadata delivery is
part of the measured completion boundary. Shape/count assertions and credited
queue invariants are acceptance checks; there are intentionally no time or
throughput thresholds.

`whole_ms` ends when `parse_landxml_document` returns its complete terrain and
plan document. `stream_ms` ends only after 64 KiB input chunks have received
credit, `finish_cursor` has run, and the final `Metadata::End` event has been
drained. Throughput uses source bytes over those respective walls. `queue_peak`
is the session's actual serialized transport queue (`queued_bytes`), which is
bounded by the **512 KiB** credit cap. It is not a memory measurement.

The three retained columns are portable semantic-payload proxies, not RSS or
allocator high-water marks: `retained_surface_or_event_proxy` is the larger of
the direct parser's largest serialized `LandXmlSurface` and a single streamed
surface payload; `retained_nonterrain_proxy` is the serialized plan document;
and `retained_document_proxy` is the complete direct document. They make the
important distinction between the tiny credited transport queue and retained
surface/document state without claiming portable process-memory precision.

Measured once on 2026-09-22 from `0830cc5b7fbc3139089fb67447fb6fd08bf38581`,
Rust `1.93.0-nightly`, Linux 6.6.87.1 WSL2 x86_64, release profile (warm build
and OS cache; timings are evidence, not a comparison baseline):

| Case | Input | Whole / stream ms | Whole / stream MiB/s | Surfaces / points / faces | Boundary / breakline / contour / COGO | Queue peak | Retained surface-or-event / non-terrain / document proxy |
|---|---:|---:|---:|---:|---:|---:|---:|
| large TIN | 6.28 MiB | 338.943 / 640.688 | 18.52 / 9.80 | 1 / 90,000 / 178,802 | 0 / 0 / 0 / 32 | 3.36 KiB (4 events) | 19.76 MiB / 8.00 KiB / 19.77 MiB |
| high-valence references | 876.20 KiB | 49.869 / 91.681 | 17.16 / 9.33 | 1 / 20,001 / 20,000 | 0 / 0 / 0 / 32 | 3.36 KiB (4 events) | 3.10 MiB / 8.00 KiB / 3.11 MiB |
| many surfaces | 52.13 KiB | 3.206 / 5.975 | 15.88 / 8.52 | 256 / 1,024 / 512 | 0 / 0 / 0 / 32 | 3.36 KiB (4 events) | 954 B / 8.00 KiB / 246.09 KiB |
| boundary/breakline/contour | 5.48 KiB | 0.280 / 0.472 | 19.09 / 11.34 | 1 / 4 / 2 | 1 / 24 / 24 / 32 | 5.92 KiB (4 events) | 19.71 KiB / 8.00 KiB / 28.21 KiB |

### One XML driver (C9a, #7784)

Pull and stream used to be four parsers (terrain, plan, alignment, pipe), each
with its own copy of the loop, the prologue, the text rules and the namespace
and attribute handling; `parse_landxml_document` read the bytes three times and
the wasm `parseLandXmlSourceBytes` four. They are now handlers on one
`xml::Driver` and the source is read once. Measured base (main before the
series) against the series head, interleaved, release, on a loaded shared host
(wall time varied by +-10% run to run, so the verdict uses callgrind instruction
counts, which are deterministic; wall medians of 5 runs agree):

| | pull: `parse_landxml_document` over the 10 golden fixtures | `landxml_streaming_bench_5050` (whole + stream, 4 cases) |
|---|---:|---:|
| base | 72.9M instr, 117 ms | 19.13G instr, whole 523 ms / stream 876 ms (large TIN) |
| series head | 25.3M instr (-65%), 51 ms | 11.37G instr (-41%), whole 189 ms / stream 532 ms |

Lessons: (1) the stream cost was the per-token `VecDeque` traffic, the
per-event attribute decode and the namespace-map clone, each done once per
family (four times); the driver does them once. (2) The memchr-driven scanner
removed the byte-at-a-time preflight. (3) Measure instruction counts for a
refactor of this size; the first wall-clock runs differed by more than the
effect of the small steps.

## Schema-specific crate-private registries (#4203, #4996)

Selecting generated per-schema attribute tables by the source file's schema
showed no measured parse, geometry or end-to-end regression on AC20-FZK-Haus
in an interleaved native base-vs-branch probe; the millisecond-quantized
movement stayed inside the base run's own spread, and mesh, vertex and
triangle counts plus the ordered mesh fingerprint were identical on both
revisions (figures in the PR's validation evidence). The lesson: generated
lookup tables can stay crate-private and be selected by the source schema
without changing emitted geometry or adding a measurable normal-load cost;
keep them out of the public Rust surface so this metadata correction does
not create a semver liability.

## Structural surface members through the face/surface machinery (#4206, #5026)

Measured exact merge-base `6500376a2` against the #5026 head on
AC20-FZK-Haus with the pinned toolchain and `profiling` profile, separate
build directories, five interleaved fresh-process base/branch pairs of
`perf_probe --iters 5 --json --fingerprint` on an otherwise-idle x86_64
Windows box. Median parse/geometry/pipeline-total were 8/8/16 ms (base,
total spread 16-17) and 8/8/17 ms (branch, spread 16-19); median full-call
wall 20.16 ms (base, spread 19.43-23.24) vs 19.78 ms (branch, spread
18.68-23.13). Every run on both revisions produced 285 meshes / 35,940
vertices / 19,456 triangles with ordered mesh FNV-1a64 `25ac885b6ff4ad00`.
Verdict: no observed regression and no speed claim; the fixture holds no
`IfcStructuralSurfaceMember`, so the new `IfcFaceSurface` route is never
entered here and this measures only the router's registration cost. Lesson:
a processor added to the built-in table is free until an element selects it.

## Full supported-schema `IfcType` parsing (#4203)

Extending the generated `IfcType::from_str` match from the canonical IFC4X3
catalog to the distinct names in every supported schema showed no parse or
end-to-end load regression on AC20-FZK-Haus in an interleaved native A/B probe.
The ordered mesh fingerprint and mesh, vertex, and triangle counts were
identical. This qualifies the ordinary IFC4 load path, not the cost of parsing
a legacy-only entity mix. The lesson is that generated exact-name match arms
can preserve the hot parser's performance, but a larger enum still needs an
end-to-end parser probe rather than an assumption based on lookup complexity.

## Bounded quick-metadata tree and reachable placement (#4689, #4743)

Measured exact merge-base `74ba2f24e664b37b96e871620fbfdbab653042f3`
against `9a6c88208079c032e577cfd0dfeb401a51ba6542` on AC20-FZK-Haus,
whose bytes matched the fixture manifest. Both native probes used the pinned
Rust toolchain, the `profiling` profile and separate build directories on
x86_64 Windows (Ryzen 9 9900X3D). Five fresh-process pairs per path ran
interleaved on an otherwise-idle machine, with balanced order from
`ab-order.mjs` seed 4743; the OS file cache was not purged.

The stock `perf_probe --iters 1 --json --fingerprint` leaves the bootstrap
disabled. Its base/branch median parse, geometry and pipeline-total times were
16/16, 19/19 and 35/36 ms; full-call wall time was 36.819/37.348 ms (+1.44%,
inside the base's 7.00% spread). That alone does not measure the new planner.
A source-identical probe on both revisions also called
`process_geometry_streaming_with_options_and_bootstrap` with
`emit_quick_metadata_bootstrap: true` and all other options at their defaults.
It used the stock probe's three preparatory index scans, timed callback entry
before cloning the bootstrap, and fingerprinted the clone and meshes after
the full-call timer stopped. Full-call time therefore includes the clone.

With the bootstrap enabled, median parse, geometry and pipeline-total times
were 16/17, 24/24 and 40/42 ms. Full-call wall time was 42.129/43.717 ms:
an observed **1.59 ms (+3.77%) opt-in cost**, just beyond the base's 3.71%
spread, not a no-regression result. Callback readiness was 13.066/14.562 ms
(+11.45%, inside the base's 13.52% spread). This small native cost is accepted
for bounded stack use and correct placement; it is not a browser worker-pool
speed claim or a scaling qualification for unusually large spatial graphs.

All 20 samples retained 285 meshes, 35,940 vertices and 19,456 triangles, with
ordered mesh FNV-1a64 `25ac885b6ff4ad00`. All ten enabled samples retained the
same 12-node, 12,600-byte serialized bootstrap, FNV-1a64 `2c58a0fc6e20ecec`.
The mesh hash covers the stock probe's payload fields, not text metadata,
material definitions, UVs, textures or instancing. The lesson: qualify the
enabled path as well as ordinary load, and report full-call cost separately
from callback readiness and the quantized pipeline timer. A disabled feature's
unchanged load time cannot establish that its new planning pass is free.

## Boolean operands dispatch from the router's built-in table (#4560)

The boolean operand resolver no longer keeps its own list of meshable operand
types; it falls through to the registry's `builtin_processor` for everything
except the two arms that carry `depth` and the cycle guard (`IfcCsgSolid`,
the boolean types). A processor is still built fresh per operand, exactly as
the hand-written arms did, so the only new work per operand is one `Rc`
allocation. Interleaved native A/B/A/B (5 rounds, `ab.sh`) on AC20-FZK-Haus
and ISSUE_129 resolved no phase beyond the base's own noise floor; mesh,
vertex and triangle counts were identical on every round of both fixtures
(285/35,940/19,456 and 1,402/218,365/132,657), as expected: neither corpus
authors a boolean operand of a type the old list lacked. Output changes only
where a boolean names such an operand — `IfcPolygonalFaceSet` cutters on the
Bonsai wall fixture now cut. This is a correctness fix, not a speedup. The
lesson: a second copy of a dispatch table drifts the moment a processor is
registered in one and not the other, and the drift is invisible because the
loser is an `UnsupportedOperand` record nobody reads; derive the operand set
from the registry instead of maintaining it.

## Consolidation keeps small openings on large faces (#4698, #4744)

Measured exact merge-base `2ecf0f096d0f2d6079963040d3293e5964785486`
against `c7e162d01dc8e59473d8e60ada081eb19abb79ef` on AC20-FZK-Haus and
ISSUE_129, both verified against the fixture manifest. The source-identical
stock `perf_probe` was built separately for each revision with the pinned Rust
toolchain and `profiling` profile on x86_64 Windows (Ryzen 9 9900X3D). Each
fixture ran five interleaved fresh-process pairs on an otherwise-idle machine,
using balanced order from `ab-order.mjs` seed 4744 and
`--iters 1 --json --fingerprint`. The three preparatory index scans and
uncontrolled OS file cache are the stock probe's warm-cache boundary.

Base/branch median milliseconds:

| Fixture | Parse | Geometry | Pipeline total | Full-call wall |
|---|---:|---:|---:|---:|
| AC20-FZK-Haus | 16 / 16 | 19 / 19 | 35 / 35 | 36.935 / 36.908 |
| ISSUE_129 | 33 / 32 | 889 / 896 | 924 / 929 | 932.971 / 938.638 |

AC20 retained 285 meshes, 35,940 vertices and 19,456 triangles in every run,
with ordered mesh FNV-1a64 `25ac885b6ff4ad00` on both revisions. ISSUE_129
retained 1,402 meshes but changed from 218,501 vertices / 132,815 triangles
to 219,858 / 135,749; its hash changed from `5dbcc345761e87a8` to
`9138d2efb799991e`, each stable across all five runs of that revision.
This is intentionally not a byte-identical comparison: the filter keeps real
opening rings that the plane-relative rule filled, and those rings also affect
seam conformance and subsequent triangulation. An untimed per-element hash
comparison found changes only in the seven hosts whose ISSUE_129 census rows
this PR repins: #7526, #32810, #59111, #139364, #149277, #244479 and #333923.
Their net increase is 2,934 triangles; every other element's mesh fingerprint
matched. These hashes cover the stock probe's ordered mesh payload, not text
metadata, material definitions, UVs, textures or instancing.

Verdict: no median timing move exceeded the base's measured spread on either fixture.
On ISSUE_129, geometry increased 0.79% against a 2.81% base spread, pipeline
total 0.54% against 3.03%, and full-call wall 0.61% against 3.01%, despite the
intentional output increase. This qualifies the observed native cost of a
correctness fix, not a like-for-like speedup, browser worker-pool result or
heavy-corpus performance verdict. The lesson: a relative speck filter can erase
real holes as its plane grows; constrain it by an absolute width as well, keep
the share guard for load-bearing thin reveal rings, and attribute changed mesh
bytes before interpreting a timing comparison.

## Qualified PDF dash expansion (#4406)

Dash expansion is reachable only from the explicit PDF annotation planner; it
does not enter ordinary IFC element production. An idle source-matched
AC20-FZK-Haus base/branch probe reported equal best parse, geometry and total
phases across five runs. Every run retained the same ordered mesh fingerprint,
mesh count and triangle count. The verdict is no ordinary-load regression, not
a PDF-page throughput claim. The lesson is to charge each dash advance and each
vertex crossed by a continuing run: a piece cap alone does not bound one long
on-run across attacker-controlled path vertices.

## Canonical appearance provenance (#4243)

Item-identified geometry now retains its canonical triangle-order identity at
WASM extraction. A production-browser worker-load A/B against the same Rust
runtime found a small median increase within the baseline run spread on the
public AC20-FZK-Haus fixture; this is not an optimization or a speedup claim.
All measured geometry/color/UV fingerprints and mesh/triangle counts matched.
The additional metadata reuses existing index arrays, with no extra geometry
buffer or transfer at extraction. Streaming fragments can retain an unsplit
source index array; that memory lifetime still requires explicit downstream
ownership and large-model qualification.

The measurement boundary was completed metadata plus geometry worker output,
with fresh Chromium processes and empty model caches. It did not measure
renderer readiness: the stock combined viewer-readiness experiment encountered
a baseline first-load viewport initialization race. Those failed samples were
retained and excluded, not treated as successful loads. The lesson is to name
and qualify the measured boundary before interpreting small load-time deltas.

## Authored metadata wire validation (#4441)

A shared early authoring guard now refuses free-text spellings that the host
mutation writer interprets as structural tokens. The source-matched idle native
AC20 A/B/A/B probe found matching normal-load geometry/total values and mesh
fingerprints, with quantized parse variation. This is a correctness fix, not a
worker-pool optimization. The lesson is to validate text at the shared authored
boundary using the consumer's exact whitespace/token rules; broad trimming can
both miss reserved inputs and reject ordinary Unicode names.
Evidence: `docs/architecture/evidence/authored-wire-tokens/native-load.json`.

## Manual scan registration foundation (#4381)

The correspondence solver is opt-in, bounded to 256 fitting and 256 held-out
points, with fixed-size matrix decompositions and explicit iteration limits.
It is reachable through the dedicated registration API only; parse, element mesh
production, styling and worker-load paths do not invoke it. An interleaved native
AC20-FZK-Haus base/branch probe found equal reported parse/geometry/total phase
medians and a full-wall median difference within the observed run spread. Every
ordered mesh fingerprint and mesh/vertex/triangle count matched. The verdict is
no material regression observed on that fixture, not a load optimization or a
browser worker-pool speed claim. See the [raw measurement](../../docs/architecture/evidence/scan-registration/native-load-perf.json).

Independent numerical review also ruled out the specialized small-matrix SVD:
its squared-matrix path lost thin but valid correspondence directions. The
bounded direct decomposition and two retained counterexamples prevent repeating
that failure. Small point-to-plane residuals remain no substitute for spatially
distributed check correspondences, as the CRAS evidence demonstrates.

## Incremental streaming finalize (#5358)

**Won.** `Scene.finalizeStreaming` / `finalizeStreamingAsync` used to dissolve
and rebuild every bucket in the scene, so each streamed federated add re-merged
and re-uploaded the whole federation (O(N²) over N models) and briefly held two
GPU copies of all of it. Finalize now rebuilds only the buckets that received
streamed meshes since the last finalize (plus any key already pending); the
in-place colour re-group it exists for only ever concerns those meshes.

Measured with the real `Scene` streaming + finalize + merge/quantize/upload code
over a byte-counting fake `GPUDevice` (10 synthetic models × 20,000 box pieces,
24 colours, two interleaved base/branch runs): the finalize of the 10th add went
from 645-819 ms to about 53 ms (flat per add; the 1st add is unchanged), and the
transient GPU bytes above the resident set during a finalize went from "the
whole federation" (155.7 MB at the 10th add) to "the new model" (15.6 MB). The
final resident bytes and batch counts are identical. The lesson is that the fake
device measures the CPU half exactly and the GPU half as bytes, not driver time.
The viewer's own federated "Add" currently takes the non-streaming
`appendToBatches` path and never reached this finalize, so the win is for
`@ifc-lite/renderer` hosts that stream federated models, and for any finalize
that runs with other models resident.

## Cross-batch shared shapes on the Parquet stream (#5407)

**Won, opt-in.** `?parquet_layout=shared-shapes&stream_shapes=cross-batch` on
`/parse/parquet-stream` sends each distinct shape once per stream instead of once
per batch. Across five fixtures (office, advanced_model, skolebygg, Holter
Tower, and a 342 MB architectural model), the client payload dropped 2.2x to
6.8x against the batch-local shared stream. It planned exactly the buffered
route's vertex rows, and landed 8-43% above the buffered route's bytes, which is
per-batch Parquet framing (17-132 batches). Peak server RSS stayed within
run-to-run noise of the batch-local stream, and every unchanged mode was
byte-identical to base.

Two lessons, both found by measuring rather than by design:

- **A content-hash registry alone is not enough.** Hash-only sharing across
  batches recovered only a third of the gap on the office model (841k vs 295k
  buffered vertices), because rotated repeats are not bit-identical. Stage 1
  (the rotation-aware collator) had to reach across batches too. That means
  keeping each instanced representation's first emitted mesh, not only
  collator templates: a representation seen once per batch is never collated
  inside any one batch.
- **The stream needs the baked basis before its first batch.** Without it,
  site-rotated models (skolebygg, advanced_model, DigitalHub) matched only the
  buffered route run with no basis, 2-5x worse. The frame is chosen before
  meshing, so `process` announces it through the sink's `on_frame` event then.

## The native probe (`perf_probe`)

`rust/processing/examples/perf_probe.rs`, wrapped by `probe.sh`. It drains the
timings the pipeline already publishes (`ProcessingStats`) plus an isolated
`build_entity_index` scan, best-of-N, and prints the split:

```
  parse (pre-geometry)   <ms>   <%>     <- single-threaded; gates time-to-first-geometry
    - index-scan alone   <ms>   <%>     <- isolated build_entity_index (structural scan)
    - entity_scan        <ms>   <%>     <- scan loop + job/quick-metadata building
    - lookup/styles      <ms>   <%>     <- style/material/void resolution
    - preprocess         <ms>   <%>     <- unit scales, RTC detect, site transforms
  geometry               <ms>   <%>     <- rayon-parallel; CSG-dominated on heavy models
    - faceted-brep       <ms>   <%>     <- only with OBS=1 (features observability)
  brep point-cache       <hits>/<misses> (<rate>% memoized)
  csg census             <subtract/union/intersect/clip> | <operand-tris>
```

Flags: `--suite` (all catalogued heavy fixtures on disk), `--iters N`,
`--census` (CSG op distribution), `--json` (stdout; table stays on stderr),
`--fingerprint` (ordered mesh fingerprint, computed outside the timed interval),
`--single-thread` (one rayon worker on the calling thread; for instruction
counting, its times are not comparable with multi-threaded runs),
`OBS=1` env (build with `observability` to fill `faceted_brep_time_ms`).

JSON `allWallMs` measures each complete `process_geometry` call, including final
metadata assembly after the pipeline's `totalMs` timer stops. Use its median
for full-load comparisons; `allTotalsMs` retains the narrower pipeline timer.
For a cold application load, pass `--cold --iters 1` with exactly one fixture
per process. This skips the isolated index scans and reports `fileReadMs` plus
`fullLoadWallMs` (file reading and the complete processing call);
`indexBuildMs` is `null`. Launch a new process for each sample. This does not
purge the operating system's file cache, so report that limitation explicitly.
With `--fingerprint`, `meshFingerprintsFnv1a64` records exact float bits and
ordered mesh identifiers, geometry, color, transforms and bounds. It does not
cover text metadata, material definitions, UV textures or instancing records;
validate those surfaces separately. Alternate base and branch runs in fresh
processes on an idle machine, with the same measurement harness on both sides.

Why `--profile profiling`: release-grade opt but keeps symbols and
`panic=unwind`, so `samply` gets a symbolized flamegraph and per-element
`catch_unwind` isolation still fires. (Plain `release` strips symbols;
`server-release` keeps unwind but strips.)

### Reading it

- **`parse` large** -> the win is in the **single-threaded** scan/decode path;
  it hits every model and is the time-to-first-geometry gate in the viewer.
- **`geometry` large** -> CSG/brep bound; check `csg census` operand-tris and the
  dead-end ledger below before touching the kernel.
- `index-scan alone` vs `entity_scan`: the gap is job-list + quick-metadata
  building layered on the raw scan.

## Instruction counts (`instructions.sh`, #6958)

`scripts/perf/instructions.sh <fixture> [--json] [--keep <dir>]` builds
`perf_probe` with `--features phase-markers` (into `target/phase-markers`, so it
never swaps the binary under `probe.sh`) and runs it once under
`valgrind --tool=callgrind` with `--single-thread --iters 1`. The feature puts a
never-inlined empty marker call on every `ProcessingStats` timer edge
(`rust/processing/src/processor/phase_marks.rs`); callgrind's
`--dump-before=...::phase_marks::*` writes one dump per edge, and
`instructions-report.mjs` folds them into
`{fixture, commit, phases:{parseIr, entityScanIr, lookupIr, preprocessIr,
geometryIr, totalIr}, outside, processIr, meshes, vertices, triangles}`. Each
phase covers exactly the window its millisecond timer covers; `parseIr`
includes the untimed code between the sub-phases, as `parse_time_ms` does.
Without the feature the markers compile to nothing (mesh fingerprints are
identical with the feature off, on, and with `--single-thread`).

- **Determinism.** Entity scan and lookup are exactly reproducible. Across
  independent runs of one binary (some concurrent, on a loaded machine),
  geometry varied by at most 254 Ir of 367M on FZK-Haus (7e-7) and 8,912 Ir of
  28.7G on ISSUE_129 (3e-7); preprocess varied by at most 31 Ir. The residue
  comes from `std::collections::HashMap` per-process hash seeds (probe lengths
  in `clip_mesh_with_half_space`, `promote_cutter_verts_onto_host_faces`,
  `remove_internal_membrane`, `union_all`, and in preprocess); output is
  unaffected. `--single-thread` runs the one rayon worker on the calling thread
  (`use_current_thread`): with a separate worker thread, idle spinning and
  hand-off added noise of up to ~1e-5. Raw runs:
  `evidence/instruction-replay-6958/determinism.json`.
- **Not wall time.** Counts are immune to machine load and need no quiet
  machine, but they ignore memory stalls, cache misses and parallel
  scheduling. Read them as work, not latency.
- **Cost.** ~60-100x a native run: FZK-Haus ~6 s, ISSUE_129 ~2.5 min.
- `perf stat -e instructions:u` is not wired in: it is unavailable under WSL and
  counts from different tools are not comparable with each other.

For historical commits, which have no markers,
`instructions-replay.mjs` injects `rust/processing/examples/instructions_driver.rs`
(one `process_geometry` call between `--dump-before`/`--dump-after` dumps) into
a throwaway worktree per ref via `build-at-ref.sh`, the same worktree builder
`ab.sh` uses for its base side. It counts whole calls only. See the replay
verdict in the ledger below.

## Flamegraph (`flame.sh`)

`samply record` on the profiling binary, opens the Firefox profiler. Click into
`ifc_lite_processing::...` for parse, `ifc_lite_geometry::kernel::...` for CSG.
Install once: `cargo install samply`.

## The WASM / viewer side

The browser can't use `std::time::Instant` (traps on wasm32), so parse phases
are timed in JS. Diagnose there with:

- **PostHog `ifc_model_loaded`** (project IFClite 199147): per-load milestones
  `file_read_ms, metadata_complete_ms, first_geometry_batch_ms,
  first_visible_geometry_ms, stream_complete_ms, total_elapsed_ms` + mesh/vert/tri
  counts. Emitted in `apps/viewer/src/hooks/useIfcLoader.ts`. This is the
  **user-facing** truth (time-to-first-paint, time-to-complete).
- **Console `[stream]` timeline** (`packages/geometry/src/geometry-parallel.ts`)
  and `[useIfc] TOTAL LOAD TIME` lines: `meta @`, `styles @`, `entity-index @`,
  worker-ready, first-batch. These are diagnostics; CI timing and readiness
  use canonical load-trace spans. Count-only console fields remain available.
- **`?perfMem=1`** -> `memoryAccounting` `[mem-summary]` (JS heap, per-worker WASM
  heap, geometry bytes, transport bytes; `apps/viewer/src/lib/perf/memoryAccounting.ts`).
- **CI viewer benchmark** (`.github/workflows/benchmark.yml`, advisory): 6 load
  milestones vs `tests/benchmark/baseline.json`, flags >50% regressions on a PR.
  Run locally: `pnpm test:benchmark:viewer:ci`; check:
  `node scripts/check-benchmark-regression.js --advisory`.
- **`?geomWorkers=N`** and `window.__ifc_lite_viewer_store__` for live poking.

WASM-specific structural cost (not in the native probe, by design):
- **Per-worker file re-decode**: each of N geometry workers re-decodes the whole
  file + rebuilds its own entity index (`packages/geometry/src/worker-count.ts`),
  the ~5x peak-memory driver. Worker count is memory-clamped, not CPU-bound
  (`SMALL_FILE_MB=24`, >512 MB caps to 3-4). More workers do **not** speed up
  CSG (memory-bandwidth bound) - see ledger.
- **No wasm threads in the live path**: `init_thread_pool` exists only in the
  `threads` bundle (off by default); cross-worker parallelism is the JS pool.

## Large-model browser cold-load A/B (#3978)

`browser-cold-ab.sh` (wrapper) / `browser-cold-ab.mts` (harness) / `browser-ab-report.mjs`
(reporter). Preserves the mechanism behind #3921's private large-model
qualification (11 real IFC models, interleaved fresh-Chrome-process base/branch
pairs) as a repeatable, in-repo tool, instead of that mechanism living only as
one-off private scripts and a set of hardware-specific numbers pasted into a
PR description.

**DELIBERATELY MANUAL — NOT WIRED INTO CI.** `node scripts/check-test-wiring.mjs`
does not require a `package.json`/workflow entry for anything under
`scripts/perf/` (the same carve-out `ab.sh`/`probe.sh` already use); nothing
here runs on a PR. It launches a real, dedicated Chromium process per sample
and is meant to be pointed at private multi-hundred-MB models — neither
belongs on a shared runner. `.github/workflows/benchmark.yml` is the separate,
CI-wired, advisory-only sibling and is unaffected.

```bash
# public-fixture A/B, working tree only (repeatability check / no --base):
scripts/perf/browser-cold-ab.sh --skip-branch-build --iters 5

# real base-vs-branch (builds BASE in a throwaway git worktree):
scripts/perf/browser-cold-ab.sh --base origin/main --iters 5

# add private/large local models (never fetched or committed by this tool):
cp scripts/perf/browser-corpus.example.json scripts/perf/browser-corpus.local.json
# edit browser-corpus.local.json with real absolute paths, then:
scripts/perf/browser-cold-ab.sh --corpus scripts/perf/browser-corpus.local.json
```

**Span-only release boundary (#7005):** the migration shipped in v10.4.0;
the follow-up package release at `7eeffbb960596669f1a4cb5e0d01e980999e20f6`
was published by [the original release run](https://github.com/LTplus-AG/ifc-lite/actions/runs/38333269170).
The harness now refuses source revisions older than #6979
(`272ebd8615d038dc20dd8aec4e3bb88d1acf9fa7`). The wrapper checks both sources
before building. Direct frozen-dist runs must pass `--branch-revision <sha>`
and, with `--dist-base`, `--base-revision <sha>`; these resolved identities are
saved in `source-revisions.json`. Fetch the migration's Git history first.
These declarations do not authenticate arbitrary dist bytes: retain the matching
build/hash receipt. Runtime completion still requires valid spans, loader success,
renderer finalization and an allocated canvas. Missing traces cannot fall back
to logs. Console mesh/entity/file-size counts and steady-state render diagnostics
remain; no console timing or completion value is accepted. Legacy timing fields
without a canonical span remain null. This removal makes no speed claim.

**What "cold" means, precisely:** each sample gets a brand-new
`chromium.launch()` (no persistent profile) closed completely before the next
one starts — fresh WASM instantiation, fresh geometry-worker pool startup, and
an empty Cache API/localStorage/IndexedDB every time. It does **not** control
the OS file cache (same caveat #3921's own qualification recorded). Observed metadata/render readiness (`metadataRenderReadyMs`) and "first geometry" (`firstBatchWaitMs`/
`firstVisibleGeometryMs`) are reported as separate rows, never collapsed.

**Repeatability:** samples are interleaved (A, B, A, B, …), and the reporter
only calls a delta "real" once it clears the base side's own round-to-round
spread — the same noise-floor discipline as `ab-report.mjs` for the native
probe. Historical runs in the original PR used the app summary as TOTAL;
that metric could precede metadata completion and does not qualify the new
observed boundary. The existing CI `totalWallClockMs` remains unchanged and is
reported separately; no CI baseline is silently regenerated. Old records without
the new readiness field are refused by this manual reporter.

The observed boundary requires metadata, geometry, renderer-summary and canvas
signals, with finite timeout/error failures. It does not qualify search readiness,
cache-tail memory, properties, spatial paths, GPU picking or Firefox. Those issue
#3978 requirements remain follow-ups in this same harness, not implied coverage.
The retained mesh count alone is not geometry-buffer identity.

**Drift detection:** there is no committed golden here to drift silently —
every invocation prints its own base-vs-branch delta from that run's fresh
samples, so a stale number is never read as current. A `totalMeshes` change
between sides invalidates the timing comparison outright (printed as
`OUTPUT CHANGED`, matching `ab-report.mjs`'s fingerprint rule) rather than
being silently absorbed into "faster".

**Verified detection (harness self-test):** `--fault-inject-ms`/
`--fault-inject-side`/`--fault-inject-pattern` route-delay matching requests
(default `\.wasm(\?|$)`) on one interleaved side, to prove the harness
actually notices a regression rather than always reporting "within noise".
Historical request-delay runs verified the old metric's response to startup
delay; they do not validate the new readiness metric. Deterministic delayed-
metadata tests now exercise premature renderer summaries, delayed paint,
metadata failure and timeout refusal without launching a benchmark. A browser
functional smoke remains required before a new performance claim.

**Failures are archived, never silently retried:** a sample that does not
reach `streamCompleteMs` with `totalMeshes > 0` is recorded as failed (not
retried), with a screenshot + console log + error message written to
`scripts/perf/.browser-cold-ab-results/FAILED-*` (gitignored) — the equivalent
of #3921/#3975's preserved failure evidence for renderer SIGILLs.

**Raw cold IFC load only** — this drives the same `.ifc` parse/geometry path
the viewer's real cold load takes, never a prepared-format reload (Fragments/
XKT/XGF); that stays out of scope per the issue.

## Specialized harnesses (when the probe is too coarse)

| Tool | Question it answers |
|------|--------------------|
| `rust/processing/examples/csg_scaling_bench.rs` (`--features csg-capture`) | Does native CSG scale with cores? (captures + replays the void-cut corpus under 1/2/4/8 threads) |
| `rust/export/examples/glb_export_profile.rs` | GLB export phase split (index / mesh / assemble+serialize) + per-type triangle mass |
| `rust/export/examples/index_vs_scan.rs` | For a whole-file helper: how much is the entity index and how much is the scan? |
| `rust/csg-thread-bench/` (detached crate, `build.sh` + `web/serve.mjs`) | Threaded-WASM CSG: atomics tax + SharedArrayBuffer scaling in the browser |

## Five-avenue cold-load audit (#5331)

The [audit record](evidence/cold-load-audit-5331/README.md) compares current
source and prior shipped, rejected and parked levers. Sparse spline samples
qualified for native cold load; direct attribute construction was rejected;
multipart mapped parts remain unqualified after correctness verification.
Worker dependency packets have no demonstrated native counterpart, and broader
analytic opening coverage needs a new overlap algorithm rather than a weakened
guard. The opening census is diagnostic opportunity evidence, not saved time.
This audit does not claim five shipped wins or a browser speedup.

## Lever ledger (read before spiking)

### Retained processor registry ownership (#3987)

Built-in processor registrations share immutable setup while each router keeps its own failure state and custom replacement behavior. Own-layer native subset comparisons did not establish a meaningful full-load improvement; the cumulative result must not be attributed to this layer. Constructor profiles identify avoided setup work, not a throughput verdict. Keep custom processors and mutable diagnostics independent. Browser performance is a separate verdict; invalid Firefox cohorts and unrun follow-ups provide no supporting result.

### N-ary repair validation (#3925)

Rebase before measuring geometry. The old direct-router census converted survey
coordinates to f32 before subtracting an origin; its apparent covering regressions
were measurements of already-collapsed inputs. Disabling shared-corner protection
to satisfy that census regressed valid large-model cuts. A raw-first union also
improved a synthetic sweep while damaging those cuts. Both were discarded.

Preserve an accepted production union. For an unusable 3D opening union, try one
coordinate-preserving candidate before sequential subtraction. Roof chains need
their own actual-cut checks and a removed-volume upper bound from clean individual
trials; a bounding box alone cannot detect over-removal. Making every diagnostic
trial reject the original path also lost existing cuts and was discarded.

The census coordinate migration uses a reference generated on pre-regression
code, with one independently checked torn-to-closed row recorded separately.
Neither arbitrary golden updates nor local closure scores establish correctness.
Keep real loader output and independent solid measurements in the comparison.
See [the implementation and reference provenance](../../docs/architecture/nary-union-repair.md).
Correctness-only native and worker-pool full-load comparisons across eleven
models were broadly neutral in time and peak memory; the large target's browser
load improved. Five interleaved fresh-process pairs were used per model and
runtime, with OS file cache uncontrolled. Native geometry was byte-identical
except for the intended CSG129 repair. Browser geometry was identical except for
two already-open walls whose reference comparison is recorded in the linked
note. The performance-only stack is evaluated separately against this corrected
baseline. **Lesson:** qualify the browser's actual detail settings too; native
full-detail identity alone does not establish browser identity.

### Retained transient decoder ownership (#4000)

Reusable output buffers and a validated string projection avoid building discarded attribute trees; one-read metadata avoids filling a cache. Expired native decoder/item caches are disposed in a joined scope while trailing georeferencing runs. Own-layer native and actual Chrome worker-pool subset comparisons did not establish a meaningful full-load improvement. Keep the cumulative result separate, include the disposal join and trailing metadata in timing, and do not treat summed worker allocations as simultaneous memory. No isolated browser gain is established here; invalid Firefox cohorts and unrun follow-ups remain excluded.

### Cold-load validation notes

A geometry-complete event does not imply an interactive viewer: metadata,
renderer finalization and the store's loading state can finish later. Compare
fresh browser processes with the target file loaded first, and stop the load
timer only after all of these finish. Exercise GPU picking, visible property
sets and spatial hierarchy afterwards; exercise section generation on demand
and federation separately. Keep integrity extraction outside the timed interval.

Worker memory summaries can finish before renderer finalization. They are not
whole-load peak-memory measurements. Sample through full readiness and name the
metric precisely: summing Chrome process RSS can double-count shared pages.
Readiness polling quantizes short loads; capture the store's readiness event.
Coarse RSS sampling can miss short-lived peaks, so also inspect OS process
high-water marks and state whether they include browser startup.
Preserve failed loads alongside successful samples. Listen for renderer crashes
as well as JavaScript errors, and stop memory sampling on every exit path.

### Shipped wins
- **Review startup bundle (#7015):** load the Script panel on demand and keep
  CodeMirror's shared state module in its own chunk. Assistant text-edit planning
  still uses `ChangeSet`, while the editor UI stays outside the eager import
  closure. The production bundle clears the unchanged size ceilings; this is a
  byte-size verdict, not a measured load-time improvement. **Lesson:** inspect
  the complete HTML preload closure, and isolate shared state before assuming a
  dynamic panel import makes its dependencies lazy.
- **Firefox spatial-publication stall (#3983):** Chrome-only cold-load timing
  missed an engine-dependent entity-cache eviction cost. Georeference discovery
  runs through the property-set index during React rendering. Restarting a Map
  iterator for each eviction repeatedly traversed its deleted prefix in Firefox;
  a live eviction cursor preserves LRU ordering without restarting that walk.
  Prepare the source fingerprint and georeferencing in the parser worker and
  carry them with both store publications, so the first render does not rescan
  the source. Deferred-property parses must wait for their complete index before
  preparing georeferencing. **Lesson:** qualify Firefox as well as Chrome, record
  event-loop gaps and visible hierarchy readiness, and keep profiling runs apart
  from uninstrumented timing. A worker-complete event alone cannot establish that
  publishing its result leaves the UI responsive.
- **Native cold-load working set (#3967):** immutable schema classification replaces
  contended global caches; completed BREP signatures are shared within one
  immutable source; the geometry scan supplies ordered georeferencing candidates
  and discovery reads unrelated property sets without retaining them. Large
  sources with `u32` offsets build compact rows in fixed pages, then select a
  direct-address index only when its allocation fits within compact columns.
  Intermediate rows have a source-based budget; unusually dense record streams
  switch to hash coalescing so duplicate records cannot keep growing staging.
  Sparse IDs keep sorted columns; wider sources and supplied hash indexes retain
  their existing representation. Duplicate IDs still resolve to their last
  authored span. Interleaved fresh-process comparisons covered large MEP,
  architecture, sanitary, CSG, structural and bridge models from multiple
  exporters and schemas, including the small guard fixtures: all full-load
  medians improved and every ordered geometry fingerprint matched. Large-model
  peak RSS fell; small-model RSS ranges overlapped. **Lesson:** measure the
  whole call including final metadata and teardown, and measure the index's
  working set, not just time attributed to the scanner. Bounded parallel typed
  scan windows passed scanner parity but added too little end-to-end benefit
  to retain; the compact-index change produced the material gain.
- **CSG topology diagnostic (#3442): no measurable pipeline regression.** The
  record-not-gate closure audit adds a strict directed-edge hash sweep and only
  runs the hairline sweep when strict closure fails. On `140a6d854` versus the
  branch, five-iteration `perf_probe` runs were flat: FZK-Haus best total 9 ->
  9 ms (geometry 5 -> 4 ms), CSG-heavy ISSUE_129 605 -> 604 ms (geometry 586
  -> 586 ms). Mesh, vertex and triangle counts were identical; the only
  intentional observable delta was ISSUE_129's new CSG diagnostic count, 1 ->
  9. **Lesson:** keep this as an audit of the final result only — auditing
  batch intermediates turns diagnostic volume into workload-dependent noise.
- **Shared void-closure verdict (#4796): supported fixtures did not regress;
  heavy result inconclusive.**
  The closure decisions now reuse one directed-edge map, while strict-only
  callers still avoid the lazy hairline phase. Balanced base/branch runs covered
  FZK-Haus, CSG-heavy ISSUE_129, and the heavy Holter model; ordered geometry
  fingerprints and entity/mesh/triangle counts matched on every iteration.
  Controlled FZK-Haus and ISSUE_129 results were flat within mixed paired runs.
  Holter's pooled full-wall median was slightly slower and three of four paired
  medians favored base, while its spread remained too wide for a confident
  regression verdict; a small heavy-model overhead is therefore not excluded.
  This is a native full-load verdict, not a browser worker-pool or UI speedup
  claim. Unlike
  #3442's final-result diagnostic audit, this change shares the edge calculation
  between the existing closure decisions without making hairline analysis eager.
  Raw samples, executable and source hashes, environment, schedule, and metric
  semantics are in
  [`docs/architecture/evidence/closure-verdict/performance-controlled.json`](../../docs/architecture/evidence/closure-verdict/performance-controlled.json).
  The superseded uncontrolled run is retained beside it as `performance.json`.
- **Entity indexes built and never read** (`index_vs_scan.rs`): `relationships()`
  built a full parallel index and handed it to the decoder, but every decode in it
  is `decode_at_with_id` over the scanner's own spans and only `decode_by_id`
  consults an index. Dead work, deleted. `extract_georeferencing` does need one, so
  it gained a `_with_index` variant and `process_geometry` now passes the index it
  already holds instead of paying a second scan.
  Measured best-of-3 on the release fixtures, ms: O-S1-BWK 327 MB, parallel index
  58.3, bare type scan 180.8, `relationships()` 234.6, `extract_georeferencing()`
  337.6; schependomlaan 47 MB, 8.5 / 27.3 / 38.1 / 48.5. **Honest size: about 1% of
  a large conversion.** It is worth having because it is free and hits every model,
  not because it is big.
  **Lesson, and the reason this entry exists:** check which decode family a helper
  uses before handing it an index. The scan is the larger half of both of these, so
  "share the index" was never going to be the lever it looked like from a sampled
  profile that folded index build, scan and decode into one bucket.
  **Harness gap, third of its kind:** `probe.sh` cannot see this change at all.
  `ProcessingStats` closes its timers before the metadata block that calls
  georeferencing runs, so the probe table is flat on this diff by construction.
  A flat table here is a control, not a measurement.
- **CDT: kill the three O(T)-per-item scans**: ISSUE_129 geometry 1568 -> 646 ms
  (main, pre-seam-conform, is 979), **byte-identical output** on 8 fixtures incl.
  advanced_model (FNV over every mesh). The quality CDT — not the seam conform —
  was the whole cost of `consolidate_coplanar`; the conform's own work
  (`build_seam_map` + `conform_plans`) measures 20 of 1400 CDT cpu-ms, so
  "the conform is slow" was a mis-frame. What was actually slow, per instrumented
  slot-visit counts on one ISSUE_129 load:
  (1) `insert_steiner` renumbered every triangle to splice each Steiner point in
  below the super vertices — **1.07e9** index touches. Fixed by reserving the
  Steiner budget below the super verts at build time, so ids never move.
  (2) `edge_exists` re-scanned every triangle per constraint probe — **4.7e8**
  slot visits. Fixed by materialising the alive-edge set once in
  `enforce_constraints` and applying the flip delta (drop `u-w`, add `apex-q`).
  (3) `locate` was an O(T) canonical scan per inserted point — **2.2e8** slot
  visits. Fixed by a walk from the previous insertion that only answers when the
  triangle STRICTLY contains the point (unique ⇒ same answer as the scan) and
  falls back to the scan on the on-edge tie-break.
  Two smaller ones with the same shape: the encroachment test scanned all
  constraints per skinny candidate (5.9e7 disk tests -> a CSR grid built once per
  refinement), and `constraints` served millions of membership probes from a
  BTreeSet (now an FxHashSet mirror; the BTreeSet stays for the recovery ORDER,
  which is target-independence-critical).
  **Lesson:** all five are output-identical by construction, so the fix is
  measurement, not risk-taking — but only after instrumenting. The prior
  hypothesis chain (lazy seam map, x-range prune, CDT caching by clone/move) all
  measured ~zero because they targeted the 20 ms, not the 1400.
- **Fast first-geometry** (#1185): ship index/styles/first-wave at scan-complete;
  22s -> 11.8s wall to first paint. Overlap parse + geometry.
- **Faceted-brep dedup** (#1184) + **CartesianPoint cache hoist** (#1568/#1572):
  memoize shared points across parts; big win on steel/Tekla.
- **Local-frame f32 collapse** (#1114): per-element origin removes far-from-origin
  jitter and shrinks coordinates.
- **Worker right-sizing** (#1431): `SMALL_FILE_MB` 64->24, -21% peak, 0 regression.
- **Shared entity-index on the export/native path** (#1516/#1533, #1682): one sorted
  `(id,start,end)` binary-search buffer instead of per-worker FxHashMaps, where a
  *single* consumer builds it (streaming glTF export, binary-search columns). This
  shipped and is a real win; it is NOT the viewer huge-file case below (see dead ends).
- **Vertex weld at faceted-brep source** (#1562): closes the volume-metric gap.
- **Incremental affinity publication** (#4051, PR #4052): publish each existing bulk job
  chunk as soon as that chunk's routing keys are ready, keeping the shared decoder/signature
  memo, first wave, chunk boundaries and exact job order, so routing overlaps geometry instead
  of preceding it. Chrome, five interleaved fresh-process pairs per model: equal-model geomean
  readiness **-2.03%** over five models; large MEP **-9.8%** readiness and **-13.3%** geometry
  for **+3.4%** sampled physical bytes; the other four models moved at most 1.4% either way.
  No native or Firefox gain is established, and the memory cost is real, so this is a targeted
  readiness tradeoff. **Lesson, and the reason this entry exists:** the intended "combined"
  map-cache build never recompiled. Timestamp-preserving source restoration let Cargo reuse
  the affinity-only artifact, and forced Turbo execution plus matching bundled hashes did NOT
  catch it; the build log reported no crate compilation. After restoring a variant, force
  mtimes forward or build into a fresh output directory, and read the log for crate
  compilation. Full per-model table:
  `git show 4fbbe8dd5:scripts/perf/evidence/affinity-publication-2026-09-06/results.json`.
- **Retained cold-load stack** (#3985, #3987, #3993, #4000, #4001, #4003, PR #4008): the
  combined native full-load result is a geomean ratio of **0.845** wall and **0.987** max RSS
  over the fixed 11-model corpus, 5 interleaved fresh-process pairs each. **Read the cohort
  size before the ratio here.** The isolated layers ran on 2 or 3 models, not 11 (A, B and C
  on small-Haus + CSG129; D adds CSG177; E is small-Haus + CSG177), so layer E being SLOWER
  at a 1.036 wall geomean is a two-model statement, not a corpus one; the standalone
  ownership subset was slower too. Chrome, also 11 models x 5 pairs: **0.713** full-readiness
  geomean and lower sampled memory (0.904 RSS), but geometry completion slower on several
  models (1.015 geomean) and small-Haus readiness regressed in every pair (1.138). The
  original Firefox cohort is invalid under its own memory-sampling rule. **Lesson:** a good
  combined number licenses no per-layer percentage and does not erase a standalone cost;
  aggregate by median paired ratio then equal-model geomean, and never multiply separate
  layer ratios together.
  Full bundle: `git show 4fbbe8dd5:scripts/perf/evidence/retained-cold-load-2026-09-06/summaries.jsonl`.
- **Server JSON `float_roundtrip`** (#4064, PR #4065): correctness, not perf. The server's
  cached JSON deserialization moved a finite Haus northing and its transform entry by one
  float step; enabling serde_json's `float_roundtrip` preserves both with no tolerance or
  geometry change. The bounded fresh-process HTTP screen kept exact cold geometry and
  data-model bytes and corrected replay parity. **It claims neither a gain nor neutrality**:
  one pair per fixture is not performance qualification, and a processing-probe gain never
  extrapolates to the shipping HTTP artifact. Screen:
  `git show 4fbbe8dd5:scripts/perf/evidence/server-json-roundtrip-4064/screen.json`.
- **Y-up winding correction** (#4056, PR #4058): correctness, no throughput claim. **The
  IFC-to-viewer map `(x, y, z) -> (x, z, -y)` preserves orientation**, so the flat binding's
  extra triangle reversal was wrong; removing it aligns flat winding with transformed normals
  and the native/IFNS route, and a viewer geometry-output revision stops stale cached winding
  from surviving the fix. Simplification and native Y-up export conversion must use that same
  orientation-preserving convention. Canonical native geometry and its determinism manifests
  are unchanged; converted flat indices intentionally differ. A real WASM boundary contract
  pins it: it fails on the old runtime and passes on the correction. **Lesson:** a canonical
  geometry fingerprint cannot certify downstream coordinate conversion, and adaptive batch
  boundaries can expose a route-specific defect by moving otherwise identical entities between
  flat and instanced transport. Browser qualification:
  `git show 4fbbe8dd5:scripts/perf/evidence/yup-orientation-2026-09-07/browser-qualification.json`.

### Retained mesh bookkeeping and no-op copies (#3988)

Orientation reuses deterministic edge adjacency, triangle filters compact their existing index buffer, and welding/content hashing avoid duplicate map probes. Geometry policy, tolerances and traversal/output order remain unchanged. Own-layer native subset comparisons did not establish a meaningful full-load improvement; sampled leaf CPU and the cumulative result cannot establish a layer-specific gain. Preserve exact output and diagnostic oracles, including invalid/degenerate triangles and reused-buffer capacity. No isolated browser gain is established here; invalid Firefox cohorts and unrun follow-ups remain excluded. Owned-weld, sliver-incidence and alternate meshing experiments are not included.

### Dead ends (do NOT re-spike without a new mechanism)
- **Frame-invariant routing for plan-rotated voided walls** (#5739, PR #6035):
  the two routing fixes were NOT SHIPPED; both were measured on ISSUE_098 against the merge-base. With
  per-element local frames (the viewer default), the analytic prism cut's route
  decisions (per-opening partition check, hairline emit gate at its 64-edge cap)
  read f32 precision in the frame the vertices are stored in, so one 61° wall
  took a different route than in the world frame and stayed open.
  (1) *Comparison cut*: when the rotated-face analytic cut was not closed as
  emitted, make the same cut in the wall frame and keep the better one. It ran
  377 times and won 29; the losing cuts cost ~13 ms each. Result: +29-33%
  single-thread geometry, +27-54% end to end. No pre-cut signal separated the
  winners (defect count, host closure, opening count, edge length, raw or
  consolidated closure, triangle count).
  (2) *World-route mirroring*: run the analytic cut on the world-coordinate copy
  of host and cutters, so a local-frame wall takes exactly the world route.
  - Cost: pinned single-thread user CPU is at or below base (world 10.18 vs
    10.25 s; local 10.38 vs 12.16 s). But end-to-end local geometry is +22%:
    1376-1508 vs 1103-1285 ms over 8 interleaved rounds, and the ranges do not
    overlap. Three walls (#1691248, #1691510, #1701652) move from a ~40 ms local
    prism cut to the world's ~400-460 ms exact wall-frame route, and they sit on
    the critical path.
  - Quality: local-frame closure regresses to world quality. 179 elements are
    worse across rvt01, ISSUE_098 and ISSUE_129. ISSUE_098 goes from 306 to 353
    torn elements.
  - A cheap world-quantized final gate alone leaves the 61° wall open.

  **Shipped instead (option B, local frame only):** two changes, both scoped
  to hosts stored relative to a per-element origin:
  - the wall-frame closure test judges the cut as emitted;
  - the snap tolerance uses the world magnitude.

  World-frame code and output are unchanged: 33/33 fixture output hashes match
  base, including ISSUE_098 and Holter. An earlier unscoped version cost a
  consistent +1.7-2.7% on ISSUE_098 in the world frame, where it was not
  needed.

  Local frame against merge-base a20989951:
  - Pinned single-thread user CPU, 6 interleaved runs:
    - ISSUE_098: 9.05-9.89 s base vs 8.99-10.74 s branch
    - ISSUE_129: 2.11-2.66 vs 2.12-2.54 s
    - Holter: 3.30-3.89 vs 3.11-3.70 s
    - AC20: 0.03 s both
  - Multi-threaded geometry, median of 8 interleaved rounds:
    - ISSUE_098: 866 vs 854 ms
    - ISSUE_129: 971 vs 1010 ms (overlapping ranges; output identical)
    - Holter: 602 vs 612 ms
    - AC20: 21 vs 22 ms
  - Closure: ISSUE_098 local goes from 306 to 305 torn elements, with none
    worse.
  - The 61° wall stays open in the local frame; it is pinned as a known
    residual.

  **Lessons:**
  - A route decision made at stored precision cannot be made frame-invariant
    without redoing the frame's computation. The world route is not the better
    route on real models: the local frame's prism cut closes more walls, more
    cheaply.
  - Judge perf by the multi-threaded critical path as well as by CPU: moving
    work onto a few heavy hosts can lower total CPU and still lengthen the load.
- **More geometry workers** -> zero CSG speedup: memory-bandwidth bound, not CPU.
- **Shared entity-index for the VIEWER huge-file path** (#1445): CLOSED, branch
  deleted, REFUTED by an end-to-end 722MB re-measure. The retained-size spike looked
  great (152 vs 354 MB/worker, projected ~600 MB lower peak) but `peakWasm` went *up*
  ~680 MB (3930 vs 3250 MB): peak is set *during* the build, `from_columns`
  double-buffers a transient `Vec<(u32,u32,u32)>` + output `Vec<u8>`, and N workers
  building concurrently spike above the old single-FxHashMap footprint. Third
  isolated-bench-misled case after #1429 and Manifold. Do NOT re-attempt without a
  transient-free in-place build — and even then the index is not the dominant cost
  (the per-worker 1x source copy is). (The single-consumer export/native shared index
  above is a *different* thing and did ship.)
- **Threaded WASM CSG** (#1429): 4.19x CSG-only isolated, but whole-pipeline only
  2.33x @ 4 threads and it REGRESSED at 8 threads (atomics tax + SAB scaling). Second
  isolated-bench-misled case. `init_thread_pool` survives in the off-by-default
  `threads` bundle only; the live path is the JS worker pool.
- **Void-cut dedup** (#1286-P5 / #1571): ~4% eligible on real models (plan-rotated
  walls ineligible AND costliest); world-frame cut can't be byte-identical. PARKED.
- **Content-dedup** (#1130): hash re-decodes the subtree, 20-30% slower net. OFF.
  (It became a NET LOSS once rect_fast made CSG cheap — a "regime rot" example: a
  measured win can flip when the surrounding cost regime changes.)
- **Manifold WASM / BSP kernel**: deleted at M9; pure-Rust exact kernel is the only
  one. C++ accelerator was a dead end.
- **Rect-fast void path**: correct where it fires but barely fires (0 on Revit/Tekla);
  not the lever.
- **CSG exact-arith**: ~15ms/cut floor is the arithmetic cost; the only lever there
  is *doing fewer/cheaper cuts* (analytic bypass), not faster exact CSG.
- **`wasm-opt` for size**: a NET LOSS on the *shipped* (brotli-compressed) bundle —
  it grows the brotli-compressed transfer size even when it shrinks the raw `.wasm`.
  Track raw AND brotli, and gate on brotli (what the user downloads).
- **`bnum` fixed-width bigint** (bnum#74): OBSOLETE post-FixedInt; the -8.9% it once
  bought is now ~0%. Another regime-rot casualty.
- **Component parity BVH filtering** (#4054, PR #4060): conservative per-component BVH
  filtering of the exact parity candidate scan, query endpoint and predicates unchanged.
  A one-pair fresh-process Chrome screen over 27 fixtures established NO corpus cold-load
  gain: one candidate run timed out after 240 s waiting for renderer finalization while its
  baseline passed, both sides of the largest fixture timed out closing Chrome, and two
  completed pairs failed the raw geometry-channel gate. **Lesson:** a classification hotspot
  does not extrapolate to an end-to-end win, and no small-component threshold is justified by
  these observations. Rejected source, the only public copy (the spike commits are not on any
  remote): `git show 4fbbe8dd5:scripts/perf/evidence/component-parity-bvh-rejected-2026-09-07/measured-candidate.patch`,
  applied to public base `96ea5f08e` with `git apply --unidiff-zero`. The test-only extension
  `bdc38d30c` chain-applies after it and is likewise public only here:
  `git show 4fbbe8dd5:scripts/perf/evidence/component-parity-bvh-rejected-2026-09-07/later-tests.patch`.
- **CDT constraint-inventory vertex reuse** (#4055, PR #4061): reusing the constraint
  inventory during refinement. Native full processing call over 27 fixtures x 5 interleaved
  fresh-process pairs: **-1.17%** by ratio of model medians, **-1.27%** by median paired ratio.
  Two estimators, not one result. The corrected-orientation browser screen was **+0.63%
  SLOWER** in complete readiness on the historical 11-model subset, and 3 of 27 pairs were
  rejected on TWO different gates, which the evidence deliberately kept apart: the 511 MB and
  263 MB pairs failed the raw mesh-count, canonical-hash, AABB/volume and spatial-multiset
  gates, while the 1.259 GB pair passed every one of those and failed the browser-close
  watchdog on BOTH arms (nonzero exit plus teardown failure). The close hang is unexplained
  and is not evidence about the candidate's geometry. **Lesson:** exact instrumented producer
  output on one fixture does not waive downstream browser mismatches; do not re-spike this on
  a microbenchmark, a normalized mesh comparison or selected-fixture timing. Rejected source,
  the only public copy:
  `git show 4fbbe8dd5:scripts/perf/evidence/rejected-vertex-reuse-2026-09-07/measured-candidate.patch`,
  applied to public base `e40992485` with `git apply --unidiff-zero`. The test follow-up
  `c0ef3e802` chain-applies after it and is likewise public only here:
  `git show 4fbbe8dd5:scripts/perf/evidence/rejected-vertex-reuse-2026-09-07/test-followup.patch`.
- **Owned server mesh-batch transfer** (#4066, PR #4072): an owned sink in the canonical
  processing loop removed the server bridge's deep mesh-buffer copy, preserving the borrowed
  API, retained output, batching, progress, styling and cancellation. Exact output and
  hash-only cache replay passed; the prespecified actual-HTTP readiness continuation gate did
  not. The small and MEP models were slower in their single pairs, and the largest model's
  modest time improvement came with higher sampled RSS. **Lesson:** removing a real
  source-level copy is not by itself an end-to-end gain; unbounded downstream ownership and
  the rest of the pipeline remain the cost. Rejected source, the only public copy:
  `git show 4fbbe8dd5:scripts/perf/evidence/rejected-owned-batches-2026-09-07/measured-candidate.patch`,
  applied to public base `1b95c6652` with `git apply --unidiff-zero`.
- **Server PGO, both variants** (#4059, PRs #4068/#4069/#4070/#4071): the native `perf_probe`
  full-value profile DID qualify: **-9.81%** aggregate processing-call time over 27 models
  (-9.97% on the 22 held out), with exact ordered geometry fingerprints and counts in all 135
  pairs. But the largest model carried a **+5.27%** median-time penalty and aggregate
  whole-process physical footprint rose **1.39%**. Neither actual-server screen inherited it:
  the counter-only HTTP screen and the full-value HTTP screen both missed their predeclared
  continuation threshold, and both kept a CSG diagnostic mismatch on the 263 MB model that
  exact geometry bytes did not waive: Complete-path CSG failures 195 -> 196 on the
  counter-only screen and 194 -> 196 on the full-value one, mechanism tracked at #4067. The
  census varies WITHIN each arm too (native probe baseline 194, 195, 197, 198; candidate 194,
  195, 196, 197), which is why the mismatch is a limitation to explain rather than a
  difference to average away. **Lesson:** a probe win does not transfer to the shipping
  server, which differs in allocator, features, build-std configuration and target. Never
  reuse a profile between the two artifacts. The flags that decide the result, inline because a
  re-spike gets exactly these wrong:
  - control `RUSTFLAGS` is **empty** on both sides;
  - generation adds `-Cprofile-generate=<fresh raw dir>`, plus (Darwin, **counter-only
    continuous training only**) `-Clink-arg=-Wl,-sectalign,__DATA,__llvm_prf_cnts,0x4000` and
    the same for `__llvm_prf_data` / `__llvm_prf_bits`; full-value training adds neither those
    nor `%c` to `LLVM_PROFILE_FILE`;
  - use adds `-Cprofile-use=<merged.profdata> -Cllvm-args=-pgo-warn-missing-function`, and
    the full-value server build adds `-Cllvm-args=-no-pgo-warn-mismatch-comdat-weak=false` on
    top so weak/comdat mismatches are reported rather than hidden;
  - the server artifact is built `CARGO_UNSTABLE_BUILD_STD=std,panic_abort cargo build
    --release -p ifc-lite-server --target aarch64-apple-darwin`, while the probe is
    `cargo build --profile server-release -p ifc-lite-processing --example perf_probe`, which
    is why their profiles are not interchangeable.

  Driver and full recipe: `git show 4fbbe8dd5:scripts/perf/evidence/server-pgo-darwin-2026-09-07/README.md` and
  `git show 4fbbe8dd5:scripts/perf/evidence/server-pgo-darwin-2026-09-07/reproduce`. The three
  screens:
  `git show 4fbbe8dd5:scripts/perf/evidence/native-pgo-current-2026-09-07/README.md`,
  `git show 4fbbe8dd5:scripts/perf/evidence/server-pgo-counter-http-4059/README.md`,
  `git show 4fbbe8dd5:scripts/perf/evidence/server-pgo-full-value-http-4059/README.md`.
- **Canonical type-ordinal handoff across the worker index** (#4031): rejected, no PR opened.
  A fixed 11-model Chrome cohort ran all 110 predeclared fresh-process runs; 109 succeeded and
  one crashed before readiness (CDP errorCode 4), so the independent audit rejected the
  cohort. Across the ten models with five complete pairs, median paired full-readiness changes
  were small and mixed, spanning **-3.07%** (architecture-343) to **+2.46%** (CSG177), with
  CSG177 and Tekla slower in four of five pairs; CSG177's physical footprint was higher in
  EVERY pair. **Lesson:** metadata improved more than full readiness did, so the removed
  reconstruction work never controlled the end-to-end boundary. Evidence is private and the
  verdict lived only in the issue's closing comment until now; the harness fixes it paid for
  landed separately as PRs #4035 and #4037.

### Cold-start / CSG levers — mixed status (read each label)
- **Viewer drawing demand, property-set discovery and parser scheduling (RETAINED, measured):** a saved
  section-overlay preference does not imply an active drawing consumer. Match
  the renderer's section-tool demand, preserve explicit export generation, and
  refresh inputs when a consumer becomes active again. On large cold loads the
  previous hidden section cut blocked metadata delivery and renderer readiness.
  Sorted parser indexes also need no permutation; association-target discovery
  was dead work once all references were indexed. A conservative resident-byte
  ePSet filter skips only proven negatives, retaining the canonical decoder for
  escaped names and possible matches. Disabling only the DXF caller did not
  help: another required georeference consumer paid the same work later.
  Parser reference arrays can overlap the geometry workers' peak allocation.
  Giving geometry a bounded head start reduces that overlap: hand off the
  already-built shared index when a worker finishes, at stream completion, or
  at a source-size-scaled deadline. Always release it on iterator shutdown too.
  Waiting only for worker completion regressed an architecture model; the
  deadline bounds that tradeoff and avoids the parser's fallback scan timeout.
  Keep smaller sources immediate: deferring a structural fixture increased its
  renderer peak despite faster loading; immediate handoff removed that increase.
  Final fresh-process comparisons across MEP, architecture, sanitary, CSG,
  structural and bridge models improved every full-readiness median, with
  matching geometry digests and real GPU picks, properties and spatial paths.
  The large target reduced whole-browser RSS and renderer peak footprint;
  smaller-model total RSS remained variable, so this is not a universal memory
  reduction claim. Actual section-tool activation produced identical cut
  geometry on small and large models. Single-to-federated loading preserved
  selection, properties and spatial hierarchy; metadata-only input still settled.
  Active drawing requests share one queue: geometry, plane and visibility
  changes keep only the newest pending inputs, and superseded cuts cannot
  publish. Parser-worker-unavailable loads do not retain a deferred handoff.
  An interleaved ablation across MEP, CSG, structural, bridge and small models
  found no material full-load or RSS benefit from retaining WASM batch decoder
  memos, including completed BREP signatures. That extra WASM cache machinery
  was removed; the native shared signature cache remains independently useful.
  Clearing local reference variables and delaying only until the first mesh
  batch did not reliably reduce whole-load memory either.
  Rare Chrome ARM64 renderer SIGILLs occurred during the style pre-pass on
  both the performance candidate and the unoptimized corrected baseline.
  Preserve failed runs alongside successful timing samples; successful replays
  do not establish a fix or equal failure rates. Follow-up #3975 carries the
  crash dumps, reproduction conditions and bounded engine/application diagnosis.
  This change does not claim to fix that shared reliability defect.
  Geometry-only events and truncated worker-memory summaries cannot settle it.
Entries below are tagged individually: CANDIDATE (measured once, not validated end-to-end),
SHIPPED (landed with a PR), or RE-REFUTED / NOT SHIPPABLE. Do not read the section as
"all unshipped".
- **GLB export trailing georeferencing** (PARKED after #5357 spike): export
  still does not consume the returned georeferencing metadata, but the old
  whole-file scan explanation is obsolete: extraction now reuses scan candidates.
  Property-set candidate decoding remains. A suppression prototype preserved the
  tested complete GLBs, including site/RTC behavior; its shared-host timings do
  not establish an end-to-end win. A production opt-out must be export-scoped
  and preserve public options compatibility. See the
  [source, observations and qualification limits](evidence/export-delivery-5357/README.md).
- **Bounded GLB geometry replay** (NOT SHIPPED after #5557 screen): recording
  the planning pass's meshes on native scratch and replaying them through the
  existing writer avoided a second meshing pass, with complete artifact identity
  in the controlled native screen. The prototype has no first-party native GLB
  consumer: CLI, MCP and viewer source-byte export use WASM, and the viewer's
  loaded-mesh export uses a different path. A replay cache large enough for the
  heavy fixture would undermine the bounded WASM memory contract. Do not add a
  native-only public API without an actual consumer; a future attempt needs a
  consumer and a portable scratch/error policy, or a separately qualified
  memory-bounded WASM design. No browser or CLI gain is established. See the
  [#5557 screen and archived patches](../../docs/architecture/evidence/bounded-glb-replay-5557/README.md)
  and the earlier #5357 archive above.
- **Brotli quality 11 on the served bundle** (PARKED after #5357 observation):
  the actual deployed WASM response already negotiates Brotli and compiles in
  Chrome. Recompressing those same decoded bytes locally leaves potential
  transfer savings, but there was no authenticated preview to verify altered
  delivery. Actual response headers, transfer/body sizes and byte-identity checks
  are archived above. No deployed improvement or whole-viewer cold-load win is
  claimed; local compressed size alone still cannot qualify this lever.
- **Parser worker's unused WASM compile** (SHIPPED, PR #1851): NOT the "compile outside
  the shared memo" this was first framed as. Verified: on the streaming cold-load path
  (`waitForEntityIndex`, every file >=2 MB) the parser worker eager-compiled the ~3.9 MB
  scanner and then NEVER USED IT — the geometry pre-pass hands over the entity index and
  `entity-scanner.ts` short-circuits before the wasm scan. So the compile was pure waste
  stealing a core from the concurrent pre-pass. Fix = defer the compile (eager only on
  the no-handoff path; lazy on the timeout fallback). Win = CPU-contention relief on the
  parse<->pre-pass overlap; shows on LOW-CORE devices, so read magnitude off the CI
  viewer benchmark / PostHog, not a fast dev machine. Lesson: the "shared compile memo"
  fix was a mis-frame — verify the code path before building the fix the research names.
- **Threaded WASM CSG — in-instance rayon** (RE-REFUTED end-to-end, measured
  2026-07-23; keep in the dead-end column): a fresh browser A/B on ISSUE_129 (the most
  CSG-heavy public model, 71% CSG) settles the old CONTESTED status against threading.
  The CSG *kernel* really does parallelize in WASM (corpus replay 4152 -> 1724 ms,
  **2.41x**), but the **full pipeline REGRESSED**: plain single-thread 6450 ms vs
  threaded-8T 7383 ms = **0.87x** (byte-identical, fp=1402). The atomics tax on the
  serial parse/decode majority (2298 -> 5659 ms, ~2.5x slower) exceeds the CSG savings.
  ISSUE_129 is the *best* case, so lighter models are worse. This vindicates #1429 and
  supersedes the `docs/architecture/csg-threading-design.md` rung-2 "1.6-1.9x
  end-to-end" numbers, which have regime-rotted (see below). Do NOT wire `pkg-threaded`
  without first defeating the whole-pipeline atomics tax (not just the CSG step).
  Data: `csg-thread-bench` build.sh was itself broken (missing shared-memory link args)
  and never booted the threaded bundle until fixed in this PR.
- **Regime rot: CSG is no longer the universal bottleneck.** Native capture 2026-07-23
  (`csg_scaling_bench`): the *expensive-CSG* corpus has collapsed 10-160x vs the
  threading-doc era as the fast paths (rect_fast, analytic bypass, faceted-brep dedup)
  matured. advanced_model CSG = **4%** of load (13/316 ms; doc: 103 jobs/26 s), dental
  32%, ISSUE_068 33%, ISSUE_129 71%. The dominant cost on the majority of models is now
  the **single-threaded parse/prepass/decode/extrude path** (advanced_model 96% non-CSG),
  which gates time-to-first-geometry and hits every model — that, not CSG threading, is
  where the next real speedup lives.
- **Wide-arithmetic exact-CSG bundle** (~1.7x on a real void cut — NOT SHIPPABLE TODAY):
  built by `BUILD_WIDE=1 scripts/build-wasm.sh`, but **V8 does not run it**. Measured
  2026-07-31 on V8 (Node 22 / V8 12.4 and Node 26.5.1 / V8 14.6): a module using
  every wide op the bundle emits fails `WebAssembly.validate`, compiling it throws
  `invalid numeric opcode: 0xfc13`, and `node --v8-options` lists **no**
  wide-arithmetic flag under any name. An earlier
  entry here claimed V8 had it behind a default-off
  `--experimental-wasm-wide-arithmetic`; that flag has never existed, so do NOT wait
  for it to be "staged" — there is nothing to stage. Firefox (SpiderMonkey) and Safari
  (JavaScriptCore) were not measured; treat them as unverified, not as rejecting.
  Track-and-adopt only; the runtime feature-probe
  (`packages/geometry/src/wasm-features.ts`, not yet created) would auto-upgrade per engine
  as each ships. The CI tripwire (`.github/workflows/wide-arithmetic.yml`) probes the
  engine every week and turns red when this changes. See
  `docs/architecture/wasm-wide-arithmetic.md` (delivery status verified 2026-07-31).

- **Content-dedup signature walk on large single BREPs** (~2.00x traversal, SHIPPED #1909):
  `item_dedup_key` walked every face/bound/loop/point of an `IfcFacetedBrep` to build a
  dedup key — a second full traversal mirroring the mesher's own. On a model that is one
  large BREP with no repeats, that key can never pay off. Gated on
  `FACETED_BREP_DEDUP_FACE_LIMIT` (20,000 faces), measured with a **deterministic counter**
  (`EntityDecoder::point_cache_stats()`), not wall-clock: 5,880,000 accesses with dedup on
  vs 2,940,000 with it off on a synthetic 980k-face BREP — exactly 2.00x — and 1.00x after.
  Post-mesh `get_or_cache_by_hash` and `direct_rep_identity` still run, so genuinely repeated
  large geometry still dedups and still instances (asserted by test).
  **Lesson, and the reason this entry exists:** an end-to-end suite verdict **cannot be
  produced for this lever on the current corpus.** The largest BREP across all 163 fixtures
  is 8,848 faces, so nothing in the suite crosses a 20,000-face gate; a base-vs-branch A/B
  swung -10%/+9%/-7% with the sign tracking run order, i.e. pure noise. Do not spend another
  afternoon on `probe.sh --suite` for a threshold this corpus cannot reach — either add a
  fixture above the gate, or measure with a deterministic counter as above. The 20,000 figure
  is a judgement call (an order of magnitude clear of realistic repeated parts, which run to
  low hundreds of faces), not a measured optimum.

### Retained canonical lexical and schema work (#4001)

Reuse checked ID-prefix accumulation and the scanner's existing ASCII proof; obtain native geometry flags from one immutable classification lookup. Generated type parsing checks canonical names before normalization, and schema detection retains the original match priority. Own-layer native subset comparisons showed a modest full-load improvement, not a corpus-wide or browser result. Keep the cumulative verdict separate and exclude invalid Firefox cohorts and unrun follow-ups. Scalar tokenizer dispatch, scanner dictionaries and ordinal transport are separate experiments, not part of this change.

### Measured feature costs (not levers — recorded so nobody re-measures)
- **Re-meshing an edited wall through the wasm mesher (#6232 WP1, measured
  2026-09-27, real-GPU Windows Chrome over CDP, production `vite build`).**
  Commit → rendered frame for `resizeWall` on a wall hosting a window, 20
  resizes each: demo project p50 64 ms / p95 98 ms; AC20-FZK-Haus p50 74 ms /
  p95 83 ms. The re-mesh itself is a small part of that: serialize the
  subgraph ~1 ms, worker pre-pass + produce ~3-6 ms (`scripts/perf/remesh-latency.mjs`,
  node/wasm, AC20 walls with openings: p50 4.4 ms total). The rest is the
  viewer re-rendering on two store updates: the commit's own mutations (~30 ms
  before the worker's answer is even read) and the geometry replacement
  (~18 ms to the drained frame). That is the design's 50 ms p50 budget missed
  by React work the re-mesh does not add, so the lever is fewer re-renders per
  geometry update, not the mesher. In a dev build the same loop is ~200 ms
  (React dev mode dominates a CPU profile). The first request per model also
  pays a one-time whole-file pre-pass for the style wire (AC20: ~170 ms).

- **Re-mesh commit → frame, render-cost follow-up (#6232, measured
  2026-09-28, same harness, production builds, 5 interleaved rounds of 20
  resizes, fresh tab per run).** Median p50 / p95: demo 71.5 / 82.6 ms →
  45.1 / 59.0 ms; AC20-FZK-Haus 72.9 / 84.1 ms → 47.1 / 63.0 ms (every
  branch round's p50 42-48.5 ms, every base round's 64.8-77.1 ms). The mesher
  was never the cost; the viewer shell was. Counted with a fiber-commit hook in
  a dev build: one resize was 19 store notifications and 6 commits, and three
  of those commits re-rendered `ViewerLayout`, the whole app, because hooks
  mounted there (`useSearchIndex`, `useUnexportedChangesGuard`, and
  `useModelUrlAutoload` via `useIfc()`) select `models`, which every geometry
  update republishes. The levers, in order of effect: those hooks moved to a
  leaf (`ShellStoreEffects`) or off `useIfc()`; the hierarchy reads `models`
  through a selector that keeps its identity while the same ids have geometry
  (a re-mesh), so the panel and its rows stop re-rendering; the file/export
  commands, ribbon and Author tab select primitives or the
  model roster (`useModelRoster`) instead of `useIfc()`; a positional batch is
  one store update (was N + 1); `useModelSelection` and `useLevelDisplayEffect`
  stop writing unchanged state back on every `models` change. Left: the edit
  commit still re-renders what legitimately reacts to `mutationVersion`
  (hierarchy authored rows, undo buttons, change counts), and the placed
  spatial index is rebuilt 200 ms after each edit, off the latency path but
  O(model).

- **Local-frame void-cut origin preservation** (#3446, measured 2026-08-31,
  base = `2edd144329`, arm64 native). This correctness fix keeps a rotated
  local-frame cut's centre and nested origin out of absolute-world `f32`.
  `probe.sh --iters 5 --json` found no performance signal: AC20-FZK-Haus best
  total/geometry was 10/5 -> 9/5 ms (base totals 14,10,10,10,10; branch
  11,10,9,9,9); ISSUE_129 was 623/604 -> 627/608 ms, inside the base's
  623..633 ms spread. Mesh/vertex/triangle counts match on both fixtures
  (AC20 285/35940/19456; ISSUE_129 1402/218346/132673). The branch intentionally
  changes the far-field void corpus, so the pinned native/wasm manifests and
  arm64 determinism harness are the stronger output evidence. Holter was not
  measured: its fixture endpoint repeatedly served a SHA-256 mismatch.

- **Legacy-site georeference negative-zero recovery (#3546 residual): no
  measurable geometry-pipeline regression.** The localized raw-record scan runs
  only while extracting `IfcSite.RefLatitude`/`RefLongitude`; it deliberately
  leaves the shared integer tokenizer untouched. Interleaved five-round native
  `perf_probe` A/B (`3d9ab0e30` -> `e81f41d66`, Apple Silicon) was below the
  harness's noise threshold: FZK-Haus total 10 -> 10 ms (mesh/vertex/triangle
  counts 285/35,940/19,456 on both); CSG-heavy ISSUE_129 total 608 -> 609 ms
  (+0.16%, base spread 2.96%) and geometry 591 -> 592 ms (+0.17%, base spread
  3.38%), with identical 1,402/218,346/132,673 output counts. **Lesson:** this
  compatibility recovery is metadata-only and too rare/small for this coarse
  end-to-end probe to distinguish from run noise; retain the behavioral fixtures
  rather than treating the apparent one-millisecond movement as a regression.
- **Geometry fingerprint pass: world AABB + volume + closure verdict**
  (#1891/#1988, PR #1993, measured 2026-08-02, base = merge-base `8f139a8e`).
  The pass gained a per-triangle tetra determinant and a six-way bounds update.
  Verdict: **hashing OFF is unaffected, hashing ON costs a fraction of a
  percent.** Output byte-identical throughout — mesh/vertex/triangle counts
  unchanged on every fixture, and an FNV-1a over every `geometryHashValues`
  entry is equal base-vs-branch on all three (so the new arrays did not perturb
  the fingerprint they ride with).
  - Native `probe.sh --iters 5`, interleaved rounds, hashing off (the only mode
    the native pipeline has — see the harness gap below): AC20-FZK-Haus
    10 -> 10 ms total; ISSUE_129 median-of-6-rounds +1.4% inside a ±10%
    round-to-round band (per-round minima 683..984 ms on base alone);
    Holter/ISSUE_053 977 -> 967 ms (-1.0%). No signal either way.
  - WASM boundary (`buildPrePassOnce` + `processGeometryBatch` in node, 3
    interleaved rounds), min ms base -> branch: AC20 off 49.0 -> 49.1 (+0.2%),
    on 50.1 -> 50.5 (+0.8%); ISSUE_129 off 1983.9 -> 1987.9 (+0.2%), on
    1989.0 -> 1999.4 (+0.5%); Holter off 3555.7 -> 3600.1 (+1.2%), on
    3790.6 -> 3849.8 (+1.6%).
  - Turning the SWITCH on is the real cost, and it is the same on both sides:
    off -> on is +2.9%/+0.6%/+6.9% on branch versus +2.2%/+0.3%/+6.6% on base,
    i.e. this PR adds ~0.3-0.7 pp to a surcharge that only the diff feature pays.
  - Honest outlier: hashing-off on Holter reads +1.2% at the wasm boundary while
    the native probe on the same fixture reads -1.0%. Nothing in the
    hashing-off path changed — the hasher is `None`, so every new accumulator is
    dead code — and the delta sits inside the base's own 3528..3584 ms spread,
    so read it as the 3.7 KB binary-size / code-layout shift, not added work.
  - **Harness gap, worth fixing before the next hashing change:** `perf_probe`
    CANNOT reach the hashing path. `process_geometry` -> `processor/jobs.rs`
    hardcodes `MeshProductionOptions::default()`, so `geometry_hash` is always
    `None` natively and the fingerprint pass only exists behind
    `IfcAPI::setComputeGeometryHashes`. The hashing-on numbers above therefore
    come from driving the real wasm entry point, not from `probe.sh`.

- **Second harness gap, same shape: `probe.sh` cannot reach the SYMBOLIC path
  either** (found on #2358, 2026-08-11). `perf_probe` drives `process_geometry`,
  which never populates `symbolic_data`; annotation/placement work hangs off a
  separate entry point, `extract_symbolic_data`, called by the wasm binding and
  the server. So a symbolic-only change produces a **flat, identical probe table
  on both sides** — which reads exactly like "no regression" but is a control,
  not a measurement. If the diff is under `rust/processing/src/symbolic/`, say so
  and drive `extract_symbolic_data` directly, rather than pasting a zero.
  - **And pick the fixture by whether it exercises the branch, not by the default.**
    #2358 only does extra work when a symbolic rep's `ContextOfItems` is a full
    `IfcGeometricRepresentationContext`. The default fixture AC20-FZK-Haus has
    **zero** such reps (all 34 are SubContext) and C20-Institute zero of 316;
    `dental_clinic.ifc` has **1080**. Scan the corpus for the shape your diff
    touches before measuring, or the "canonical" fixture will confirm nothing.
  - Related trap when reading byte-identity on this path: **every WCS in the
    corpus is the identity**, which is precisely why the #2358 bug survived —
    resolving it correctly and never resolving it agree on every shipped fixture.
    Identical output there is evidence about the corpus, not about the change.

### Retained prepass source fingerprint sharing (#3985)

The existing prepass can publish the exact full-byte source key through a fresh per-load shared cell, including malformed tails. The parser uses it only when already ready; prior entry points and unavailable-cell fallback remain compatible without another source copy or worker. Retained cumulative qualification is not an isolated percentage claim. Record actual parser/prepass key origin when diagnosing overlap; an unavailable key can still pay the original parser hash.

### Reading the FIELD telemetry (PostHog) — verdicts and traps

- **A per-model PostHog regression alert is device-mix noise until you control for
  device — and at this traffic level it CANNOT be made to control for device**
  (2026-08-08, alert "Per-model load regression — any model >2x baseline").
  It fired at `x_change = 2.29` on one fingerprint (76.7 MB / 6668 meshes,
  14406 -> 32994 ms median). It is **NOT a regression.**
  - The decisive estimator is the **within-person same-model paired ratio**:
    for every (person, model) cell with loads in both windows, `median(recent) /
    median(baseline)`. Fleet-wide that is **0.927** (IQR 0.852-1.127) over 24
    cells / 16 persons / 97 loads — i.e. slightly *faster*. This holds the device
    constant by construction, which is the only property that matters here.
  - The fingerprint that fired has **zero** paired persons: 11 loads in 90 days by
    10 different people, no person in both windows. Its paired ratio is not
    small, it is **undefined** — there was never a regression estimate, only a
    comparison of one set of laptops against another.
  - **A per-model alert is not salvageable at current volume.** Across the whole
    17-day window, **no** model fingerprint has more than **one** paired person
    (24 fingerprints have exactly 1, 1825 have 0). Any per-model gate strong
    enough to be sound can never fire. Alert **fleet-wide** on the pooled paired
    ratio and keep per-model as a drill-down insight.
  - **Two tempting controls that are circular — do not lean on them.** (1)
    Normalising each load by that person's own median ms/MB *over the full
    window* looks great (it collapses 2.29x to 1.00x) but the divisor is computed
    from inside the suspect window, so a real uniform 2x regression normalises to
    ~1.4x and a person whose only loads are recent cancels out by construction.
    If you normalise, build the divisor from the **baseline window only**.
    (2) "The one person who loaded it on both recent builds got faster" compares
    two *recent* builds to each other and never bridges the windows.
  **Lesson:** the alert's anti-false-positive gates (>=5 loads, >=3 persons per
  window, recent p25 >= baseline median) are all satisfiable by five loads from
  five *different* laptops. Person count is not person *overlap*. This is the
  second retracted field perf claim on this project (see the #2183 "compression
  is worse" retraction) — both died to contaminated measurement, not to bad code.
- **A `total_triangles` change for one file can split WITHIN a single build.**
  On the fingerprint above, build `1aa498e26339` emitted **both** 4423296 (two
  persons) and 4432196 (a third) — same file, same `mesh_count` (6668), same
  `file_size_mb` to 2dp. Because the split is inside one build, every
  commit-range / "which merge changed the mesher" argument is moot, and so is
  fingerprint collision (it would need two files matching to +-5 KB and +-0
  meshes while differing 0.2% in triangles). An identical mesh roster with more
  triangles distributed *within* it means **environment-conditional
  triangulation on a deterministic code path** — most plausibly a CSG void cut
  that failed and fell back under memory pressure on one run. Note the CI
  determinism manifests would **not** catch this (pinned fixtures, controlled
  memory), so if CSG fallback is the mechanism it is known-by-design variance,
  not a latent determinism defect. `total_csg_failures` now rides
  `ifc_model_loaded` so this is answerable from telemetry. Do **not** spend a
  probe on `?geomWorkers=N`: `useIfcLoader.ts` documents that worker count cannot
  affect output (disjoint deterministic element slices), so that probe is
  predicted clean by the codebase itself.
- **`mesh_count` and `total_triangles` count FLAT meshes only, and the flat /
  instanced split is decided per WASM batch call.** An occurrence is instanced
  when its representation repeats often enough *within one call*, so anything
  that changes call composition moves geometry between the flat list and the
  instancing shards without changing what renders: the wall-clock adaptive batch
  sizer, the device-dependent worker count, and a hung-call replay at one job per
  call. Measured on a synthetic heavy model: identical rendered geometry came out
  as 549 meshes / 242,052 flat triangles on an idle host and 683 / 243,660 under
  CPU load. So "the geomWorkers probe is predicted clean" holds for rendered
  geometry, not for these two telemetry fields. A small `mesh_count` delta with a
  LARGE `total_triangles` delta is the other signature: a skipped element (see
  the "In-call geometry heartbeat replaces wall-clock element skips" section near
  the top of this file); read `hung_elements_skipped` first.
- **`total_elapsed_ms` is not pure compute — it contained an unbounded hidden-tab
  stall** (#2385, fixed). `useIfcLoader` awaited a bare `requestAnimationFrame`
  at stream-complete; rAF is never serviced while the document is hidden, so a
  tabbed-away load parked there indefinitely. Field evidence: 30 days of loads
  contain a 25-hour and a 3.4-hour `total_elapsed_ms`, and 20 loads over 60 s of
  post-stream time on models under 5000 meshes — durations no amount of finalize
  work can produce. 5.5% of all loads (420 / 7605) spent over 10 s after
  `stream_complete_ms`. **When mining this event, treat `total_elapsed_ms` minus
  `stream_complete_ms` above ~30 s as a visibility artifact, not compute, on any
  data captured before this fix.** That duration cut is a stopgap and has a real
  cost — it also hides a genuine slow-finalize regression. `ifc_model_loaded` now
  carries **`was_hidden`**; once it has 17 days of history, filter on
  `was_hidden != true` instead, which excludes the artifact without blinding the
  metric.
- **BVH construction no longer sorts every subtree synchronously** (#5252).
  The old `BVH.build` re-sorted each node's index slice and blocked the main
  thread during phase 2. A bounded median selection now builds the same exact
  leaf set with expected O(N log N) work; a heap-sort fallback bounds adversarial
  partitions. The async builder also slices phase 2, yielding through a timer
  while visible so Chromium can paint, and through the existing scheduler while
  hidden so background timer throttling does not stall the load. Keep exact
  query equivalence against brute-force AABB tests as the correctness oracle:
  tree shape and node order may change. A phase-2 microbench cannot establish a
  load win; use interleaved cold browser loads of the same IFC and compare
  spatial readiness, total load, mesh counts and visible-frame progress. The
  initial Holter browser cohort confirmed frame progress and no 14-second load,
  but concurrent host jobs made its small timing delta inconclusive.

#### Field properties on every load and journey (#6961)

`ifc_model_loaded` now carries the same milestones on every load path (wasm
streaming, cache, server, IFCX, GLB, point cloud, LandXML), plus main-thread
health, worker bytes, the journey and the perf-flag arm. Absent always means
"not measured", never 0; a value the load path measured itself always wins.

| property | meaning |
|---|---|
| `first_visible_geometry_ms` | first pixel: the paint after the first geometry append (`geometry.firstVisible`). Was wasm-only; now also cache. |
| `spatial_ready_ms` | spatial tree usable (`parser.spatialReady`; on a cache hit, the store restore `cache.storeReady`). New. |
| `metadata_complete_ms` | properties usable (`parser.complete`; cache: `cache.storeReady`). Was wasm-only. |
| `stream_complete_ms` | last geometry batch appended (`geometry.streamComplete`). Was wasm-only; now also cache. |
| `milestone_source` | `trace`: the four come from the load's streamed milestones. `commit`: a single-step path (server, IFCX, GLB, point cloud, LandXML) committed the model at once, so all four are its `total_elapsed_ms`. Never compare a `commit` row's first pixel with a `trace` row's. |
| `journey` | charter journey: `J1` cold open, `J2` cache hit, `J4` federated add. |
| `cache_tier` | `source`, `mesh-only` or `none` (the cache plan for this load). |
| `worker_count` | geometry workers the pool started (absent on paths without a pool). |
| `main_thread_blocked_ms` | sum of long-animation-frame `blockingDuration` (or long-task time over 50 ms where LoAF is missing) for frames starting between load start and capture. |
| `longest_long_frame_ms`, `long_frame_count` | the longest such frame and how many there were. |
| `long_frame_source` | `loaf` or `longtask`; compare rows of the same source only. All four main-thread fields are absent where the engine has neither (Firefox, Safari). |
| `worker_transfer_bytes` | mesh bytes the geometry workers handed the main thread plus the parser's transport bytes, from `memoryAccounting` (already on every load). 0 when a pool ran and moved nothing; absent when no pool ran (cache, server). It counts payload bytes, not the clone estimate `?perfTrace=1` records per message. |
| `perf_flags` | the M7 arm: `default`, or the non-default flags as sorted `id=value` pairs joined by `,` (read at capture). |
| `load_path` | now actually arrives. The scrubber deleted it until #6961 (the key matches the `path` word); the closed vocabulary `wasm`/`cache`/`server`/`point-cloud`/`landxml` is now kept. Rows before that have no `load_path` and no `journey`, so a pre-#6961 cache hit reads as `J1`: judge `J1` against `J2` only on a baseline captured entirely after this change. |

How it is measured without the tracer. With `?perfTrace=1` off, every load
gets a `FieldLoadTrace` (`apps/viewer/src/lib/perf/fieldLoadTrace.ts`) in place
of the old no-op trace: it records the first time of each milestone and the
load attributes that the instrumented call sites already pass, and nothing
else (spans, records and worker merges stay no-ops). Main-thread health comes
from one `PerformanceObserver` on `long-animation-frame` (and `longtask`),
created when the first load starts and reading back missed frames through its
`buffered` replay; it only fires on frames over 50 ms and keeps at most 2,000.
Both, and the three events below, live in an on-demand chunk
(`lib/perf/fieldTelemetry.ts`), so the entry chunk grows by about 600 raw
bytes. The recording tracer was not an option: it keeps every span, a counter
registry and a 20k-entry frame log, and counting message bytes walks every
worker payload.

Sampled events. All carry `journey`, `perf_flags`, `was_hidden` and, where a model is
loaded, `file_size_mb`/`mesh_count` from the last load (the same model key as
`ifc_model_loaded`); nothing else identifies the model.

| event | journey | what | sample rate, and why |
|---|---|---|---|
| `ifc_inspect` | J5 | `inspect_ms`: viewport click to the paint after the properties panel committed that entity | 10% of selection clicks, at most 10 per page session. Clicks outnumber loads by an order of magnitude; the paired ratio needs a few samples per person per window, not every click. Sent only when the panel is open. |
| `ifc_navigate` | J6 | `frame_p50_ms`, `frame_p95_ms`, `frame_max_ms` over 120 camera-interaction frames (orbit, pan, zoom), excluding each interaction's first frame, frames while geometry streams and hidden-tab frames | once per page session, every session: one row per session is already the cap. Frame intervals include the adaptive render throttle, which is what the user sees. |
| `viewer_boot` | J0 | `drop_target_ms` (navigation to the empty viewer's drop target enabled), `engine_wasm_compiled_ms` (navigation to the prewarmed engine compiled), `engine_wasm_compile_ms` (the prewarm's own fetch + compile), `engine_wasm_compiled` | once per page load, every page load. Sent when both are known, or 30 s after the field chunk loads. `drop_target_ms` is absent when a load started first; `engine_wasm_compile_ms` is absent when a load joined the compile; both are absent when the prewarm was skipped (Save-Data, 2G). |

#### The field verdict (#6961)

`scripts/perf/field-verdict.mjs` applies the paired-ratio method above to one
deployed build: per (event, metric, journey, person, model) cell,
`median(recent) / median(baseline)`, where recent is the judged build's rows
and the divisor comes from the baseline window (the 14 days before that build
first appeared) and from the `default` arm only. A group's pooled ratio is the
median of its cell ratios, reported per journey and pooled across journeys,
each per `perf_flags` arm. The threshold is on speed (1 / ratio): pooled speed
below 0.95 with at least 5 paired cells is `regressed`; fewer cells is
`insufficient`, which is the common case at current volume and is not a
pass. `was_hidden = true` rows and bot traffic are excluded in the query.

```bash
node scripts/perf/field-verdict.mjs --print-sql --build <sha> > verdict.sql   # the HogQL below, filled in
POSTHOG_PERSONAL_API_KEY=... node scripts/perf/field-verdict-fetch.mjs --build <sha> --out result.json
node scripts/perf/field-verdict.mjs result.json --build <sha>                  # markdown; --json for data
```

`.github/workflows/field-verdict.yml` runs this daily at 05:15 UTC, before the
05:45 deploy, against the build production has served since the previous
deploy, and posts the markdown on the PR that build's commit came from (once
per build). It needs one repository secret, `POSTHOG_PERSONAL_API_KEY`: a
PostHog personal API key with only `query:read`, scoped to project 199147
(EU cloud). Without it every run skips with a notice. Opening a thread when a
pooled group regresses is the next step and is not wired yet.

The HogQL the script expects (`__BUILD__` is the 12-character
`app_build_sha`, `__BASELINE_DAYS__` the baseline length; the script reads it
from this block). It already aggregates to one row per (person, model,
journey, arm, metric, window) cell, not per load; `field-verdict-fetch.mjs`
appends `LIMIT`/`OFFSET` and pages over the fully ordered result until it is
complete, and fails rather than judge a partial one:

<!-- field-verdict-hogql -->
```sql
SELECT
  event,
  journey,
  arm,
  person,
  model,
  metric,
  window,
  quantile(0.5)(value) AS median,
  count() AS n
FROM (
  SELECT
    event,
    -- Rows before #6961 carry no `journey` (and no `load_path`: the scrubber
    -- deleted it), so they fall back to load_target; a pre-#6961 cache hit
    -- therefore reads as J1.
    coalesce(
      toString(properties.journey),
      multiIf(
        event = 'ifc_model_loaded' AND properties.load_target = 'federated', 'J4',
        event = 'ifc_model_loaded' AND properties.load_path = 'cache', 'J2',
        event = 'ifc_model_loaded', 'J1',
        event = 'ifc_inspect', 'J5',
        event = 'ifc_navigate', 'J6',
        'J0'
      )
    ) AS journey,
    coalesce(toString(properties.perf_flags), 'default') AS arm,
    toString(person_id) AS person,
    -- The model is its format plus size to 10 KB: no name ever leaves the browser.
    if(event = 'viewer_boot', '-', concat(coalesce(toString(properties.format), '?'), ':', toString(round(toFloat(properties.file_size_mb), 2)))) AS model,
    if(toString(properties.app_build_sha) = '__BUILD__', 'recent', 'baseline') AS window,
    arrayJoin(arrayFilter(m -> isNotNull(m.2), [
      tuple('total_elapsed_ms', toFloat(properties.total_elapsed_ms)),
      tuple('first_visible_geometry_ms', toFloat(properties.first_visible_geometry_ms)),
      tuple('spatial_ready_ms', toFloat(properties.spatial_ready_ms)),
      tuple('metadata_complete_ms', toFloat(properties.metadata_complete_ms)),
      tuple('stream_complete_ms', toFloat(properties.stream_complete_ms)),
      tuple('main_thread_blocked_ms', toFloat(properties.main_thread_blocked_ms)),
      tuple('inspect_ms', toFloat(properties.inspect_ms)),
      tuple('frame_p95_ms', toFloat(properties.frame_p95_ms)),
      tuple('drop_target_ms', toFloat(properties.drop_target_ms)),
      tuple('engine_wasm_compile_ms', toFloat(properties.engine_wasm_compile_ms))
    ])) AS pair,
    pair.1 AS metric,
    pair.2 AS value
  FROM events
  WHERE event IN ('ifc_model_loaded', 'ifc_inspect', 'ifc_navigate', 'viewer_boot')
    AND timestamp >= now() - INTERVAL 90 DAY
    -- Baseline: the __BASELINE_DAYS__ days before the judged build first appeared.
    AND timestamp >= (
      SELECT min(timestamp) FROM events
      WHERE event = 'ifc_model_loaded' AND timestamp >= now() - INTERVAL 60 DAY
        AND toString(properties.app_build_sha) = '__BUILD__'
    ) - INTERVAL __BASELINE_DAYS__ DAY
    AND (
      toString(properties.app_build_sha) = '__BUILD__'
      OR (
        timestamp < (
          SELECT min(timestamp) FROM events
          WHERE event = 'ifc_model_loaded' AND timestamp >= now() - INTERVAL 60 DAY
            AND toString(properties.app_build_sha) = '__BUILD__'
        )
        -- Only people who also used the judged build can form a pair.
        AND person_id IN (
          SELECT person_id FROM events
          WHERE event IN ('ifc_model_loaded', 'ifc_inspect', 'ifc_navigate', 'viewer_boot')
            AND timestamp >= now() - INTERVAL 60 DAY
            AND toString(properties.app_build_sha) = '__BUILD__'
        )
      )
    )
    -- A load spanning a tab switch timed the user's absence (#2385).
    AND NOT ifNull(toString(properties.was_hidden) = 'true', false)
    AND NOT ifNull(toString(properties.$virt_is_bot) = 'true', false)
)
GROUP BY event, journey, arm, person, model, metric, window
ORDER BY event, journey, metric, person, model, window
```

### Source and buffer ownership during WASM prepass (#3989)

Source-session reuse, binding-owned index adoption and direct transfer of already-owned mesh getter arrays preserve byte-taking compatibility and source-replacement resets. The standalone own-layer native subset was slower in full-load timing, while Holter's measured peak memory fell; the cause remains unestablished and favorable memory does not waive the timing concern. The intended integrated merge parent differs from that standalone comparison, and its proposed comparison remains unrun; results with different parents must not be pooled. Combined native/browser results do not isolate a gain for this layer, and invalid Firefox cohorts provide no throughput evidence. Real WASM contracts verify returned buffers survive handle free, memory growth and transfer, including textures. Establish ownership at the binding: a JavaScript view does not remove the WASM input copy, and borrowed WASM-memory views must not be transferred as owned output.

### Remaining sharded prepass column adoption (#6537)

The [retained source-matched hosted qualification](https://github.com/LTplus-AG/ifc-lite/blob/5081a5efadc3072e6b710fd8e1c3b22aa6aafa9b/scripts/perf/evidence/owned-prepass-columns-6537/README.md) is neutral: every public family had mixed paired elapsed deltas, with no consistent default SDK throughput improvement or measured comparative RSS gain. Complete produced CPU-channel identity and unnormalized diagnostics matched across fresh default-pool samples, with original shard activation logs retained. Historical local refusals remain separate and provide no timing verdict. This is not native, full-viewer, metadata or GPU evidence.

Both sharded prepass bindings adopt numeric columns already copied into WASM by the ABI; geometry-worker index installation already adopts them under #3989. Original-order discovery precedes sorting/deduplication, preserving class alignment, every discovery occurrence and last-occurrence lookup precedence. Actual native pointer and real-WASM controls qualify that ownership contract. On unsorted input, later index construction can overlap existing sort transients with discovered jobs/spans: deleting a clone does not prove a lower physical memory peak or faster loading. The finite hosted result does not isolate that allocation lifetime or an elapsed cause. The durable evidence passed bounded data-only extraction, literal-original comparison and replay controls.

A [separate public GNI correctness inspection](https://github.com/LTplus-AG/ifc-lite/blob/b0a8c2f00091dea356e2a06472b1bb82ef8f2c55/scripts/perf/evidence/public-gni-fullpool-6537/README.md) completed this unchanged source through the default pool under its separately declared correctness resource budget. It is not a paired performance comparison or admission under the timing memory ceiling. Integration and review disposition remain separate.

### Standing constraints
- Geometry is **client-side only** (no server meshing).
- One mesh home: `produce_element_meshes` - a fix in one pipeline diverges the other.
- Parity gates: `mesh_determinism` manifests (x86_64 + arm64 + wasm32),
  `styling_parity`, `exact_predicate_determinism`. A real output change re-pins them.

### Manual browser readiness boundary (#3978)

The manual server matches deployed COOP/COEP (`same-origin` / `credentialless`)
and records `crossOriginIsolated` plus SharedArrayBuffer availability, refusing
samples without them. `--port` selects both server and shared benchmark-page
origin; the default remains 3000 for CI compatibility.

`metadataRenderReadyMs` is the first successful observation from a 100ms polling
loop after file selection: metadata, geometry, renderer-completion logs and a
canvas check. WebGPU falls back to nonzero canvas dimensions, so this is not a
pixel-readback or exact paint timestamp. Screenshots are separate post-boundary
artifacts. Polling and automation latency are included; differences on that
scale cannot establish small-model causal gains. The manual path skips the
legacy fixed one-second pre-observation sleep; CI keeps its original default.

Manual runs default to five interleaved pairs. Fewer pairs remain available for
functional smoke checks, but the reporter withholds noise estimates and performance
verdicts. Any failed sample makes the report exit nonzero, including when other
rounds completed. Renderer readiness requires the successful streaming-finalization
log; the app summary and an allocated canvas do not establish GPU readiness.

For local real-GPU Chrome qualification, pass `--headed --browser-executable
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"` to either manual
entrypoint. The record includes the selected executable, browser version, headed
mode and GPU arguments. The default remains bundled Chromium headless, which may
not provide WebGPU on a particular host; renderer failure invalidates that sample.
Never compare different launch modes or browser artifacts as a code A/B.

Headless bundled Chromium has no GPU adapter, so a renderer-readiness smoke needs headed
installed Chrome with cross-origin isolation and SharedArrayBuffer; the first three #3978
attempts are retained as invalid for exactly that reason (PR #4035). Capture and
fixture/runtime hashes: `git show 4fbbe8dd5:scripts/perf/evidence/harness-readiness-3978-2026-09-06/capture.json`.

### Retained column-native metadata preparation (#3985)

Keep pre-scanned numeric entity columns through categorization and reuse equivalent borrowed columns during cache index serialization. The shared validated row walk retains stable duplicates, deferred atoms and complete reference access; generic iterable indexes remain supported. This removes transient reference-object reconstruction without adding another loader or dropping metadata. Retained cumulative qualification does not establish an isolated per-layer percentage.

### Retained cold-load work: search index ownership (#3993)

The viewer shell owns search indexing for the lifetime of each loaded model.
Search interfaces consume the same records, so opening or closing search does
not create another owner or abandon its index. Cleanup releases in-flight
claims, and stale promises cannot replace a newer build. Lifecycle tests cover
StrictMode, unmount and partial/final metadata publications. This removes
redundant work and preserves search availability; no separate cold-load speedup
is attributed to this layer. Final frozen-artifact functional runs exercise actual search, model-ID resolution,
properties and GPU picking with one and multiple models, including cache-hit
reopening. Coverage limits ride the retained cold-load stack bullet under Shipped wins.

### Retained parser publication and receiver ownership (#3985)

Pack immutable type-index publication once and reuse partial columns on complete, retaining legacy transport and shared source access. Terminate the completed parser worker before receiver hydration and use the compact maximum ID during ingestion. Retained as cumulative cold-load work, with no isolated percentage attributed. Qualification must include full property/reference access, federation and memory through cache completion; worker completion alone is not readiness.

### Retained cold-load work: exact LOD keys (#3991)

Bounded LOD cell neighborhoods use exact integer keys containing all three cell
coordinates and the full entity ID. Inputs outside the proved range keep the
existing string representation. The independent tuple oracle checks identical
representatives and triangle order, including range boundaries, subviews,
nonfinite coordinates and full-width entity IDs. This removes per-vertex key
allocation; no isolated end-to-end speedup is attributed to this layer. The
retained cold-load stack must carry its cumulative browser qualification,
including picking and peak-memory observations, before landing.

### Retained cold-load work: bounded cache compression (#4003)

Geometry cache compression can run in one lazy module worker, using the same
codec and bounded chunk window as the workerless writer. The viewer opts in;
SDK callers retain the workerless default. Only fresh serialized chunks transfer,
and worker failures reject the cache write with deterministic disposal. This
moves compression off the interaction thread without removing its CPU or memory
cost. Cumulative qualification must include cache completion, full-lifetime
memory and actual cache reopening; raw IFC timing must not be replaced by a
prepared reload. No isolated throughput gain is attributed to this layer.

Explicit corpus entries are mandatory: missing files, duplicate fixture labels
and colliding filename keys fail before launching a browser. Default outputs use
a fresh per-run directory; existing JSONL/report/screenshot evidence is refused
rather than overwritten. Ref comparisons require a source WASM build and verify
the bundled viewer engine has the same hash after Turbo. They do not fetch a
published engine as a substitute. Without wasm-pack, supply independently frozen
distributions directly to the TypeScript entrypoint and retain their provenance.
`--skip-branch-build` labels its input as supplied distribution, not a verified
current-commit build. The wrapper retains the temporary base through child exit
and then removes it while preserving the child failure status.


### Appearance preview ownership and batch restoration (#4243)

A production-viewer API experiment on normally loaded FZK geometry found that
isolating shared batches for reversible appearance previews left persistent
partitions after cancellation. Exact geometry/bounds and GPU rectangle-picking
results survived, but repeated broad edits would retain extra draw batches.
Cohort-scoped restoration now stages a replacement only for descendants of the
same original batch once all related drafts close. Committed textured owners
remain separate; later Undo can rejoin their flat parts. The actual viewer
returned to the original batch count and primary geometry GPU residency.

This experiment measures synchronous Scene/Renderer preview phases, not IFC
planning, image decoding, end-to-end Apply latency, or GPU completion. The fixture
bounds the result to its eligible non-instanced owners; it does not qualify a
large-model whole-scope workflow. Resource snapshots exclude pick/highlight
caches and do not capture transient staging peaks. Restoration respects original
allocation limits and keeps valid split batches with a reported warning if
replacement allocation fails. The lesson is to check the post-cancel draw
structure as well as geometry and picking: a correct image alone hid persistent
batch fragmentation.

### Appearance Apply composition and unchanged dependency rows (#4243)

A real Convento whole-model Apply profile located synchronous dependency row
serialization and nested atomic snapshots in the click handler. Keep unchanged
non-binding source rows as bounded byte scans and compose appearance edits
inside the command's existing detached transaction; standalone helpers remain
atomic. Three interleaved fresh-browser A/B pairs show a combined reduction in
Apply delay, with identical geometry/UV bytes for all authored parts and intact
Undo/Redo and non-target-model isolation. The remaining frame stall still fails
the intended interaction smoothness bar. This is a development-viewer action
measurement, not cold-load throughput, GPU completion, or an isolated attribution
to either change. Raw samples and artifact hashes are retained in
`docs/architecture/evidence/appearance/appearance-apply-paired-summary.json` and
`appearance-apply-paired-manifest.json`. Preserve transaction ownership and
rollback checks while addressing the remaining work; do not remove them to
make an incomplete commit appear faster.

### Opt-in appearance planning (#4243)

Appearance planning invokes canonical mesh production for the source and planned
styles so preview topology agrees with reopening the exported IFC. It adds no
call to the ordinary load pipeline. Interleaved base/branch native house probes
found unchanged ordered mesh fingerprints and no observed ordinary-load timing
regression. This is a regression verdict, not a browser speedup claim. Keep
projection work in a cancellable worker and bound aggregate output as well as
input: a shared coordinate list can otherwise multiply into many UV arrays.

The planner must also resolve load-time RTC and material-layer context once per
request. Comparing two equally misconfigured routers can falsely certify empty
georeferenced triangles or an unsliced layer-bearing product; topology equality
alone is not proof of agreement with reopening. This context work stays on the
opt-in planner path and does not change ordinary load callers.

Embedded-header preflight reads PNG dimensions directly and walks bounded JPEG
markers through the STEP hex bytes. It neither copies the complete compressed
image nor allocates pixels before the plan budget is checked; ordinary raster
decoding remains unchanged.

### Effective appearance scope catalog (#4243)

The optional Rust catalog shares the planner's bounded effective-source decoder
and returns canonical product classes and type identities; it does not add a
call to ordinary model loading. Exact source-built base and branch WASM
distributions were compared through the actual browser worker pool in fresh,
interleaved processes. Every geometry fingerprint matched and no material
ordinary-load regression was observed within sample variation. This is a
regression check, not a speedup claim or a measurement of catalog latency.
Retain the bounded decode and shared cancellation lifecycle instead of
reimplementing IFC type relationships in the UI. Reproduction provenance and
samples are in `appearance-catalog-load-evidence.json`; the observation ends at
worker-model readiness, not renderer readiness.

### Prepared-overlay comparison ownership (#4243)

Compare a private borrowed overlay descriptor synchronously against the detached
checkpoint. Cloning the live overlay solely to compare it adds allocation while
providing no additional isolation; original/draft/prepared/publication snapshots
remain deep copies. Cyclic escaped values, skip-history edits and rollback
rejection remain covered. A fresh real Convento Apply profile with this change
and the earlier command/dependency changes still locates substantial synchronous
work in dependency scanning and authored-data/history construction plus retained
snapshots. This single sampled run does not establish an isolated improvement
for comparison-only clone removal. Keep ownership guards while investigating
preparation outside the Apply interaction. The profile, timing, summary and
exact source/runtime hashes are in
`docs/architecture/evidence/appearance/appearance-apply-after-comparison-*`.

### Appearance dependency validation: immutable source byte scan (#4243)

The Apply CPU profile identified effective dependency capture and repeated overlay
copies as the dominant main-thread work. Unchanged source rows already use
immutable markers in history checkpoints; decoding, rewriting and re-encoding
large coordinate rows only to extract references therefore adds no validation
information. Read those non-binding rows with the canonical source-byte scanner.
Keep edited, authored, retyped and inverse-binding rows on the effective STEP
writer path, with unchanged byte/reference budgets and compressed-source support.

Three interleaved fresh-browser Convento pairs showed a consistent end-to-end
Apply improvement when combined with removing nested appearance transactions.
This is a combined result, not an isolated speedup for the scanner. Geometry,
UVs, owner identity, Undo/Redo and the untouched federated model were checked;
the remaining main-thread stall still fails the intended smoothness requirement.
Do not treat fewer copies or a faster helper microbenchmark as acceptance: retain
the paired interaction measurement and continue profiling transaction preparation.

### Finite page appearance composition (#4260)

The opt-in page planner bakes topology-preserving PNG charts and retains source
texture density outside the page. It adds a PNG encoder to WASM; ordinary loading
does not invoke the new operation. Source-verified baseline and final runtimes
were compared in fresh interleaved browser workers under identical JS/assets.
All geometry, color, UV and provenance fingerprints matched. A small ordinary
worker-readiness increase was observed with overlapping samples; this is neither
a speedup nor a zero-cost claim. Retain the explicit atlas budgets and source
fidelity floor rather than silently downsampling photos to page resolution.
Exact runtime provenance, samples and deltas are in `pdf-page-load-evidence.json`;
page compositing latency and renderer readiness were not measured by this check.

### Cooperative appearance command preparation (#4336)

The appearance command now consumes owned cooperative entity operations and keeps
its final source, dependency, resource and history checks synchronous. A fresh
real Convento browser interaction confirms that preparation yields, but the
final synchronous phase still produces a visible long task and rendering gaps
remain during preparation. This is an observational integration sample, not an
isolated speedup or smoothness-complete verdict. Do not infer responsiveness from
an async return type or successful cancellation tests. Retain the exact fences
while addressing remaining synchronous dependency work separately. Raw timing,
source/runtime identity and functional Undo/Redo evidence are recorded under
`docs/architecture/evidence/appearance/appearance-cooperative-apply-*`.

### Calibrated image annotation creation (#4308)

The opt-in native annotation planner reuses canonical placement, schema validation and per-element geometry production. A source-matched ordinary worker-load A/B observed a small increase with overlapping samples and identical geometry/provenance; no speedup or zero-cost claim is made. Final JavaScript/assets were identical while the verified IFC WASM was swapped, so this checks runtime size/initialization effects without invoking annotation creation. See [the exact runtime hashes and paired samples](annotation-plane-load-evidence.json). Annotation creation and the downstream Save Into Model UI are outside this load measurement.

### Captured mesh authoring (#4380)

The opt-in captured-surface planner shares annotation authoring's canonical
product path; it does not modify ordinary geometry loading. Interleaved native
ordinary-load probes retained all mesh/vertex/triangle counts, but quantized and
noisy samples were inconclusive. Exclusive machine idleness was not established,
so these are smoke evidence only, not a speedup, regression or browser worker-pool
latency claim. The lesson is to compare triangle-corner geometry and UVs across
capture authoring and normal import: valid canonical welding may change vertex
layout while preserving the surface and seams. [Raw source-matched samples and
limitations](../../docs/architecture/evidence/captured-mesh/native-load.json)
record the experiment; capture-creation and integrated UI timing remain separate.

### Appearance preparation input scheduling (#4336)

Fresh background tasks allow trusted viewport and Discard input to run during broad
Apply preparation. In the paired real Convento viewer workflow, scheduler.yield
continuations painted frames but delayed trusted input until completion. This is
a different mechanism from timer-clamping or microbenchmark speedups: it trades
slightly longer elapsed preparation for earlier user interaction. The exact final
transaction fence is unchanged and still blocks. Identical runtime and canonical
owner/mesh output were verified across paired runs; cancellation published no IFC
or history changes. Raw evidence, memory caveats and methodology live in
`docs/architecture/evidence/appearance/apply-responsiveness/README.md`.

### Opt-in evaluated occurrence appearance (#4404)

Occurrence-local normalization runs only during an explicit appearance plan;
ordinary loading keeps its existing pipeline. Interleaved AC20 base/branch native
load probes found no resolvable regression at the probe's integer-millisecond
phase precision, with identical ordered mesh fingerprints and geometry counts.
This is native load evidence, not a worker-pool speedup or conversion-latency
claim. Preserve the opt-in boundary and measure broad authoring separately when
its host UI lands. [Raw samples and measurement limits](../../docs/architecture/evidence/evaluated-occurrences/native-load.json)
record the comparison.

The F6 composite-allocation follow-up keeps compaction inside authoring only.
Repeated base/branch AC20 load probes retained identical phase timings at the
probe's measurement precision and identical ordered mesh fingerprints. This
supports no resolvable native-load regression, not an authoring or worker-pool
speedup. Preserve literal-versus-reference schema slots when compacting plans;
never trade semantic fidelity for convenient generic string rewriting.
[Follow-up samples and limits](../../docs/architecture/evidence/evaluated-occurrences/allocation-load.json).

### Evaluated face masks and tessellatable-body policy (#4404)

Face masks and the widened evaluated policy live only inside an explicit
appearance plan; normal loading does not touch them. The interleaved,
order-balanced native AC20 base/branch probe (nine rounds per side, prebuilt
profiling binaries, `scripts/perf/ab-order.mjs` seed 4404) found phase
medians equal or within two milliseconds, every phase inside the reporter's
noise band, and the reporter refused a verdict because the base's own spread
exceeded its 15% threshold on a machine shared with other builds. This is
"no resolvable change", not a speedup or a regression claim, and no browser
worker-pool measurement was made. A separate `--fingerprint` run of both
binaries reports identical mesh, vertex and triangle counts and identical
ordered geometry fingerprints. Tool lesson: at the time of this probe
`scripts/perf/ab-order.mjs`'s CLI guard compared `import.meta.url` with a bare
`file://` prefix and printed nothing on Windows, so `ab.sh` there produced
zero rounds and a vacuous "within noise" verdict; the probe drove `roundOrder`
directly and checked the run count. #4541 fixed the guard with
`pathToFileURL`; always check the round count `ab.sh` reports.
[Raw rounds](../../docs/architecture/evidence/evaluated-face-masks/native-load.json) and [fingerprints](../../docs/architecture/evidence/evaluated-face-masks/native-fingerprints.json).

The #4550 native/wasm fingerprint-parity follow-up makes the existing
per-element local frame explicit only inside opt-in appearance planning. Fresh
interleaved base/branch and branch/base AC20 normal-load controls resolved no
change at the probe's phase precision, and every run retained identical mesh,
vertex and triangle counts plus ordered geometry fingerprint. The useful lesson
is to select frame policy per router before its caches are populated: a
process-global override would make concurrent native planning unsafe, while
changing the native load default would needlessly disturb deterministic output.
An interleaved release A/B over the real AC20 mapped-member
`plan_appearance` path also retained the same source-index checksum and
fingerprint with no slowdown. The final implementation evaluates the canonical
surface once and shares that mesh between replacement and fingerprinting; a
second identity-only evaluation was measured and removed before review.

### Shared appearance atlas sampling (#4381)

Factoring target appearance preservation, charts and canonical image binding into
an internal sampler retains the finite-page operation and avoids a second atlas
pipeline for scan observations. Interleaved native AC20 base/extraction/transfer
probes found no resolvable ordinary-load regression, with identical geometry
counts and ordered fingerprints. This is a load-path isolation verdict, not a
browser worker-pool speedup or authoring-capacity claim. Keep expensive source
matching opt-in and separately bounded; broad transfer needs its own measured
candidate-reuse work. [Raw probes and limits](../../docs/architecture/evidence/shared-atlas/native-load.json)
record the comparison.


The registered mesh-transfer foundation preserves that ordinary-load isolation,
but its aggregate per-texel BVH work cap refuses the complete captured boulder.
A bounded prefix qualifies the surface/UV and unknown-coverage behavior; it does
not establish broad authoring capacity. The next mechanism to evaluate is
conservative candidate reuse across target triangles/tiles, retaining nearest
surface refusal and one atomic result, rather than enlarging the work ceiling.
[Real-surface coverage and refusal evidence](../../docs/architecture/evidence/mesh-transfer/README.md#real-boulder-geometry-conservative-coverage-and-capacity)
keeps that limitation separate from the ordinary-load measurements.

The emitted-texel applicability follow-up separates geometric centroid evidence
from pixels actually sampled into a transfer atlas. Ordinary-load paired probes
show mixed subphase differences at the probe's millisecond precision, with the
same ordered mesh payload fingerprint; no consistently directed change or
worker-pool speedup is claimed. The correctness result is refusing an all-old
atlas despite positive centroid coverage while retaining byte-identical dense
transfer output. [Samples, fingerprints and PNG evidence](../../docs/architecture/evidence/mesh-transfer-texel-gate/README.md)
record that distinction.

Canonical occurrence source snapshots reuse the mesh already evaluated by the
opt-in appearance planner. Moving its bounded vectors into the plan avoids
reconstructing IFC geometry from GPU instance transforms. Interleaved exact-base
native AC20 probes found no resolvable ordinary-load change and identical geometry
counts. This establishes load-path isolation, not a browser worker-pool speedup
or conversion throughput claim; the additional authored payload remains governed
by the existing aggregate geometry budget.
[Source-mesh payload probe](../../docs/architecture/evidence/evaluated-occurrences/source-mesh-load.json)
records source heads, precision limits and the unchanged census.

Candidate reuse for registered transfer was tested through whole-triangle leaf
caches, exact observation memoization, lazy spatial cells, and conservative
centroid-witness seed bounds. These preserve bounded controls but still exceed
the complete captured-boulder work quota; none was merged. A calculation-only
fresh-worker diagnostic separates actual traversal latency/memory from the work
proxy, without authorizing a larger quota or producing an applicable plan.
Do not repeat those cache mechanisms unchanged or infer broad capacity from a
small target prefix. [Recorded experiments and worker evidence](../../docs/architecture/evidence/mesh-transfer-capacity/README.md)
state the remaining gate and the limits of the measurement.


The follow-up nearest-first BVH experiment shrank an exact per-sample search
bound, retained the near-tie band in one traversal, and combined it with bounded
exact observation memoization. It still refused the full selected boulder under
the existing work cap, so the runtime experiment remains unmerged. A tighter
candidate search alone did not establish complete-target capacity; do not
reintroduce this variant as a shipped optimization without new end-to-end
acceptance. [Reproducible refusal](../../docs/architecture/evidence/mesh-transfer-capacity/README.md#nearest-first-traversal-follow-up).

### Product-scoped polygonal annotation fills (#4406)

Direct annotation fills reuse canonical placement/triangulation and a lazy
source-owned inverse style index shared across recreated native/batch decoders.
The ordinary AC20 source-matched A/B/A/B probe found identical paired reported
best-of-five phase timings and identical mesh fingerprints/counts; this is a normal-load regression
check, not annotation throughput or worker-pool speedup evidence. Keep style
lookup failures cached and diagnostic, and keep auxiliary type maps excluded.
[Exact inputs and paired runs](../../docs/architecture/evidence/annotation-fills/native-load.json).

### PDF vector graphics-state preparation (#4406)

The opt-in decoded-state preparation API adds no ordinary IFC geometry processing
step. An idle source-matched native A/B/A/B probe showed small millisecond timing
variation with identical ordered mesh fingerprints and counts. It does not
establish zero overhead, a worker-pool speedup or vector-page preparation
throughput. Keep page operator/path/stack limits distinct from PDF.js decoder
allocation limits; post-decode counting cannot bound the decoder's earlier work.
See [exact source IDs, five-iteration samples and identity evidence](../../docs/architecture/evidence/pdf-vector-state/native-load.json).

## Reference opening semantics (#4433)

An element-aware representation predicate excludes non-subtractive Reference
shapes only for opening elements. Controlled native base/branch probes on AC20
and ISSUE_129 resolved no material normal-load regression; mesh, vertex and
triangle counts stayed identical. This is a correctness change, not a speedup.
The lesson is to preserve the existing type-based rendering predicate for
ordinary products while applying opening-specific semantics consistently to
mesh production and fast void probes. Numeric evidence and source revisions are
in `docs/architecture/evidence/evaluated-openings/performance.json`.

### Reference-only opening host routing (#4440)

A retained Reference-only opening must keep its host on the textured submesh
path. The new predicate inspects representation membership without producing
cutter meshes; unknown or over-budget data retains the existing cutter path.
Two interleaved base/branch native probe pairs on AC20 and ISSUE_129 resolved no
consistent material normal-load regression, with unchanged mesh/vertex/triangle
counts and existing CSG diagnostics. This is a correctness fix, not a browser
worker-pool speedup claim; small overhead below run-to-run variation remains
unresolved. [Exact revisions, probe results and limits](../../docs/architecture/evidence/evaluated-openings/reference-textures.json)
are recorded with the fixture evidence. Do not infer that a nonempty void-index
entry implies actual subtraction: the opening representation identifier matters.

## Shared authored source context (#4406)

Extracting common creator setup resolved no normal-load timing difference in
interleaved exact-source native probes, with identical ordered mesh fingerprints
and counts. Independently rebuilt WASM modules also returned byte-identical
complete plans for the checked annotation/captured controls. This is a reuse
prerequisite, not an optimization or an authoring-throughput claim. Reuse the
canonical source, placement and row author when adding non-image geometry; do
not introduce a dummy texture to access shared setup. See the [raw native
measurements](../../docs/architecture/evidence/authored-context/native-load.json)
and adjacent plan identity evidence.

### Complete selected-target mesh transfer (#4381)

Nearest-first traversal plus same-chart raster padding avoids source queries
for unobserved padding while retaining exact nearest/ambiguity checks and all
interior unknown appearance. Combined with an explicit aggregate work allowance
increase, the full selected boulder now returns identical applicable plans in
fresh workers and passes the normal viewer transaction/export/reopen journey.
The original quota experiments remain negative; neither this result nor the
quota increase alone retroactively turns them into wins. Scan-owned memory is
still bounded, including padding scratch, and overlapping/dense cases refuse
before publication. Ordinary-load paired probes had a slower first candidate
pair and matching second pair with identical ordered geometry; no consistent
regression or zero-overhead claim follows. This is measured capacity acceptance, not a throughput
speedup. [Worker, independent-reader and refusal evidence](../../docs/architecture/evidence/mesh-transfer-full-target/README.md).

### Behind-surface refusal for thin-wall transfer (#4381)

Registered mesh transfer now refuses a same-facing nearest scan surface that
lies deeper than an explicit `maxBehindMetres` behind the IFC face. The
controlled 4 mm partition showed the gap the symmetric distance bound left
open: with a 20 mm bound, a surface 10 mm beyond the wall painted the near face
although both faces were classified correctly against each other. The check is
one closest-point dot product after the existing nearest/ambiguity/normal
refusals, so it adds no BVH work; a coplanar capture is tolerated within f64
rounding under a zero bound because the centroid-only control runs exactly
there. Interleaved native AC20 A/B/A/B probes on a shared host found equal
best totals within run spread and identical ordered geometry fingerprints and
counts; the sampler is not on the load path, so this is only a no-regression
control, not a transfer-throughput claim. The lesson is that nearest-first
matching needs a signed depth bound, not a larger symmetric one: relaxing the
distance bound to reach the opposite face reintroduces every far-side bleed.
See the [controls and raw probe samples](../../docs/architecture/evidence/mesh-transfer-surfaces/README.md).

### RGB point-cloud transfer source (#4381)

The registered transfer source became a tagged union and gained an RGB
point-cloud path: a bounded uniform grid (16 bytes/point) instead of a BVH leaf
per point, a least-squares plane per sample, and a target self-occlusion rule
that costs two budgeted BVH ray queries per sample (exact segment for the
nearest point, one thickness probe for the rest of the support) after a first
version that spent one ray per supporting point exhausted the 128 M budget on a
real 25 m² wall. Review then added the nearest-face rule for unoriented
captures inside the solid: a sample whose nearest capture lies deeper inside
than one surface band pays one wider query out to the distance bound to look
for a capture in front, and the support is regathered around the nearest point
whenever it lies farther than half the radius. On the CRAS corridor drywall the
accepted plan used 43.5 M of 128 M units in 376 ms (Node, 465 k points,
64 texels/m); the windowed north wall with both faces scanned was refused at
64 texels/m and accepted at 32 (59.5 M units, 331 ms; 49.0 M before the rule),
so the planner now reports `budget.workUsed` next to coverage. Interleaved
native AC20 A/B/A/B probes on a shared host at the final head: best totals
16/15 ms (base 1996e9281) vs 14/15 ms (branch), identical mesh/vertex/triangle
counts (285 / 35,940 / 19,456) and identical ordered geometry fingerprint
`25ac885b6ff4ad00` in all four runs — no load-path regression, and, as before,
only a control: the sampler is not on the load path. Lesson: for point sources
the per-sample cost is set by point density times the support area, not by the
point count, so the grid cell must follow the support radius and any per-point
occlusion test must be replaced by a per-sample one. See the
[real-pair evidence](../../docs/architecture/evidence/scan-registration-cras/README.md).

## Qualified PDF fill composition (#4406)

The new explicit creation API leaves ordinary model loading on the existing
path. Interleaved exact-source native probes showed a slower first candidate
pair and matching second-pair timings, with identical ordered mesh fingerprints
and counts. This resolves no consistent normal-load regression and does not
establish zero overhead or browser-worker throughput. The composition budget
precharges pairwise overlay work and separately limits generated contours and
transport; do not tune those caps using unrelated normal-load timings. See
[raw samples and source identity](../../docs/architecture/evidence/pdf-fill-annotations/native-load.json).

## Qualified curved PDF fill boundaries (#4406)

Native normal-load A/B/A/B resolved no consistent regression, with identical
ordered mesh fingerprints and counts. This does not measure curved-page worker
throughput. Subdivision and original-piece hull qualification share the existing
creation budget; finely tessellated holes can still refuse its overlay work cap.
Do not silently coarsen to fit it. A global exact convex-control-polygon check
rejected a real sheared control on tiny near-collinear turns; exact per-piece
hull separation admitted that control without snapping or ignoring features.
Keep finite-chord error bounds: infinite-line flatness incorrectly collapses
backtracking curves. See [source-matched samples](../../docs/architecture/evidence/pdf-curved-fill-annotations/native-load.json)
and the adjacent independently decoded PDF evidence.

### Evaluated post-opening appearance and companion history (#4404)

The authoring evaluator now consumes canonical post-opening source geometry and
carries bounded opening companion meshes for one preview/history transaction.
Controlled native normal-load A/B probes retained equal geometry counts. The
small AC20 fixture showed a slight absolute increase at coarse phase resolution;
the opening-heavy control stayed close across both interleaved pairs. No speedup
or browser worker-pool timing claim is made. See the
[measured source revisions and results](../../docs/architecture/evidence/evaluated-openings/authoring-performance.json).
This changes the authoring path, not the normal-load mesh evaluator; future
optimization should measure the explicit conversion workload independently.

## Version-bound closed PDF dashes (#4583, #4406)

Closed-dash interpretation is confined to opt-in PDF preparation and annotation
planning. Independently compiled base/branch then branch/base native-load
controls on AC20-FZK-Haus retained identical ordered mesh fingerprint
`25ac885b6ff4ad00` and counts (285 meshes, 35,940 vertices, 19,456 triangles)
in all 20 iterations. Paired wall-time medians were 14.28/16.03 ms and
14.45/14.65 ms; the second pair nearly converges and the absolute differences
are below the probe's useful phase resolution, so no material ordinary-load
regression is observed. This is not a PDF-planning or browser-worker throughput
measurement. The useful lesson is semantic: the effective PDF version must be
bound before geometry because the compatibility policy caps a PDF 1.x
closed-dash seam while PDF 2.0 explicitly requires a join, and a mature
independent reader may still render the capped form for both. See the
[paired raw runs and reader evidence](../../docs/architecture/evidence/pdf-closed-dash-annotations/README.md).

## Qualified solid straight PDF strokes (#4406)

Fresh exact-source native A/B, A/B, then reverse B/A normal-load controls for
the round-cap/join expansion resolve no regression. The warmed pairs reported
base/branch totals of 9/8 ms, 9/9 ms, then branch/base totals of 8/9 ms, while
mesh, vertex and triangle counts and every ordered mesh fingerprint remained
identical. This isolates the normal IFC load path; it does
not measure opt-in PDF authoring or worker-pool throughput. Stable sagitta
inversion also reduced the independent round controls' bounded planner work and
triangle counts without changing analytic acceptance; the source-specific
oracle carries those measurements. A draft union
of segment rectangles and join wedges was rejected by existing conservative
contact/intersection guards even on ordinary joins; direct offset contours
retain the same guards and avoid manufacturing those internal boundaries.
Collapsed/reversing offsets and unresolved joins refuse rather than repairing
an unqualified stroke arrangement. See the [source-specific raw controls](../../docs/architecture/evidence/pdf-straight-stroke-annotations/native-load.json)
and original PDF/independent IFC evidence alongside them.

## Symbolic fill routing for native annotation meshes (#4459)

Source-specific native A/B/A/B controls retain identical ordered geometry
fingerprints and counts. The candidate's first launch is slightly slower at
coarse phase resolution; the second pair matches. This is normal-load
isolation, not a symbolic-extraction or browser worker-pool performance claim.
The lesson is to carry qualified item provenance once, then filter the 3D
overlay output; deleting the shared drawing primitives would hide the duplicate
at the cost of 2D content. See the [raw runs and immutable binary identities](../../docs/architecture/evidence/annotation-fill-routing/native-load.json).

## One integer lattice for registered PDF composition (#4458)

Exact-source interleaved normal-load probes resolve no regression; both paired
phase minima and all ordered mesh fingerprints/counts are identical. This does
not measure PDF authoring or worker throughput. The useful mechanism is retaining
integer groups through classification, clipping and paint ordering: repeatedly
creating floating adapters had shifted a shared CropBox edge enough to trigger
a false topology refusal. Source qualification now happens once, and every stage
still checks finite-edge topology. A separate finite-segment separation
certificate avoids treating an unrelated infinite-line side change as an edge
intersection. No tolerance/endpoint guard was replaced by epsilon snapping.
[Source-matched raw samples and original PDF evidence](../../docs/architecture/evidence/pdf-composition-lattice/README.md)
record the control and prevent repeating the float-roundtrip approach.

## Regime-1 coincidence requires near-parallel planes (#4439)

The exact boolean classifier's "sub-triangle lies ON a coincident shared face"
regime now also requires the sub-triangle's own plane to be within 45° of the
candidate face (`coincident_planes`, a sqrt-free `2·d² ≥ |n₁|²|n₂|²` test on
products the classifier already forms). Interleaved native A/B/A/B on AC20 and
ISSUE_129 resolved no phase delta beyond the base's own noise floor; AC20's
ordered mesh fingerprint is identical on every run. ISSUE_129's output changes
on purpose: host #9094 is one of the 17 census hosts the gate reclassifies
(triangle delta of the whole run equals that row's census delta), so its timing
is not a like-for-like comparison and is not claimed either way. This is a
correctness fix, not a speedup. The lesson: a centroid-in-band test locates a
face, it does not establish coincidence — a needle hugging the intersection
line of two transversal faces sits in both planes' bands with no orientation to
agree with, and a `dot > 0` verdict there is a coin flip that can override an
exact ray-cast. Add the angle premise per candidate face rather than gating on
a parent flag (the parent-flag gate was measured to cost 20+ census hosts).
[Raw interleaved runs and fingerprints](../../docs/architecture/evidence/csg-coincident-planes/native-load.json).
Found while measuring: on Windows `ab.sh` ran ZERO rounds and still printed a
"within noise, counts matched" verdict, because `ab-order.mjs`'s CLI guard
compared `import.meta.url` with a backslash `argv[1]` and never fired. Fixed in
the same PR (`pathToFileURL`, a CLI test, and `ab.sh` now refuses an order file
with fewer lines than `--iters`); the recorded runs replicate the procedure by
hand with the same `roundOrder()` and reporter.

## PDF fidelity report and partial acceptance (#4406)

Bounded graphics-state preparation now interprets forms, groups, annotation
appearances, clips, ExtGState dictionaries, optional content, text, images and
stroke features into a page-level fidelity report, and fill planning records
the accepted verdict in a provenance property set. None of this is on the
parse or element-geometry path. An interleaved base/branch/base/branch native
AC20-FZK-Haus probe (5 iterations each) retained identical ordered mesh
fingerprints and mesh/vertex/triangle counts in all 20 iterations; total-phase
medians were 13 and 20 ms on base against 24 and 19 ms on the branch, so the
base-to-base spread exceeds any base/branch difference and no regression is
observed. The host was shared with other builds during the first branch pair,
which the raw record states. The verdict is no material regression on that
fixture, not a PDF-preparation throughput claim: the report interpreter is
bounded by the existing operation, path-number and save-depth budgets plus a
4,096-entry listed-omission cap with complete summary counts. See the
[raw runs](../../docs/architecture/evidence/pdf-fidelity-report/native-load.json).

## Mixed planar and residual opening compatibility (#4610)

Interleaved native end-to-end probes show byte-identical AC20 output and no
material phase change. ISSUE_129 intentionally restores the exact mesh,
vertex, and triangle counts from immediately before #4579; its comparison with
the regressed parent is not like-for-like because the parent dropped geometry.
A separate interleaved comparison against that pre-regression commit produced
identical output and timings within run-to-run noise. The discarded topology
fallback was materially slower because it built both the torn hybrid candidate
and the full-context candidate. The useful lesson is to quarantine a known
composition incompatibility before doing either expensive route, while keeping
the public and pure-2D union operation correct; #4617 owns removing that
temporary boundary once mixed routing can preserve both union semantics and
final topology.

## Comment-free STEP point-list scan (#4735)

The record scanner now proves once that a point-list tail contains no STEP
comments before entering its per-item delimiter loop; commented records retain
the original comment-aware path. Source-matched interleaved native probes and
fresh Chromium worker-pool loads of AC20-FZK-Haus retained identical ordered
geometry fingerprints or mesh counts. Their base/branch phase differences all
stayed within run-to-run noise, so the verdict is no material full-load
regression and no demonstrated end-to-end speedup. The useful lesson is that a
tighter inner loop is not itself a user-visible performance claim: retain the
single outer proof, but judge it through the full parser and browser worker
pool, where geometry and startup dominate this small fixture.

## Exact emitted RTC frames for auxiliary geometry (#4799)

The additive frame-aware grid, alignment and symbolic parsers reuse the exact
RTC decision emitted by the mesh pre-pass; standalone callers retain whole-file
detection. Five balanced native AC20-FZK-Haus base/branch rounds against
`3b10435ab117b1fcaf3ad7c47f7d9fdf74e0f2a4` kept the ordered mesh fingerprint
`25ac885b6ff4ad00` and the 285 meshes / 35,940 vertices / 19,456 triangles
identical. Parse and total medians were 7 ms and 17 ms on both sides; geometry
was 9 -> 10 ms inside the base's 11% spread. This is ordinary-load isolation,
not an overlay speedup claim.

Five fresh Chromium pairs on the complete contract plus viewer integration all
used the default eight-worker pool and produced 317 meshes / 44,249 entities.
Base -> branch medians were 538 -> 570 ms first-visible, 511 -> 533 ms stream,
658 -> 712 ms metadata and 782 -> 794 ms observed metadata-plus-render. No
metric exceeded its measured noise, but the base readiness spread was 24.94%,
above the reporter's 20% limit, so the browser cohort is explicitly **too
noisy** and supports neither a regression qualification nor a speedup claim.
The browser harness records mesh/entity counts rather than vertex-payload
identity; the native ordered fingerprint supplies that separate identity
control. Explicit-frame-versus-standalone parser microbenchmarks are only
supplementary mode timings, not full-load evidence.

## Precision-derived RTC gate (#4934)

Lowered `LARGE_COORD_THRESHOLD_METERS` from 10 km to 1 km. Base
(521e8d8e9) vs branch, native `perf_probe` on AC20-FZK-Haus (best-of-5,
interleaved): total 15 ms both sides, parse 7 ms / geometry 7 ms both
sides. Mesh output byte-identical: 285 meshes / 35,940 vertices /
19,456 triangles on both, and this fixture's coordinates sit well under
1 km so the gate's `Small` verdict — and therefore the mesh frame — is
unchanged either side; the lever this PR pulls has no reach into
AC20-sized files. The lesson: a threshold-only change with no new work
in the hot path needs no dedicated perf lever, only a byte-identity
check on a fixture the gate does not touch; the real cost of moving the
line is paid only by files that cross between the old and new bands
(1-10 km), which this fixture is not one of.

## Kernel-plane tags for consolidate's rounding-split fix (#3914)

`kernel::mesh_bridge::tris_to_mesh` now tags every output triangle with its
f64 supporting plane (`Mesh::plane_tags`) and `consolidate_coplanar` validates
each tag (a per-triangle supporting-plane check) and cross-checks adjacent
`POS_QUANT`-bucket pairs against it before merging any of them. On
AC20-FZK-Haus (no CSG cuts in this fixture) output was byte-identical
(285 meshes / 35,940 vertices / 19,456 triangles both sides) and total time
was noise-dominated at this file's scale — nothing in the hot path runs
differently when a mesh carries no tags or a bucket has no rounding-split
neighbour, which is the overwhelming majority case. On the CSG-heavy
ISSUE_129 fixture the new merge pass legitimately fires: output triangle/
vertex counts drop slightly (fewer, correctly-merged coplanar triangles
where a physical plane used to be torn across two buckets), confirmed
non-regressive by the full `triangulation_invariance` census/golden suite
passing (previously two hosts in that suite — `issue_129_mixed_bool2d_
residual_preserves_established_topology` and `issue_4627_candidate_
failures_preserve_prior_analytic_cuts` — caught two earlier, broader
variants of this fix that keyed EVERY bucket by the kernel tag instead of
only merging validated adjacent pairs). Lesson: for a per-triangle
provenance tag meant to correct a narrow rounding edge case, do not let it
become the primary bucketing key everywhere it validates — real models
carry legitimately distinct near-coplanar faces (the #3913 sweep's
deliberate `SNAP_GRID` controls) that a blanket re-key cannot tell apart
from a genuine rounding split; gate the tag's effect to the specific
adjacent-bucket-pair mechanism the defect actually is, with a tolerance
tight against the true-positive margin (~1e-10) and far below the
legitimate-distinct-plane separation (~1.5e-5).

## Deterministic B-spline degree/control-point budget, memoized Cox-de Boor (#4901)

Base `0d84727c5` vs branch, native `perf_probe` (best-of-5): AC20-FZK-Haus
14 ms both sides (285 meshes / 35,940 vertices / 19,456 triangles,
byte-identical); ISSUE_129 CSG fixture 912 -> 910 ms (within noise), 1,402
meshes / 219,860 vertices / 135,749 triangles / 41 CSG failures / 6 degenerate
dropped, identical on both sides. Neither fixture carries a B-spline surface
or curve, so this is an isolation check, not a speedup claim. The fixture that
DOES (`tests/models/issues/472_2222.ifc`, issue #472, 145 B-spline surfaces /
503 B-spline curves) is covered by `geometry_correctness_harness`'s pinned
snapshot instead of a timing probe: 53,479 triangles / 33,069 vertices,
byte-identical base vs branch.

The lever itself: `bspline_basis` (Cox-de Boor recursion,
`rust/geometry/src/processors/advanced_face/bspline.rs`) was called once per
control-point index with no caching between calls, so it re-derived the same
sub-results `O(control points)` times per sample point on top of being
`O(2^degree)` unmemoized — a file-supplied `Degree` in the tens already made a
single face non-terminating in practice, and nothing bounded it. Replaced with
one bottom-up table build per sample point per axis (`bspline_basis_table`,
`O(degree * (n + degree))`, mathematically identical, so legitimate output is
byte-for-bit unchanged — pure caching, not a formula change) plus a
deterministic (not wall-clock) degree cap (`bspline_budget.rs`) so a file that
still exceeds it fails loudly via `GeometryRouter::record_unsupported_item`
instead of hanging.

**Dead end, caught before merge, worth recording:** the first cut also capped
raw `ControlPointsList` size (a flat `n_u * n_v` ceiling calibrated by guessing
"a few hundred is already a dense patch"). `geometry_correctness_harness`'s
pinned snapshot for the #472 fixture caught it immediately — that fixture's
worst surface is a REAL 207x180 (37,260-point) patch, and the flat cap
silently dropped it, losing exactly one tessellated face's 1,152 triangles
(53,479 -> 52,327). Replaced with a bound on the actual cost driver instead:
`(u_segments+1) * (v_segments+1) * n_u * n_v` (`MAX_BSPLINE_SURFACE_SAMPLE_WORK`,
since `evaluate_bspline_surface`'s weighted sum is `O(n_u * n_v)` PER SAMPLE
POINT, not once) — the #472 fixture's worst surface measures ~23.3M against a
500M bound. The lesson, twice over: an unmemoized recursive basis-function
evaluator is an easy trap in geometry code — it reads as "just math," but its
complexity is exponential in a file-controlled parameter, so it needs the same
file-driven-loop scrutiny as an explicit `for` loop over entity references —
AND a breadth cap must bound the same quantity the hot loop actually multiplies
out to (samples x grid, not grid alone), or a real fixture proves the guess
wrong. Always run the correctness harness against a fixture that exercises the
lever before trusting a calibrated constant.

## Wall-local vertical opening classification (#3977)

Exact-source native `perf_probe` comparison of base `6304b8ebc` and branch
`89b93e364` used five balanced, interleaved fresh-process rounds per fixture.
Median parse / geometry / total milliseconds were 8 / 11 / 19 -> 8 / 10 / 19
on AC20-FZK-Haus and 26 / 929 / 955 -> 28 / 930 / 958 on CSG-heavy ISSUE_129.
The heavy Holter control was deliberately included because the classifier runs
once per opening: its medians were 407 / 741 / 1,160 -> 403 / 752 / 1,155 ms.
Holter's geometry samples were noisy on both sides (base 455-774 ms, branch
430-775 ms), so the 1.5% geometry-median difference is not a regression signal;
its total median improved 0.4%. Every round retained identical output counts:
AC20 285 meshes / 35,940 vertices / 19,456 triangles / 0 failures, ISSUE_129
1,402 / 219,848 / 135,737 / 41, and Holter 109,514 / 4,502,946 / 2,882,383 /
0. Verdict: no material full-load regression and no performance claim.

The source-matched browser worker-pool control compared the same base with
`cb7557caa` in five interleaved fresh-Chromium-process pairs per fixture. The
observed metadata-plus-render median was 479 -> 483 ms on AC20 (+0.8%, below
the base's 7% spread), 1,862 -> 1,860 ms on ISSUE_129 (-0.1%, below 5%), and
5,114 -> 5,084 ms on Holter (-0.6%, below 17%). First geometry, first visible,
stream completion, spatial readiness, metadata completion, and the legacy app
total likewise stayed inside their respective noise floors. Every round kept
the same total mesh count between revisions. This qualifies the actual browser
worker path as well as the native phase split; it does not qualify search,
cache-tail memory, properties, picking, or Firefox.

The lesson is to scope authored-depth preservation to the vertical-depth
selector itself. Applying it to the established horizontal-depth route changed
real heavy-model cuts even though small synthetic cases remained green; the
heavy census caught that overreach, and restoring the old horizontal route
removed every branch-caused census delta.

## Hole-wall winding and host-derived wall frames (#5410)

Correctness change, no performance claim. Extruded profile holes now emit side
walls wound into the void, so a voided host reaches the exact kernel as a
consistently wound solid, and a plan-rotated wall whose cutters author no depth
is cut in its own frame. Native `perf_probe` base `04dd98f96` vs branch, three
interleaved rounds of best-of-3 per fixture, median parse / geometry / total ms:
AC20-FZK-Haus 8 / 28 / 36 -> 9 / 24 / 33 (byte-identical ordered fingerprint),
ISSUE_129 30 / 1,164 / 1,194 -> 30 / 1,157 / 1,182, Holter 463 / 945 / 1,409
-> 465 / 598 / 1,146 (Holter's totals spread 977-1,711 ms on base, so its
geometry delta is noise, not a win). Mesh, vertex, triangle and CSG-failure
counts are identical on all three; ISSUE_129 and Holter fingerprints differ
only in normals of holed extrusions, which the output orienter used to flip and
recompute. The lesson: an extruder's winding is an input contract of the
kernel, not a rendering detail the output orienter may repair afterwards.
After review folded the three side-wall builders onto one shared orientation
helper, a re-run against `ea4cc3718` (eight interleaved rounds) gave AC20 and
ISSUE_129 byte-identical fingerprints to main; ISSUE_129 per-round best totals
spread 1,178-1,951 ms on main and 1,143-1,873 ms on the branch on a loaded
host, so the medians' order (1,391 vs 1,476 ms) is not a signal either way.

## Structural curved/oriented edge rendering, no reach into either fixture (#4206, #5020)

Native `perf_probe` comparison of base `0e8a42175` (merge-base with `origin/main`)
and branch `9a469537b` (this PR merged onto that base), five balanced,
interleaved fresh-process rounds per fixture, `--iters 5 --json --fingerprint`.
Neither in-tree fixture instantiates a standalone `IfcEdge`/`IfcEdgeCurve`/
`IfcOrientedEdge` as a geometry item, so `IfcEdgeProcessor::process` (the only
code this PR touches) never runs on them: this is an isolation check, not a
speedup claim, and the ordered mesh FNV was byte-identical on every one of the
25 runs per fixture per side.

AC20-FZK-Haus: median parse/geometry/total (best-of-5) 8/7/15 ms (base) vs
8/7/16 ms (branch); median full-pipeline wall 18.0 ms (base, spread 16.8-22.4)
vs 18.3 ms (branch, spread 17.1-26.2) — branch sits inside the base's own
spread. Output identical both sides: 285 meshes / 35,940 vertices / 19,456
triangles / 0 CSG failures, fingerprint `25ac885b6ff4ad00` on all 50 runs.

`C20-Institute-Var-2.ifc` (10.3 MB, 147,712 entities): median parse/geometry/
total 44/47/92 ms (base, total spread 89-104) vs 48/51/102 ms (branch, total
spread 86-133); median full-pipeline wall 111.5 ms (base, spread 103.2-145.3)
vs 121.4 ms (branch, spread 98.4-191.9). The branch's one high outlier (a
133 ms total / 191.9 ms wall round, immediately following an unusually fast
89 ms base round in the same interleaved pair) drove most of the median gap;
excluding it drops the branch median to within 4% of base. Both branch median
figures fall inside the base's own measured range, so this is noise from a
10 MB/147k-entity file's larger absolute jitter budget, not a signal: output
was identical on every round, 2,668 meshes / 83,310 vertices / 51,682 triangles
/ 0 CSG failures, fingerprint `3616a1e7d01c6950` on all 50 runs.

Verdict: no measurable full-load regression on either fixture, and none
expected — the new ribbon-mesh path only activates for a structural curve
member's raw edge entities, which neither architectural fixture contains.
Lesson: for a processor gated on IFC types absent from the standard perf
corpus, the correct "perf verdict" is an isolation proof (identical mesh
counts and fingerprint, timing inside noise) rather than a speedup or
regression claim — don't force a delta narrative onto a lever that has no
reach into the fixtures the ledger already tracks.

## Direct attribute construction (#5324, rejected)

A shared STEP grammar with separate token and attribute construction sinks
removed intermediate nested token vectors from full decode. Compaction was
needed to avoid retaining the parser's geometric vector capacity. The final
seven-model alternating native cohort preserved ordered geometry fingerprints,
counts and diagnostics, but did not establish a meaningful complete-load win:
results were mixed, with slower control medians and substantial Holter variation.
The candidate was rejected before browser qualification; no WASM speedup or
memory improvement is established. The lesson is to qualify the whole decode
consumer, including final vector capacity and existing cache fast paths, rather
than infer load improvement from removing an intermediate tree.

[Complete rejected source, measurements and limits](evidence/direct-attributes-5324/README.md).

## Surface spline sample reuse (#5321)

Surface evaluation reuses axis samples and removes only exact-zero coefficients,
keeping the order and threshold of the dense weighted sum. A bounded sparse-sample
cache also handles malformed knot vectors with dense support without retaining
all their samples. The existing degree and work-admission budgets stay unchanged.

Five alternating fresh-process native pairs improved full-call load on the real
spline fixture in every pair; the four control-model medians remained within
observed variation. Ordered mesh fingerprints, counts and diagnostics matched in
all samples. Real WASM prepass/batch comparisons also retained exact geometry
payloads at three detail levels. This establishes no browser speedup by itself.
Five alternating fresh-process browser pairs per fixture completed without
load/GPU errors on the same target and controls. Readiness changes were mixed
within run variation and target geometry-streaming was flat: no demonstrated
browser speedup. The adapter was SwiftShader; RSS sampling is a coarse sum of
owned processes through a fixed post-readiness tail, not cache-settled memory.
See [evidence and measurement limits](evidence/spline-5321/README.md).


## Multipart mapped occurrences: parked (#5328)

An opt-in prototype kept per-source-part identity through canonical production,
WASM shard recovery and the native USD consumer. Fixture-backed workspace tests,
strict clippy, real WASM contracts and independent composed-USD geometry checks
passed. No meaningful complete-load benefit was qualified: native flat Holter
signals reversed across an A/A-controlled follow-up, native export timings were
mixed and later overlapped unrelated host work, and a browser timing attempt was
interrupted for the same contention. Smaller serialized output is not a load
win. Preserve the rejected source, observer failures, completed functional checks
and every timing cohort in [the experiment record](evidence/multipart-5328/README.md).
No runtime change from this prototype ships.

## Physical summary membership scan (#5477)

The viewer now visits candidate source type buckets when collecting physical
entities, while retaining canonical overlay semantics, and memoizes metadata
panel membership across geometry-only updates. The first two fresh-browser
Holter cohorts were too noisy for a verdict and remain in the evidence. A
third, more isolated alternating cohort cleared the existing base-spread noise
limit, improved every paired browser-readiness comparison, and met the Holter
browser gate on every candidate run. Geometry counts, visible metadata, GPU
picking and selection remained consistent. Three post-result launcher races
left missing method files; pre-load process/variant proofs and complete browser
results survive for every sample. The result measures full model/index/canvas
readiness, not worker geometry alone. AC20 and ISSUE_129 control medians stayed
close to base, with matching output counts and functional checks. The lesson is to profile React
publication work on large entity stores: repeated whole-store scans can
dominate after worker geometry has finished. See the
[sample-level browser evidence](evidence/physical-summary-5477/README.md).

## Edge-grazing half-space cap repair (#5314)

The cap builder now ignores triangles that collapse after its section-vertex
weld. This reaches edge-grazing `IfcHalfSpaceSolid` cuts; the inline #30 and
Holter #148571 regression tests show a closed section with the analytic prism
volume. Five alternating fresh-process base-vs-branch native
`perf_probe --iters 5 --json --fingerprint` pairs covered AC20-FZK-Haus,
ISSUE_129 and Holter. AC20's ordered mesh fingerprint and counts stayed
byte-identical. ISSUE_129 and Holter emitted more vertices and triangles from
the intended caps, with stable but changed ordered fingerprints on every run.
Parse, geometry and total times varied widely on the shared WSL host; paired
samples crossed in both directions. The run establishes neither a speed gain
nor a regression. The numeric A/B evidence lives in the PR, not this ledger.

The lesson is that a small boundary-accounting guard can repair many reused
Boolean items. Full-load counts and ordered fingerprints reveal its reach
where a single-element test cannot, while variable host timing should not be
sold as a speed verdict.

## Viewer ancestor subscriptions and transient-upload screen (#5555)

A post-summary-fix production profile showed distributed React reconciliation
and renderer staging rather than another dominant metadata panel. Narrowing
subscriptions in the two viewer ancestors improved one interleaved Holter pair
and regressed the other, so the bounded screen did not justify shipping it.
A separate diagnostic retained only the first streaming preview and skipped
later transient uploads before normal finalization; it improved both pairs but
missed the predeclared investment gate for a larger renderer redesign. That
diagnostic deliberately reduces progressive display and must not ship.

Both patches remain unapplied in the [complete screen evidence](../../docs/architecture/evidence/viewer-ancestor-screen-5555/README.md).
The experiment reused identical frozen WASM with current JavaScript, so it is
an investment screen, not source-matched shipping qualification. All attempts
and provenance are retained. Lesson: a large inclusive React sample bucket does
not establish that removing a framework or a few subscriptions buys the same
wall time; test the actual change, and measure the avoidable upload work before
committing to permanent renderer pages.

## High-coordinate mapped-operator precision (#5792)

Mapped translations beyond the local f32 precision range now stay in the f64
mesh origin through the final world/RTC transform. Normal-size mapped items
retain their prior vertex path. One fresh-process native run per fixture used
`perf_probe --iters 1 --json --fingerprint` to compare exact main base
`382d1190d51750dce28b9f9568392d29c43e579f` with head
`d79ca0fe95c3f75282f0c0b0b3464deaf644ce9d`. AC20 matched at 285 meshes,
20,322 triangles and ordered FNV `c4d504b83ff698ea`; ISSUE_129 matched at
1,402 meshes, 136,807 triangles and ordered FNV `ff42e1a3f7fcf540`. The
hashes cover ordered mesh identifiers, geometry, colours, transforms and bounds.

Five balanced fresh-process base/branch pairs per fixture then ran the same
source-matched native binaries with `--iters 5 --json --fingerprint`. AC20's
median parse/geometry/total times were 6/23/30 ms on both sides; the base
total spread was 46.67%. ISSUE_129's medians were 23/952/976 ms on base and
21/950/972 ms on branch; its base total spread was 4.61%. Every paired run
retained the same counts and ordered fingerprint. Verdict: no meaningful
full-load regression on these two native fixtures and no speedup claim. This
does not measure browser worker-pool performance or rare mapped-item cost.

The lesson is that protecting high-coordinate geometry at the mapped-item
boundary can affect the normal path even when its mesh bytes are unchanged;
qualify the full load on both ordinary and CSG-heavy fixtures, and measure
browser worker-pool cost separately when that claim matters.

## IFC4x3 alignment geometry on Viadotto Acerno (#5327)

Five interleaved native base-versus-branch runs covered AC20-FZK-Haus and the
source-verified Viadotto Acerno fixture. AC20 emitted identical mesh, vertex,
and triangle counts. Its parse, geometry, and total timings all fell within
the wide run-to-run noise. Viadotto emitted additional meshes and triangles
because the branch now generates its sectioned solids; its timing comparison
is therefore not like-for-like. No measurable end-to-end speed verdict follows
from either fixture. The numeric A/B evidence is in the PR.

The incremental clothoid sampler avoids repeatedly integrating from the
origin for each station. A follow-up review found that inverting 3D station
length still rescanned every densely sampled horizontal segment and vertical
profile segment at each integration point; those lookups now use their sorted
station keys. The final interleaved A/B kept AC20's output counts identical
and its phase timings within noise. Viadotto again emitted the intended extra
geometry, so its timing remains non-comparable. The lesson is to check
complete model output before interpreting alignment timings and to trace
the lookup cost inside each repeated station evaluation.

## Analytic mapped-source reuse (#5786)

The analytic source walker now reuses a validated representation-map source,
its immutable item list and parsed MappingOrigin across occurrences in one
extraction. Each MappingTarget and final world transform still resolves for
its own occurrence; the uncached comparison switch exists only in test builds.
The generated many-instance test reduces source loads from 64 to one, and the
real Revit Snowdon model from 1,073 to 128, while cached/uncached descriptions,
definitions, extrusions, quantities, instance order and diagnostics agree.
Nested, reflected and scaled mappings retain their distinct f64 world frames.

Earlier idle-host native AC20 and ISSUE_129 controls kept ordered mesh output
identical and showed overlapping parse, geometry, total-time and peak-RSS
ranges. A [current-lock hosted AC20 control](https://github.com/LTplus-AG/ifc-lite/actions/runs/36474112703)
compared a synthetic parent made from then-current `main` (`c17ee39`) plus
the patch-identical final #6283 source with a clean #6276 merge. Five balanced,
interleaved fresh-process profiling pairs kept the fixture checksum, ordered mesh
fingerprints and entity/mesh/vertex/triangle counts identical; paired phase
timings remained within noise. After #6283 squashed as `d9b05c2f5`, exact
native probe-input comparisons found no differences between that squash and
the synthetic parent or between the restacked #6276 source and the synthetic
child. Only a Python README clarification differed under the broader Rust
tree. The combined Snowdon analytic
JSON was byte-identical across the earlier parent and child.
These ordinary mesh-load probes do not execute the opt-in analytic cache, so
they establish no browser worker-pool speedup or analytic-call memory win.
The lesson is to cache only immutable source facts and to measure opt-in
analytic extraction separately: far fewer source validations need not shorten
the full call.

### Fresh-process analytic cache control (#6442)

The [raw five-pair A/B runs and reproduction commands](evidence/analytic-cache-6442/README.md)
now measure the combined opt-in analytic call itself, using the `cfg(test)`
uncached control in a separate process for every run. The catalogued Snowdon
IFC yielded 1,073 → 128 source loads and identical ordered analytic JSON
(2,297,028 bytes, SHA-256 `63e64dd4a18a29b5d99abdd5d476032fba53aa43e389c2aff92cde7f3b6adc1d`):
149 swept-disk products/occurrences and 869 extrusion products with 911
occurrences. Cache-minus-control wall deltas were -1.87, -6.27, -5.36, -1.73
and -4.50 ms; medians were 70.66 → 65.04 ms. All five pairs favor caching,
but the two run ranges overlap, so this is a directional Snowdon signal, not
a general speedup claim. Peak RSS ranges also overlap (control 33,408–33,984
KiB; cache 33,600–34,244 KiB), establishing no memory win.

The generated 1,024-occurrence case reduced loads 1,024 → 1 and retained
1,024 ordered occurrences byte-identically; its median moved 3.12 → 2.90 ms,
with one of five pairs slower under caching. The nested reflected/scaled case
reduced loads 6 → 2 and retained four ordered occurrences; its medians were
0.619 → 0.617 ms. These small-call deltas are within run-to-run noise, and
neither fixture showed a consistent peak-RSS reduction. A separate post-call
index-build sample provides parse-cost context, not a parse/extraction split;
the canonical analytic call builds its index internally. The lesson is that
eliminating source validations can lower extraction time on a repeated-source
real model, while absolute memory cost and small-input timing remain dominated
by the surrounding walk and process variation. This result says nothing about
ordinary mesh loading or browser worker-pool throughput.

## Shared trimmed line and circle decoding (#6402)

The final decoder was measured against its parent in alternating,
fresh-process native pairs on AC20 and the real Snowdon structural IFC.
Every ordered mesh fingerprint and mesh, vertex, and triangle count matched;
separate source-verified builds had distinct binary hashes. The timing shifts
overlap normal run-to-run noise, so this change has no measured native pipeline
regression or speedup on these fixtures. This does not measure browser
worker-pool cost. The final-head timings and paired deltas are in the PR.

An [earlier hosted run](https://github.com/LTplus-AG/ifc-lite/actions/runs/36485574030)
recorded raw phase timings and passed native mesh-determinism and quick
committed-reference IfcOpenShell parity checks. Later review fixes changed the
decoder, so its timing result is not the final-head measurement above.

The lesson is that sharing trim-select decoding need not perturb common mesh
output: keep strict IFC validation for analytic curves separate from the mesh
recovery policy, and test malformed circular spans as well as valid trims.

## Rejected original-host retention after a batch miss (#6516)

A public release-regression witness reached a conforming unchanged opening
group, then repeated its individual subtractions. Skipping those singles and
keeping the original host removed real work, but also skipped their topology
consolidation. The public witness itself had fewer unmatched edges; broader
validation disproved the safety of that shortcut. A source-matched full census
passed on the base and regressed under the candidate, and normal WASM output
reopened previously closed material-layer parts in the real Revit `rvt01` model.
The candidate was rejected before any browser speedup claim or golden update.

The lesson is that an unchanged solid classification does not make its
retessellation disposable. Any reuse must preserve validated topology repair
as well as cuts, welded-operand identity, and budget rejection. A small volume
delta or close sampled surfaces cannot excuse reopening a closed mesh.
[Evidence and release provenance](evidence/opening-work-6516/README.md) also
distinguish accepted-open-output telemetry from actual kernel rejection; those
diagnostic labels alone do not identify which work can be removed.


## Retain validated group misses; qualify the whole load (#6516)

The conforming batch miss already contains a completed arrangement. The private
void-group path can retain its consolidated, validated retessellation when the
welded operands exactly match the sequential kernel operands. Keeping the
retessellation, rather than the original host, preserves the repair that the
rejected shortcut lost. Uncertain misses, altered operands, same-count misses,
multi-chunk groups, budget rejection and the existing retention floor keep their
fallback behavior; genuine cuts retain their existing gates.

Source-matched counters confirm that the public witness avoids repeated single
arrangements. Full-corpus and heavy-fixture topology checks pass, with only
independently reviewed precision changes to volume fingerprints. Fresh browser
pairs show a target worker-stream signal, but full readiness and the broader
controls remain unqualified because the observed spread is too large. A noisy
same-build control was retained, and its bounded recheck did not justify a broad
performance claim. Native phase results are attribution, not a substitute.

The lesson is to separate removed work, topology preservation, and whole-load
performance qualification. The published release comparison also locates a
separate output increase at the small-hole retention policy; do not delete
corrective geometry to recover a former triangle count. The private reporter's
complete slowdown remains unresolved. [All samples, identities, limits and
reproduction commands](evidence/opening-work-6516/README.md) are retained together.


## Optional per-face geometry export colors (#6601)

Color-aware analysis exports keep material indices attached to triangles through
welding. The legacy builder still accumulates its original element map directly;
only the opt-in builder adds a lazy palette sidecar. An initial implementation
converted a second map even for legacy callers; that unnecessary allocation was
removed before acceptance. Interleaved actual export-API runs retain byte-identical
legacy JSON on both reference models. Small-model timing varied between pairs and
the larger fixture's legacy total remained within the observed spread. The opt-in
metadata adds bounded work and output bytes; no speedup is claimed.

Native whole-load controls retain identical ordered mesh fingerprints and counts.
A repeat showed a small positive timing shift on the larger fixture, with mixed
paired deltas. The export API is not called by that probe, and a code-generation
audit found no changed hot-path arithmetic or branches. This supports isolating
export overhead, not claiming zero runtime variation or browser worker throughput.
The PR records both native runs and the actual API timings. The lesson is to
measure the consuming API, preserve the old accumulation path, and allocate
optional metadata only when a distinct material requires it.

## Canonical alignment sampling (#6600)

The new retained alignment evaluator and bounded Python sampling API are opt-in;
ordinary mesh production and the existing WASM alignment line sampler continue
using the original permissive curve policy. An otherwise-idle, interleaved
base-versus-branch native worker-pool probe on the default Haus fixture found
unchanged median parse, geometry and total time, with identical ordered mesh
fingerprints and mesh/vertex/triangle counts. Verdict: no measured regression
in the existing full-load path; this is an isolation result, not a speed win.

The real OIP infrastructure fixture was also timed through the installed Python
binding, including Rust parsing/evaluation and Python result conversion. That
cost belongs to the newly requested sampling feature, not ordinary mesh loads.
Lesson: retain canonical f64 evaluators for station queries, report curve
approximations and refused fallback geometry, and charge failed frames to the
model sampling budget. Per-axis output limits alone do not bound model-wide
sampling work or diagnostic output.

## Opt-in alignment section worker (#6603)

The retained WASM axis handle and dedicated evaluator worker are opened only by
explicit alignment selection. Ordinary loading retains the existing worker-pool
pipeline. Five interleaved fresh-browser pairs against the shared-core parent
showed matching flat geometry payloads and canonical geometry hashes, including
instanced entity coverage. Measured phases stayed within the observed variation;
this is no observed default-load regression, not a speed improvement.

The control used matching frozen JavaScript/WASM bundles and first-load Haus
samples. Background Chrome contention and an earlier baseline-only renderer
completion timeout limit the inference; the evidence preserves qualification
failures rather than discarding them. The lesson is to measure the actual default
worker pool even for opt-in APIs, and to separate post-timing byte witnesses from
the completion boundary. See [the evidence](../../docs/architecture/evidence/alignment-sections-6603/README.md).

### Checked direct-record prepass projection screen (#6537)

The [canonical-parser census](evidence/prepass-projection-6537/README.md) found
no unused nested attribute containers in the screened direct prepass record
families across the small, CSG, heavy and large public controls. The separate Revit
medical capture had no covered void/fill records. Snowdon's covered pairs had
no unused nested void/fill containers. Other unused fields are not classified
by that screen. The dominant
styled-item population's unused name field had no string payload. Do not
prototype removing unused nested value trees on this evidence or revisit the
rejected general constructor. A different worker capture must first establish
substantial unused materialization on the critical path. This native opportunity
screen is not a browser speedup or a measurement of indirect style decoding.

## Activity tray startup budget (#6952, U02)

The maintainer approved the measured eager-JavaScript ceiling for U02 while
keeping its existing tolerance. Job recording, the running badge and completion
announcements must work before the detail tray opens; detail rows remain lazy.
Deferring popup initialization and journal restoration increased eager bytes in
the production bundle and was discarded. The verdict is a deliberately approved
startup cost, not a speed improvement. Measure the complete eager chunk graph:
extracting a module can increase shared imports even when its entry chunk shrinks.

### Viewer preferences editor imports (P20, #6924)

A hook used by the Assistant must live separately from the optional preferences editor: importing the hook from the editor makes its dynamic import ineffective. Keep the live project/model hook in a small module and load the form through its native lazy boundary. The combined production measurement showed no meaningful size improvement from the hook split. The remaining content-library registration and recipe run state still participate in startup; keep the split for the lazy editor boundary, without claiming a bundle reduction.

## Federated CPU alias release correctness (#6584, #6537)

Main's single-model array stamping supersedes the old general owner-cache
prototype, whose measurements remain historical. Current-main mounted controls
still reproduce CPU buffers stranded in retained federation copies, including
an earlier immutable recolour that array-revision refresh misses. Canonical
release now follows weak aliases at the existing shallow-copy/provenance seam,
clearing only shared fields and preserving independent updates, retained counts,
GPU content version and the global streaming prefix.

The [retained controls and earlier negative measurements](evidence/owner-cache-6537/README.md)
prove reference removal and collectability; they do not measure OS peak memory
or establish a current end-to-end speedup. Lesson: invalidate shared CPU owners
at release rather than repairing only the current rendering cache.

Follow-up review of the bounded CPU release fix found that canonical frame restoration replaces source allocations before release, leaving prior registered copies alive. The release helper now remembers historical source allocation identities weakly and clears them alongside current shared fields while preserving independent replacements. Actual frame-restore regression and backing-allocation collection controls qualify this correction; no native speed or resident-memory improvement is claimed. See `evidence/owner-cache-6537/source-frame-replacement/`.

A second bounded-release follow-up showed that immutable recolouring after frame restoration also needs to carry historical ownership. Flat pruned weak snapshots now transfer only across complete shared allocation domains; snapshots remain independent so derived replacements cannot pollute original ownership. Actual canonical recolour regressions and collection controls qualify this correction. The evidence retains the separate WASM identities observed before and after Turbo typecheck rather than relabeling a functional run. See `evidence/owner-cache-6537/immutable-history-carry/`; no native performance claim is made.

## Opening-repair evidence and recording checker (#6940)

**Unmerged geometry stack: browser performance UNQUALIFIED; geometry merge hold.** The
five-layer stack adds opening corner reconciliation, certified independent plane
fits, closed-original-operand finite-wall protection and locally unrepresentable
cap repair. Recorded source-matched MiniBIM native/WASM/viewer parity and complete
per-arm normalized FZK/ISSUE129/Holter CPU transfers support bounded correctness.
Explained changed outputs retain strict cross-arm identity FAIL.

Both source-matched Holter recordings qualify functional recording feasibility.
The original October 15 finite interleaved browser cohort (plan `fdd4b255…`) fails: the first completed load fails its
unchanged POST cadence gate, the next planned load exhausts canonical host
refusals, and the remaining planned samples are unlaunched. Every failed attempt
and missing sample is retained. No throughput, neutral-performance or speed claim
is supported. Lesson: classify full consumer output in its actual frame/context,
then qualify the unchanged complete worker-pool cohort; repaired geometry and a
successful functional recording cannot substitute for those gates.
Before selecting a cohort, verify the live HTTPS state and collector rather than
trusting a cached preview page. A scheduled opportunity stopped before timing
when the benchmark server and its forwarding route were missing; restoring them
does not turn that unlaunched cohort into performance evidence.
The three October 16 opportunities are distinct failed cohorts, not replacement
samples for that original report; the [evidence index](../../docs/architecture/evidence/opening-tears-6940/README.md)
identifies each plan and disposition. Their local receipts are not included in
the original published packet. All scheduled opportunities are exhausted.
Lesson: retain cohort identity through PR summaries and stop at the original
admission budget; later host quietness cannot qualify a refused case.
The [V6 supplemental join](../../docs/architecture/evidence/opening-tears-6940/recording-checker-v6/README.md)
now uses the reviewed first-frame clock contract in both cadence and markers,
and reads finalized sidecars at their actual case paths. Lesson: verify final
checker contracts and receipt discovery against retained real captures before
spending another capture window. This integration fix grants no timing verdict.

## SMLib replacement feasibility

The isolated [SMLib evaluation](../../tools/smlib-evaluation/README.md) builds
the pinned C++ kernel natively and for browser workers without upstream source
patches or TBB. Known geometric invariants pass on both targets. This is a new
curved-BRep fidelity/maintenance mechanism, distinct from the retired Manifold
mesh accelerator; it is not a measured load-time optimization. No production
geometry path changed and no end-to-end speedup is claimed.

Lesson: verify optional dependency guards before dismissing browser feasibility,
and retain local coordinate frames before float32 mesh extraction. Native
concurrency, adapter overhead, tessellation fidelity and full-worker-pool
performance remain qualification gates.

## Shared geometry execution foundation

The [platform foundation](../../docs/architecture/geometry-platform-foundation.md)
keeps the exact engine and adds isolated SMLib execution behind explicit operation
contracts. Canonical output admission is opt-in and copies geometry buffers; it
is not an optimization and does not activate a new default meshing path. Default-
path A/B receipts belong with the foundation evidence, not the published baseline.
No SMLib throughput or retained-document memory win is claimed.

Lesson: distinguish exact predicate decisions, curved-source fidelity and validated
output. A successful primitive constructor can still publish a collapsed solid at
large coordinates; local frames and output admission are necessary. Measure worker
IPC, retention, copies and upstream tessellation peak memory in the actual future
pipeline before choosing pool sizing or making speed claims. Buffer-transfer limits
alone do not bound the kernel's temporary allocations.

The execution-layer follow-up adds opt-in authored-source planning, a shared wire
encoder and supervised native/browser workers. These do not execute on the default
load path. Separate source-fingerprinted receipts live under
`docs/architecture/evidence/geometry-platform-execution/`; default-path comparisons
remain output-identity evidence, without a qualified latency or memory claim.
Lesson: deadline/cancellation must be enforced outside the thread blocked on kernel
IPC. Queue time and initialization belong to the deadline, and completion follows
owned-process reaping; transfer quotas still do not constrain kernel RAM.

The canonical production-stage migration separates strategy planning, numerical
execution and presentation assembly while keeping one native/browser entry point.
An owned extrusion construction replays the current builder without source bytes;
its profile regions remain explicitly sampled. Preservation receipts live under
`docs/architecture/evidence/geometry-platform-phases/`. No retained-BRep backend
or performance baseline is activated by this extraction.
Lesson: empty geometry is not one outcome. Instance-only success, terminal input
refusal and a host legitimately consumed by an opening need separate decisions;
otherwise a generic retry can duplicate or resurrect geometry.

The construction-layer follow-up makes the processor registry authoritative for
family aliases and dispatch origin, and reuses owned primitive/triangle lowering
through the current builders. Base-versus-candidate whole-worker-pool comparisons
on the house, opening-heavy and heavy Holter fixtures retain identical mesh counts
and ordered payload fingerprints. Parse/geometry/total deltas and source hashes
live under `docs/architecture/evidence/geometry-platform-construction/`.
Shared-host timings remain unqualified; this is preservation evidence, without a
latency, retained-BRep throughput or memory-improvement claim.
Lesson: owning constructor inputs can remove decoder lifetime coupling without
changing numerical construction. Keep f32/sample admission, frame policy and
extension dispatch explicit; mesh fingerprints exclude UVs and instancing, so
independent presentation and occurrence tests remain necessary.

The owned-operation layer extends shared production lowering to tapered,
revolved, swept, polygonal and faceted constructors and extracts the existing
solid/solid boolean numerical policy. The opt-in operation arena shares definitions
and moves mesh buffers to their last consumer. Raw real-file replay and canonical
base-versus-candidate comparisons preserve the measured geometry payloads; source,
parse/geometry/total deltas and buffer-fingerprint receipts live under
`docs/architecture/evidence/geometry-platform-operations/`. Shared-host timings
remain unqualified, with no latency, retained-BRep throughput or memory-win claim.
Lesson: preserve lazy unit discovery when extracting numerical execution. Linear
graph size also does not imply linear diagnostic output: repeated DAG edges can
double loss records, so bound new records and copies before allocation and report
exhaustion without deduplicating real semantic occurrences. Conditional execution
and source/TLS diagnostic ownership remain required before activating the graph.

The constructor-family layer completes shared production lowering for all
nineteen leaf families, adds demand-driven raw operation scheduling and retains
owned source/execution reports on failures. Base-versus-candidate whole-worker-pool
comparisons on the canonical models, advanced BRep samples and Revit export retain
identical mesh counts and ordered geometry fingerprints. Source pins, phase deltas,
raw replay checks and qualification commands live under
`docs/architecture/evidence/geometry-platform-families/`. Shared-host timings remain
unqualified; no latency non-regression, memory improvement or retained-engine speed
claim follows from this layer. Some recorded branch timings are slower; an
exclusive-runner repeat and profiling remain required before a latency verdict.
Lesson: separating source admission from numerical construction can preserve every
mesh while reordering refusal reports. Capture/replay mixed-face reports in their
original execution order and keep source-only snapshots distinct from attributed
runtime events. Numerical branch skipping also does not eliminate sampling already
performed during eager lowering; admission effort, contextual budgets and memory
still need explicit preservation before graph activation.

The cutter/control extraction owns half-space, bounded-prism and void-shell
inputs, snapshots production polygonal candidates and separates grouped-cut
numerics. Base-versus-candidate whole-worker-pool comparisons retain matching
mesh counts and ordered geometry fingerprints on the same six fixtures; source
pins and parse/geometry/total deltas live under
`docs/architecture/evidence/geometry-platform-cutters/`. Shared-host timings remain
unqualified, with no latency or memory-improvement claim. Separate native
process high-water samples on three fixtures are recorded in the same directory;
they do not qualify browser/retained-plan memory or establish process limits.
Geometry fingerprints still omit presentation and occurrence metadata.
Lesson: preserve conditional admission through owned continuation requests.
Eagerly decoding a dormant operand mutates decoder refusal state and may sample
large inputs; deferring numerical execution or TLS publication cannot undo that
work. A failed grouped cutter union also owns a diagnostic that sequential
execution cannot reproduce, unlike provisional trial records that are rewound.

The canonical continuation layer deletes recursive boolean/CSG operand dispatch
and owns suspended hosts, spines, contextual path/visit state and provisional
batch marks. Whole-worker-pool comparisons retain matching counts and ordered
geometry fingerprints on the six measured models; source pins and phase deltas
live under `docs/architecture/evidence/geometry-platform-continuations/`.
Native process high-water samples cover three fixtures. Shared-host timing and
those samples do not establish a latency or memory improvement; retained/browser
memory and complete presentation/occurrence identity remain separate work.
Lesson: sharing the CSG diagnostic recorder is safe only with depth-first
execution and mark-relative rewinds that preserve the parent's prefix. Keep
release-state mutations outside debug assertions, and qualify explicit work
queues dynamically because the recursive-reference scanner does not inspect
their continuation transitions.

The initial owned product session replaces the synchronous strategy orchestrator
while retaining the same canonical producer and presentation builders. It owns
job metadata, attempt state, outputs and hashing, and installs owned budget/drop
counters only for a synchronous poll. Worker-pool comparisons preserve the measured
geometry counts and fingerprints on six fixtures; source pins and phase deltas
live under `docs/architecture/evidence/geometry-platform-products/`. Native process
high-water samples cover three fixtures. Some branch timing samples are slower;
shared-host timing does not establish a latency verdict or memory improvement.
Lesson: moving state into a session does not permit moving every drain to a poll.
CSG records remain grouped by processor until the original final drain, and
extension mutations of triangle-order mode must survive into the next poll while
the caller's ambient mode is restored. A live router/cache owner still needs a
lease, diagnostic provenance and publication barriers before asynchronous work.

### Typed product work and executor ownership

The canonical producer now admits and accepts typed synchronous work with
exclusive decoder/router reservations, configuration generations, pending TLS
isolation and sparse actual registry-entry identities. This preserves original
CSG retry/final drain grouping; acceptance validates the packet before assembly
and does not replay numerical callbacks or cache insertions. Successful packet
validation does not establish that complete model context or diagnostic/cache
effects are portable.

[Work-stage measurements](../../docs/architecture/evidence/geometry-platform-work/)
compare the full worker-pool path against the same base, interleaved on six real
models. Mesh counts and ordered geometry fingerprints match; the fingerprints
omit textures, UVs, instances and text metadata. Shared-host timing remains
unqualified, including samples with slower candidate phases. Native RSS is
sampled separately on three models. There is no speedup, memory-reduction or
latency non-regression verdict. The ownership lesson is to reserve the warm
executor and validate before presentation while retaining channel-specific drain
semantics; a scheduling boundary alone does not make its caches or diagnostics
transportable. Exact arithmetic remains the numerical engine on the default path.

The initial reservation implementation failed the existing zero-allocation warm
router invariant. Lazy shared state preserves it. Compatibility probes also
required trusted callback generation commits, lexical children through live
ancestors, final-hook ambient-state preservation and joined mutable-decoder
worker borrowing. Exclusive ownership must express the existing extension
contract before it can safely become a scheduling boundary.

### Owned model inputs and mapped traversal

The canonical native chunks and browser batches now retain immutable production
input snapshots, while mapped-source traversal owns its continuation frames.
The [context-layer receipts](../../docs/architecture/evidence/geometry-platform-context-final/)
record passing native, WASM and installed Python consumers, structured scene
comparisons and positive material-layer invariants. Interleaved base/candidate
whole-worker-pool measurements preserve the measured geometry counts and ordered
fingerprints; those fingerprints omit appearance and occurrence metadata.

Timing remains an unqualified shared-host diagnostic. Results are mixed, and
the heavy Holter model shows slower candidate execution and higher native peak
memory. Treat this as an unresolved performance risk requiring controlled
profiling before cutover, not a latency non-regression or memory-win verdict.
The process high-water samples do not attribute heap costs or qualify browser
and retained-plan memory. Lesson: immutable ownership and preserved geometry do
not establish inexpensive ownership. Measure the canonical consumer, retain the
heavy case, and identify allocation/copy costs before choosing an optimization;
these observations alone do not identify the responsible component.

The subsequent
[requested-allocation diagnostic](../../docs/architecture/evidence/geometry-platform-context-final/allocation-diagnostic/)
links identical instrumented consumers to the pinned native libraries and runs
the full worker pool. Holter makes more allocation requests and requests more
allocation traffic, while retained result bytes match and peak requested live
bytes do not increase. Whole-process RSS remains higher. This narrows the next
investigation toward allocation traffic and patterns, without identifying copy
sites or proving allocator fragmentation or arena behavior. Requested backing
bytes, actual copied bytes and process RSS are different measurements. Preserve
the uninstrumented controlled-runner latency gate; allocator instrumentation
adds contention and cannot qualify timing.
## Explicit Rust resource admission: performance unqualified

Compatibility preserves existing dispatch, source reads, cache publication and
numerical algorithms; accounted execution adds checked preflight and ownership
at audited mapping/copy/output sites. Reservation probes establish early refusal,
not speed or physical-memory savings. Fleet storage admission prevents compiled
qualification and an end-to-end A/B verdict for this integration. No
microbenchmark or inherited timing receipt qualifies it. Full default-worker
comparisons, heavy-model timing/RSS and actual WASM output lifetime qualification
remain outstanding. Lesson: keep deterministic request allowances separate from
shared resident admission, and do not describe partial requested-storage
accounting as an allocator or process bound. The implementation coverage is in
[the resource note](../../docs/architecture/geometry-platform-resource-accounting.md).
