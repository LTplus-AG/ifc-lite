# SPDX-License-Identifier: MPL-2.0
import hashlib, json, os, re, shutil, subprocess
from pathlib import Path
out = Path('/tmp/ifclite-source-owner-preservation-round2')
def git(*args):
    return subprocess.check_output(['git', *args])
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
parent = git('rev-parse', '772522f9').decode().strip()
baseline = git('rev-parse', '17d120a3').decode().strip()
correction = (out/'correction-head.txt').read_text().strip()
head = git('rev-parse', 'HEAD').decode().strip()
assert not git('status', '--porcelain'), 'checkpoint final generated declarations first'
paths = git('diff', '--name-only', '-z', parent, head).decode().strip('\0').split('\0')
rows = []
for p in paths:
    path = Path(p)
    rows.append({'path': p, 'sha256': sha(path), 'bytes': path.stat().st_size} if path.exists() else {'path': p, 'deleted': True})
manifest = {'parent_commit': parent, 'source_layer_baseline': baseline, 'correction_commit': correction, 'final_commit': head,
            'final_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'scope': 'Combined round-1 source layer plus round-2 preservation correction and canonical declaration regeneration, relative to prepared parent. Parent already contains inherited implementation and qualification fixes.',
            'files': rows}
(out/'combined-source-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(out/'combined-source.patch').write_bytes(git('diff', '--binary', parent, head))
(out/'generated-declarations.patch').write_bytes(git('diff', '--binary', correction, head, '--', 'packages/wasm/pkg/ifc-lite.d.ts'))
env = dict(os.environ, GIT_INDEX_FILE=str(out/'combined-check.index'))
subprocess.run(['git','read-tree',parent],env=env,check=True)
subprocess.run(['git','apply','--cached',str(out/'combined-source.patch')],env=env,check=True)
applied = subprocess.check_output(['git','write-tree'],env=env).decode().strip()
assert applied == manifest['final_tree']
(out/'combined-application.json').write_text(json.dumps({'parent_commit':parent,'final_commit':head,'applied_tree':applied,'match':True},indent=2)+'\n')
receipts = []
for job in ['80fdd95f-4b5a-49ba-84a4-93ac7cba4dcd','11e07922-4aca-4eb5-bfba-2d3bf8053d83','7ef8d1c4-6891-4465-a485-fb9384450d14']:
    src = Path('/home/louistrue/build-workers/worker-state/jobs')/job/'receipt.json'
    dest = out/(job+'-receipt.json')
    shutil.copyfile(src,dest)
    receipts.append({'original':str(src),'copy':str(dest),'sha256':sha(dest)})
commands=[]
for line in (out/'commands.tsv').read_text().splitlines():
    name, code, start, end, cmd = line.split('\t',4)
    commands.append({'name':name,'exit_code':int(code),'start':start,'end':end,'command':cmd.strip(),'log':str(out/(name+'.log'))})
workspace = (out/'workspace.log').read_text(errors='replace')
results = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored',workspace)
verification = {'commands':commands,'receipts':receipts,'verification_script_sha256':sha(out/'verify.sh'),
    'focused_processing':{'exit_code':0,'passed':3,'command':'cargo test -p ifc-lite-processing --lib preservation_tests'},
    'focused_core':{'exit_code':next(x['exit_code'] for x in commands if x['name']=='core-caches'),'passed':8},
    'workspace_summaries':{'groups':len(results),'passed':sum(int(x[1]) for x in results),'failed':sum(int(x[2]) for x in results),'ignored':sum(int(x[3]) for x in results)},
    'qualified_source_commit':'307c7c60ee5a9674d25dd5a485b9c31e3f7a505b', 'final_test_setup_delta_unverified':True, 'final_admission_refused':'disk 204.3 GiB free; require 316 GiB (reserve plus scratch; existing jobs continue)', 'limitations':json.loads((out/'limitations.json').read_text())}
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
artifacts=['correction.patch','combined-source.patch','combined-source-manifest.json','source-layer-baseline.json','generated-declarations.patch','verification.json','limitations.json','verify.sh','verify-final.sh','verify-boundary.sh','integration-overlap.json','workspace-skips.log','workspace-first-run-summary.json','fleet-after-build.json','final-admission.log','parent-application-check.json','applied-source.patch','correction-application.json','combined-application.json']
delivery={'checkout':str(Path.cwd()),'parent_commit':parent,'source_layer_baseline':baseline,'correction_commit':correction,'final_commit':head,
          'source_layer_input':{'original_patch_sha256':'d7094616225a0291a9168949f1a73150a56e0618cc3ad6785341c57538c1c8f2','excluded_path':'packages/wasm/pkg/ifc-lite.d.ts','applied_patch_sha256':sha(out/'applied-source.patch')},'source_files':len(rows),'artifacts':{p:{'path':str(out/p),'sha256':sha(out/p)} for p in artifacts},'receipts':receipts}
(out/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps(delivery,indent=2))
