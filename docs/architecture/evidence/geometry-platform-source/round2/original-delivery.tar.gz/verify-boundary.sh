#!/usr/bin/env bash
# SPDX-License-Identifier: MPL-2.0
set -uo pipefail
out=/tmp/ifclite-source-owner-preservation-round2
validation_failed=0
run_step() {
  local name="$1"
  shift
  local started finished code
  started=$(date -u +%FT%TZ)
  "$@" > "$out/$name.log" 2>&1
  code=$?
  if [ "$code" -ne 0 ]; then validation_failed=1; fi
  finished=$(date -u +%FT%TZ)
  printf '%s\t%s\t%s\t%s\t' "$name" "$code" "$started" "$finished" >> "$out/commands.tsv"
  printf '%q ' "$@" >> "$out/commands.tsv"
  printf '\n' >> "$out/commands.tsv"
  return "$code"
}
run_step boundary-dependency-build pnpm build --filter=@ifc-lite/geometry... --filter=@ifc-lite/export... --filter=@ifc-lite/renderer...
if [ "$?" -eq 0 ]; then
  run_step wasm-contract-built pnpm test:wasm-contract
  run_step wasm-package-tests pnpm test --filter=@ifc-lite/wasm
fi
exit "$validation_failed"
