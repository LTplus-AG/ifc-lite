#!/usr/bin/env bash
# SPDX-License-Identifier: MPL-2.0
set -uo pipefail
out=/tmp/ifclite-source-owner-preservation-round2
validation_failed=0
run_step() {
  local name="$1"
  shift
  local started finished code
  started=$(date -u +%FT%TZ)
  "$@" > "$out/$name.log" 2>&1
  code=$?
  if [ "$code" -ne 0 ]; then validation_failed=1; fi
  finished=$(date -u +%FT%TZ)
  printf '%s\t%s\t%s\t%s\t' "$name" "$code" "$started" "$finished" >> "$out/commands.tsv"
  printf '%q ' "$@" >> "$out/commands.tsv"
  printf '\n' >> "$out/commands.tsv"
  return "$code"
}
run_step final-processing-library cargo test -p ifc-lite-processing --lib -- --nocapture
run_step final-clippy cargo clippy --workspace --all-targets -- -D warnings
bash "$out/verify-boundary.sh"
if [ "$?" -ne 0 ]; then validation_failed=1; fi
exit "$validation_failed"
