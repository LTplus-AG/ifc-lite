#!/usr/bin/env bash
# SPDX-License-Identifier: MPL-2.0
set -uo pipefail
out=/tmp/ifclite-source-owner-preservation-round2
validation_failed=0
run_step() {
  local name="$1"
  shift
  local started finished code
  started=$(date -u +%FT%TZ)
  "$@" > "$out/$name.log" 2>&1
  code=$?
  if [ "$code" -ne 0 ]; then validation_failed=1; fi
  finished=$(date -u +%FT%TZ)
  printf '%s\t%s\t%s\t%s\t' "$name" "$code" "$started" "$finished" >> "$out/commands.tsv"
  printf '%q ' "$@" >> "$out/commands.tsv"
  printf '\n' >> "$out/commands.tsv"
  return "$code"
}
run_step core-caches cargo test -p ifc-lite-core source_caches
run_step fixtures pnpm fixtures
run_step workspace cargo test --workspace --no-fail-fast -- --nocapture
run_step clippy cargo clippy --workspace --all-targets -- -D warnings
run_step dependencies pnpm install --frozen-lockfile --prefer-offline
run_step wasm-build bash scripts/build-wasm.sh
wasm_code=$?
if [ "$wasm_code" -eq 0 ] && [ -f packages/wasm/pkg/ifc-lite_bg.wasm ]; then
  run_step wasm-contract pnpm test:wasm-contract
else
  printf 'WASM contract not run: canonical build failed or runtime absent.\n' > "$out/wasm-contract-not-run.txt"
fi
exit "$validation_failed"
