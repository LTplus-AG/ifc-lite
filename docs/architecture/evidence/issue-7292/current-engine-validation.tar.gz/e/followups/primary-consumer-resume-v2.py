"""Source-current root Turbo build and real WASM-boundary checks, then freeze dist."""
from pathlib import Path
import subprocess, json, hashlib, os, sys, time, importlib.util, shutil, re
sys.dont_write_bytecode = True
R = Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69')
W = Path('/tmp/7292-main2d-primary-build-preparation-v1/wasm-run/receipt.json')
O = Path('/tmp/7292-main2d-primary-build-preparation-v1/viewer-run-v2')
H = lambda b: hashlib.sha256(b).hexdigest()
def req(x, message):
    if not x: raise RuntimeError(message)
def save(p, x): p.write_text(json.dumps(x, indent=2)+'\n')
def command(*a): return subprocess.check_output(a, cwd=R)
def tree(root, names):
    rows = [{'path':n, 'bytes':(root/n).stat().st_size, 'sha256':H((root/n).read_bytes())} for n in sorted(names)]
    return {'rows':rows, 'sha256':H(''.join(f"{v['path']}\0{v['bytes']}\0{v['sha256']}\n" for v in rows).encode())}
def production():
    names = command('git','ls-files','--cached','--others','--exclude-standard','-z','rust','packages','apps/viewer','scripts/build-wasm.sh','scripts/build-wasm-postprocess.mjs','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','pnpm-lock.yaml','package.json','turbo.json','tsconfig.json','tsconfig.packages.json').decode().split('\0')
    return tree(R, {n for n in names if n and not re.search(r'(^|/)(tests?|examples|benches|evidence|__snapshots__)/',n) and not re.search(r'(\.test\.|\.spec\.|_tests\.rs$|(^|/)(README|CHANGELOG)\.)',n)})
def main():
    req(sys.argv[1:]==['--run','--exclusive-native-lease'], 'Explicit owned build lease required')
    spec=importlib.util.spec_from_file_location('controls','/tmp/7292-current-main-rust-qualification-preparation-v3/run.py'); c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    wb=W.read_bytes(); w=json.loads(wb)
    req(w['status']=='CURRENT_MAIN_FRESH_SOURCE_WASM_BUILD_COMPLETE_NOT_BROWSER_GEOMETRY_OR_PERFORMANCE_QUALIFIED' and w['sourceUnchanged'] and w['helpersAndToolsStable'], 'Fresh WASM build prerequisite')
    source=w['sourceManifest'];req(c.source_map(R)==source,'Rust source differs from fresh WASM')
    wasm=R/'packages/wasm/pkg/ifc-lite_bg.wasm'; wasmhash=H(wasm.read_bytes());req(w['generatedArtifacts'][str(wasm)]['sha256']==wasmhash,'WASM artifact differs')
    req(not O.exists(),'Fresh external output');O.mkdir();before=production();head=command('git','rev-parse','HEAD').decode().strip()
    env={**os.environ,'PATH':'/home/louistrue/.nvm/versions/node/v24.21.0/lib/node_modules/wasm-pack/binary:/home/louistrue/.cargo/bin:'+os.environ.get('PATH',''),'CI':'1','CARGO_TARGET_DIR':'/tmp/7292-main2d-primary-wasm-target-v1','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RAYON_NUM_THREADS':'1','TURBO_ENV_MODE':'loose','TURBO_TELEMETRY_DISABLED':'1','NODE_OPTIONS':'--max-old-space-size=12288'}
    rec={'status':'RUNNING_NOT_QUALIFIED','sourceManifest':source,'wasmReceiptSHA256':H(wb),'performanceClaim':False,'geometryAcceptanceClaim':False,'steps':[]};child=None
    try:
        for label,args in [('typecheck',['pnpm','typecheck']),('wasm-contract',['pnpm','test:wasm-contract']),('wasm-package',['pnpm','test','--filter=@ifc-lite/wasm','--force','--concurrency=1']),('viewer',['pnpm','exec','turbo','run','build','--filter=@ifc-lite/viewer','--concurrency=1','--env-mode=loose','--force'])]:
            req(c.source_map(R)==source and production()==before,'Source changed before step')
            log=O/(label+'.log');step={'kind':label,'cwd':str(R),'command':['nice','-n','19',*args],'logPath':str(log),'startedNs':time.time_ns()};rec['steps'].append(step)
            with log.open('wb') as f:
                child=subprocess.Popen(step['command'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);step['ownedPID']=child.pid;deadline=time.monotonic()+3600
                while child.poll() is None:
                    resources=c.resources(O)
                    if time.monotonic()>deadline or resources['memAvailableBytes']<2*1024**3 or resources['targetDiskFreeBytes']<20*1024**3:step['boundExceeded']=True;c.terminate(child);break
                    time.sleep(2)
                step['exitCode']=child.wait();step['ownedChildReaped']=True;child=None
            step['logSha256']=H(log.read_bytes());req(step['exitCode']==0 and not step.get('boundExceeded'),label+' failed or bounded')
            req(H(wasm.read_bytes())==wasmhash,'Turbo replaced WASM with different bytes')
        req(c.source_map(R)==source and production()==before,'Final source changed')
        dist=O/'frozen-dist';shutil.copytree(R/'apps/viewer/dist',dist,copy_function=shutil.copy2);dt=tree(dist,{str(p.relative_to(dist))for p in dist.rglob('*')if p.is_file()})
        req(any(v['path'].endswith('.wasm') and v['sha256']==wasmhash for v in dt['rows']),'Dist lacks exact fresh WASM')
        req((dist/'index.html').stat().st_mtime_ns>=wasm.stat().st_mtime_ns,'Dist predates WASM')
        ws=w['step'];build={'version':1,'builtRevision':head,'productionTreeSha256':before['sha256'],'distSha256':dt['sha256'],'wasmSha256':wasmhash,'steps':[{'kind':'wasm','cwd':str(R),'exitCode':ws['exit'],'command':ws['command'],'logPath':str(W.parent/'build-wasm.log'),'logSha256':H((W.parent/'build-wasm.log').read_bytes())},next(s for s in rec['steps']if s['kind']=='viewer')]}
        save(O/'build-receipt.json',build);save(O/'production-tree.json',before);save(O/'dist-tree.json',dt);rec['status']='SOURCE_CURRENT_VIEWER_BUILD_TYPECHECK_AND_WASM_CONTRACT_COMPLETE_NOT_GEOMETRY_QUALIFICATION';rec['buildReceiptSHA256']=H((O/'build-receipt.json').read_bytes())
    except BaseException as error:
        rec['status']='FAILED_OR_UNRESOLVED_NOT_QUALIFIED';rec['error']=repr(error);raise
    finally:
        c.terminate(child);rec['sourceUnchanged']=c.source_map(R)==source and production()==before;rec['wasmUnchanged']=H(wasm.read_bytes())==wasmhash;save(O/'receipt.json',rec)
if __name__=='__main__': main()
