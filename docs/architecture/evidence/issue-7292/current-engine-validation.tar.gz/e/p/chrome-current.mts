/** Scratch correctness harness; --seal is filesystem-only; --run needs later root authorization. */
import { chromium, type BrowserContext, type Page } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/node_modules/@playwright/test/index.mjs';
import { ViewerBenchmarkPage } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/tests/benchmark/viewer-benchmark-page.ts';
import { runColdSample } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/scripts/perf/browser-cold-sample.ts';
import { readGpuHealth } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/tests/benchmark/gpu-health.ts';
import { probeMetadataRenderTrace } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/tests/benchmark/metadata-render-readiness.ts';
import { raceWithTimeout } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/scripts/perf/browser-cold-teardown.ts';
import { launchWindowsChrome, findWindowsChrome, type WindowsChrome } from './frame-gpu-chrome.ts';
import { installRuntimeProof, requireFourWorkerPool } from './runtime-proof.mts';
import { validateBuildReceipt } from '/tmp/7292-build-receipt-validation.mts';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync } from 'node:fs';
import { join, relative, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const D=dirname(fileURLToPath(import.meta.url));
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
const fileSha=(p:string)=>sha(readFileSync(p));
const CANONICAL_ROOT="/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69";
const CANONICAL_PINS_SHA256="cdeec6d0a16b38da98b1d182b3f6b39c24d82c2cdde7494ac5dda1712ec3df12";
function boundJson<T>(p:string,expected:string):T{const bytes=readFileSync(p);need(sha(bytes)===expected,'Consumed JSON hash '+p);return JSON.parse(bytes.toString('utf8')) as T;}
function need(value:unknown,message:string):asserts value {if(!value)throw Error(message);}
const save=(p:string,v:unknown)=>writeFileSync(p,JSON.stringify(v,null,2),{flag:'wx'});
const arg=(n:string)=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
type FilePin={path:string;bytes:number;sha256:string};
type Fixture={key:string;kind:'real'|'reporter';path:string;selectedIds:number[];requireFourWorkers:boolean;timeoutMs:number};
type Config={root:string;frozenDist:string;wasmPath:string;origin:string;serverReceiptPath:string;buildReceiptPath:string;
 qualification:{path:string;sha256:string;acceptedStatus:string};candidatePreparation:string;candidatePreparationSHA256:string;
 chromeExecutable?:string;fixtures:Fixture[]};
type Pins={version:1;config:Config;files:Record<string,string>;productionTreeSha256:string;distFiles:FilePin[];distSha256:string;wasmSha256:string;head:string};
const walk=(p:string):string[]=>readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(p,e.name)):[join(p,e.name)]).sort();
const git=(r:string,...a:string[])=>execFileSync('git',['-C',r,...a],{encoding:'utf8',timeout:10000});
function sourceFiles(root:string){return [...new Set(git(root,'ls-files','--cached','--others','--exclude-standard','-z','rust','packages','apps/viewer','scripts/build-wasm.sh','scripts/build-wasm-postprocess.mjs','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','pnpm-lock.yaml','package.json','turbo.json','tsconfig.json','tsconfig.packages.json').split('\0').filter(Boolean))].filter(p=>!/(^|\/)(tests?|examples|benches|evidence|__snapshots__)\//.test(p)&&!/(\.test\.|\.spec\.|_tests\.rs$|(^|\/)(README|CHANGELOG)\.)/.test(p)).sort();}
function tree(root:string,files:string[]){const rows=files.map(path=>({path,bytes:statSync(join(root,path)).size,sha256:fileSha(join(root,path))}));return {rows,sha256:sha(rows.map(f=>`${f.path}\0${f.bytes}\0${f.sha256}\n`).join(''))};}
function configChecks(c:Config){
 need(new URL(c.origin).hostname==='localhost'&&new URL(c.origin).protocol==='http:','Fresh localhost HTTP origin only');
 need(![5273,5274,5276,5277,56792].includes(Number(new URL(c.origin).port)),'Preserve old listener ports');
 need(c.fixtures.length>=2&&c.fixtures.length<=8&&c.fixtures[0].kind==='real'&&c.fixtures[0].requireFourWorkers,'Real target FIRST, four actual workers required');
 need(c.fixtures.some(f=>f.kind==='reporter'),'At least one real reporter required');
 need(new Set(c.fixtures.map(f=>f.key)).size===c.fixtures.length,'Unique fixture keys');
 for(const f of c.fixtures){need(/^[a-zA-Z0-9_-]+$/.test(f.key)&&f.selectedIds.length>0&&new Set(f.selectedIds).size===f.selectedIds.length&&f.selectedIds.every(i=>Number.isSafeInteger(i)&&i>0),'Explicit selected IDs/key');need(f.timeoutMs>=10000&&f.timeoutMs<=180000,'Bounded fixture timeout');}
}
function verifyArtifacts(c:Config){
 configChecks(c);const protocol=boundJson<Record<string,string>>(join(D,'canonical-helper-pins.json'),CANONICAL_PINS_SHA256);for(const [rel,h]of Object.entries(protocol)){need(fileSha(join(CANONICAL_ROOT,rel))===h,'Executing current canonical helper changed '+rel);need(fileSha(join(c.root,rel))===h,'Build checkout canonical helper differs '+rel);}
 const qualification=boundJson(c.qualification.path,c.qualification.sha256) as {status:string;candidateManifest?:Record<string,string>;sourceManifest?:Record<string,string>;candidatePreparationSHA256?:string};need(qualification.status===c.qualification.acceptedStatus,'Explicit reviewed qualification status');
 // Parse exactly the candidate bytes whose reviewed hash is required.
 const candidate=boundJson(c.candidatePreparation,c.candidatePreparationSHA256) as {sourceManifest?:Record<string,string>;candidateManifest?:Record<string,string>};const manifest=candidate.sourceManifest??candidate.candidateManifest;need(manifest&&Object.keys(manifest).length,'Candidate full source map required');
 const qualified=qualification.candidateManifest??qualification.sourceManifest;need(qualified&&JSON.stringify(Object.entries(qualified).sort())===JSON.stringify(Object.entries(manifest).sort()),'Qualification receipt does not bind exact compiled candidate source manifest');if(qualification.candidatePreparationSHA256!==undefined)need(qualification.candidatePreparationSHA256===c.candidatePreparationSHA256,'Qualification candidate prep mismatch');
 for(const [p,h]of Object.entries(manifest))need(fileSha(join(c.root,p))===h,'Build source differs candidate '+p);
 const source=tree(c.root,sourceFiles(c.root)),dist=tree(c.frozenDist,walk(c.frozenDist).map(p=>relative(c.frozenDist,p))),wasm=fileSha(c.wasmPath),head=git(c.root,'rev-parse','HEAD').trim();
 need(dist.rows.some(p=>p.path.endsWith('.wasm')&&p.sha256===wasm),'Frozen dist must include exact pkg WASM');
 const rust=source.rows.filter(p=>p.path.startsWith('rust/')&&p.path.endsWith('.rs'));need(rust.length>0&&statSync(c.wasmPath).mtimeMs>=Math.max(...rust.map(p=>statSync(join(c.root,p.path)).mtimeMs)),'WASM predates source');need(statSync(join(c.frozenDist,'index.html')).mtimeMs>=statSync(c.wasmPath).mtimeMs,'Dist predates WASM');
 const buildBytes=readFileSync(c.buildReceiptPath),buildSHA256=sha(buildBytes);const build=JSON.parse(buildBytes.toString('utf8')) as {steps:Array<{logPath:string;logSha256:string}>};
 validateBuildReceipt(c.buildReceiptPath,{builtRevision:head,productionTreeSha256:source.sha256,wasmSha256:wasm,distSha256:dist.sha256},['wasm','viewer'],c.root);
 need(fileSha(c.buildReceiptPath)===buildSHA256,'Build receipt changed during validation');return {source,dist,wasm,head,build,buildSHA256};
}
function seal(c:Config,out:string){
 const a=verifyArtifacts(c),files:Record<string,string>={};
 const helperRoot=CANONICAL_ROOT;
 for(const p of [...walk(D).filter(p=>/\.(mts|ts|ps1|mjs|cjs|py)$/.test(p)),...walk(join(helperRoot,'tests/benchmark')).filter(p=>/\.(ts|mts)$/.test(p)),...walk(join(helperRoot,'scripts/perf')).filter(p=>/\.(ts|mts)$/.test(p)),join(D,'canonical-helper-pins.json'),join(D,'runtime-transport.json'),join(helperRoot,'scripts/lib/benchmark-upload-mode.mjs'),c.qualification.path,c.candidatePreparation,c.buildReceiptPath,c.serverReceiptPath,...c.fixtures.map(f=>f.path),'/tmp/7292-build-receipt-validation.mts'])files[p]=fileSha(p);
 files[c.buildReceiptPath]=a.buildSHA256;for(const s of a.build.steps){need(fileSha(s.logPath)===s.logSha256,'Actual build log drift');files[s.logPath]=s.logSha256;}
 save(out,{version:1,config:c,files,productionTreeSha256:a.source.sha256,distFiles:a.dist.rows,distSha256:a.dist.sha256,wasmSha256:a.wasm,head:a.head} satisfies Pins);
}
function verify(p:Pins){
 for(const [path,h]of Object.entries(p.files))need(fileSha(path)===h,'Sealed input drift '+path);
 const a=verifyArtifacts(p.config);need(a.source.sha256===p.productionTreeSha256&&a.dist.sha256===p.distSha256&&a.wasm===p.wasmSha256&&a.head===p.head,'Compiled source/runtime drift');
 const s=boundJson(p.config.serverReceiptPath,p.files[p.config.serverReceiptPath]!)as{root:string;port:number;buildReceiptSHA256:string;distSha256:string;wasmSha256:string};need(s.root===p.config.frozenDist&&s.port===Number(new URL(p.config.origin).port)&&s.buildReceiptSHA256===fileSha(p.config.buildReceiptPath)&&s.distSha256===p.distSha256&&s.wasmSha256===p.wasmSha256,'Owned server/build binding');
}
async function verifyHttp(p:Pins){for(const f of p.distFiles.filter(x=>x.path==='index.html'||x.path.endsWith('.wasm'))){const u=new URL(f.path==='index.html'?'':f.path,p.config.origin+'/');const r=await fetch(u,{redirect:'error',signal:AbortSignal.timeout(15000)});need(r.ok&&sha(Buffer.from(await r.arrayBuffer()))===f.sha256,'Actual served index/WASM hash '+f.path);}}
function preserve(){
 const script=String.raw`$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'; $p=Get-CimInstance Win32_Process -Filter 'ProcessId = 41276'; if($null -eq $p){@{present=$false;pid=41276}|ConvertTo-Json -Compress;exit 0};if($p.CreationDate.ToUniversalTime().ToString('o') -ne '2026-10-15T20:17:15.2346820Z'){throw 'Preserved Chrome process identity changed'}; $profile='C:\Users\louistrue\AppData\Local\Temp\ifclite-7292-resume-20261015';if(-not $p.CommandLine.Contains($profile)){throw 'Preserved profile changed'};$owners=@(Get-NetTCPConnection -State Listen -LocalPort 56792);if($owners.Count -eq 0 -or @($owners|Where-Object {$_.OwningProcess -ne 41276}).Count -ne 0){throw 'Preserved CDP owner changed'};@{present=$true;pid=$p.ProcessId;creation=$p.CreationDate.ToUniversalTime().ToString('o');profile=$profile;executable=$p.ExecutablePath;commandLine=$p.CommandLine}|ConvertTo-Json -Compress`;
 return JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{encoding:'utf8',timeout:15000})) as Record<string,unknown>;
}
async function preservedTarget(){if(preserve().present===false)return null;const r=await fetch('http://127.0.0.1:56792/json/list',{signal:AbortSignal.timeout(5000)});need(r.ok,'Preserved CDP metadata');const rows=await r.json()as Array<{id:string;url:string}>;const selected=rows.filter(x=>x.id==='CBC8877EFA5363F1C61EA45892D71C67');need(selected.length===1&&selected[0].url==='http://localhost:5274/?perfTrace=1&geomWorkers=4','Preserved target identity changed');return selected[0];}
function physicalGpu(v:{gpu:{devices:Array<{vendorId:number;deviceString:string}>;auxAttributes:Record<string,unknown>;featureStatus:Record<string,string>}}){const renderer=String(v.gpu.auxAttributes.glRenderer??'');need(/nvidia/i.test(renderer)&&!/swiftshader|llvmpipe|software|microsoft basic/i.test(renderer)&&v.gpu.featureStatus.webgpu?.startsWith('enabled')&&v.gpu.devices.some(d=>d.vendorId===0x10de),'Actual NVIDIA hardware WebGPU not proved');return renderer;}
async function rendererAdapter(page:Page){return raceWithTimeout(page.evaluate(()=>{const host=globalThis as unknown as{__ifc_lite_render_stats__?:()=>{adapter?:{vendor?:string;architecture?:string}|null}};return host.__ifc_lite_render_stats__?.()?.adapter??null;}),10000,'Actual initialized renderer adapter');}
async function ownedWitness(profile:string,port:number){
 const literal=profile.replace(/'/g,"''");const script=`$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';${readFileSync(join(D,'frame-gpu-owned-profile.ps1'),'utf8')}\n$rows=@(Get-OwnedChromeProcesses -Profile '${literal}' -BrowserRoot -RequireCompleteObservation);if($rows.Count -ne 1){throw 'Unique owned root required'};$p=$rows[0];$ls=@(Get-NetTCPConnection -State Listen -LocalPort ${port});if($ls.Count -eq 0 -or @($ls|Where-Object {$_.OwningProcess -ne $p.ProcessId}).Count -ne 0){throw 'Owned endpoint mismatch'};@{pid=$p.ProcessId;creation=$p.CreationDate.ToUniversalTime().ToString('o');profile='${literal}';commandLine=$p.CommandLine;executable=$p.ExecutablePath;port=${port}}|ConvertTo-Json -Compress`;
 return JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{encoding:'utf8',timeout:15000}))as Record<string,unknown>;
}
function rawPage(ids:number[]){
 type M={expressId:number;geometryItemId?:number;positions:Float32Array;normals:Float32Array;indices:Uint32Array;origin?:ArrayLike<number>;localToWorld?:ArrayLike<number>};
 type G={meshes:M[];coordinateInfo:unknown;totalTriangles:number;totalVertices:number;instancedGeometryHashes?:Map<number,bigint>};type Model={geometryResult?:G;ifcDataStore?:{entities:{count:number;expressId:ArrayLike<number>}}};
 const s=(globalThis as unknown as{__ifc_lite_viewer_store__?:{getState():{models:Map<string,Model>;geometryResult?:G;ifcDataStore?:Model['ifcDataStore']}}}).__ifc_lite_viewer_store__?.getState();if(!s||s.models.size!==1)throw Error('One canonical model required');const m=[...s.models.values()][0],g=m.geometryResult??s.geometryResult,data=m.ifcDataStore??s.ifcDataStore;if(!g||!data||!g.coordinateInfo)throw Error('Missing actual geometry/frame/datastore');
 const selected=g.meshes.filter(x=>ids.includes(x.expressId));
 const rawMeshes=[];
 for(const x of selected){
  if(!(x.positions instanceof Float32Array)||!(x.normals instanceof Float32Array)||!(x.indices instanceof Uint32Array))throw Error('Actual typed-array contract');
  const origin=Array.from(x.origin??[0,0,0]);const originF64BitsDecimal:string[]=[];
  for(const value of origin){const buffer=new ArrayBuffer(8);const view=new DataView(buffer);view.setFloat64(0,value,true);originF64BitsDecimal.push(view.getBigUint64(0,true).toString());}
  let localToWorldF64BitsDecimal:string[]|null=null;
  if(x.localToWorld){localToWorldF64BitsDecimal=[];for(const value of Array.from(x.localToWorld)){const buffer=new ArrayBuffer(8);const view=new DataView(buffer);view.setFloat64(0,value,true);localToWorldF64BitsDecimal.push(view.getBigUint64(0,true).toString());}}
  rawMeshes.push({expressId:x.expressId,geometryItemId:x.geometryItemId??null,positions:Array.from(x.positions),positionF32Bits:Array.from(new Uint32Array(x.positions.buffer,x.positions.byteOffset,x.positions.length)),normals:Array.from(x.normals),normalF32Bits:Array.from(new Uint32Array(x.normals.buffer,x.normals.byteOffset,x.normals.length)),indices:Array.from(x.indices),origin,originF64BitsDecimal,localToWorldF64BitsDecimal,localToWorld:x.localToWorld?Array.from(x.localToWorld):null});
 }
 return {coordinateFrame:'Canonical viewer Y-up; raw positions/origin and already-baked localToWorld metadata retained without reconstruction',coordinateInfo:g.coordinateInfo,entityCount:data.entities.count,entityIds:Array.from(data.entities.expressId).sort((a,b)=>a-b),totalTriangles:g.totalTriangles,totalVertices:g.totalVertices,meshCount:g.meshes.length,allMeshOwnerIds:[...new Set(g.meshes.map(x=>x.expressId))].sort((a,b)=>a-b),instancedOnlyIds:[...(g.instancedGeometryHashes?.keys()??[])].sort((a,b)=>a-b),selectedIds:ids,rawMeshes};
}
async function run(p:Pins,out:string){
 need(p.version===1,'Pin schema');verify(p);mkdirSync(out,{recursive:false});save(join(out,'pins.json'),p);
 await verifyHttp(p);const records:Record<string,unknown>[]=[];let owned:WindowsChrome|undefined;let browser:Awaited<ReturnType<typeof chromium.connectOverCDP>>|undefined;let context:BrowserContext|undefined;let page:Page|undefined;
 const receipt:Record<string,unknown>={status:'RUNNING_NOT_QUALIFIED',performanceClaim:false,geometryAcceptanceClaim:false,records};
 try{
  receipt.preservedBefore=preserve();receipt.preservedTargetBefore=await preservedTarget();
  for(const k of Object.keys(process.env))if(k.startsWith('VIEWER_BENCHMARK_'))throw Error('Unexpected inherited benchmark override '+k);
  process.env.VIEWER_BENCHMARK_GEOM_WORKERS='4';process.env.VIEWER_BENCHMARK_GPU_UPLOADS='0';process.env.VIEWER_BENCHMARK_CACHE_MODE='cold';
  owned=await launchWindowsChrome(findWindowsChrome(p.config.chromeExecutable),1);need(owned.cdpUrl!=='http://127.0.0.1:56792','Owned endpoint must be fresh');receipt.ownedBefore=await ownedWitness(owned.profileWin,Number(new URL(owned.cdpUrl).port));receipt.ownedEndpoint=owned.cdpUrl;
  browser=await chromium.connectOverCDP(owned.cdpUrl,{timeout:15000});receipt.browserVersion=browser.version();const session=await raceWithTimeout(browser.newBrowserCDPSession(),10000,'Owned CDP session');
  for(const fixture of p.config.fixtures){
   const dir=join(out,fixture.key);mkdirSync(dir);const record:Record<string,unknown>={key:fixture.key,kind:fixture.kind,fixtureSHA256:fileSha(fixture.path),status:'RUNNING_NOT_QUALIFIED'};records.push(record);const errors:string[]=[];const requests:string[]=[];let bp:ViewerBenchmarkPage|undefined;let proof:ReturnType<typeof installRuntimeProof>|undefined;
   try{
    verify(p);const before=await raceWithTimeout(session.send('SystemInfo.getInfo'),10000,'CDP GPU before');record.gpuBefore=before;physicalGpu(before);
    context=await raceWithTimeout(browser.newContext({viewport:{width:1400,height:1000}}),10000,'Owned context');proof=installRuntimeProof(context,p.config.origin,p.distFiles);await raceWithTimeout(proof.ready,10000,'Runtime routes');page=await raceWithTimeout(context.newPage(),10000,'Owned page');page.on('pageerror',e=>errors.push(String(e)));page.on('requestfailed',r=>{if(!r.url().endsWith('/_vercel/insights/script.js'))requests.push(`${r.url()}: ${r.failure()?.errorText}`);});bp=new ViewerBenchmarkPage(page,p.config.origin);
    const metrics=await raceWithTimeout(runColdSample(bp,{fixturePath:fixture.path,timeoutMs:fixture.timeoutMs,afterSetup:async()=>{await page!.bringToFront();const s=await page!.evaluate(()=>{const store=(globalThis as unknown as{__ifc_lite_viewer_store__?:{getState():{models:Map<unknown,unknown>;geometryMode:string;geometryModePendingReload:boolean;setGeometryMode(mode:'exact'):void}}}).__ifc_lite_viewer_store__;if(!store||store.getState().models.size!==0)throw Error('Exact policy requires canonical empty store');store.getState().setGeometryMode('exact');const s=store.getState();return{models:s.models.size,geometryMode:s.geometryMode,geometryModePendingReload:s.geometryModePendingReload,persistedMode:localStorage.getItem('ifc-lite-geometry-mode'),visible:document.visibilityState,focused:document.hasFocus(),crossOriginIsolated,sab:typeof SharedArrayBuffer!=='undefined'};});record.preUpload=s;need(s.models===0&&s.geometryMode==='exact'&&!s.geometryModePendingReload&&s.persistedMode==='exact'&&s.visible==='visible'&&s.focused&&s.crossOriginIsolated&&s.sab,'Fresh foreground isolated empty canonical model required');}}),fixture.timeoutMs+30000,'Canonical target FIRST fresh load');record.metrics=metrics;
    await page.waitForFunction(()=>((globalThis as unknown as{__ifc_lite_render_stats__?:()=>{frame?:{drawCalls?:number}}}).__ifc_lite_render_stats__?.()?.frame?.drawCalls??0)>0,{}, {timeout:15000});await raceWithTimeout(bp.refreshLoadTrace(),10000,'Trace refresh');const trace=bp.getLoadTrace();record.trace=trace;const ready=await probeMetadataRenderTrace(page);record.readiness=ready;need(ready&&!ready.invalid&&!ready.failed.length&&ready.ended&&['parser.complete','geometry.streamComplete','scene.finalize'].every(x=>ready.done.includes(x)),'Canonical completion/readiness');need(trace?.attrs?.loadPath==='wasm'&&!trace.spans.some(s=>s.name==='parser.failed'||s.attrs?.success===false)&&metrics.canvasHasContent,'Actual WASM and canvas content');if(fixture.requireFourWorkers)record.actualPool=requireFourWorkerPool(trace);
    const adapter=await rendererAdapter(page);record.adapterSource='actual initialized renderer GPUAdapter.info snapshot';record.adapter=adapter;need(adapter&&/nvidia/i.test(adapter.vendor??''),'UNKNOWN actual initialized renderer NVIDIA adapter not proved');
    const raw=await raceWithTimeout(page.evaluate(rawPage,fixture.selectedIds),30000,'Bounded selected raw arrays');save(join(dir,'browser-raw.json'),raw);need(fixture.selectedIds.every(id=>raw.rawMeshes.some(m=>m.expressId===id)),'UNKNOWN selected raw absent or instanced-only; no invented transform/mesh');need(raw.rawMeshes.every(m=>m.positions.length===m.normals.length&&m.indices.length%3===0&&m.origin.length===3),'Actual buffer shape');record.rawSHA256=fileSha(join(dir,'browser-raw.json'));
    await raceWithTimeout(proof.verify(p.wasmSha256),20000,'Actual delivered runtime bytes');record.runtimeResponses=proof.rows;record.runtimeRequests=proof.observedRequests;record.gpuHealth=await readGpuHealth(page,bp.getConsoleLogs());const health=record.gpuHealth as Awaited<ReturnType<typeof readGpuHealth>>;need(!health.contaminated&&!health.deviceLost&&!health.deviceReplacements&&!health.uncapturedErrors&&!health.instanceErrors,'GPU health');const after=await raceWithTimeout(session.send('SystemInfo.getInfo'),10000,'CDP GPU after');record.gpuAfter=after;physicalGpu(after);need(!errors.length&&!requests.length,'Actual page/network errors');await page.screenshot({path:join(dir,'viewer.png'),fullPage:true,timeout:10000});record.consoleLogs=bp.getConsoleLogs();need(bp.getConsoleLogs().some(line=>line.includes('geomMode=exact tier=medium')),'Actual loader exact/medium policy not observed');record.trace=bp.getLoadTrace();const finalHealth=await raceWithTimeout(readGpuHealth(page,bp.getConsoleLogs()),10000,'GPU after screenshot');record.gpuHealthAfterScreenshot=finalHealth;record.adapterAfterScreenshot=await rendererAdapter(page);need(record.adapterAfterScreenshot&&/nvidia/i.test((record.adapterAfterScreenshot as{vendor?:string}).vendor??''),'UNKNOWN late renderer NVIDIA adapter not proved');need(!finalHealth.contaminated&&!finalHealth.deviceLost&&!finalHealth.deviceReplacements&&!finalHealth.uncapturedErrors&&!finalHealth.instanceErrors,'Late GPU failure');verify(p);record.status='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED';
   }catch(error){record.status='PRESERVED_FAILURE_OR_UNKNOWN';record.error=String(error);if(page)try{await page.screenshot({path:join(dir,'failure.png'),timeout:5000});}catch(e){record.screenshotError=String(e);}throw error;
   }finally{record.runtimeResponses=proof?.rows??[];record.runtimeRequests=proof?.observedRequests??[];record.pageErrors=errors;record.requestFailures=requests;if(context){await raceWithTimeout(context.close(),10000,'Close owned sample context');context=undefined;page=undefined;}save(join(dir,'receipt.json'),record);}
  }
  await raceWithTimeout(session.detach(),5000,'Detach owned browser session');receipt.status='FRESH_OWNED_CHROME_RUNTIME_CAPTURE_COMPLETE_NOT_GEOMETRY_QUALIFICATION';
 }catch(error){receipt.status='PRESERVED_FAILURE_OR_UNKNOWN';receipt.error=String(error);process.exitCode=2;}
 finally{
  if(context)try{await raceWithTimeout(context.close(),10000,'Bounded fallback owned context cleanup');}catch(e){receipt.contextCleanupError=String(e);process.exitCode=2;}
  if(owned){try{receipt.ownedAfter=await ownedWitness(owned.profileWin,Number(new URL(owned.cdpUrl).port));}catch(e){receipt.ownedIdentityError=String(e);process.exitCode=2;}const e=await owned.dispose();receipt.ownedCleanupError=e;if(e)process.exitCode=2;}
  // No browser.close: only lifecycle utility retires verified fresh profile; never attach existing Chrome.
  try{receipt.preservedAfter=preserve();need(!(receipt.preservedBefore as {present?:boolean}|undefined)?.present||(receipt.preservedAfter as {present?:boolean}).present===true,'Observed protected Chrome disappeared');receipt.preservedTargetAfter=await preservedTarget();verify(p);}catch(e){receipt.finalGuardError=String(e);process.exitCode=2;}
  if(process.exitCode)receipt.status='PRESERVED_FAILURE_OR_UNKNOWN';receipt.outputFileSHA256=Object.fromEntries(walk(out).map(x=>[x,fileSha(x)]));save(join(out,'receipt.json'),receipt);
 }
}
const configPath=arg('--config'),pinsPath=arg('--pins');
if(process.argv.includes('--seal')){need(configPath&&pinsPath,'--seal --config FILE --pins NEW_FILE');seal(JSON.parse(readFileSync(configPath,'utf8')) as Config,resolve(pinsPath));}
else if(process.argv.includes('--verify-only')){need(pinsPath,'--verify-only --pins FILE');verify(JSON.parse(readFileSync(pinsPath,'utf8')) as Pins);console.log('SOURCE_RUNTIME_PINS_VERIFIED');}
else if(process.argv.includes('--run'))throw Error('Direct WSL CDP route disabled; use reviewed run-windows.py native transport');
else throw Error('Explicit --seal (filesystem only) or later authorized --run required; no implicit browser launch.');
