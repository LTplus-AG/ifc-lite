"""Deferred final-build binding and scratch helper translation; no browser/server launch."""
from pathlib import Path
import json,sys,subprocess,hashlib
D=Path(__file__).resolve().parent
if sys.argv[1:]!=['--bind-completed-build']:raise SystemExit('Explicit --bind-completed-build required')
c=json.loads((D/'config.template.json').read_text());qpath=Path(c['qualification']['path']);qb=qpath.read_bytes();q=json.loads(qb)
if q['status']!=c['qualification']['acceptedStatus']or not q['sourceUnchanged']or not q['wasmUnchanged']:raise RuntimeError('Completed final viewer build required')
b=json.loads(Path(c['buildReceiptPath']).read_text())
head=subprocess.check_output(['git','-C',c['root'],'rev-parse','HEAD'],text=True).strip()
if b['builtRevision']!=head:raise RuntimeError('Current source HEAD differs from actual final build')
for rel,h in q['sourceManifest'].items():
 if hashlib.sha256((Path(c['root'])/rel).read_bytes()).hexdigest()!=h:raise RuntimeError('Compiled source changed: '+rel)
subprocess.run(['node',str(D/'prepare_windows.mjs'),'--prepare-after-build'],check=True)
h=hashlib.sha256(qb).hexdigest();c['qualification']['sha256']=h;c['candidatePreparationSHA256']=h
with (D/'config.json').open('x')as f:f.write(json.dumps(c,indent=2)+'\n')
print('Deferred current-source config and scratch runtime prepared; no browser/server launched.')
