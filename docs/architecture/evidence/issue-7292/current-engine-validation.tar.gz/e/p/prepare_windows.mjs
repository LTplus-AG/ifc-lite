/** Deferred scratch helper translation only; never compiles product/source or launches Chrome. */
import ts from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/node_modules/typescript/lib/typescript.js';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const D='/tmp/7292-primary-functional-chrome-preparation-v2',R='/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69';
if(process.argv.slice(2).join(' ')!=='--prepare-after-build')throw Error('Explicit deferred preparation required');
const qualification=JSON.parse(readFileSync('/tmp/7292-main2d-primary-build-preparation-v1/viewer-run-v2/receipt.json'));
if(qualification.status!=='SOURCE_CURRENT_VIEWER_BUILD_TYPECHECK_AND_WASM_CONTRACT_COMPLETE_NOT_GEOMETRY_QUALIFICATION'||!qualification.sourceUnchanged||!qualification.wasmUnchanged)throw Error('Completed final build required');
const sha=b=>createHash('sha256').update(b).digest('hex');
const expected=JSON.parse(readFileSync(D+'/canonical-helper-pins.json'));
for(const [rel,h]of Object.entries(expected))if(sha(readFileSync(R+'/'+rel))!==h)throw Error('Reviewed canonical helper changed: '+rel);
const modules={
 'viewer-benchmark-page.mjs':R+'/tests/benchmark/viewer-benchmark-page.ts',
 'metadata-render-readiness.mjs':R+'/tests/benchmark/metadata-render-readiness.ts',
 'load-trace-metrics.mjs':R+'/tests/benchmark/load-trace-metrics.ts',
 'gpu-health.mjs':R+'/tests/benchmark/gpu-health.ts',
 'browser-cold-sample.mjs':R+'/scripts/perf/browser-cold-sample.ts',
 'browser-cold-teardown.mjs':R+'/scripts/perf/browser-cold-teardown.ts',
 'runtime-proof.mjs':D+'/runtime-proof.mts',
 'windows-capture.mjs':D+'/windows-capture.template.mts',
 'benchmark-upload-mode.mjs':R+'/scripts/lib/benchmark-upload-mode.mjs',
};
const rows=[];
for(const [name,source]of Object.entries(modules)){
 const before=readFileSync(source),text=before.toString('utf8').replaceAll('./metadata-render-readiness.js','./metadata-render-readiness.mjs').replaceAll('./load-trace-metrics.js','./load-trace-metrics.mjs').replaceAll('../../scripts/lib/benchmark-upload-mode.mjs','./benchmark-upload-mode.mjs');
 const result=source.endsWith('.mjs')?{outputText:text,diagnostics:[]}:ts.transpileModule(text,{fileName:source,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,verbatimModuleSyntax:false}});
 if(result.diagnostics.some(d=>d.category===ts.DiagnosticCategory.Error))throw Error('Scratch helper translation diagnostic: '+name);
 if(/(?:from\s*|import\s*)['"]@playwright\/test['"]/.test(result.outputText))throw Error('Windows must use resolved playwright-core; runtime test package import remains');
 const out=D+'/'+name;if(existsSync(out))throw Error('Fresh scratch module required: '+out);writeFileSync(out,result.outputText,{flag:'wx'});
 rows.push({source,sourceSHA256:sha(before),output:out,outputSHA256:sha(result.outputText),changes:'Only TypeScript erasure and local import paths; native template separately records transport adaptations'});
}
writeFileSync(D+'/runtime-transport.json',JSON.stringify({status:'SCRATCH_RUNTIME_MODULES_PREPARED_NOT_BROWSER_EXECUTED',typescriptCompilerSHA256:sha(readFileSync(R+'/node_modules/typescript/lib/typescript.js')),rows},null,2)+'\n',{flag:'wx'});
