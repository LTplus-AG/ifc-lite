"""WSL source verifier + proven Windows-node native-loopback runtime, no T3 changes."""
from pathlib import Path
import argparse,subprocess,json,hashlib,os,shutil
D=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true',required=True);ap.add_argument('--pins',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
pins=a.pins.resolve();out=a.out.resolve();pb=pins.read_bytes();p=json.loads(pb);R=Path(p['config']['root'])
if out.exists():raise RuntimeError('Fresh external output required')
if out.is_relative_to(R):raise RuntimeError('Output must remain outside source')
loader=str(R/'node_modules/tsx/dist/loader.mjs')
verify=['node','--import',loader,str(D/'chrome-current.mts'),'--verify-only','--pins',str(pins)]
subprocess.run(verify,check=True)
# Resolve package physically, rather than passing @playwright/test through pnpm symlinks to Windows.
version=json.loads((R/'node_modules/@playwright/test/package.json').read_text())['version']
core=(R/f'node_modules/.pnpm/playwright-core@{version}/node_modules/playwright-core').resolve(strict=True)
if json.loads((core/'package.json').read_text())['version']!=version:raise RuntimeError('Playwright-core version mismatch')
win=lambda path:subprocess.check_output(['wslpath','-w',str(path)],text=True).strip()
node=Path('/mnt/c/Program Files/nodejs/node.exe')
if not node.is_file():raise RuntimeError('Proven native Windows Node missing; no install or WSL CDP fallback')
args=[str(node),win(D/'windows-capture.mjs'),'--run','--pins',str(pins),'--expected-pins-sha256',hashlib.sha256(pb).hexdigest(),'--out',str(out),'--playwright-core',win(core),'--owned-helper',str(D/'frame-gpu-owned-profile.ps1'),'--wsl-root-win',win('/'),'--wsl-distro',os.environ['WSL_DISTRO_NAME'],'--wsl-node',str(Path(shutil.which('node')).resolve(strict=True))]
if any(k.startswith('VIEWER_BENCHMARK_')for k in os.environ):raise RuntimeError('Inherited benchmark overrides refused')
try:
 rc=subprocess.run(args).returncode
finally:
 subprocess.run(verify,check=True)
raise SystemExit(rc)
