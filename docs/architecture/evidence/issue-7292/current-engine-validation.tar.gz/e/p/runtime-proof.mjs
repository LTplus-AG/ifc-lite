import { createHash } from 'node:crypto';
export function expectedRuntimeAsset(url, origin, files) {
    const u = new URL(url);
    if (!/\.(?:m?js|wasm)$/.test(u.pathname))
        return null;
    if (u.origin !== new URL(origin).origin)
        throw Error(`Unexpected runtime origin ${u.origin}`);
    const path = decodeURIComponent(u.pathname).replace(/^\//, '');
    const file = files.find(f => f.path === path);
    if (!file)
        throw Error(`Runtime asset absent from frozen dist: ${path}`);
    return { path, sha256: file.sha256, kind: u.pathname.endsWith('.wasm') ? 'wasm' : 'js' };
}
/** Correctness-only interception. Never use this reader to claim unmodified network performance. */
export function installRuntimeProof(context, origin, files) {
    const rows = [], tasks = [], observedRequests = [];
    const ids = new WeakMap(), observed = new Set(), delivered = new Map();
    let nextId = 1;
    const id = (request) => { let n = ids.get(request); if (n === undefined) {
        n = nextId++;
        ids.set(request, n);
    } return n; };
    context.on('request', request => { if (/\.(?:m?js|wasm)$/.test(new URL(request.url()).pathname) && !observed.has(request)) {
        observed.add(request);
        observedRequests.push({ requestId: id(request), url: request.url() });
    } });
    const ready = context.route('**/*', async (route) => {
        const request = route.request(), url = request.url(), u = new URL(url);
        if (!/\.(?:m?js|wasm)$/.test(u.pathname)) {
            await route.continue();
            return;
        }
        const row = { requestId: id(request), url, kind: u.pathname.endsWith('.wasm') ? 'wasm' : 'js' };
        rows.push(row);
        delivered.set(request, row);
        let fetched;
        const task = (async () => {
            try {
                if (u.origin !== new URL(origin).origin)
                    throw Error(`Unexpected runtime origin ${u.origin}`);
                const response = await route.fetch({ maxRedirects: 0, timeout: 15000 });
                fetched = response;
                row.status = response.status();
                row.headers = response.headers();
                if (response.url() !== url)
                    throw Error('Runtime redirect/URL identity changed');
                if (row.headers['content-encoding'] && row.headers['content-encoding'] !== 'identity')
                    throw Error('Compressed runtime unsupported; refuse ambiguous decoded-body/original-header delivery');
                const bytes = await response.body();
                row.bytes = bytes.length;
                row.sha256 = createHash('sha256').update(bytes).digest('hex');
                const optional = u.pathname === '/_vercel/insights/script.js' && !u.search && row.status === 404 && !files.some(f => f.path === '_vercel/insights/script.js');
                if (optional)
                    row.optionalDeploymentAnalyticsAbsent = true;
                else {
                    const pin = expectedRuntimeAsset(url, origin, files);
                    row.path = pin.path;
                    if (row.status !== 200 || row.sha256 !== pin.sha256)
                        throw Error('Actual runtime status/body differs from frozen source');
                }
                // Actual route.fetch response only; no generated asset, fallback, re-request, or alternate bytes.
                await route.fulfill({ status: row.status, headers: row.headers, body: bytes });
                row.fulfilledOriginalResponse = true;
            }
            catch (error) {
                row.error = String(error);
                try {
                    await route.abort('failed');
                }
                catch (abortError) {
                    row.error += `; abort: ${String(abortError)}`;
                }
            }
            finally {
                if (fetched) {
                    try {
                        await fetched.dispose();
                    }
                    catch (error) {
                        row.error = (row.error ?? '') + `; response disposal: ${String(error)}`;
                    }
                }
            }
        })();
        tasks.push(task);
        await task;
    });
    return { rows, observedRequests, ready, async verify(wasmSha256) {
            await ready;
            await Promise.all(tasks);
            if ([...observed].some(request => { const r = delivered.get(request); return !r || r.error || r.fulfilledOriginalResponse !== true; }))
                throw Error('Browser runtime request escaped verified delivery');
            if (rows.some(r => !observedRequests.some(q => q.requestId === r.requestId)))
                throw Error('Route response lacks independent browser request event');
            const required = rows.filter(r => !r.optionalDeploymentAnalyticsAbsent);
            if (!required.some(r => r.kind === 'js') || !required.some(r => r.kind === 'wasm') || rows.some(r => r.error || r.fulfilledOriginalResponse !== true) || required.some(r => r.kind === 'wasm' && r.sha256 !== wasmSha256))
                throw Error('Actual fetched-and-delivered JS/WASM proof failed');
        } };
}
export function requireFourWorkerPool(trace) {
    const pools = trace?.spans.filter(s => s.name === 'geometry.pool') ?? [];
    if (trace?.attrs?.loadPath !== 'wasm' || trace.attrs.workerCount !== 4 || !pools.length || pools.some(s => s.attrs?.workerCount !== 4 || typeof s.end !== 'number' || !Number.isFinite(s.end)))
        throw Error('Actual completed WASM geometry.pool with four workers required');
    return pools;
}
