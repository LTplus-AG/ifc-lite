"""Expected Rustdoc-only output, never writes the repository's generated type file."""
def expected_dts(before):
    anchor = b' * Returns `undefined` when the mesh encloses no volume (no triangles survive\n'
    inserted = (b' * Returns `undefined` if an intersection, zone union or remainder exhausts\n'
                b" * the exact kernel's work budget. Completed pieces are not returned as a\n"
                b' * successful partial split, and a failed empty piece is not treated as disjoint.\n'
                b' *\n')
    old = b' * if (!split) return; // the mesh encloses no volume\n'
    new = b' * if (!split) return; // no usable complete split\n'
    if before.count(anchor) != 1 or before.count(old) != 1 or inserted in before:
        raise RuntimeError('Expected unique unregenerated zone Rustdoc preimage absent')
    return before.replace(anchor, inserted + anchor, 1).replace(old, new, 1)
