"""Deferred source/tool freeze: invoke only after native lease and temporary mutations end."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,subprocess,importlib.util,argparse,tomllib
from dts_contract import expected_dts
D=Path(__file__).resolve().parent
R=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69')
T=Path('/tmp/7292-main2d-primary-wasm-target-v1')
CONTROL=Path('/tmp/7292-current-main-rust-qualification-preparation-v3/run.py')
GUARD=Path('/tmp/7292-server-route-paired-diagnostic-preparation-v3/run.py')
H=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def scoped_native(control):
    spec=importlib.util.spec_from_file_location('scoped_native_guard',GUARD)
    guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
    return guard.foreign_native({'variants':[{'repo':str(R),'target':str(T)}]},control)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source-lease-released',action='store_true',required=True);ap.parse_args()
    spec=importlib.util.spec_from_file_location('controls',CONTROL);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    scoped_native(c)
    require(not (D/'preparation.json').exists(),'Fresh deferred seal required')
    require(not T.exists() and not T.is_symlink(),'New exclusive WASM target must be absent')
    patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=R)
    require(not patch,'Commit final source checkpoint after native PASS before sealing')
    pr=json.loads((D/'tool-prerequisites.json').read_bytes())
    tc=tomllib.loads((R/'rust-toolchain.toml').read_text())['toolchain']['channel']
    require(tc=='nightly-2025-11-15','Canonical toolchain changed')
    require('WASM_PACK_VERSION: v0.15.0' in (R/'.github/actions/setup-wasm-build/action.yml').read_text(),'Canonical wasm-pack changed')
    source=c.source_map(R)
    (D/'source-before.json').write_text(json.dumps(source,indent=2)+'\n');(D/'source-before.patch').write_bytes(patch)
    dts=R/'packages/wasm/pkg/ifc-lite.d.ts'
    require(dts.is_file() and not dts.is_symlink(),'Regular committed d.ts required')
    before=dts.read_bytes();expected=expected_dts(before)
    (D/'preimage-ifc-lite.d.ts').write_bytes(before);(D/'expected-ifc-lite.d.ts').write_bytes(expected)
    sourcePins={k:H(Path(k).read_bytes()) for k in pr['files'] if k!=str(dts)}
    toolPins=pr['localExecutableSHA256'];require(all(H(Path(k).read_bytes())==v for k,v in toolPins.items()),'Installed executable hash drift')
    owner={'repoAbsoluteIdentity':str(R.resolve()),'role':'PRIMARY_MAIN2D_WASM_ONLY_NEVER_NATIVE_OR_OTHER_CHECKOUT','run':str(D.parent),'sourceManifestSHA256':H(json.dumps(source,sort_keys=True).encode())}
    p={'status':'CURRENT_MAIN_FRESH_WASM_BUILD_FROZEN_UNRUN','repo':str(R),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sourceMap':source,'sourceManifestAliasContract':'Runtime receipt.sourceManifest equals this exact sourceMap','gitDiffSHA256':H(patch),'targetDirectory':str(T),'sharedControl':str(CONTROL),'rustup':'/home/louistrue/.cargo/bin/rustup','toolchain':tc,'wasmPack':'/home/louistrue/.nvm/versions/node/v24.21.0/lib/node_modules/wasm-pack/binary/wasm-pack','sourcePins':sourcePins,'plannedTargetOwner':owner,'targetMode':'CREATE_NEW_EXCLUSIVE_EMPTY_WASM_TARGET','dtsPreimageSHA256':H(before),'dtsExpectedSHA256':H(expected),'dtsPolicy':'Exact approved four Rustdoc lines plus example comment only; official generated expected bytes preserved, all evidence retained on failure'}
    files=[GUARD,*D.glob('*.py'),D/'PLAN.md',D/'tool-prerequisites.json',D/'source-before.json',D/'source-before.patch',D/'preimage-ifc-lite.d.ts',D/'expected-ifc-lite.d.ts',CONTROL,D.parent/'run.py',D.parent/'viewer.py',D.parent/'measure-wasm.mjs']
    p['pins']={**sourcePins,**toolPins,**{str(f):H(f.read_bytes()) for f in files}}
    require(source==c.source_map(R) and patch==subprocess.check_output(['git','diff','HEAD','--binary'],cwd=R) and dts.read_bytes()==before,'Source changed during seal')
    pb=(json.dumps(p,indent=2)+'\n').encode();(D/'preparation.json').write_bytes(pb);(D/'seal.json').write_text(json.dumps({'preparationSHA256':H(pb)},indent=2)+'\n')
    print(H(pb),len(source),'source files',len(p['pins']),'pins')
if __name__=='__main__':main()
