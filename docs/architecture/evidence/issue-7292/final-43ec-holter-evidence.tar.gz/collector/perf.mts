/** Offline prepared, fresh owned Windows Chrome per side/fixture/round. No implicit build/server/start. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
const DRIVER="/tmp/7292-current-passive-worker-pool-preparation-v35";
import {verifyTimingAuthority} from './timing-authority.mjs';
import {roundOrder,seededRand} from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/scripts/perf/ab-order.mjs';
import {readHostAdmission} from './partition-host.mts';
const arg=(n:string)=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
function need(v:unknown,m:string):asserts v{if(!v)throw Error(m);}
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
const controls=process.argv.includes('--control-only');
const out=arg('--out'),base=arg('--base-pins'),branch=arg('--branch-pins'),cohort=arg('--cohort-config');need(out&&base&&branch&&cohort&&process.argv.includes('--run-new-cohort'),'--run-new-cohort --out NEW --base-pins FILE --branch-pins FILE --cohort-config ACTUAL_BOUND_FILE');
type Pins={head:string;files:Record<string,string>;config:{fixtures:Array<{key:string;path:string;selectedIds:number[]}>}};
const inputs={base:{path:resolve(base),bytes:readFileSync(base)},branch:{path:resolve(branch),bytes:readFileSync(branch)}};
const p={base:JSON.parse(inputs.base.bytes.toString())as Pins,branch:JSON.parse(inputs.branch.bytes.toString())as Pins};
need(p.base.config.fixtures.length===p.branch.config.fixtures.length,'Same fixture scope');
const fixtures=p.base.config.fixtures.map(f=>f.key);need(fixtures.join(',')==='Holter'&&fixtures.every(k=>p.branch.config.fixtures.some(f=>f.key===k)),'Supplemental Holter only; mandatory FZK+ISSUE129 already completed separately');
for(const key of fixtures){const a=p.base.config.fixtures.find(f=>f.key===key)!,b=p.branch.config.fixtures.find(f=>f.key===key)!;need(sha(readFileSync(a.path))===sha(readFileSync(b.path)),'Same actual fixture bytes');need(a.selectedIds.length===0&&b.selectedIds.length===0,'Capture ALL flat output after timing');}
const cohortBytes=readFileSync(cohort),cohortInput=JSON.parse(cohortBytes.toString());
const timingBinding={cohortConfigPath:resolve(cohort),cohortConfigSHA256:sha(cohortBytes),workerPins:{base:{path:inputs.base.path,sha256:sha(inputs.base.bytes)},branch:{path:inputs.branch.path,sha256:sha(inputs.branch.bytes)}}};
type Authority={untilUTC:string;[key:string]:unknown};
function timingGuard():Authority{
 guard();const authority=verifyTimingAuthority(cohortInput.timingAuthority,readFileSync);
 need(sha(readFileSync(cohort))===sha(cohortBytes),'Cohort binding drift');
 need(cohortInput.purpose==='EXPLICIT_NEW_DIRECT_USER_7292_TIMING_SCHEDULE_NOT_OLD_CAPTURE'&&cohortInput.seed===7292&&cohortInput.iters===5,'Explicit new fivepair schedule input');
 const start=Date.parse(cohortInput.notBeforeUTC),end=Date.parse(cohortInput.notAfterUTC);need(Number.isFinite(start)&&Number.isFinite(end)&&end>start&&end-start<=30*60*1000&&Date.now()>=start&&Date.now()<end,'Actual declared idle window absent/notopen/expired');
 need(authority.opensUTC===cohortInput.notBeforeUTC&&authority.untilUTC===cohortInput.notAfterUTC,'Schedule differs from actual grant');
 for(const side of ['base','branch']as const){const approved=authority.sides[side];need(approved.pinsPath===inputs[side].path&&approved.pinsSHA256===sha(inputs[side].bytes),'Approved actual pins differ '+side);const binding=cohortInput.sides[side];need(binding.pinsPath===inputs[side].path&&binding.pinsSHA256===sha(inputs[side].bytes)&&binding.expectedHead===p[side].head,'Exact current side binding '+side);}
 return {untilUTC:cohortInput.notAfterUTC,notBeforeUTC:cohortInput.notBeforeUTC,scope:'Explicit affinity-controlled partition window; whole-host idle not claimed',authority};
}
// No output/cohort/order binding before actual matching builds, prior FZK qualification and explicit coordinator window.
// Canonical SAME source/build/prior-FZK verification MUST finish before order/output selection.
for(const side of ['base','branch']as const){
 const stdout=execFileSync('node',['--import','/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/node_modules/tsx/dist/loader.mjs',DRIVER+'/'+side+'/sample.mts','--verify-only','--pins',inputs[side].path],{timeout:120000});
 need(stdout.equals(Buffer.from('SOURCE_RUNTIME_PINS_VERIFIED\n')),'Actual current side/FZK prerequisites failed '+side);
}
const initialTimingAuthority=timingGuard();
need(p.base.head==='b0b670f0cfd704ceb7c78a622f5730d0cd9510de'&&p.branch.head==='43ecf3aa3e240e1a7c41c5c799212b60df010ebd','Exact final6ca/aca pair only');
const D=resolve(out);mkdirSync(D,{recursive:false});const order=roundOrder(5,seededRand(7292));const rows:Array<Record<string,unknown>>=[];
const receipt:Record<string,unknown>={status:'RUNNING_NOT_A_VERDICT',timingBinding,initialTimingAuthority,seed:7292,iters:controls?3:5,controlsOnly:controls,order,rows,basePinsSHA256:sha(inputs.base.bytes),branchPinsSHA256:sha(inputs.branch.bytes),identityLimitation:'All flat typed bytes+ownorigins+metadata SHA256; canonical per-owner instanced hashes/AABB/volume. Raw instanced buffer bytes not retained by canonical viewer; no complete instance byte-identity claim.',performanceMath:'Existing runColdSample metrics and trace spans; no new timing arithmetic.'};
function save(p:string,v:unknown){writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});}
function guard(){need(sha(readFileSync(cohort))===sha(cohortBytes),'Cohort inputs changed');for(const s of ['base','branch']as const){need(sha(readFileSync(inputs[s].path))===sha(inputs[s].bytes),'Pins drift '+s);for(const file of ['perf.mts','timing-authority.mjs','partition-host.mts','raw-stream-fingerprint.py']){const path=join(DRIVER,file);need(p[s].files[path]===sha(readFileSync(path)),'Timing protocol helper absent from side seal or changed '+file);}}}
try{
 for(const fixture of fixtures)for(let round=0;round<(controls?3:5);round++)for(const side of (controls?['base']as const:order[round])){
  guard();const timingBeforeHost=timingGuard();need(Date.now()+360000<Date.parse(timingBeforeHost.untilUTC),'Less than four minutes remain for one bounded Holter load/proof/cleanup; no new sample starts');let pre;let admissionAttempt=0;
  // No sample exists yet: wait for actual idle, retaining every observation. Never retry a measured/postchecked row.
  for(;;){
   timingGuard();pre=await readHostAdmission();save(join(D,`${fixture}-${round}-${side}-admission-${admissionAttempt++}.json`),pre);
   if(pre.quiet)break;
   need(Date.now()+1000<Date.parse(cohortInput.notAfterUTC),'Idle admission deadline; no sample launched');
   await new Promise(resolve=>setTimeout(resolve,1000));
  }
  save(join(D,`${fixture}-${round}-${side}-host-before.json`),pre);need(pre.quiet,'Actual host idle admission failed; preserve no timing verdict');
  const dir=join(D,`${fixture}-${round}-${side}`);
  const timingBeforeLaunch=timingGuard();
  const code=await new Promise<number>((resolve,reject)=>{const child=spawn('python3',[DRIVER+'/'+side+'/run-windows.py','--run','--pins',inputs[side].path,'--out',dir,'--fixture',fixture,'--timing-authority',cohortInput.timingAuthority.path,'--expected-timing-authority-sha256',cohortInput.timingAuthority.sha256],{stdio:'inherit'});child.once('error',reject);child.once('exit',code=>resolve(code??2));});
  need(code===0,'Native Windows sample failure/unknown, not replaced');need(!process.exitCode,'Sample failure/unknown, not replaced');
  const compositeBytes=readFileSync(join(dir,'composite-receipt.json')),composite=JSON.parse(compositeBytes.toString());need(composite.status==='NATIVE_CAPTURE_AND_FINAL_LINUX_SOURCE_VERIFICATION_COMPLETE_NOT_GEOMETRY_QUALIFICATION'&&Object.values(composite.gates).every(x=>x===true),'Native and final Linux verification composite required');const r=JSON.parse(readFileSync(join(dir,'receipt.json'),'utf8'));need(r.status==='FRESH_OWNED_CHROME_RUNTIME_CAPTURE_COMPLETE_NOT_GEOMETRY_QUALIFICATION','Actual complete sample required');need(r.records?.length===1&&r.records[0].passiveProof?.stage==='verified'&&!r.records[0].observerRetirementError,'Actual full-byte verified passive observer required');const caseDir=join(dir,fixture),affinityCase=JSON.parse(readFileSync(join(caseDir,'receipt.json'),'utf8'));need(affinityCase.partitionBefore?.mask===4095&&affinityCase.partitionAfter?.mask===4095&&affinityCase.partitionBefore.rows.length>0&&affinityCase.partitionAfter.rows.length>0,'Actual owned browser partition before/after required');const rawBytes=readFileSync(join(caseDir,'browser-raw.json.gz')),record=JSON.parse(readFileSync(join(caseDir,'receipt.json'),'utf8'));need(r.outputFileSHA256[join(caseDir,'browser-raw.json.gz')]===sha(rawBytes),'Actual complete compressed raw bound');const decoded=JSON.parse(execFileSync('python3',[DRIVER+'/raw-stream-fingerprint.py',join(caseDir,'browser-raw.json.gz')],{encoding:'utf8',maxBuffer:128*1024*1024,timeout:180000}));need(decoded.compressedSHA256===sha(rawBytes)&&decoded.decodedSHA256===record.rawStream.decodedSHA256&&record.rawStream.snapshotVersionsAndReferencesStable,'Full streamed raw identity differs');const fingerprint=decoded.fingerprint;save(join(caseDir,'geometry-fingerprint.json'),fingerprint);
  const post=await readHostAdmission();save(join(D,`${fixture}-${round}-${side}-host-after.json`),post);const timingAfter=timingGuard();need(post.quiet,'Postsample canonical host admission failed; no accepted row');need(Date.now()<Date.parse(timingAfter.untilUTC),'No sampled row accepted outside approved timing window');rows.push({fixture,round,side,timingBeforeHost,timingBeforeLaunch,timingAfter,metrics:record.metrics,trace:record.trace,actualPool:record.actualPool,geometry:fingerprint,rawSHA256:sha(rawBytes),rawEncoding:'gzip-json',decodedRawSHA256:decoded.decodedSHA256,runtimeResponses:record.runtimeResponses,hostBefore:pre,hostAfter:post,hostAfterQuiet:post.quiet,receiptSHA256:sha(readFileSync(join(dir,'receipt.json'))),compositeReceiptSHA256:sha(compositeBytes)});
 }
 guard();receipt.timingBeforeCompletion=timingGuard();receipt.status=controls?'SAME_SOURCE_PARTITION_CONTROLS_CAPTURED_REPORT_REQUIRED':'FIVE_MATCHED_INTERLEAVED_PAIRS_CAPTURED_REPORT_REQUIRED';receipt.geometryDifferencesRequireAdjudication=[];
 if(!controls)for(const fixture of fixtures)for(let round=0;round<5;round++){const pair=rows.filter(r=>r.fixture===fixture&&r.round===round);need(pair.length===2,'Missing pair');if(JSON.stringify(pair[0].geometry)!==JSON.stringify(pair[1].geometry))(receipt.geometryDifferencesRequireAdjudication as unknown[]).push({fixture,round,baseFingerprintSHA256:sha(JSON.stringify(pair.find(r=>r.side==='base')?.geometry)),branchFingerprintSHA256:sha(JSON.stringify(pair.find(r=>r.side==='branch')?.geometry)),fullFingerprintsRetainedInOriginalRows:true});}
}catch(error){receipt.status='PRESERVED_FAILURE_OR_UNKNOWN_NO_PERF_VERDICT';receipt.error=String(error);process.exitCode=2;}
finally{try{guard();if(receipt.status==='FIVE_MATCHED_INTERLEAVED_PAIRS_CAPTURED_REPORT_REQUIRED'||receipt.status==='SAME_SOURCE_PARTITION_CONTROLS_CAPTURED_REPORT_REQUIRED')receipt.timingAtCompletion=timingGuard();}catch(error){receipt.status='PRESERVED_FAILURE_OR_UNKNOWN_NO_PERF_VERDICT';receipt.finalGuardError=String(error);process.exitCode=2;}save(join(D,'receipt.json'),receipt);}
