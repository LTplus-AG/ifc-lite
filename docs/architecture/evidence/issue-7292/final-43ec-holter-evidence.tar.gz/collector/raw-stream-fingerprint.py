from pathlib import Path
import gzip,hashlib,json,sys
p=Path(sys.argv[1]);compressed=hashlib.sha256(p.read_bytes()).hexdigest()
with gzip.open(p,'rb')as f:data=f.read()
decoded=hashlib.sha256(data).hexdigest();r=json.loads(data);del data
flat=[]
for m in r['rawMeshes']:
 keys=[('expressId','expressId'),('geometryItemId','geometryItemId'),('positions','positionF32Bits'),('normals','normalF32Bits'),('indices','indices'),('origin','originF64BitsDecimal'),('localToWorld','localToWorldF64BitsDecimal')];value={a:m[b]for a,b in keys if b in m};flat.append(json.dumps(value,separators=(',',':'),ensure_ascii=False,allow_nan=False))
fingerprint={'flatTypedSHA256':hashlib.sha256('\n'.join(sorted(flat)).encode()).hexdigest(),'flatMeshCount':len(r['rawMeshes']),'allMeshCount':r['meshCount'],'totalTriangles':r['totalTriangles'],'totalVertices':r['totalVertices'],**{k:r[k]for k in ['instancedCanonicalHashes','instancedAabbs','instancedVolumes','coordinateInfo']}}
print(json.dumps({'fingerprint':fingerprint,'compressedSHA256':compressed,'decodedSHA256':decoded},separators=(',',':'),allow_nan=False))
