<!-- perf-ratchet-report -->

### Perf ratchet: all metrics within their ceilings

Measured at `ced41577dc4898bc257148889cee284d3da754dd`.

| Metric | Ceiling | Tolerance | Allowed | Measured | Change vs ceiling | Status |
| --- | ---: | :---: | ---: | ---: | ---: | --- |
| `bundle/engine-wasm-brotli` (bytes) | 2,299,706 | +0.50% | 2,311,204 | 2,302,261 | +2,555 (+0.11%) | ok: above ceiling, inside tolerance |
| `bundle/viewer-entry-js-bytes` (bytes) | 3,116,390 | +0.10% | 3,119,506 | 3,119,260 | +2,870 (+0.09%) | ok: above ceiling, inside tolerance |
| `bundle/viewer-eager-js-bytes` (bytes) | 19,244,128 | +0.10% | 19,263,372 | 19,254,858 | +10,730 (+0.06%) | ok: above ceiling, inside tolerance |

0 other metric(s) unchanged.

Informational, not gated:
- `bundle/viewer-entry-js-brotli`: 732,113 bytes (main-BdE2tobO.js)
- `bundle/viewer-eager-js-brotli`: 3,198,219 bytes (268 files, each compressed on its own)
