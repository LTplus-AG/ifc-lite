"""Read a completed canonical20-row cohort only; no host/browser/acceptance actions."""
from pathlib import Path
import argparse,json,hashlib,statistics,math
from validation import verify
H=lambda b:hashlib.sha256(b).hexdigest()
def need(v,m):
 if not v:raise RuntimeError(m)
def encoded(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def number(v):return type(v)in(int,float)and math.isfinite(v)and v>=0
def pct(base,branch):return None if base==0 else 100*(branch-base)/base
p=argparse.ArgumentParser();p.add_argument('--receipt',type=Path,required=True);p.add_argument('--receipt-sha256',required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();need(not a.out.exists(),'Fresh reporting output required')
try:
 data=a.receipt.read_bytes();need(H(data)==a.receipt_sha256,'Actual completed receipt SHA required');r=json.loads(data)
 need(r.get('status')=='FIVE_MATCHED_INTERLEAVED_PAIRS_CAPTURED_REPORT_REQUIRED'and not r.get('error')and not r.get('finalGuardError'),'Incomplete/failed cohort: NO REPORTING VERDICT')
 expected={'base':'b0b670f0cfd704ceb7c78a622f5730d0cd9510de','branch':'43ecf3aa3e240e1a7c41c5c799212b60df010ebd'}
 need(all(r['initialTimingAuthority']['authority']['sides'][side]['expectedHead']==head for side,head in expected.items()),'Wrong actual source pair')
 rows=r['rows'];need(r['iters']==5 and r['seed']==7292 and len(rows)==10,'Exactly10 accepted canonical rows required')
 need({(x['fixture'],x['round'],x['side'])for x in rows}=={(f,i,s)for f in ['Holter']for i in range(5)for s in ['base','branch']},'Missing/duplicate/foreign row')
 need(r.get('timingAtCompletion')and r.get('timingBeforeCompletion'),'Producer final timing gates incomplete')
 need(all(x['hostBefore']['quiet']is True and x['hostAfter']['quiet']is True and x['hostAfterQuiet']is True for x in rows),'Producer host gate incomplete')
 need(not a.out.exists(),'Fresh reporting output required')
 verified=verify(r,a.receipt.parent,expected)
 def measures(row):
  spans=[s for s in row['trace']['spans']if s['name']=='parser.worker']
  parse=spans[0]['end']-spans[0]['start']if len(spans)==1 and number(spans[0].get('start'))and number(spans[0].get('end'))and spans[0]['end']>=spans[0]['start']else None
  return {'parserWorkerSpanMs':parse,'geometryStreamingMs':row['metrics'].get('geometryStreamingMs'),'totalWallClockMs':row['metrics'].get('totalWallClockMs'),'firstVisibleGeometryMs':row['metrics'].get('firstVisibleGeometryMs'),'renderCompleteMs':row['metrics'].get('renderCompleteMs')}
 def aggregate(v):return statistics.median(v)if len(v)==5 and all(number(x)for x in v)else None
 summary={};paired=[];identities={};components=['flatTypedSHA256','flatMeshCount','allMeshCount','totalTriangles','totalVertices','instancedCanonicalHashes','instancedAabbs','instancedVolumes','coordinateInfo']
 for fixture in ['Holter']:
  summary[fixture]={};ids={}
  for side in ['base','branch']:
   side_rows=sorted([x for x in rows if x['fixture']==fixture and x['side']==side],key=lambda x:x['round']);values={k:[measures(x)[k]for x in side_rows]for k in ['parserWorkerSpanMs','geometryStreamingMs','totalWallClockMs','firstVisibleGeometryMs','renderCompleteMs']}
   summary[fixture][side]={k:{'medianMs':aggregate(v),'fiveValuesMs':v,'count':len(v),'allFiveAvailable':all(number(x)for x in v)}for k,v in values.items()}
   ids[side]={'flatTypedSHA256ByRound':[x['geometry']['flatTypedSHA256']for x in side_rows],'flatTypedStableWithinSide':len({x['geometry']['flatTypedSHA256']for x in side_rows})==1,'completeFingerprintStableWithinSide':len({H(encoded(x['geometry']))for x in side_rows})==1,'componentSHA256ByRound':{k:[H(encoded(x['geometry'][k]))for x in side_rows]for k in components},'countsByRound':[{k:x['geometry'][k]for k in ['flatMeshCount','allMeshCount','totalTriangles','totalVertices']}for x in side_rows]}
  for k in ['parserWorkerSpanMs','geometryStreamingMs','totalWallClockMs','firstVisibleGeometryMs','renderCompleteMs']:
   b=summary[fixture]['base'][k]['medianMs'];c=summary[fixture]['branch'][k]['medianMs'];summary[fixture][k+'MedianDifference']={'branchMinusBaseMs':None if b is None or c is None else c-b,'percentOfBase':None if b is None or c is None else pct(b,c)}
  differences=[]
  for i in range(5):
   b=next(x for x in rows if x['fixture']==fixture and x['round']==i and x['side']=='base');c=next(x for x in rows if x['fixture']==fixture and x['round']==i and x['side']=='branch');bm=measures(b);cm=measures(c);d={}
   for k in bm:
    d[k]={'baseMs':bm[k],'branchMs':cm[k],'branchMinusBaseMs':cm[k]-bm[k]if number(bm[k])and number(cm[k])else None,'percentOfBase':pct(bm[k],cm[k])if number(bm[k])and number(cm[k])else None}
   paired.append({'fixture':fixture,'round':i,'metrics':d});different=[k for k in components if encoded(b['geometry'][k])!=encoded(c['geometry'][k])];differences.append({'round':i,'differentComponents':different,'flatTypedBytesEqual':not('flatTypedSHA256'in different),'instancedCanonicalHashesEqual':not('instancedCanonicalHashes'in different),'instancedAabbsEqual':not('instancedAabbs'in different),'instancedVolumesEqual':not('instancedVolumes'in different)})
  for k in ['parserWorkerSpanMs','geometryStreamingMs','totalWallClockMs','firstVisibleGeometryMs','renderCompleteMs']:
   pairs=[x['metrics'][k]for x in paired if x['fixture']==fixture];ms=[x['branchMinusBaseMs']for x in pairs];pc=[x['percentOfBase']for x in pairs];summary[fixture][k+'PairedDifference']={'medianBranchMinusBaseMs':statistics.median(ms)if all(type(x)in(int,float)and math.isfinite(x)for x in ms)else None,'medianPairedPercent':statistics.median(pc)if all(type(x)in(int,float)and math.isfinite(x)for x in pc)else None}
  identities[fixture]={'withinSides':ids,'fiveActualPairs':differences}
 report={'status':'COMPLETED_SUPPLEMENTAL_HOLTER_TEN_ROW_DESCRIPTIVE_REPORT_NO_NEW_ACCEPTANCE_RULE','inputReceipt':str(a.receipt.resolve()),'inputReceiptSHA256':a.receipt_sha256,'sourcePair':{'base':'b0b670f0cfd704ceb7c78a622f5730d0cd9510de','branch':'43ecf3aa3e240e1a7c41c5c799212b60df010ebd'},'originalProducerStatus':r['status'],'seed':r['seed'],'iters':5,'acceptedRows':10,'metricDefinitions':{'parserWorkerSpanMs':'Single existing parser.worker trace span end-start, milliseconds. Includes authored waiting/serialization scope; not parser.parse compute-only duration, not native probe parse or metadataComplete-loadstart. Missing/ambiguous span gives null and no reporting verdict.','geometryStreamingMs':'Original stored runColdSample metric, canonical metricsFromLoadTrace aliases streamCompleteMs: milestone end minus LOAD start roundedms; NOT pure geometry-worker compute duration.','totalWallClockMs':'Original stored runColdSample metric, trace root end minus start roundedms; excludes untimed setup and later body proof/screenshots/strict cleanup.','overlap':'Parser and geometry overlap; these are not additive phase timings.','deltas':'Branch minus base; percentage relative to base. Median-of-five arm difference and median-of-five paired differences reported separately. No threshold/verdict invented.'},'mediansAndDeltas':summary,'pairedRows':paired,'geometryIdentity':identities,'producerGeometryDifferencesRequireAdjudication':{'count':len(r['geometryDifferencesRequireAdjudication']),'fullEvidence':'Bound original completed receipt geometryDifferencesRequireAdjudication field; component deltas reproduced above without copying raw arrays.'},'verifiedRetainedRows':verified,'identityScope':'Canonical fingerprint: all flat mesh exactposition/normalF32bit arrays,indices,originF64bits,localToWorldF64bits and owner/itemIDs, sorted per-mesh strings SHA256. Instanced identity only canonical per-owner hashes/AABBs/volumes; no original instancedbuffer bytes. No completeUV/text/material/texture/instancebyteidentity or universal geometry acceptance.','scopeLimits':['This report does not alter original schedule, admission, metric arithmetic or acceptance thresholds.','Changed geometry fingerprints require explicit scope/adjudication; not automatically a correctness failure or byte-identical performance result.','Read-only completed receipt reporting, no browser/host observations/newtiming rows/archive/source mutation.']}
 need(all(number(measures(row)[key])for row in rows for key in ['parserWorkerSpanMs','geometryStreamingMs','totalWallClockMs']),'Required canonical metric missing/ambiguous: NO_VERDICT')
 report['measurementVerdict']='DESCRIPTIVE_SIGNED_DELTAS_ONLY_NO_INVENTED_RUNTIME_THRESHOLD'
 report['geometryComparability']='UNSTABLE_WITHIN_SIDE_REQUIRES_ADJUDICATION'if any(not v['completeFingerprintStableWithinSide']for f in identities.values()for v in f['withinSides'].values())else'STABLE_WITHIN_EACH_SIDE_BASE_BRANCH_DIFFERENCES_REQUIRE_SCOPED_ADJUDICATION'
 report['mergeReadyClaim']=False
 a.out.mkdir();(a.out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');lines=['Completed five paired fresh native-Windows worker-pool samples for Holter. Descriptive results; source/host/window acceptance belongs to the original producer receipt.','parser.worker span duration and original geometryStreamingMs/totalWallClockMs are different scopes and are NOT additive.']
 for fixture in summary:
  lines.append(fixture)
  for k in ['parserWorkerSpanMs','geometryStreamingMs','totalWallClockMs','firstVisibleGeometryMs','renderCompleteMs']:
   b=summary[fixture]['base'][k]['medianMs'];c=summary[fixture]['branch'][k]['medianMs'];v=summary[fixture][k+'MedianDifference'];lines.append(f"  {k}: median base={b}, branch={c} ms; branch-base={v['branchMinusBaseMs']} ms ({v['percentOfBase']}%).")
  lines.append('  Geometry differing components by pair: '+json.dumps(identities[fixture]['fiveActualPairs'],separators=(',',':')))
 (a.out/'report.txt').write_text('\n'.join(lines)+'\n');print(json.dumps({'status':report['status'],'reportSHA256':H((a.out/'report.json').read_bytes())}))
except Exception as error:
 a.out.mkdir(exist_ok=True)
 failure={'status':'NO_VERDICT','reason':str(error),'inputReceipt':str(a.receipt),'inputReceiptSHA256':a.receipt_sha256,'expectedSourcePair':{'base':'b0b670f0cfd704ceb7c78a622f5730d0cd9510de','branch':'43ecf3aa3e240e1a7c41c5c799212b60df010ebd'},'partialRowsNotPooledOrCompared':True,'mergeReadyClaim':False}
 (a.out/'report.json').write_text(json.dumps(failure,indent=2)+'\n');print(json.dumps(failure))
