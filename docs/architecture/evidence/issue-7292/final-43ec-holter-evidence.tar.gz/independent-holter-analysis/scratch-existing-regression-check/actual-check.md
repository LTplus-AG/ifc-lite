<!-- viewer-benchmark-report -->
## Viewer benchmark

✅ No threshold regressions detected.

### Holter

Baseline recorded 2026-10-18T11:11:20.435Z on LOCAL native Windows NVIDIA Blackwell DPR1.5 six-core affinity; explicit integrated CPU protocol.

> ⚠ This baseline is not CI-recorded (no CI environment tag), so the deltas below may reflect a machine/metric-era mismatch rather than a code change. Refresh it via the Benchmark workflow (`record_baseline`).

| Metric | Current | Baseline | Delta | Threshold | Status |
|---|---|---|---|---|---|
| firstBatchWaitMs | 486ms | 472ms | +3.0% | +50% | ✅ |
| firstVisibleGeometryMs | 881ms | 884ms | -0.3% | +50% | ✅ |
| streamCompleteMs | 2339ms | 2342ms | -0.1% | +50% | ✅ |
| spatialReadyMs | 2405ms | 2416ms | -0.5% | +50% | ✅ |
| metadataCompleteMs | 2786ms | 2849ms | -2.2% | +50% | ✅ |
| totalWallClockMs | 3010ms | 3083ms | -2.4% | +50% | ✅ |

Refresh the baseline from a CI run: dispatch the Benchmark workflow with `record_baseline`, download the `benchmark-baseline` artifact, and commit `baseline.json` (see tests/benchmark/README.md).
