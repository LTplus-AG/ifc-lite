"""Read-only verification of the existing perf.mts receipt and retained rows."""
from pathlib import Path
import hashlib,json,datetime,math,gzip
H=lambda b:hashlib.sha256(b).hexdigest()
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def check(ok,msg):
 if not ok:raise RuntimeError(msg)
def time(v):return datetime.datetime.fromisoformat(v.replace('Z','+00:00')).timestamp()
def verify(r,folder,heads,controls=False):
 pins={};owners={};authority=r['initialTimingAuthority']['authority'];lo=time(authority['opensUTC']);hi=time(authority['untilUTC']);check(0<hi-lo<=1800 and authority.get('resourceConditionsWaived')is False,'Current actual unwaived lease required')
 def load(p,h=None):
  b=Path(p).read_bytes()
  if h:check(H(b)==h,'Retained row hash mismatch: '+str(p));pins[str(p)]=h
  return json.loads(b)
 def timing(x):check(x['authority']==authority and time(x['notBeforeUTC'])==lo and time(x['untilUTC'])==hi,'Lease changed across row/completion')
 if not controls:
  actual=load(authority['authorityPath'],authority['authoritySHA256']);larger=actual['largerModelRequest'];request=load(larger['path'],larger['sha256']);check(request['item']['createdBy']=='user' and request['item']['text']=='maybe test on larger models? dont know if issue 129 is relevant','Actual larger-model request required');control=actual['sameSourceControlEvidence'];applicability=load(control['path'],control['sha256']);check(applicability['status']=='COMPLETED_HOLTER_CONTROLS_TRANSFER_EXACT_TIMED_BODY_AND_COMPLETE_SERIALIZATION_EQUIVALENCE','Actual completed-control applicability proof missing');amendment=actual['measurementProtocolAmendment'];approved=load(amendment['path'],amendment['sha256']);check(approved['item']['createdBy']=='user' and approved['item']['text'].endswith('Approve integrated CPU protocol'),'Actual explicit integrated CPU approval required');policy=actual['partitionPolicy'];check(load(policy['path'],policy['sha256'])['version']=='physical-ccd0-integrated-budget-v1','Predeclared amended policy hash/version mismatch');check(actual['noConcurrentOwnedBrowserCapture'] is True and actual['noSharedHostHold'] is True,'Actual owned-browser window scope differs')
 for x in [r['initialTimingAuthority'],r['timingBeforeCompletion'],r['timingAtCompletion']]:timing(x)
 for side,head in heads.items():
  p=authority['sides'][side];check(p['expectedHead']==head and p['pinsSHA256']==r[side+'PinsSHA256'],'Source/runtime seal mismatch');check(load(p['pinsPath'],p['pinsSHA256'])['head']==head,'Sealed source head mismatch')
 check(len(r['order'])==5 and all(sorted(x)==['base','branch']for x in r['order']),'Original canonical interleaved order missing');check([(x['fixture'],x['round'],x['side'])for x in r['rows']]==([(f,i,'base')for f in ['Holter']for i in range(3)]if controls else [(f,i,s)for f in ['Holter']for i in range(5)for s in r['order'][i]]),'Accepted rows differ from actual declared schedule')
 for row in r['rows']:
  f,i,s=row['fixture'],row['round'],row['side'];d=folder/f'{f}-{i}-{s}'
  for h in [row['hostBefore'],row['hostAfter']]:
   check(h['quiet']is True and h['policy']['minimumLinuxKiB']==41943040 and h['policy']['maximumWindowsCpuPercent']==10,'Canonical host policy/gates missing');check(h['policy']['version']==('physical-ccd0-controlled-load-v1' if controls else 'physical-ccd0-integrated-budget-v1')and h['policy']['wholeHostIdleClaim']is False,'Explicit new partition policy required');check(h['linux']['MemAvailableKiB']>=41943040 and isinstance(h['linux']['activeGraphs'],list),'Memory/observed workload evidence incomplete');check(len(h['windows'])==3,'Three partition intervals required');
   for w in h['windows']:
    counters=w['physicalProcessorCounters'];check(len(counters)==24 and {x['instance']for x in counters}=={'0,'+str(i)for i in range(24)},'Complete actual physical processor instances required');check(all(x['status']in[0,1]and math.isfinite(x['value'])and 0<=x['value']<=100 for x in counters),'Invalid physical processor counter');mean=sum(x['value']for x in counters if int(x['instance'].split(',')[1])<12)/12;check(abs(mean-w['benchmarkPartitionProcessorPercent'])<1e-9 and (not controls or mean<=10),'Actual measured benchmark-domain counter mismatch or strict control exceeds limit');check(math.isfinite(w['totalProcessorPercent'])and 0<=w['totalProcessorPercent']<=100,'Whole-host observation missing')
   means=[w['benchmarkPartitionProcessorPercent'] for w in h['windows']];integrated=sum(means)/3
   if not controls:check(abs(integrated-h['partitionMeanCPU'])<1e-9 and integrated<=10 and abs(max(means)-h['partitionPointwiseMaximumCPU'])<1e-9,'Approved integrated budget or retained pointwise maximum differs')
   check(lo<=time(h['capturedAt'])<hi,'Host admission outside actual lease')
  for k in ['timingBeforeHost','timingBeforeLaunch','timingAfter']:timing(row[k])
  comp=load(d/'composite-receipt.json',row['compositeReceiptSHA256']);check(comp['status']=='NATIVE_CAPTURE_AND_FINAL_LINUX_SOURCE_VERIFICATION_COMPLETE_NOT_GEOMETRY_QUALIFICATION'and comp['gates']and all(v is True for v in comp['gates'].values()),'Incomplete native/source/protected/cleanup composite');check(comp['nativeRequirements']['pass']and comp['nativeProcess']['status']==0 and comp['pinsSHA256']==r[s+'PinsSHA256'],'Native gate/source seal mismatch');check(lo<=time(comp['nativeProcess']['startedUTC'])<=time(comp['nativeProcess']['finishedUTC'])<hi,'Actual native capture outside lease')
  for k in ['sourceBefore','sourceAfter']:
   check(comp[k]['status']==0,'Actual source verification failed');p=comp[k]['stdout'];b=Path(p['path']).read_bytes();check(H(b)==p['sha256']and b==b'SOURCE_RUNTIME_PINS_VERIFIED\n','Source verification marker/hash mismatch');pins[p['path']]=p['sha256']
  native=load(d/'receipt.json',row['receiptSHA256']);check(native['compiledArtifactRevision']==heads[s]and native['observedCheckoutHead']==heads[s]and native['ownedCleanupError']is None,'Actual capture source/cleanup mismatch');check(len(native['records'])==1 and native['records'][0]['passiveProof']['stage']=='verified'and not native['records'][0].get('observerRetirementError'),'Full-byte passive protocol incomplete')
  transport=native['largeFileTransport'];check(native['largeFileCleanupError'] is None and transport['cleaned'] is True and transport['sha256']==transport['finalSHA256']=='d8cc92c00ba634d9f25f3d00185136cbc34f3b14f2cc552634551997ddc148f8' and transport['bytes']==177465622 and len(transport['attempts'])==1 and transport['attempts'][0]['observed']['size']==177465622,'Native staged whole IFC identity/event/cleanup mismatch')
  proof=native['records'][0]['passiveProof'];check(proof['errors']==[]and proof['setupErrors']==[]and proof['coreErrors']==[]and proof['verified'],'Native passive errors or missing full body proof');dist={x['path']:x for x in load(authority['sides'][s]['pinsPath'])['distFiles']}
  for body in proof['verified']:
   expected=dist[body['path']];payload=body['payloadCompletion'];certificate=body['certificate'];check(body['bytes']==expected['bytes']==payload['expectedBytes']==payload['actualBytes'] and body['sha256']==expected['sha256']==payload['expectedSHA256']==payload['actualSHA256'],'Delivered complete body bytes/hash differ from sealed dist');check(body['requestId']==payload['requestId']==certificate['requestId'] and certificate['status']==200 and payload['source']=='original-requestId-full-expected-body','Original same-request-ID status/body proof incomplete')
  check(any(x['path'].endswith('.wasm')for x in proof['verified']),'Original full WASM body missing');check(len(proof['requests'])==len(proof['verified']) and {(x['requestId'],x['url'],x['phase'])for x in proof['requests']}=={(x['requestId'],x['url'],x['phase'])for x in proof['verified']},'Any original required runtime request lacks complete original body proof')
  record=load(d/f/'receipt.json');
  for when in ['partitionBefore','partitionAfter']:
   a=record[when];check(a['mask']==4095 and a['rows']and len({x['pid']for x in a['rows']})==len(a['rows'])and all(x['mask']==4095 and x['pid']>0 and time(x['creation'])>0 for x in a['rows']),'Actual owned browser child affinity evidence incomplete')
  check(record['status']=='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED'and record['pageErrors']==[]and record['gpuHealth']['contaminated']is False and record['gpuHealthAfterScreenshot']['contaminated']is False,'Actual case/graphics gates incomplete');check(record['metrics']==row['metrics']and record['trace']==row['trace']and record['actualPool']==row['actualPool'],'Metric/trace/pool row mismatch');pool=[x for x in row['actualPool']if x['name']=='geometry.pool'];check(pool and all(x['attrs']['workerCount']==4 for x in pool),'Actual four-worker pool missing');rawpath=d/f/'browser-raw.json.gz';compressed=rawpath.read_bytes();check(H(compressed)==row['rawSHA256'] and row['rawEncoding']=='gzip-json','Complete compressed RAW hash/encoding mismatch');decoded=gzip.decompress(compressed);check(H(decoded)==row['decodedRawSHA256']==record['rawStream']['decodedSHA256'] and len(decoded)==record['rawStream']['decodedBytes'],'Complete decoded RAW differs');raw=json.loads(decoded);del decoded,compressed;pins[str(rawpath)]=row['rawSHA256'];check(record['rawStream']['allFlatMeshesRetained']==len(raw['rawMeshes']) and record['rawStream']['snapshotVersionsAndReferencesStable'] is True and record['rawSHA256']==row['rawSHA256'],'Full streamed geometry/shape/source snapshot proof incomplete');check(native['outputFileSHA256'][str(rawpath)]==row['rawSHA256'],'Raw output not bound to capture');check(load(d/f/'geometry-fingerprint.json')==row['geometry'],'Retained fingerprint differs')
  grouped={};flat=[]
  for m in raw['rawMeshes']:
   keys=[('expressId','expressId'),('geometryItemId','geometryItemId'),('positions','positionF32Bits'),('normals','normalF32Bits'),('indices','indices'),('origin','originF64BitsDecimal'),('localToWorld','localToWorldF64BitsDecimal')];value={a:m[b]for a,b in keys if b in m};text=json.dumps(value,separators=(',',':'),ensure_ascii=False,allow_nan=False);flat.append(text);grouped.setdefault(str(m.get('expressId')),[]).append(text)
  actualFingerprint={'flatTypedSHA256':H('\n'.join(sorted(flat)).encode()),'flatMeshCount':len(raw['rawMeshes']),'allMeshCount':raw['meshCount'],'totalTriangles':raw['totalTriangles'],'totalVertices':raw['totalVertices'],**{k:raw[k]for k in ['instancedCanonicalHashes','instancedAabbs','instancedVolumes','coordinateInfo']}};check(actualFingerprint==row['geometry'],'Independent full fingerprint differs');per={'flat':{k:{'meshCount':len(v),'typedSHA256':H('\n'.join(sorted(v)).encode())}for k,v in grouped.items()}}
  for k in ['instancedCanonicalHashes','instancedAabbs','instancedVolumes']:
   per[k]={}
   for owner,value in raw[k]:per[k].setdefault(str(owner),[]).append(value)
  owners[(f,i,s)]=per
 if controls:return {'retainedRowPins':pins,'actualCompleteWorkerHostSourceCleanupLeaseChecks':True,'controlOnly':True}
 result={}
 for f in ['Holter']:
  result[f]=[]
  for i in range(5):
   b=owners[(f,i,'base')];c=owners[(f,i,'branch')];diff={k:[{'owner':owner,'base':b[k].get(owner),'branch':c[k].get(owner)}for owner in sorted(set(b[k])|set(c[k]))if enc(b[k].get(owner))!=enc(c[k].get(owner))]for k in b};result[f].append({'round':i,'perOwnerDifferences':diff})
 return {'retainedRowPins':pins,'actualCompleteWorkerHostSourceCleanupLeaseChecks':True,'ownerDifferences':result}
