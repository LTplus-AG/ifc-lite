from pathlib import Path
import hashlib,json,subprocess
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();old=Path('/tmp/7292-current-passive-worker-pool-preparation-v34');new=Path('/tmp/7292-current-passive-worker-pool-preparation-v35');new.mkdir();pins=json.loads((old/'preparation-pins.json').read_text())
for rel,h in pins.items():
 p=old/rel;assert H(p)==h;q=new/rel;q.parent.mkdir(parents=True,exist_ok=True);s=p.read_text().replace(str(old),str(new))
 if rel.endswith('windows-capture.template.mts'):s=s.replace('if(!Array.isArray(request)&&request.chunkOnly)return rawMeshes;','if(!Array.isArray(request)&&request.chunkOnly)return JSON.stringify(rawMeshes);')
 if rel.endswith('/raw-stream.mjs'):
  oldcall='const rows=await page.evaluate(reader,{selectedIds:[],start,end,chunkOnly:true,snapshotToken:token});';newcall="const payload=await page.evaluate(reader,{selectedIds:[],start,end,chunkOnly:true,snapshotToken:token});if(typeof payload!=='string')throw Error('Complete JSON raw chunk string required');const rows=JSON.parse(payload);";assert oldcall in s;s=s.replace(oldcall,newcall)
 q.write_text(s)
for side in ['base','branch']:
 p=new/side/'preparation-pins.json';d=json.loads(p.read_text());p.write_text(json.dumps({rel:H(new/side/rel)for rel in d},indent=2)+'\n')
(new/'preparation-pins.json').write_text(json.dumps({rel:H(new/rel)for rel in pins},indent=2)+'\n');d=Path('/tmp/7292-partition-research-v2/binding-holter-v35');d.mkdir();s=Path('/tmp/7292-partition-research-v2/binding-holter-v34/bind-timing.py').read_text().replace(str(old),str(new));(d/'bind-timing.py').write_text(s);(d/'preparation-sha256.json').write_text(json.dumps({str(d/'bind-timing.py'):H(d/'bind-timing.py')}));prior={'base':Path('/tmp/7292-finalb0-base-fzk-passive-qualification-v3/composite-receipt.json'),'branch':Path('/tmp/7292-final43ec-candidate-fzk-passive-qualification-v1/composite-receipt.json')};inv=Path('/tmp/7292-partition-protected-inventory-v1/protected-user-binding.json')
for side in ['base','branch']:subprocess.run(['python3',str(d/'bind-timing.py'),'--side',side,'--prior-fzk',str(prior[side]),'--prior-fzk-sha256',H(prior[side]),'--inventory-binding',str(inv),'--inventory-sha256',H(inv),'--out',str(d/(side+'-binding'))],check=True)
print('POST_TIMING_FULL_RAW_STRING_WIRE_BOTH_SIDES_BOUND')
