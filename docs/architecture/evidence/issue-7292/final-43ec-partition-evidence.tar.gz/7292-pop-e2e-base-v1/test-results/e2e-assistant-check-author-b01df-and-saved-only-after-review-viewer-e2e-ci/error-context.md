# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/assistant-check-authoring.e2e.spec.ts >> assistant check drafts are dry-run natively and saved only after review
- Location: tests/e2e/assistant-check-authoring.e2e.spec.ts:71:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Assistant', exact: true })
Expected substring: "2 specifications · 1 requirement not checkable"
Received string:    "AssistantWhere the Assistant opens: Below the source panelModels and new IFC filesCurrent1 of 1 rows attachedEvidence detailsModels and new IFC filesCaptured workspace evidenceFrozen evidence: 1 of 1 rows includedRows represent model load reports. Unavailable diagnostics are not clean loads.2026-10-18T10:12:07.132ZModels loaded at capture: 1 of 1 metadata entriesLoaded model metadata does not establish which models an analysis evaluated.AC20-FZK-Haus.ifc (d98ed20d-f9ea-4f10-b64f-e9f8e274d4da)AC20-FZK-Haus.ifc:b4b6b144fd02d2eaInspect evidence sent to the model{\"source\":\"loadReport\",\"capturedAt\":\"2026-10-18T10:12:07.132Z\",\"models\":[{\"id\":\"d98ed20d-f9ea-4f10-b64f-e9f8e274d4da\",\"name\":\"AC20-FZK-Haus.ifc\",\"fingerprint\":\"AC20-FZK-Haus.ifc:b4b6b144fd02d2ea\"}],\"totalModels\":1,\"modelMetadataTruncated\":false,\"sourceAvailability\":\"available\",\"reportProvenance\":\"unknown\",\"totalRows\":1,\"includedRows\":1,\"sampled\":false,\"projectionTruncated\":false,\"evidence\":{\"summary\":{\"kind\":\"model-load-reports\",\"modelCount\":1,\"loadReportsAvailable\":true,\"nativeNewIfc\":{\"kind\":\"native-new-ifc-scaffold\",\"schemas\":[\"IFC4\",\"IFC4X3\"],\"LengthUnit\":[\"METRE\",\"MILLIMETRE\"],\"operations\":[\"project\",\"addIfcBuildingStorey\",\"toIfc\"],\"suppliedFields\":[\"Name\",\"Schema\",\"LengthUnit\",\"Description\",\"Author\",\"Organization\",\"Currency\",\"storeys.Name\",\"storeys.Elevation\"],\"nativeDefaults\":{\"SiteName\":\"Site\",\"BuildingName\":\"Building\",\"GUIDs\":\"native generated\",\"timestamp\":\"native preparation time\"},\"existingModelFacts\":false,\"publication\":\"explicit file download; optional primary viewer load request is not load completion or Undo\",\"limitation\":\"No product geometry, currency, units, elevations or engineering requirements may be inferred.\"},\"diagnosticsAvailable\":1,\"diagnosticsUnavailable\":0,\"cleanLoads\":0,\"limitations\":\"Load diagnostics describe the original load, not validation of later edits. Affected entities are only those supplied by native diagnostics; missing diagnostics never mean clean.\"},\"rows\":[{\"citation\":\"E1\",\"data\":{\"modelId\":\"d98ed20d-f9ea-4f10-b64f-e9f8e274d4da\",\"name\":\"AC20-FZK-Haus.ifc\",\"schemaVersion\":\"IFC4\",\"sourceFileName\":\"AC20-FZK-Haus.ifc\",\"fileSize\":2526511,\"loadedAt\":1792318324174,\"loadFormat\":\"ifc\",\"loadPath\":\"wasm\",\"skipSmallCuts\":true,\"diagnosticsAvailable\":true,\"diagnostics\":{\"schemaVersion\":3,\"totalCsgFailures\":0,\"productsWithFailures\":0,\"hostsWithOpenings\":9,\"classification\":{\"rectangular\":29,\"diagonal\":0,\"nonRectangular\":2,\"total\":31},\"failuresByReason\":[],\"silentNoOps\":0,\"rectFast\":{\"fired\":1,\"openingsCut\":1,\"deferHostNotBox\":0,\"deferNotThrough\":0,\"deferOffFace\":0,\"deferNearEdge\":0,\"deferNoOpenings\":0,\"deferTooManyOpenings\":0},\"oversizedRefDrops\":0,\"worstHosts\":[],\"totalUnsupportedItems\":0,\"unsupportedItemsByType\":[]},\"actions\":[\"Loaded in fast geometry mode (small cuts skipped) — small openings may be missing; reload in full-fidelity mode for complete geometry.\"],\"affectedEntities\":[],\"isClean\":false}}]}}Ask about these resultsAnswers cite attached rows as [E1], [E2]… and never change native results.Prepare a new native IFC project and storeys using the schema, units and elevations I supply; ask for any missing input.Explain the load warnings and their likely causesPrepare a model authoring proposal for review: Draft IDS specifications for review: Draft information rules (uniqueness, counts, comparisons) for review: Build a list of walls with their area and fire ratingChart element counts by IFC classNo AI model is configured. Add an API key and select a model, or configure models for the server proxy.Draft IDS with toolsThe agent looks every IFC name up, changes a draft only through checked operations, and shows you each change before anything is kept. Write the requirements in the message box, then start.Draft IDS from the messageReview report draftTurn the latest answer into an editable document that keeps its captured evidence. Verify claims and citations before saving.Narrative languageEnglishGermanFrenchItalianSpanishDutchPortugueseDanishSwedishNorwegian BokmålFinnishPolishCzechDraft report with AIReport namePrepare report draftStorage and backupDownload library backupImport library backupRetry all librariesDownload preserved originalsRemove migrated legacy copiesCheck storage usageProtect browser storageAnswer languageEnglishGermanFrenchItalianSpanishDutchPortuguesePolishCzechSwedishDanishFinnishNorwegian BokmålJapaneseChineseKoreanNames and values from the model keep their original spelling.Attach selectionAttach viewAsk about these resultsDraft IDS specifications for review: external walls flagged, slabs at least 200 mm; escape doors open outwards.No model configuredClaude Opus 5.5$$$1MClaude Fable 5.1$$$1MClaude Sonnet 5.5$$1MClaude Haiku 4.5$200KGPT-6 Astra$$$1MGPT-6.1 Sol$$1MGPT-6 Luna$1MGPT-5.3 Codex$$400KSend"
Timeout: 5000ms

Call log:
  - Expect "toContainText" getByRole('region', { name: 'Assistant', exact: true }) with timeout 5000ms
  - waiting for getByRole('region', { name: 'Assistant', exact: true })
    14 × locator resolved to <section aria-label="Assistant" class="h-full min-h-0 min-w-0 flex flex-col overflow-y-auto bg-background text-foreground">…</section>
       - unexpected value "AssistantWhere the Assistant opens: Below the source panelModels and new IFC filesCurrent1 of 1 rows attachedEvidence detailsModels and new IFC filesCaptured workspace evidenceFrozen evidence: 1 of 1 rows includedRows represent model load reports. Unavailable diagnostics are not clean loads.2026-10-18T10:12:07.132ZModels loaded at capture: 1 of 1 metadata entriesLoaded model metadata does not establish which models an analysis evaluated.AC20-FZK-Haus.ifc (d98ed20d-f9ea-4f10-b64f-e9f8e274d4da)AC20-FZK-Haus.ifc:b4b6b144fd02d2eaInspect evidence sent to the model{"source":"loadReport","capturedAt":"2026-10-18T10:12:07.132Z","models":[{"id":"d98ed20d-f9ea-4f10-b64f-e9f8e274d4da","name":"AC20-FZK-Haus.ifc","fingerprint":"AC20-FZK-Haus.ifc:b4b6b144fd02d2ea"}],"totalModels":1,"modelMetadataTruncated":false,"sourceAvailability":"available","reportProvenance":"unknown","totalRows":1,"includedRows":1,"sampled":false,"projectionTruncated":false,"evidence":{"summary":{"kind":"model-load-reports","modelCount":1,"loadReportsAvailable":true,"nativeNewIfc":{"kind":"native-new-ifc-scaffold","schemas":["IFC4","IFC4X3"],"LengthUnit":["METRE","MILLIMETRE"],"operations":["project","addIfcBuildingStorey","toIfc"],"suppliedFields":["Name","Schema","LengthUnit","Description","Author","Organization","Currency","storeys.Name","storeys.Elevation"],"nativeDefaults":{"SiteName":"Site","BuildingName":"Building","GUIDs":"native generated","timestamp":"native preparation time"},"existingModelFacts":false,"publication":"explicit file download; optional primary viewer load request is not load completion or Undo","limitation":"No product geometry, currency, units, elevations or engineering requirements may be inferred."},"diagnosticsAvailable":1,"diagnosticsUnavailable":0,"cleanLoads":0,"limitations":"Load diagnostics describe the original load, not validation of later edits. Affected entities are only those supplied by native diagnostics; missing diagnostics never mean clean."},"rows":[{"citation":"E1","data":{"modelId":"d98ed20d-f9ea-4f10-b64f-e9f8e274d4da","name":"AC20-FZK-Haus.ifc","schemaVersion":"IFC4","sourceFileName":"AC20-FZK-Haus.ifc","fileSize":2526511,"loadedAt":1792318324174,"loadFormat":"ifc","loadPath":"wasm","skipSmallCuts":true,"diagnosticsAvailable":true,"diagnostics":{"schemaVersion":3,"totalCsgFailures":0,"productsWithFailures":0,"hostsWithOpenings":9,"classification":{"rectangular":29,"diagonal":0,"nonRectangular":2,"total":31},"failuresByReason":[],"silentNoOps":0,"rectFast":{"fired":1,"openingsCut":1,"deferHostNotBox":0,"deferNotThrough":0,"deferOffFace":0,"deferNearEdge":0,"deferNoOpenings":0,"deferTooManyOpenings":0},"oversizedRefDrops":0,"worstHosts":[],"totalUnsupportedItems":0,"unsupportedItemsByType":[]},"actions":["Loaded in fast geometry mode (small cuts skipped) — small openings may be missing; reload in full-fidelity mode for complete geometry."],"affectedEntities":[],"isClean":false}}]}}Ask about these resultsAnswers cite attached rows as [E1], [E2]… and never change native results.Prepare a new native IFC project and storeys using the schema, units and elevations I supply; ask for any missing input.Explain the load warnings and their likely causesPrepare a model authoring proposal for review: Draft IDS specifications for review: Draft information rules (uniqueness, counts, comparisons) for review: Build a list of walls with their area and fire ratingChart element counts by IFC classNo AI model is configured. Add an API key and select a model, or configure models for the server proxy.Draft IDS with toolsThe agent looks every IFC name up, changes a draft only through checked operations, and shows you each change before anything is kept. Write the requirements in the message box, then start.Draft IDS from the messageReview report draftTurn the latest answer into an editable document that keeps its captured evidence. Verify claims and citations before saving.Narrative languageEnglishGermanFrenchItalianSpanishDutchPortugueseDanishSwedishNorwegian BokmålFinnishPolishCzechDraft report with AIReport namePrepare report draftStorage and backupDownload library backupImport library backupRetry all librariesDownload preserved originalsRemove migrated legacy copiesCheck storage usageProtect browser storageAnswer languageEnglishGermanFrenchItalianSpanishDutchPortuguesePolishCzechSwedishDanishFinnishNorwegian BokmålJapaneseChineseKoreanNames and values from the model keep their original spelling.Attach selectionAttach viewAsk about these resultsDraft IDS specifications for review: external walls flagged, slabs at least 200 mm; escape doors open outwards.No model configuredClaude Opus 5.5$$$1MClaude Fable 5.1$$$1MClaude Sonnet 5.5$$1MClaude Haiku 4.5$200KGPT-6 Astra$$$1MGPT-6.1 Sol$$1MGPT-6 Luna$1MGPT-5.3 Codex$$400KSend"

```

```yaml
- region "Assistant":
  - heading "Assistant" [level=2]
  - button "Where the Assistant opens"
  - button "Saved conversations"
  - button "Task recipes"
  - button "Project preferences"
  - button "API keys"
  - text: Models and new IFC files Current
  - button "Discuss something else"
  - button "Return to source"
  - button "Refresh evidence and start a new conversation"
  - paragraph: 1 of 1 rows attached
  - group: Evidence details
  - paragraph: Ask about these results
  - paragraph: Answers cite attached rows as [E1], [E2]… and never change native results.
  - group "Suggested questions":
    - button "Prepare a new native IFC project and storeys using the schema, units and elevations I supply; ask for any missing input."
    - button "Explain the load warnings and their likely causes"
    - button "Prepare a model authoring proposal for review:"
    - button "Draft IDS specifications for review:"
    - button "Draft information rules (uniqueness, counts, comparisons) for review:"
    - button "Build a list of walls with their area and fire rating"
    - button "Chart element counts by IFC class"
  - alert: No AI model is configured. Add an API key and select a model, or configure models for the server proxy.
  - region "Draft IDS with tools":
    - heading "Draft IDS with tools" [level=3]
    - paragraph: The agent looks every IFC name up, changes a draft only through checked operations, and shows you each change before anything is kept. Write the requirements in the message box, then start.
    - button "Draft IDS from the message"
  - group: Review report draft
  - text: Answer language
  - combobox "Answer language":
    - option "English" [selected]
    - option "German"
    - option "French"
    - option "Italian"
    - option "Spanish"
    - option "Dutch"
    - option "Portuguese"
    - option "Polish"
    - option "Czech"
    - option "Swedish"
    - option "Danish"
    - option "Finnish"
    - option "Norwegian Bokmål"
    - option "Japanese"
    - option "Chinese"
    - option "Korean"
  - text: Names and values from the model keep their original spelling.
  - button "Attach selection" [disabled]
  - button "Attach view"
  - text: Ask about these results
  - textbox "Ask about these results":
    - /placeholder: Ask a question… (Enter to send, Shift+Enter for a new line)
    - text: "Draft IDS specifications for review: external walls flagged, slabs at least 200 mm; escape doors open outwards."
  - combobox: No model configured
  - button "Send"
  - status
```

# Test source

```ts
  5   | import { test, expect, type Page } from '@playwright/test';
  6   | import { existsSync } from 'node:fs';
  7   | import { join } from 'node:path';
  8   | import { ViewerBenchmarkPage } from '../benchmark/viewer-benchmark-page';
  9   | 
  10  | const fixture = join(process.cwd(), 'tests/models/ara3d/AC20-FZK-Haus.ifc');
  11  | 
  12  | // Recorded so the reviewer can watch the journey; the hosted-viewer privacy toast is acknowledged up front.
  13  | test.use({ video: 'retain-on-failure', viewport: { width: 1440, height: 1000 } });
  14  | 
  15  | type Counts = { applicable: number; passed: number; failed: number };
  16  | type StoreState = {
  17  |   models: Map<string, unknown>; loading: boolean; geometryStreamingActive: boolean;
  18  |   ifcDataStore: { entityCount: number } | null; selectedEntityId: number | null;
  19  |   idsValidationReport: { specificationResults: Array<{ specification: { id: string; name: string };
  20  |     applicableCount: number; passedCount: number; failedCount: number }> } | null;
  21  |   validationRuleSetEditing: boolean;
  22  |   documents: Array<{ id: string; name: string; blocks: Array<{ kind: string; source?: { kind: string; ruleId?: string } }> }>;
  23  |   activeDocumentId: string | null;
  24  |   openPanelInHome(panel: string): void;
  25  | };
  26  | const state = (page: Page) => page.evaluate(() => {
  27  |   const s = (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } }).__ifc_lite_viewer_store__.getState();
  28  |   const report = s.idsValidationReport?.specificationResults.map(r => ({ id: r.specification.id, name: r.specification.name,
  29  |     applicable: r.applicableCount, passed: r.passedCount, failed: r.failedCount })) ?? null;
  30  |   return { report, selected: s.selectedEntityId, ruleEditing: s.validationRuleSetEditing, activeDocumentId: s.activeDocumentId,
  31  |     documents: s.documents.map(d => ({ id: d.id, name: d.name, tables: d.blocks.filter(b => b.kind === 'table').map(b => b.source?.ruleId ?? null) })) };
  32  | });
  33  | 
  34  | // Recorded provider answers in the shapes the P07 guidance teaches; everything else is the real viewer on a real ArchiCAD file.
  35  | const IDS_ANSWER = {
  36  |   version: 1, kind: 'ids.specifications', title: 'AC20 wall and slab checks', ifcVersions: ['IFC4'],
  37  |   specifications: [
  38  |     { name: 'External walls are flagged', applicability: [{ type: 'entity', name: 'IFCWALLSTANDARDCASE' }],
  39  |       requirements: [{ type: 'property', propertySet: 'Pset_WallCommon', baseName: 'IsExternal', dataType: 'IFCBOOLEAN', value: true }] },
  40  |     { name: 'Slabs are at least 200 mm thick', applicability: [{ type: 'entity', name: 'IFCSLAB' }],
  41  |       requirements: [{ type: 'property', propertySet: 'Qto_SlabBaseQuantities', baseName: 'Width', dataType: 'IFCLENGTHMEASURE',
  42  |         unit: 'mm', value: { type: 'bounds', minInclusive: 200 } }] },
  43  |   ],
  44  |   unsupported: [{ text: 'Escape doors open outwards', reason: 'opening direction is geometry, not an IDS facet' }],
  45  | };
  46  | const chips = (rules: unknown[]) => ({ groups: [{ combinator: 'AND', rules }], authoredAs: 'chips' });
  47  | const RULES_ANSWER = {
  48  |   version: 1, kind: 'rules.proposal', title: 'AC20 information rules',
  49  |   ruleSet: { version: 1, name: 'AC20 information rules', rules: [
  50  |     { id: 'door-fire-rating', name: 'Doors state a fire rating', severity: 'error',
  51  |       applicability: chips([{ kind: 'ifcType', values: ['IfcDoor'], op: 'in' }]),
  52  |       requirement: { kind: 'element', block: chips([{ kind: 'property', setName: 'Pset_DoorCommon', propertyName: 'FireRating', op: 'isSet', value: '' }]) } },
  53  |     { id: 'wall-names-unique', name: 'Wall names are unique', severity: 'warning',
  54  |       applicability: chips([{ kind: 'ifcType', values: ['IfcWallStandardCase'], op: 'in' }]),
  55  |       requirement: { kind: 'unique', subject: { kind: 'name' } } },
  56  |   ] },
  57  |   unsupported: [{ text: 'Party walls reach 53 dB airborne sound insulation', reason: 'acoustic performance needs a test certificate' }],
  58  | };
  59  | const outlineAnswer = (specification: string) => ({
  60  |   version: 1, kind: 'document.outline', title: 'AC20 wall findings',
  61  |   sections: [
  62  |     { heading: 'Summary', purpose: 'summary', blocks: [{ kind: 'validationSummary' }] },
  63  |     { heading: 'External walls', purpose: 'findings', blocks: [
  64  |       { kind: 'text', style: 'body', text: 'Walls the IDS expects to be flagged as external.' },
  65  |       { kind: 'validationTable', specification, rows: 'failed', columns: ['name', 'globalId', 'reason'] }] },
  66  |   ],
  67  |   unsupported: [{ text: 'Thermal bridges at slab edges', reason: 'needs a thermal simulation' }],
  68  | });
  69  | 
  70  | // #6915: drafted IDS / rules / outline -> native audit and dry run on the loaded model -> save only after review -> native handoff.
  71  | test('assistant check drafts are dry-run natively and saved only after review', async ({ page }, testInfo) => {
  72  |   test.skip(!existsSync(fixture), 'AC20-FZK-Haus.ifc missing — run pnpm fixtures');
  73  |   await page.addInitScript(() => localStorage.setItem('ifclite.extensions.privacy-disclosure.v2', 'e2e'));
  74  |   const viewer = new ViewerBenchmarkPage(page);
  75  |   await viewer.setup();
  76  |   await viewer.loadFile(fixture);
  77  |   await expect.poll(async () => page.evaluate(() => {
  78  |     const s = (globalThis as unknown as { __ifc_lite_viewer_store__?: { getState(): StoreState } }).__ifc_lite_viewer_store__?.getState();
  79  |     return s?.models.size === 1 && !s.loading && !s.geometryStreamingActive && (s.ifcDataStore?.entityCount ?? 0) > 100;
  80  |   }), { timeout: 120_000 }).toBe(true);
  81  | 
  82  |   let outlineSpec = '';
  83  |   // `vite preview` has no chat proxy: answer the quota poll so it cannot hold the browser's connections open.
  84  |   await page.route('**/api/chat?usage=1', route => route.fulfill({ status: 404 }));
  85  |   await page.route('**/api/chat', async route => {
  86  |     const request = route.request().postDataJSON() as { messages: Array<{ content: string }> };
  87  |     const prompt = request.messages.at(-1)?.content ?? '';
  88  |     const answer = prompt.startsWith('Draft IDS') ? IDS_ANSWER : prompt.startsWith('Draft information rules') ? RULES_ANSWER : outlineAnswer(outlineSpec);
  89  |     await route.fulfill({ contentType: 'text/event-stream', body:
  90  |       `data: ${JSON.stringify({ choices: [{ delta: { content: JSON.stringify(answer) } }] })}\n\ndata: [DONE]\n\n` });
  91  |   });
  92  |   const assistant = page.getByRole('region', { name: 'Assistant', exact: true });
  93  |   const ask = async (prompt: string) => {
  94  |     await assistant.getByLabel('Ask about these results').fill(prompt);
  95  |     await assistant.getByRole('button', { name: 'Send', exact: true }).click();
  96  |   };
  97  | 
  98  |   // IDS draft from the load report.
  99  |   await page.evaluate(() => (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } })
  100 |     .__ifc_lite_viewer_store__.getState().openPanelInHome('loadReport'));
  101 |   await page.getByRole('region', { name: 'Load report', exact: true }).getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  102 |   // The suggestion chip starts the request; the user completes it.
  103 |   await assistant.getByRole('button', { name: /^Draft IDS specifications for review:/ }).click();
  104 |   await ask('Draft IDS specifications for review: external walls flagged, slabs at least 200 mm; escape doors open outwards.');
> 105 |   await expect(assistant).toContainText('2 specifications · 1 requirement not checkable');
      |                           ^ Error: expect(locator).toContainText(expected) failed
  106 |   const ids = assistant.getByRole('region', { name: 'Review IDS draft', exact: true });
  107 |   await expect(ids).toContainText('Native IDS audit: 0 errors');
  108 |   await expect(ids).toContainText('Escape doors open outwards');
  109 |   const saveIds = ids.getByRole('button', { name: 'Save to IDS library', exact: true });
  110 |   await expect(saveIds).toBeDisabled();
  111 |   await ids.getByRole('button', { name: 'Dry run on loaded models', exact: true }).click();
  112 |   const dry = ids.getByRole('region', { name: 'Dry-run results', exact: true });
  113 |   await expect(dry).toContainText('Dry run on 1 model');
  114 |   const dryCounts = (await dry.getByText(/\d+ applicable · \d+ passed · \d+ failed/).allTextContents()).map((text): Counts => {
  115 |     const [applicable, passed, failed] = text.match(/\d+/g)!.map(Number);
  116 |     return { applicable, passed, failed };
  117 |   });
  118 |   expect(dryCounts).toHaveLength(2);
  119 |   expect(dryCounts[0].applicable).toBeGreaterThan(0);
  120 |   expect(dryCounts[0].failed).toBeGreaterThan(0);
  121 |   expect((await state(page)).report, 'a dry run publishes no report').toBeNull();
  122 |   await dry.getByRole('button', { name: /^Show .* in the model$/ }).first().click();
  123 |   expect((await state(page)).selected, 'a failing sample selects in the model').not.toBeNull();
  124 |   await expect(saveIds).toBeEnabled();
  125 |   await ids.scrollIntoViewIfNeeded();
  126 |   await page.screenshot({ path: testInfo.outputPath('p07-ids-dry-run.png') });
  127 |   await saveIds.click();
  128 |   await expect(ids).toContainText('Saved to the Data validation IDS library');
  129 |   await ids.getByRole('button', { name: 'Open in Data validation', exact: true }).click();
  130 | 
  131 |   // The saved IDS runs in the native panel with the same counts the dry run showed.
  132 |   await page.getByRole('button', { name: 'Run Validation', exact: true }).click();
  133 |   await expect.poll(async () => (await state(page)).report?.length ?? 0, { timeout: 60_000 }).toBe(2);
  134 |   const native = (await state(page)).report!;
  135 |   expect(native.map(({ applicable, passed, failed }) => ({ applicable, passed, failed }))).toEqual(dryCounts);
  136 |   await page.screenshot({ path: testInfo.outputPath('p07-ids-native-run.png') });
  137 | 
  138 |   // Information rules from the load report: per-element and set requirements IDS cannot express.
  139 |   await page.evaluate(() => (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } })
  140 |     .__ifc_lite_viewer_store__.getState().openPanelInHome('loadReport'));
  141 |   await page.getByRole('region', { name: 'Load report', exact: true }).getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  142 |   await ask('Draft information rules (uniqueness, counts, comparisons) for review: doors need a fire rating, wall names unique.');
  143 |   const rules = assistant.getByRole('region', { name: 'Review information rules', exact: true });
  144 |   await expect(rules).toContainText('property Pset_DoorCommon.FireRating isSet');
  145 |   await expect(rules).toContainText('Party walls reach 53 dB');
  146 |   await expect(rules.getByRole('button', { name: 'Save as rule set', exact: true })).toBeDisabled();
  147 |   await rules.getByRole('button', { name: 'Dry run on loaded models', exact: true }).click();
  148 |   await expect(rules.getByRole('region', { name: 'Dry-run results', exact: true })).toContainText(/\d+ applicable · \d+ passed · \d+ failed/);
  149 |   await rules.scrollIntoViewIfNeeded();
  150 |   await page.screenshot({ path: testInfo.outputPath('p07-rules-dry-run.png') });
  151 |   await rules.getByRole('button', { name: 'Save as rule set', exact: true }).click();
  152 |   await rules.getByRole('button', { name: 'Open in the rule editor', exact: true }).click();
  153 |   expect((await state(page)).ruleEditing).toBe(true);
  154 |   await page.screenshot({ path: testInfo.outputPath('p07-rules-editor.png') });
  155 | 
  156 |   // Report outline from the native validation result, bound to the live report. Opening the saved rule set
  157 |   // made it the active definition, which (as any library switch does) cleared the shown report: run the IDS again.
  158 |   expect((await state(page)).report).toBeNull();
  159 |   await page.getByRole('tab', { name: 'IDS validation', exact: true }).click();
  160 |   await page.getByRole('button', { name: 'Run Validation', exact: true }).click();
  161 |   await expect.poll(async () => (await state(page)).report?.length ?? 0, { timeout: 60_000 }).toBe(2);
  162 |   expect((await state(page)).report).toEqual(native);
  163 |   outlineSpec = native[0].id;
  164 |   await page.getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  165 |   await ask('Outline a validation report with live result tables');
  166 |   await expect(assistant).toContainText('2 sections · 1 requirement not checkable');
  167 |   const outline = assistant.getByRole('region', { name: 'Review report outline', exact: true });
  168 |   await expect(outline).toContainText(`live: ${native[0].failed} failed row`);
  169 |   await outline.scrollIntoViewIfNeeded();
  170 |   await page.screenshot({ path: testInfo.outputPath('p07-outline-review.png') });
  171 |   await outline.getByRole('button', { name: 'Save as new document', exact: true }).click();
  172 |   await expect(outline).toContainText('Saved to the Documents library');
  173 |   await outline.getByRole('button', { name: 'Open in Documents', exact: true }).click();
  174 |   const saved = await state(page);
  175 |   const doc = saved.documents.find(candidate => candidate.name === 'AC20 wall findings');
  176 |   expect(doc?.tables).toEqual([outlineSpec]);
  177 |   expect(saved.activeDocumentId).toBe(doc?.id);
  178 |   await expect(page.getByText('Outline drafted with AI assistance', { exact: false }).last()).toBeVisible({ timeout: 15_000 });
  179 |   await page.screenshot({ path: testInfo.outputPath('p07-outline-document.png') });
  180 | });
  181 | 
```