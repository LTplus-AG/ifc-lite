# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/assistant-check-authoring.e2e.spec.ts >> assistant check drafts are dry-run natively and saved only after review
- Location: tests/e2e/assistant-check-authoring.e2e.spec.ts:71:1

# Error details

```
TimeoutError: locator.click: Timeout 60000ms exceeded.
Call log:
  - waiting for getByRole('region', { name: 'Assistant', exact: true }).getByRole('button', { name: /^Draft IDS specifications for review:/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - generic [ref=e5]:
      - tablist "Ribbon tabs" [ref=e6]:
        - tab "File" [ref=e7]
        - tab "Home" [selected] [ref=e8]
        - tab "View" [ref=e10]
        - tab "Elements" [ref=e11]
        - tab "Analyze" [ref=e12]
        - tab "Author" [ref=e13]
      - generic [ref=e15]:
        - combobox "Search entities" [ref=e21]
        - button "Advanced filter" [ref=e23]
      - generic [ref=e25]:
        - button "Commands… Ctrl+K" [ref=e26]:
          - text: Commands…
          - generic [ref=e27]: Ctrl+K
        - button "Settings" [ref=e28]
        - switch "Toggle dark mode" [ref=e35] [cursor=pointer]
        - button "Info and keyboard shortcuts" [ref=e114]
        - button "Collapse the ribbon" [expanded] [ref=e115]
    - tabpanel "Home" [ref=e116]:
      - group "Tools" [ref=e117]:
        - generic [ref=e118]:
          - button "Reposition" [ref=e119]:
            - generic [ref=e127]: Reposition models and pointclouds
          - button "Select" [pressed] [ref=e128]
          - button "Walk" [ref=e135]
      - group "Measure & Mark" [ref=e143]:
        - generic [ref=e144]:
          - button "Measure" [ref=e145]
          - button "Section" [ref=e152]
          - button "Annotate" [ref=e164]
      - group "Scene" [ref=e175]:
        - button "Home" [ref=e177]:
          - generic [ref=e183]: Home (isometric camera + fit)
  - generic [ref=e186]:
    - generic [ref=e188]:
      - generic [ref=e193]:
        - generic [ref=e194]:
          - textbox "Search hierarchy" [ref=e200]:
            - /placeholder: Search...
          - generic [ref=e201]:
            - button "Spatial" [ref=e202]
            - button "Class" [ref=e203]
            - button "Type" [ref=e204]
            - button "Materials" [ref=e205]
            - button "Groups, systems and zones" [ref=e206]
            - button "Presentation layers" [ref=e207]
          - 'button "Sort: Elevation" [ref=e208]'
        - generic [ref=e211]:
          - generic [ref=e216]: Hierarchy
          - generic [ref=e217]: "5"
        - generic [ref=e218]:
          - generic [ref=e219]:
            - generic [ref=e220]:
              - button "Stacked" [pressed] [ref=e221]
              - button "Solo" [ref=e227]
            - button "Exploded" [ref=e233]
            - button "Floorplan the active storey" [disabled] [ref=e238]
          - generic [ref=e243]: Choose Solo storey on a row to show only that level
        - tree "Hierarchy" [ref=e244]:
          - generic [ref=e245]:
            - treeitem "Collapse Projekt-FZK-Haus Hide Projekt-FZK-Haus Projekt-FZK-Haus" [expanded] [level=1] [ref=e247] [cursor=pointer]:
              - button "Collapse Projekt-FZK-Haus" [expanded] [ref=e248]
              - generic [ref=e251]:
                - generic [aria-hidden] [ref=e252]: 
                - button "Hide Projekt-FZK-Haus" [ref=e253]
              - generic [ref=e257]: Projekt-FZK-Haus
            - treeitem "Collapse Gelaende Hide Gelaende Gelaende" [expanded] [level=2] [ref=e259] [cursor=pointer]:
              - button "Collapse Gelaende" [expanded] [ref=e260]
              - generic [ref=e263]:
                - generic [aria-hidden] [ref=e264]: 
                - button "Hide Gelaende" [ref=e265]
              - generic [ref=e269]: Gelaende
            - treeitem "Collapse FZK-Haus Hide FZK-Haus FZK-Haus" [expanded] [level=3] [ref=e271] [cursor=pointer]:
              - button "Collapse FZK-Haus" [expanded] [ref=e272]
              - generic [ref=e275]:
                - generic [aria-hidden] [ref=e276]: 
                - button "Hide FZK-Haus" [ref=e277]
              - generic [ref=e281]: FZK-Haus
            - treeitem "Expand Dachgeschoss Hide Dachgeschoss Dachgeschoss ACID00000002-0000-0000-0000-000000000000 +2.70m Solo storey Dachgeschoss Filter by this Dachgeschoss Actions for Dachgeschoss" [level=4] [ref=e283] [cursor=pointer]:
              - button "Expand Dachgeschoss" [ref=e284]
              - generic [ref=e287]:
                - generic [aria-hidden] [ref=e288]: 
                - button "Hide Dachgeschoss" [ref=e289]
              - generic "Dachgeschoss - ACID00000002-0000-0000-0000-000000000000" [ref=e293]:
                - generic [ref=e294]: Dachgeschoss
                - generic: ACID00000002-0000-0000-0000-000000000000
              - generic [ref=e295]: +2.70m
              - generic:
                - button "Solo storey Dachgeschoss"
                - button "Filter by this Dachgeschoss"
                - button "Actions for Dachgeschoss"
            - treeitem "Expand Erdgeschoss Hide Erdgeschoss Erdgeschoss ACID00000001-0000-0000-0000-000000000000 +0.00m Solo storey Erdgeschoss Filter by this Erdgeschoss Actions for Erdgeschoss" [level=4] [ref=e297] [cursor=pointer]:
              - button "Expand Erdgeschoss" [ref=e298]
              - generic [ref=e301]:
                - generic [aria-hidden] [ref=e302]: 
                - button "Hide Erdgeschoss" [ref=e303]
              - generic "Erdgeschoss - ACID00000001-0000-0000-0000-000000000000" [ref=e307]:
                - generic [ref=e308]: Erdgeschoss
                - generic: ACID00000001-0000-0000-0000-000000000000
              - generic [ref=e309]: +0.00m
              - generic:
                - button "Solo storey Erdgeschoss"
                - button "Filter by this Erdgeschoss"
                - button "Actions for Erdgeschoss"
        - generic [ref=e310]: Click to select · Ctrl toggle
      - separator [ref=e311]
      - generic [ref=e319]:
        - generic "Annotations layer"
        - generic [ref=e324]:
          - button "FRONT" [ref=e325] [cursor=pointer]
          - button "BACK" [ref=e326] [cursor=pointer]
          - button "TOP" [ref=e327] [cursor=pointer]
          - button "BTM" [ref=e328] [cursor=pointer]
          - button "RIGHT" [ref=e329] [cursor=pointer]
          - button "LEFT" [ref=e330] [cursor=pointer]
        - generic [ref=e331]:
          - generic [ref=e332]: 3.3m
          - generic [ref=e337]:
            - generic [ref=e339]: X
            - generic [ref=e341]: Z
            - generic [ref=e343]: "Y"
          - button "Show model basepoints" [ref=e345]
        - generic:
          - alert:
            - generic [ref=e348]:
              - generic [ref=e351]: The 3D view could not recover automatically. Reload the page to restore rendering.
              - button "Dismiss notification" [ref=e352]
          - status
    - generic [ref=e356]:
      - separator "Resize sidebar" [ref=e357]
      - generic [ref=e360]:
        - generic [ref=e361]:
          - generic [ref=e362]:
            - button "Split panel" [pressed] [ref=e373]
            - button "Collapse sidebar to icons" [ref=e376]
          - region "Load report" [ref=e380]:
            - generic [ref=e381]:
              - generic [ref=e384]: Load report
              - button "Discuss with AI" [ref=e385]
              - button "Export JSON" [ref=e386]
              - button "Close" [ref=e387]
            - generic [ref=e389]:
              - generic [ref=e390]:
                - generic [ref=e391]: AC20-FZK-Haus.ifc
                - generic [ref=e392]: Issues found
              - generic [ref=e393]: IFC4 · ifc · wasm · fast mode
              - list [ref=e394]:
                - listitem [ref=e395]: Loaded in fast geometry mode (small cuts skipped) — small openings may be missing; reload in full-fidelity mode for complete geometry.
        - separator "Resize split" [ref=e396]
        - region "Assistant" [ref=e406]:
          - generic [ref=e407]:
            - heading "Assistant" [level=2] [ref=e411]
            - generic [ref=e412]:
              - button "Where the Assistant opens" [ref=e413]
              - button "Saved conversations" [ref=e414]
              - button "Task recipes" [ref=e415]
              - button "Project preferences" [ref=e416]
              - button "API keys" [ref=e417]
          - generic [ref=e418]:
            - generic [ref=e419]:
              - generic [ref=e420]:
                - generic [ref=e421]: Models and new IFC files
                - generic [ref=e422]: Out of date
                - generic [ref=e423]:
                  - button "Discuss something else" [ref=e424]
                  - button "Return to source" [ref=e425]
                  - button "Refresh evidence and start a new conversation" [ref=e426]
              - paragraph [ref=e427]: 1 of 1 rows attached
              - generic [ref=e428]:
                - paragraph [ref=e429]: Results changed since capture
                - paragraph [ref=e432]: The source or model has changed, or this result predates an edit. Refresh the evidence before sending.
                - button "Refresh evidence" [ref=e433]
              - group [ref=e434]:
                - generic "Evidence details" [ref=e435] [cursor=pointer]
            - generic [ref=e437]:
              - paragraph [ref=e438]: Ask about these results
              - paragraph [ref=e439]: Answers cite attached rows as [E1], [E2]… and never change native results.
            - region "Draft IDS with tools" [ref=e440]:
              - heading "Draft IDS with tools" [level=3] [ref=e441]
              - generic [ref=e446]:
                - paragraph [ref=e447]: The agent looks every IFC name up, changes a draft only through checked operations, and shows you each change before anything is kept. Write the requirements in the message box, then start.
                - button "Draft IDS from the message" [disabled]
                - paragraph [ref=e448]: Write the requirements in the message box first.
            - group [ref=e449]:
              - generic "Review report draft" [ref=e450] [cursor=pointer]
              - option "English" [selected]
              - option "German"
              - option "French"
              - option "Italian"
              - option "Spanish"
              - option "Dutch"
              - option "Portuguese"
              - option "Danish"
              - option "Swedish"
              - option "Norwegian Bokmål"
              - option "Finnish"
              - option "Polish"
              - option "Czech"
          - generic [ref=e454]:
            - generic [ref=e455]:
              - generic [ref=e456]: Answer language
              - combobox "Answer language" [ref=e457]:
                - option "English" [selected]
                - option "German"
                - option "French"
                - option "Italian"
                - option "Spanish"
                - option "Dutch"
                - option "Portuguese"
                - option "Polish"
                - option "Czech"
                - option "Swedish"
                - option "Danish"
                - option "Finnish"
                - option "Norwegian Bokmål"
                - option "Japanese"
                - option "Chinese"
                - option "Korean"
              - generic [ref=e458]: Names and values from the model keep their original spelling.
            - generic [ref=e460]:
              - button "Attach selection" [disabled]
              - button "Attach view" [disabled]
            - generic [ref=e461]: Ask about these results
            - textbox "Ask about these results" [disabled] [ref=e462]:
              - /placeholder: Ask a question… (Enter to send, Shift+Enter for a new line)
            - generic [ref=e463]:
              - generic [ref=e464]:
                - combobox [ref=e465]:
                  - generic: No model configured
                - combobox [aria-hidden] [ref=e468]
              - button "Send" [disabled]
          - status [ref=e469]
      - generic [ref=e470]:
        - generic [ref=e471]:
          - generic [ref=e472]:
            - heading "Coordinate" [level=3] [ref=e473]
            - button "Hierarchy" [pressed] [ref=e474]
          - button "Properties" [ref=e480]
          - button "Cloud Sources" [ref=e484]
          - button "Location zones" [ref=e488]
          - button "Placement" [ref=e493]
          - button "Assistant" [pressed] [ref=e500]
          - button "Linked records" [ref=e505]
          - button "Review" [ref=e510]
          - generic [ref=e514]:
            - heading "Check" [level=3] [ref=e515]
            - button "Compare models" [ref=e516]
          - button "BCF Topics" [ref=e525]
          - button "Data validation" [ref=e529]
          - button "Lens" [ref=e535]
          - button "Clash detection" [ref=e543]
          - button "Layer stack" [ref=e547]
          - button "Load report" [pressed] [ref=e553]
          - button "Changes" [ref=e558]
          - button "IDS Studio" [ref=e564]
          - generic [ref=e570]:
            - heading "Quantify" [level=3] [ref=e571]
            - button "Schedule (Gantt)" [ref=e572]
          - button "Lists" [ref=e576]
          - button "Charts" [ref=e580]
          - button "Cost" [ref=e584]
          - button "Measurements" [ref=e591]
          - generic [ref=e598]:
            - heading "Automate" [level=3] [ref=e599]
            - button "Extensions" [ref=e600]
          - button "Script Editor" [ref=e604]
          - button "Flow" [ref=e608]
          - generic [ref=e613]:
            - heading "Site" [level=3] [ref=e614]
            - button "Appearance" [ref=e615]
          - button "Document" [ref=e623]
          - button "Environment" [ref=e628]
          - button "Drawing" [ref=e636]
          - button "Point Cloud" [ref=e645]
          - button "Presentation" [ref=e652]
          - generic [ref=e656]:
            - heading "Author" [level=3] [ref=e657]
            - button "Model inspector" [ref=e658]
          - button "Change sets" [ref=e666]
        - generic [ref=e671]:
          - button "Customize sidebar" [ref=e672]
          - button "Collapse to icons" [ref=e674]
          - button "Sidebar options" [ref=e678]
  - generic [ref=e683]:
    - generic [ref=e684]: Ready
    - generic [ref=e686]: 82 elements
    - generic [ref=e699]:
      - generic [ref=e700]: WebGPU
      - button "Model" [ref=e705]
      - status [ref=e709]: "Load model (AC20-FZK-Haus.ifc): Complete"
      - button "Activity" [ref=e710]
      - button "Present" [ref=e714]
      - 'button "Active profile: Default. Click to manage profiles." [ref=e719]':
        - generic [ref=e726]: Default
      - generic [ref=e727]: v5.1.5
      - link "Visit ifclite.dev — about, docs, and packages" [ref=e728] [cursor=pointer]:
        - /url: https://ifclite.dev
        - text: ifclite.dev →
```

# Test source

```ts
  3   |  * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
  4   | 
  5   | import { test, expect, type Page } from '@playwright/test';
  6   | import { existsSync } from 'node:fs';
  7   | import { join } from 'node:path';
  8   | import { ViewerBenchmarkPage } from '../benchmark/viewer-benchmark-page';
  9   | 
  10  | const fixture = join(process.cwd(), 'tests/models/ara3d/AC20-FZK-Haus.ifc');
  11  | 
  12  | // Recorded so the reviewer can watch the journey; the hosted-viewer privacy toast is acknowledged up front.
  13  | test.use({ video: 'retain-on-failure', viewport: { width: 1440, height: 1000 } });
  14  | 
  15  | type Counts = { applicable: number; passed: number; failed: number };
  16  | type StoreState = {
  17  |   models: Map<string, unknown>; loading: boolean; geometryStreamingActive: boolean;
  18  |   ifcDataStore: { entityCount: number } | null; selectedEntityId: number | null;
  19  |   idsValidationReport: { specificationResults: Array<{ specification: { id: string; name: string };
  20  |     applicableCount: number; passedCount: number; failedCount: number }> } | null;
  21  |   validationRuleSetEditing: boolean;
  22  |   documents: Array<{ id: string; name: string; blocks: Array<{ kind: string; source?: { kind: string; ruleId?: string } }> }>;
  23  |   activeDocumentId: string | null;
  24  |   openPanelInHome(panel: string): void;
  25  | };
  26  | const state = (page: Page) => page.evaluate(() => {
  27  |   const s = (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } }).__ifc_lite_viewer_store__.getState();
  28  |   const report = s.idsValidationReport?.specificationResults.map(r => ({ id: r.specification.id, name: r.specification.name,
  29  |     applicable: r.applicableCount, passed: r.passedCount, failed: r.failedCount })) ?? null;
  30  |   return { report, selected: s.selectedEntityId, ruleEditing: s.validationRuleSetEditing, activeDocumentId: s.activeDocumentId,
  31  |     documents: s.documents.map(d => ({ id: d.id, name: d.name, tables: d.blocks.filter(b => b.kind === 'table').map(b => b.source?.ruleId ?? null) })) };
  32  | });
  33  | 
  34  | // Recorded provider answers in the shapes the P07 guidance teaches; everything else is the real viewer on a real ArchiCAD file.
  35  | const IDS_ANSWER = {
  36  |   version: 1, kind: 'ids.specifications', title: 'AC20 wall and slab checks', ifcVersions: ['IFC4'],
  37  |   specifications: [
  38  |     { name: 'External walls are flagged', applicability: [{ type: 'entity', name: 'IFCWALLSTANDARDCASE' }],
  39  |       requirements: [{ type: 'property', propertySet: 'Pset_WallCommon', baseName: 'IsExternal', dataType: 'IFCBOOLEAN', value: true }] },
  40  |     { name: 'Slabs are at least 200 mm thick', applicability: [{ type: 'entity', name: 'IFCSLAB' }],
  41  |       requirements: [{ type: 'property', propertySet: 'Qto_SlabBaseQuantities', baseName: 'Width', dataType: 'IFCLENGTHMEASURE',
  42  |         unit: 'mm', value: { type: 'bounds', minInclusive: 200 } }] },
  43  |   ],
  44  |   unsupported: [{ text: 'Escape doors open outwards', reason: 'opening direction is geometry, not an IDS facet' }],
  45  | };
  46  | const chips = (rules: unknown[]) => ({ groups: [{ combinator: 'AND', rules }], authoredAs: 'chips' });
  47  | const RULES_ANSWER = {
  48  |   version: 1, kind: 'rules.proposal', title: 'AC20 information rules',
  49  |   ruleSet: { version: 1, name: 'AC20 information rules', rules: [
  50  |     { id: 'door-fire-rating', name: 'Doors state a fire rating', severity: 'error',
  51  |       applicability: chips([{ kind: 'ifcType', values: ['IfcDoor'], op: 'in' }]),
  52  |       requirement: { kind: 'element', block: chips([{ kind: 'property', setName: 'Pset_DoorCommon', propertyName: 'FireRating', op: 'isSet', value: '' }]) } },
  53  |     { id: 'wall-names-unique', name: 'Wall names are unique', severity: 'warning',
  54  |       applicability: chips([{ kind: 'ifcType', values: ['IfcWallStandardCase'], op: 'in' }]),
  55  |       requirement: { kind: 'unique', subject: { kind: 'name' } } },
  56  |   ] },
  57  |   unsupported: [{ text: 'Party walls reach 53 dB airborne sound insulation', reason: 'acoustic performance needs a test certificate' }],
  58  | };
  59  | const outlineAnswer = (specification: string) => ({
  60  |   version: 1, kind: 'document.outline', title: 'AC20 wall findings',
  61  |   sections: [
  62  |     { heading: 'Summary', purpose: 'summary', blocks: [{ kind: 'validationSummary' }] },
  63  |     { heading: 'External walls', purpose: 'findings', blocks: [
  64  |       { kind: 'text', style: 'body', text: 'Walls the IDS expects to be flagged as external.' },
  65  |       { kind: 'validationTable', specification, rows: 'failed', columns: ['name', 'globalId', 'reason'] }] },
  66  |   ],
  67  |   unsupported: [{ text: 'Thermal bridges at slab edges', reason: 'needs a thermal simulation' }],
  68  | });
  69  | 
  70  | // #6915: drafted IDS / rules / outline -> native audit and dry run on the loaded model -> save only after review -> native handoff.
  71  | test('assistant check drafts are dry-run natively and saved only after review', async ({ page }, testInfo) => {
  72  |   test.skip(!existsSync(fixture), 'AC20-FZK-Haus.ifc missing — run pnpm fixtures');
  73  |   await page.addInitScript(() => localStorage.setItem('ifclite.extensions.privacy-disclosure.v2', 'e2e'));
  74  |   const viewer = new ViewerBenchmarkPage(page);
  75  |   await viewer.setup();
  76  |   await viewer.loadFile(fixture);
  77  |   await expect.poll(async () => page.evaluate(() => {
  78  |     const s = (globalThis as unknown as { __ifc_lite_viewer_store__?: { getState(): StoreState } }).__ifc_lite_viewer_store__?.getState();
  79  |     return s?.models.size === 1 && !s.loading && !s.geometryStreamingActive && (s.ifcDataStore?.entityCount ?? 0) > 100;
  80  |   }), { timeout: 120_000 }).toBe(true);
  81  | 
  82  |   let outlineSpec = '';
  83  |   // `vite preview` has no chat proxy: answer the quota poll so it cannot hold the browser's connections open.
  84  |   await page.route('**/api/chat?usage=1', route => route.fulfill({ status: 404 }));
  85  |   await page.route('**/api/chat', async route => {
  86  |     const request = route.request().postDataJSON() as { messages: Array<{ content: string }> };
  87  |     const prompt = request.messages.at(-1)?.content ?? '';
  88  |     const answer = prompt.startsWith('Draft IDS') ? IDS_ANSWER : prompt.startsWith('Draft information rules') ? RULES_ANSWER : outlineAnswer(outlineSpec);
  89  |     await route.fulfill({ contentType: 'text/event-stream', body:
  90  |       `data: ${JSON.stringify({ choices: [{ delta: { content: JSON.stringify(answer) } }] })}\n\ndata: [DONE]\n\n` });
  91  |   });
  92  |   const assistant = page.getByRole('region', { name: 'Assistant', exact: true });
  93  |   const ask = async (prompt: string) => {
  94  |     await assistant.getByLabel('Ask about these results').fill(prompt);
  95  |     await assistant.getByRole('button', { name: 'Send', exact: true }).click();
  96  |   };
  97  | 
  98  |   // IDS draft from the load report.
  99  |   await page.evaluate(() => (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } })
  100 |     .__ifc_lite_viewer_store__.getState().openPanelInHome('loadReport'));
  101 |   await page.getByRole('region', { name: 'Load report', exact: true }).getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  102 |   // The suggestion chip starts the request; the user completes it.
> 103 |   await assistant.getByRole('button', { name: /^Draft IDS specifications for review:/ }).click();
      |                                                                                          ^ TimeoutError: locator.click: Timeout 60000ms exceeded.
  104 |   await ask('Draft IDS specifications for review: external walls flagged, slabs at least 200 mm; escape doors open outwards.');
  105 |   await expect(assistant).toContainText('2 specifications · 1 requirement not checkable');
  106 |   const ids = assistant.getByRole('region', { name: 'Review IDS draft', exact: true });
  107 |   await expect(ids).toContainText('Native IDS audit: 0 errors');
  108 |   await expect(ids).toContainText('Escape doors open outwards');
  109 |   const saveIds = ids.getByRole('button', { name: 'Save to IDS library', exact: true });
  110 |   await expect(saveIds).toBeDisabled();
  111 |   await ids.getByRole('button', { name: 'Dry run on loaded models', exact: true }).click();
  112 |   const dry = ids.getByRole('region', { name: 'Dry-run results', exact: true });
  113 |   await expect(dry).toContainText('Dry run on 1 model');
  114 |   const dryCounts = (await dry.getByText(/\d+ applicable · \d+ passed · \d+ failed/).allTextContents()).map((text): Counts => {
  115 |     const [applicable, passed, failed] = text.match(/\d+/g)!.map(Number);
  116 |     return { applicable, passed, failed };
  117 |   });
  118 |   expect(dryCounts).toHaveLength(2);
  119 |   expect(dryCounts[0].applicable).toBeGreaterThan(0);
  120 |   expect(dryCounts[0].failed).toBeGreaterThan(0);
  121 |   expect((await state(page)).report, 'a dry run publishes no report').toBeNull();
  122 |   await dry.getByRole('button', { name: /^Show .* in the model$/ }).first().click();
  123 |   expect((await state(page)).selected, 'a failing sample selects in the model').not.toBeNull();
  124 |   await expect(saveIds).toBeEnabled();
  125 |   await ids.scrollIntoViewIfNeeded();
  126 |   await page.screenshot({ path: testInfo.outputPath('p07-ids-dry-run.png') });
  127 |   await saveIds.click();
  128 |   await expect(ids).toContainText('Saved to the Data validation IDS library');
  129 |   await ids.getByRole('button', { name: 'Open in Data validation', exact: true }).click();
  130 | 
  131 |   // The saved IDS runs in the native panel with the same counts the dry run showed.
  132 |   await page.getByRole('button', { name: 'Run Validation', exact: true }).click();
  133 |   await expect.poll(async () => (await state(page)).report?.length ?? 0, { timeout: 60_000 }).toBe(2);
  134 |   const native = (await state(page)).report!;
  135 |   expect(native.map(({ applicable, passed, failed }) => ({ applicable, passed, failed }))).toEqual(dryCounts);
  136 |   await page.screenshot({ path: testInfo.outputPath('p07-ids-native-run.png') });
  137 | 
  138 |   // Information rules from the load report: per-element and set requirements IDS cannot express.
  139 |   await page.evaluate(() => (globalThis as unknown as { __ifc_lite_viewer_store__: { getState(): StoreState } })
  140 |     .__ifc_lite_viewer_store__.getState().openPanelInHome('loadReport'));
  141 |   await page.getByRole('region', { name: 'Load report', exact: true }).getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  142 |   await ask('Draft information rules (uniqueness, counts, comparisons) for review: doors need a fire rating, wall names unique.');
  143 |   const rules = assistant.getByRole('region', { name: 'Review information rules', exact: true });
  144 |   await expect(rules).toContainText('property Pset_DoorCommon.FireRating isSet');
  145 |   await expect(rules).toContainText('Party walls reach 53 dB');
  146 |   await expect(rules.getByRole('button', { name: 'Save as rule set', exact: true })).toBeDisabled();
  147 |   await rules.getByRole('button', { name: 'Dry run on loaded models', exact: true }).click();
  148 |   await expect(rules.getByRole('region', { name: 'Dry-run results', exact: true })).toContainText(/\d+ applicable · \d+ passed · \d+ failed/);
  149 |   await rules.scrollIntoViewIfNeeded();
  150 |   await page.screenshot({ path: testInfo.outputPath('p07-rules-dry-run.png') });
  151 |   await rules.getByRole('button', { name: 'Save as rule set', exact: true }).click();
  152 |   await rules.getByRole('button', { name: 'Open in the rule editor', exact: true }).click();
  153 |   expect((await state(page)).ruleEditing).toBe(true);
  154 |   await page.screenshot({ path: testInfo.outputPath('p07-rules-editor.png') });
  155 | 
  156 |   // Report outline from the native validation result, bound to the live report. Opening the saved rule set
  157 |   // made it the active definition, which (as any library switch does) cleared the shown report: run the IDS again.
  158 |   expect((await state(page)).report).toBeNull();
  159 |   await page.getByRole('tab', { name: 'IDS validation', exact: true }).click();
  160 |   await page.getByRole('button', { name: 'Run Validation', exact: true }).click();
  161 |   await expect.poll(async () => (await state(page)).report?.length ?? 0, { timeout: 60_000 }).toBe(2);
  162 |   expect((await state(page)).report).toEqual(native);
  163 |   outlineSpec = native[0].id;
  164 |   await page.getByRole('button', { name: 'Discuss with AI', exact: true }).click();
  165 |   await ask('Outline a validation report with live result tables');
  166 |   await expect(assistant).toContainText('2 sections · 1 requirement not checkable');
  167 |   const outline = assistant.getByRole('region', { name: 'Review report outline', exact: true });
  168 |   await expect(outline).toContainText(`live: ${native[0].failed} failed row`);
  169 |   await outline.scrollIntoViewIfNeeded();
  170 |   await page.screenshot({ path: testInfo.outputPath('p07-outline-review.png') });
  171 |   await outline.getByRole('button', { name: 'Save as new document', exact: true }).click();
  172 |   await expect(outline).toContainText('Saved to the Documents library');
  173 |   await outline.getByRole('button', { name: 'Open in Documents', exact: true }).click();
  174 |   const saved = await state(page);
  175 |   const doc = saved.documents.find(candidate => candidate.name === 'AC20 wall findings');
  176 |   expect(doc?.tables).toEqual([outlineSpec]);
  177 |   expect(saved.activeDocumentId).toBe(doc?.id);
  178 |   await expect(page.getByText('Outline drafted with AI assistance', { exact: false }).last()).toBeVisible({ timeout: 15_000 });
  179 |   await page.screenshot({ path: testInfo.outputPath('p07-outline-document.png') });
  180 | });
  181 | 
```