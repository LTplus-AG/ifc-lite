"""External capture composition. No invocation occurs on import; no retry or acceptance relaxation."""
from pathlib import Path
import hashlib,json,subprocess,datetime

COMPLETE='FRESH_OWNED_CHROME_RUNTIME_CAPTURE_COMPLETE_NOT_GEOMETRY_QUALIFICATION'
CASE_COMPLETE='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED'
MARKER=b'SOURCE_RUNTIME_PINS_VERIFIED'

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,value):
 with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')

def process_record(command,directory,label):
 """Preserve exact binary streams even on subprocess failure, never stringify away diagnostics."""
 stdout=directory/(label+'.stdout');stderr=directory/(label+'.stderr')
 record={'command':command,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with stdout.open('xb') as out,stderr.open('xb') as err:
   result=subprocess.run(command,stdout=out,stderr=err)
  record.update(status=result.returncode,signal=-result.returncode if result.returncode<0 else None,error=None)
 except Exception as error:
  record.update(status=None,signal=None,error={'message':str(error),'code':getattr(error,'errno',None),'type':type(error).__name__})
 for name,path in [('stdout',stdout),('stderr',stderr)]:
  record[name]={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())} if path.exists() else None
 record['finishedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 save(directory/(label+'.json'),record)
 return record

def verified(record):
 return record['status']==0 and record['error'] is None and record['stdout'] is not None and Path(record['stdout']['path']).read_bytes()==MARKER+b'\n'

def native_requirements(out,pins,fixtures,returncode):
 failures=[];native=None;raw=None
 def require(value,message):
  if not value:failures.append(message)
 try:
  raw=(out/'receipt.json').read_bytes();native=json.loads(raw)
  require(returncode==0,'Native exit status not zero')
  require(native.get('status')==COMPLETE,'Native aggregate incomplete or failed')
  for key in ['error','contextCleanupError','ownedIdentityError','finalGuardError']:
   require(key not in native,'Native failure field present: '+key)
  require('ownedCleanupError' in native and native['ownedCleanupError'] is None,'Strict owned cleanup not proved')
  before=native.get('ownedBefore');after=native.get('ownedAfter')
  require(isinstance(before,dict) and isinstance(after,dict),'Owned before/after identity required')
  if isinstance(before,dict) and isinstance(after,dict):
   for key in ['pid','creation','profile','commandLine','executable','port']:
    require(key in before and key in after and before[key]==after[key],'Owned identity mismatch: '+key)
  for key in ['preservedBefore','preservedAfter']:
   row=native.get(key)
   require(isinstance(row,dict) and row.get('completeCanonicalObservation') is True,'Complete protected observation required: '+key)
  for key in ['preservedTargetBefore','preservedTargetAfter']:
   require(isinstance(native.get(key),list),'Protected targets result required: '+key)
  records=native.get('records',[])
  require(isinstance(records,list) and [r.get('key') for r in records]==[f['key'] for f in fixtures],'Exactly expected ordered cases required')
  for record,fixture in zip(records,fixtures):
   require(record.get('status')==CASE_COMPLETE,'Incomplete native case: '+fixture['key'])
   require(record.get('fixtureSHA256')==pins['files'][fixture['path']],'Case fixture differs sealed input: '+fixture['key'])
   for key in ['error','screenshotError']:
    require(key not in record,'Native case error: '+fixture['key']+'/'+key)
   path=out/fixture['key']/'receipt.json'
   require(json.loads(path.read_bytes())==record,'Per-case receipt differs native aggregate: '+fixture['key'])
   require(native['outputFileSHA256'][str(path)]==sha(path.read_bytes()),'Per-case receipt hash mismatch: '+fixture['key'])
  expected_echo={**pins,'config':{**pins['config'],'fixtures':fixtures}}
  require(json.loads((out/'pins.json').read_bytes())==expected_echo,'Native pins echo differs sealed input')
 except Exception as error:failures.append('Native receipt validation failure: '+str(error))
 return {'pass':not failures,'failures':failures,'receiptPath':str(out/'receipt.json'),'receiptSHA256':sha(raw) if raw is not None else None}

def supervise(pins_path,out,verify,make_native_command,fixture=None):
 """Run canonical precheck and canonical final check around one native attempt."""
 pb=pins_path.read_bytes();pins=json.loads(pb);initial_sha=sha(pb)
 if out.exists():raise RuntimeError('Fresh native output required')
 evidence=out.with_name(out.name+'.supervisor');evidence.mkdir()
 state={'status':'PRESERVED_FAILURE_OR_UNKNOWN','nativeReceiptModified':False,'pinsPath':str(pins_path),'pinsSHA256':initial_sha,'performanceClaim':False,'geometryAcceptanceClaim':False}
 before=None;after=None;child=None
 try:
  before=process_record(verify,evidence,'source-before');state['sourceBefore']=before
  if not verified(before):raise RuntimeError('Canonical initial Linux source verification failed')
  if sha(pins_path.read_bytes())!=initial_sha:raise RuntimeError('Pins changed before native launch')
  child=process_record(make_native_command(),evidence,'native');state['nativeProcess']=child
 except Exception as error:state['supervisorError']={'message':str(error),'code':getattr(error,'errno',None),'type':type(error).__name__}
 finally:
  # This is the same sealed filesystem/source/runtime verifier formerly called twice at completion.
  # It runs after the native collector has completed its strict cleanup and protected checks.
  after=process_record(verify,evidence,'source-after');state['sourceAfter']=after
  selected=pins['config']['fixtures'] if fixture is None else [f for f in pins['config']['fixtures'] if f['key']==fixture]
  state['nativeRequirements']=native_requirements(out,pins,selected,child['status'] if child else None)
  state['pinsUnchanged']=pins_path.is_file() and sha(pins_path.read_bytes())==initial_sha
  state['gates']={'sourceBefore':before is not None and verified(before),'nativeProcess':child is not None and child['status']==0 and child['error'] is None,'nativeCaptureCleanupProtected':state['nativeRequirements']['pass'],'sourceAfter':verified(after),'pinsUnchanged':state['pinsUnchanged'],'supervisorNoError':'supervisorError' not in state}
  if all(state['gates'].values()):state['status']='NATIVE_CAPTURE_AND_FINAL_LINUX_SOURCE_VERIFICATION_COMPLETE_NOT_GEOMETRY_QUALIFICATION'
  save(evidence/'composite-receipt.json',state)
  if out.is_dir():save(out/'composite-receipt.json',state)
 return 0 if all(state['gates'].values()) else 2
