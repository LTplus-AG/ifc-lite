/** Scratch alternative only; no execution or timing approval. */
import { independentPageAndChildren } from './flat-child-session.mjs';
import { installPassivePageRetention as installCore } from './retention-core.mjs';
export async function installPassivePageRetention(context,page,origin,files,ownedEndpoint) {
 const session=await independentPageAndChildren(context,page,ownedEndpoint);
 try {
  const proof=await installCore(context,page,origin,files,session);
  return {...proof,childSessionAudit:session.audit,
    async finishOwnSessionConfiguration(){await session.finishObservers();}};
 } catch(error) {
  error.observerAudit=session.audit;
  try { await session.detach(); } catch(cleanupError) {
   const failure=new AggregateError([error,cleanupError],'Child retention setup and observer cleanup failed',{cause:error});
   failure.observerAudit=session.audit;throw failure;
  }
  throw error;
 }
}
