"""Validate actual build source bytes against one exact Git commit using one cat-file process."""
from pathlib import PurePosixPath
import hashlib,re,subprocess,tempfile

def verify_committed_source(root,head,manifest):
 sha=lambda data:hashlib.sha256(data).hexdigest()
 if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',head):raise RuntimeError('Malformed exact commit identity')
 if not isinstance(manifest,dict) or not manifest:raise RuntimeError('Nonempty source manifest required')
 def current_head():return subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
 backend='/home/louistrue/wt/7292-4fbe-main592-merge-preparation-v1'
 def identity():
  if current_head()!=head:raise RuntimeError('Source HEAD changed during exact blob verification')
  trees=[subprocess.check_output(['git','-C',str(repo),'rev-parse',head+'^{tree}'],text=True).strip()for repo in [root,backend]]
  if trees[0]!=trees[1]:raise RuntimeError('Actual source and read-only backend exact commit trees differ')
  return trees[0]
 exact_tree=identity()
 # Resolve exact committed paths ONCE; per-blob reads below use only this OID.
 raw_tree=subprocess.check_output(['git','-C',str(backend),'ls-tree','-r','-z','--full-tree',head])
 if not raw_tree.endswith(b'\0'):raise RuntimeError('Missing or malformed exact committed tree')
 entries={}
 for record in raw_tree[:-1].split(b'\0'):
  fields=record.split(b'\t',1)
  if len(fields)!=2 or not fields[1] or fields[1]in entries:raise RuntimeError('Malformed or duplicate committed tree path')
  match=re.fullmatch(rb'([0-7]{6}) (blob|tree|commit) ([0-9a-f]{40}|[0-9a-f]{64})',fields[0])
  if match is None:raise RuntimeError('Malformed committed tree entry')
  entries[fields[1]]=(match[1],match[2],match[3])
 with tempfile.TemporaryFile() as stderr:
  proc=subprocess.Popen(['git','-C',str(backend),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr)
  try:
   for rel,expected in manifest.items():
    path=PurePosixPath(rel)
    if not isinstance(rel,str) or any(c in rel for c in '\x00\r\n') or path.is_absolute() or '..' in path.parts or str(path)!=rel:raise RuntimeError('Malformed source manifest path')
    if not isinstance(expected,str) or not re.fullmatch('[0-9a-f]{64}',expected):raise RuntimeError('Malformed source SHA256')
    entry=entries.get(rel.encode('utf8'))
    if entry is None or entry[1]!=b'blob' or entry[0]not in (b'100644',b'100755',b'120000'):raise RuntimeError('Missing or non-blob committed source path: '+rel)
    oid=entry[2]
    actual=(root/rel).read_bytes()
    if sha(actual)!=expected:raise RuntimeError('Built worktree source changed: '+rel)
    # Request/read one object at a time within the SAME process, avoiding pipe deadlock.
    proc.stdin.write(oid+b'\n');proc.stdin.flush()
    header=proc.stdout.readline(256)
    match=re.fullmatch(rb'([0-9a-f]{40}|[0-9a-f]{64}) blob ([0-9]+)\n',header)
    if match is None or match[1]!=oid:raise RuntimeError('Missing, mismatched or malformed committed blob: '+rel)
    size=int(match[2])
    if size!=len(actual):raise RuntimeError('Committed blob byte length differs build source: '+rel)
    digest=hashlib.sha256();remaining=size
    while remaining:
     data=proc.stdout.read(min(remaining,65536))
     if not data:raise RuntimeError('Truncated committed blob: '+rel)
     digest.update(data);remaining-=len(data)
    if proc.stdout.read(1)!=b'\n':raise RuntimeError('Malformed committed blob terminator: '+rel)
    if digest.hexdigest()!=expected:raise RuntimeError('Build source differs exact committed blob: '+rel)
   proc.stdin.close()
   if proc.stdout.read(1)!=b'':raise RuntimeError('Unexpected extra cat-file output')
   if proc.wait()!=0:raise RuntimeError('Git batch blob verification failed')
  except BaseException:
   if proc.poll() is None:proc.kill()
   proc.wait();raise
  finally:
   if not proc.stdin.closed:proc.stdin.close()
   proc.stdout.close()
 if identity()!=exact_tree:raise RuntimeError('Exact source/backend tree changed during blob verification')
