/** Supported CDP flat envelopes, independent of Playwright's private connections. NOT QUALIFIED. */
import { raceWithTimeout } from './browser-cold-teardown.mjs';

export async function independentPageAndChildren(context, page, ownedEndpoint) {
  const endpoint = new URL(ownedEndpoint);
  if (!['127.0.0.1', 'localhost'].includes(endpoint.hostname) || endpoint.protocol !== 'http:')
    throw Error('Verified owned loopback endpoint required');
  const lookup = await raceWithTimeout(context.newCDPSession(page), 10000, 'Public owned-page target lookup');
  let target;
  try { target = (await raceWithTimeout(lookup.send('Target.getTargetInfo'), 10000, 'Owned page target identity')).targetInfo; }
  finally { await raceWithTimeout(lookup.detach(), 5000, 'Detach target lookup observer'); }
  if (target.type !== 'page' || !target.targetId) throw Error('Actual owned page target required');
  const version = await fetch(new URL('/json/version', endpoint), { signal: AbortSignal.timeout(5000) });
  if (!version.ok) throw Error('Owned CDP endpoint metadata unavailable');
  const websocketURL = new URL((await version.json()).webSocketDebuggerUrl);
  if (websocketURL.protocol !== 'ws:' || websocketURL.hostname !== endpoint.hostname ||
      websocketURL.port !== endpoint.port || !websocketURL.pathname.startsWith('/devtools/browser/'))
    throw Error('Browser websocket does not match verified owned endpoint');

  const socket = new WebSocket(websocketURL);
  const handlers = new Map();
  const pending = new Map();
  const sessions = new Map();
  const initializing = new Set();
  const requestOwners = new Map();
  const responseOwners = new Map();
  const extraStatusOwners = new Map();
  const finished = new Map();
  const audit = { commands: [], acknowledgements: [], targets: [], network: [], errors: [] };
  let nextId = 0, pageSession, cancelled = false, pageConfigured = false, deliberateClose = false;
  let enableParams, durableParams;
  const filter = [{ type: 'worker', exclude: false }, { type: 'iframe', exclude: false }, { exclude: true }];
  const emit = (name, event) => { for (const listener of handlers.get(name) ?? []) listener(event); };
  function raw(method, params = {}, sessionId, cleanup = false) {
    if (cancelled && !cleanup) return Promise.reject(Error('Independent observer cancelled'));
    const id = ++nextId;
    audit.commands.push({ id, method, params, sessionId: sessionId ?? null });
    const result = new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject, method, sessionId });
      socket.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
    return raceWithTimeout(result, 10000, 'Independent CDP ' + method).finally(() => pending.delete(id));
  }
  async function configureChild(sessionId) {
    // Never pause or resume a target. Existing Playwright retains its own lifecycle unchanged.
    const results = await Promise.allSettled([
      raw('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: false, flatten: true, filter }, sessionId),
      // Same ordered WebSocket: enable is dispatched before durable registration,
      // without waiting a renderer ACK roundtrip before sending that registration.
      raw('Network.enable', enableParams, sessionId),
      raw('Network.configureDurableMessages', durableParams, sessionId),
    ]);
    const failures = results.filter(result => result.status === 'rejected').map(result => result.reason);
    if (failures.length) throw new AggregateError(failures, 'Required child recursion/network configuration did not all acknowledge');
    sessions.get(sessionId).configurationComplete = true;
  }
  function attached(message) {
    const { sessionId, targetInfo, waitingForDebugger } = message.params;
    const row = { sessionId, parentSessionId: message.sessionId ?? null, targetId: targetInfo.targetId,
      type: targetInfo.type, url: targetInfo.url, waitingForDebugger, detached: false, configurationComplete: false };
    audit.targets.push(row); sessions.set(sessionId, row);
    if (targetInfo.targetId === target.targetId && !message.sessionId) return;
    if (!pageConfigured || !sessions.has(message.sessionId) || !['worker', 'iframe'].includes(targetInfo.type)) {
      audit.errors.push({ error: 'Unexpected attached target', row }); return;
    }
    const work = configureChild(sessionId).catch(error => {
      audit.errors.push({ error: 'Child observer configuration incomplete', row, cause: String(error) });
    });
    initializing.add(work); work.finally(() => initializing.delete(work));
  }
  function network(message) {
    if (!['Network.requestWillBeSent', 'Network.responseReceived', 'Network.responseReceivedExtraInfo', 'Network.loadingFinished', 'Network.loadingFailed'].includes(message.method))
      return;
    if (!sessions.has(message.sessionId)) {
      audit.errors.push({ error: 'Network event from unrecognized owned session', sessionId: message.sessionId }); return;
    }
    const event = message.params;
    const url = event.request?.url ?? event.response?.url;
    if (url && !/\.(?:m?js|wasm)$/.test(new URL(url).pathname)) return;
    audit.network.push({ method: message.method, sessionId: message.sessionId, event });
    if (message.method === 'Network.requestWillBeSent') {
      const old = requestOwners.get(event.requestId);
      if (old) {
        if (old.sessions.includes(message.sessionId)) {
          audit.errors.push({ error: 'Repeated request ID within one session', event, sessionId: message.sessionId }); return;
        }
        old.sessions.push(message.sessionId);
        if (old.url !== url || event.redirectResponse)
          audit.errors.push({ error: 'Conflicting/redirected request ID', old, event });
        return;
      }
      requestOwners.set(event.requestId, { url, sessions: [message.sessionId] });
    } else if (message.method === 'Network.responseReceived') {
      const old = responseOwners.get(event.requestId);
      if (old) {
        if (old.sessions.includes(message.sessionId)) {
          audit.errors.push({ error: 'Repeated response ID within one session', event, sessionId: message.sessionId }); return;
        }
        old.sessions.push(message.sessionId);
        if (old.url !== url || old.status !== event.response.status)
          audit.errors.push({ error: 'Conflicting response metadata', old, event });
        return;
      }
      responseOwners.set(event.requestId, { url, status: event.response.status, sessions: [message.sessionId] });
      const extra = extraStatusOwners.get(event.requestId);
      if (extra && (extra.status !== event.response.status))
        audit.errors.push({ error: 'Conflicting or non-200 exact-ID extra status', extra, event });
      emit(message.method, event);
      // Reapply only an actually observed finish with the SAME CDP request ID.
      // Cross-session delivery can put that real finish before its response metadata.
      if (finished.has(event.requestId)) emit('Network.loadingFinished', finished.get(event.requestId));
      return;
    } else if (message.method === 'Network.responseReceivedExtraInfo') {
      const old = extraStatusOwners.get(event.requestId);
      if (old) {
        if (old.sessions.includes(message.sessionId) || old.status !== event.statusCode)
          audit.errors.push({ error: 'Repeated same-session or conflicting extra status', old, event, sessionId: message.sessionId });
        old.sessions.push(message.sessionId);
        return;
      }
      extraStatusOwners.set(event.requestId, { status: event.statusCode, sessions: [message.sessionId] });
      const response = responseOwners.get(event.requestId);
      if (response && (event.statusCode !== response.status))
        audit.errors.push({ error: 'Conflicting or non-200 exact-ID extra status', response, event });
    } else if (message.method === 'Network.loadingFinished') {
      if (finished.has(event.requestId)) return;
      finished.set(event.requestId, event);
    }
    emit(message.method, event);
  }
  socket.addEventListener('message', event => {
    let message;
    try { message = JSON.parse(String(event.data)); }
    catch (error) { audit.errors.push({ error: 'Malformed CDP envelope', cause: String(error) }); return; }
    if (message.id) {
      const call = pending.get(message.id);
      if (!call) { audit.errors.push({ error: 'Unmatched CDP response', id: message.id }); return; }
      pending.delete(message.id);
      audit.acknowledgements.push({ id: message.id, method: call.method, sessionId: call.sessionId ?? null,
        acknowledged: !message.error, error: message.error ?? null });
      if (message.error) call.reject(Error(call.method + ': ' + JSON.stringify(message.error)));
      else call.resolve(message.result ?? {});
      return;
    }
    if (message.method === 'Target.attachedToTarget') attached(message);
    else if (message.method === 'Target.detachedFromTarget') {
      const row = sessions.get(message.params.sessionId);
      if (row) row.detached = true;
      else audit.errors.push({ error: 'Unmatched child detach', event: message.params });
    } else if (message.method?.startsWith('Network.')) network(message);
  });
  socket.addEventListener('error', event => audit.errors.push({ error: 'Independent websocket transport error', detail: String(event.message ?? event) }));
  socket.addEventListener('close', () => {
    if (!deliberateClose) audit.errors.push({ error: 'Unexpected independent observer socket close' });
    cancelled = true;
    for (const call of pending.values()) call.reject(Error('Independent CDP socket closed: ' + call.method));
    pending.clear();
  });
  async function closeOwnSocket() {
    deliberateClose = true;
    if (socket.readyState === WebSocket.CLOSED) return;
    const closed = new Promise(resolve => socket.addEventListener('close', resolve, { once: true }));
    socket.close();
    await raceWithTimeout(closed, 5000, 'Close independent observer websocket');
  }
  try {
    await raceWithTimeout(new Promise((resolve, reject) => {
      socket.addEventListener('open', resolve, { once: true });
      socket.addEventListener('error', () => reject(Error('Independent CDP websocket open failed')), { once: true });
    }), 10000, 'Open independent owned browser websocket');
    ({ sessionId: pageSession } = await raw('Target.attachToTarget', { targetId: target.targetId, flatten: true }));
    if (sessions.get(pageSession)?.targetId !== target.targetId) throw Error('Owned page attachment identity mismatch');
  } catch (error) {
    cancelled = true;
    let failure = error;
    try { await closeOwnSocket(); }
    catch (cleanupError) { failure = new AggregateError([error, cleanupError], 'Observer setup and owned socket close failed', { cause: error }); }
    failure.observerAudit = audit;
    throw failure;
  }

  return {
    audit,
    on(name, callback) {
      if (!handlers.has(name)) handlers.set(name, []);
      handlers.get(name).push(callback);
    },
    async send(method, params) {
      if (method === 'Network.enable') enableParams = params;
      const value = await raw(method, params, pageSession);
      if (method === 'Network.configureDurableMessages') {
        durableParams = params; pageConfigured = true;
        // Attach only descendants of the positively identified owned page, not other browser tabs.
        await raw('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: false, flatten: true, filter }, pageSession);
        sessions.get(pageSession).configurationComplete = true;
      }
      return value;
    },
    async finishObservers() {
      while (initializing.size)
        await raceWithTimeout(Promise.all([...initializing]), 10000, 'Finish child observer configuration');
      if (audit.errors.length) throw Error('Independent child observation incomplete: ' + JSON.stringify(audit.errors));
      if ([...sessions.values()].some(row => !row.configurationComplete))
        throw Error('An owned observer session never completed configuration');
    },
    cancel() { cancelled = true; },
    async detach() {
      cancelled = true;
      try {
        await raw('Target.setAutoAttach', { autoAttach: false, waitForDebuggerOnStart: false, flatten: true }, pageSession, true);
        await raw('Target.detachFromTarget', { sessionId: pageSession }, undefined, true);
      } finally {
        cancelled = true;
        await closeOwnSocket();
      }
    },
  };
}
