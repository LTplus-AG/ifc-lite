/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
/**
 * Every line the renderer and viewer print when the renderer's device is lost,
 * in one place (#6993 review): each names its own log site. A loss surfaces
 * through one or more of them, so per sample the loss count is the largest
 * per-format count, never their sum. `destroyed` is intentional teardown.
 */
export const DEVICE_LOSS_LOG_FORMATS = [
    // packages/renderer/src/device.ts: the `device.lost` promise (Chromium).
    { site: 'WebGPUDevice.lost', pattern: /\[WebGPU\] Device lost:.*\(reason: ([\w-]+)\)/, reason: 1 },
    // packages/renderer/src/index.ts `handleDeviceLost`: also synchronous losses
    // (Safari throws, upload exceptions) that never settle `device.lost`.
    { site: 'Renderer.handleDeviceLost', pattern: /\[Renderer\] GPU device lost — halting rendering until re-init:/ },
    // apps/viewer/src/components/viewer/device-loss-report.ts: once per episode.
    { site: 'reportDeviceLost', pattern: /\[Viewport\] GPU device lost:/ },
];
const INSTANCE_LOST = /valid external Instance reference no longer exists/i;
const UNCAPTURED = /\[WebGPU\] Uncaptured error:/;
const MAX_EVENTS = 20;
/** Which loss format a console line is, or null; `destroyed` teardown lines are not losses. */
export function deviceLossFormat(line) {
    for (const { site, pattern, reason } of DEVICE_LOSS_LOG_FORMATS) {
        const match = pattern.exec(line);
        if (match && (reason === undefined || match[reason] !== 'destroyed'))
            return site;
    }
    return null;
}
export function gpuHealthFrom(consoleLogs, sessionCounters) {
    const lossesBySite = new Map();
    let instanceErrors = 0;
    let consoleUncaptured = 0;
    const events = [];
    for (const line of consoleLogs) {
        const site = deviceLossFormat(line);
        const isLoss = site !== null;
        // Loss lines quote the same message, and a destroyed-teardown line is no
        // instance error either; count that event once, as the loss.
        const isInstance = !isLoss && !DEVICE_LOSS_LOG_FORMATS[0].pattern.test(line) && INSTANCE_LOST.test(line);
        const isUncaptured = UNCAPTURED.test(line);
        if (site)
            lossesBySite.set(site, (lossesBySite.get(site) ?? 0) + 1);
        if (isInstance)
            instanceErrors++;
        if (isUncaptured)
            consoleUncaptured++;
        if ((isLoss || isInstance || isUncaptured) && events.length < MAX_EVENTS)
            events.push(line.slice(0, 300));
    }
    const consoleLost = Math.max(0, ...lossesBySite.values());
    const counter = (name) => sessionCounters?.[name] ?? 0;
    const deviceLost = Math.max(consoleLost, counter('gpu.deviceLost'));
    const uncapturedErrors = Math.max(consoleUncaptured, counter('gpu.uncapturedErrors'));
    const devicesCreated = sessionCounters ? counter('gpu.devices') : null;
    const deviceReplacements = sessionCounters ? counter('gpu.deviceReplacements') : null;
    const reasons = [];
    if (deviceLost > 0)
        reasons.push(`GPU device lost ≥${deviceLost}x`);
    if (deviceReplacements !== null && deviceReplacements > 0)
        reasons.push(`renderer replaced its GPU device ${deviceReplacements}x: scene re-uploaded`);
    return {
        contaminated: reasons.length > 0,
        reasons,
        deviceLost,
        instanceErrors,
        devicesCreated,
        deviceReplacements,
        uncapturedErrors,
        source: sessionCounters ? 'counters+console' : 'console',
        events,
    };
}
/** Where the viewer publishes its trace API under `?perfTrace=1`. */
const LOAD_TRACE_GLOBAL = '__IFC_LITE_LOAD_TRACE__';
/** Session counter totals, or null when the build exposes none (tracing off, or a pre-#6993 base). */
export async function readSessionCounters(page) {
    try {
        return await page.evaluate((key) => {
            const api = globalThis[key];
            return typeof api?.sessionCounters === 'function' ? api.sessionCounters() : null;
        }, LOAD_TRACE_GLOBAL);
    }
    catch (error) {
        // A crashed page or lost context cannot answer; the console witness still can.
        console.warn('[Benchmark] could not read session counters', error);
        return null;
    }
}
export async function readGpuHealth(page, consoleLogs) {
    return gpuHealthFrom(consoleLogs, await readSessionCounters(page));
}
