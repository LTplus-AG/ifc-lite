/** Actual-app passive metadata/body adapter. No interception, refetch or timing-time body reads. */
import { independentPageAndChildren } from './flat-child-session.mjs';
import { installPassivePageRetention as installCore } from './retention-core.mjs';
import { raceWithTimeout } from './browser-cold-teardown.mjs';

const need = (value, message) => { if (!value) throw Error(message); };
const runtime = url => /\.(?:m?js|wasm)$/.test(new URL(url).pathname);
const counts = rows => {
  const result = new Map();
  for (const row of rows) result.set(row.url, (result.get(row.url) ?? 0) + 1);
  return JSON.stringify([...result].sort(([a], [b]) => a.localeCompare(b)));
};

// Only the already-declared unpinned analytics404 occurrence may fail loading.
function optional404URL(url, expectedOrigin, pins) {
  const actual = new URL(url), path = decodeURIComponent(actual.pathname).replace(/^\//, '');
  return actual.origin === expectedOrigin && path === '_vercel/insights/script.js' && !pins.has(path);
}
export function permitsOptionalRaw404Failure(row, expectedOrigin, pins) {
  return row.decision === 'optional-absent' && Array.isArray(row.statuses) && row.statuses.length > 0 &&
    row.statuses.every(status => status === 404) && optional404URL(row.url, expectedOrigin, pins);
}
export function permitsOptionalPublic404Failure(failure, responses, expectedOrigin, pins) {
  const sameID = responses.filter(row => row.publicRequestID === failure.publicRequestID);
  return Number.isSafeInteger(failure.publicRequestID) && failure.publicRequestID > 0 && sameID.length === 1 &&
    sameID[0].status === 404 && sameID[0].url === failure.url && optional404URL(failure.url, expectedOrigin, pins);
}

export async function installRuntimeProof(context, page, origin, files, endpoint, retentionLimits) {
  const expectedOrigin = new URL(origin).origin;
  const pins = new Map(files.map(pin => [pin.path, pin]));
  need(pins.size === files.length && files.every(pin => Number.isSafeInteger(pin.bytes) && pin.bytes >= 0 && /^[a-f0-9]{64}$/.test(pin.sha256)),
    'Actual frozen distribution path, length and hash pins required');
  const requestIDs = new WeakMap();
  const observedRequests = [], publicResponses = [], publicFailures = [], rows = [], errors = [];
  const occurrences = new Map(), optionalRows = [], handlers = new Map();
  let nextPublicID = 0, stage = 'untimed-setup', cancelled = false, detached = false;
  let session, core;
  const setupPending = new Map(), setupErrors = [], metadataWaiters = new Set();
  let metadataVersion=0;
  function changed(){metadataVersion++;for(const resolve of metadataWaiters)resolve();metadataWaiters.clear();}
  async function waitForMetadata(version){
    if(cancelled)throw Error('Owned runtime observer retiring');
    if(metadataVersion!==version)return;
    let resolve;
    const pending=new Promise(done=>{resolve=done;metadataWaiters.add(done);});
    try{await raceWithTimeout(pending,10000,'Actual setup response/ID retention metadata');}
    finally{metadataWaiters.delete(resolve);}
  }
  function setupResponsesRetained(){
    const available=new Map();
    const add=(url,status)=>{const key=JSON.stringify([url,status]);available.set(key,(available.get(key)??0)+1);};
    for(const id of core.retainedSetupIDs())add(core.requests.get(id).url,200);
    for(const row of optionalRows)add(row.url,404);
    for(const row of publicResponses.filter(row=>row.stage==='untimed-setup')){
      const url=new URL(row.url),path=decodeURIComponent(url.pathname).replace(/^\//,'');
      need(url.origin===expectedOrigin&&(row.status===200||(row.status===404&&path==='_vercel/insights/script.js'&&!pins.has(path))),
        'Actual setup response is outside original permitted status/origin');
      const key=JSON.stringify([row.url,row.status]),left=available.get(key)??0;
      if(!left)return false;
      available.set(key,left-1);
    }
    return true;
  }
  function retainSetup(id) {
    if (cancelled || stage !== 'untimed-setup' || !core || setupPending.has(id)) return;
    const pending = core.retainUntimedSetupBody(id).catch(error => setupErrors.push({requestId:id,error:String(error)})).finally(changed);
    setupPending.set(id,pending);
  }
  const publicID = request => {
    if (!requestIDs.has(request)) requestIDs.set(request, ++nextPublicID);
    return requestIDs.get(request);
  };
  const onRequest = request => {
    if (runtime(request.url())) {observedRequests.push({ url: request.url(), publicRequestID: publicID(request), stage });changed();}
  };
  const onResponse = response => {
    if (runtime(response.url())) publicResponses.push({ url: response.url(), status: response.status(),
      publicRequestID: publicID(response.request()), stage });
    changed();
  };
  const onFailure = request => {
    if (runtime(request.url())) publicFailures.push({ url: request.url(), publicRequestID: publicID(request),
      error: request.failure()?.errorText ?? 'unknown request failure', stage });
    changed();
  };
  context.on('request', onRequest); context.on('response', onResponse); context.on('requestfailed', onFailure);
  const emit = (method, event) => { for (const listener of handlers.get(method) ?? []) listener(event); };
  function occurrence(id) {
    if (!occurrences.has(id)) occurrences.set(id, { requestId: id, events: [], statuses: [], decision: null });
    return occurrences.get(id);
  }
  function route(method, event) {
    const row = occurrence(event.requestId);
    const eventURL = event.request?.url ?? event.response?.url;
    if (eventURL) {
      if (row.url && row.url !== eventURL) errors.push({ error: 'Conflicting exact-ID runtime URL', requestId: event.requestId });
      row.url = eventURL;
    }
    if (method === 'Network.requestWillBeSent') row.requestObserved = true;
    const status = method === 'Network.responseReceivedExtraInfo' ? event.statusCode : event.response?.status;
    if (status !== undefined) {
      if (row.statuses.some(old => old !== status)) errors.push({ error: 'Conflicting exact-ID status', requestId: event.requestId });
      row.statuses.push(status);
    }
    if (method === 'Network.loadingFailed') {
      row.loadingFailed = true;
      row.loadingFailureEvent = event;
    }
    // Preserve actual metadata until an original-ID URL and status identify the one existing optional exception.
    row.events.push({ method, event });
    if (!row.decision && row.url && row.statuses.length) {
      const url = new URL(row.url), path = decodeURIComponent(url.pathname).replace(/^\//, '');
      if (url.origin !== expectedOrigin) errors.push({ error: 'Unexpected runtime origin', requestId: event.requestId, url: row.url });
      const optional = path === '_vercel/insights/script.js' && row.statuses.every(value => value === 404) && !pins.has(path);
      row.decision = optional ? 'optional-absent' : 'required';
      if (optional) optionalRows.push({ requestId: event.requestId, url: row.url, path, status: 404,
        optionalDeploymentAnalyticsAbsent: true, bodyRead: false });
    }
    if (row.decision === 'required') {
      const pending = row.events.splice(0);
      for (const actual of pending) {
        emit(actual.method, actual.event);
        if (actual.method === 'Network.loadingFinished' && core?.requests.has(event.requestId)) retainSetup(event.requestId);
      }
    } else if (row.decision === 'optional-absent') row.events.length = 0;
    changed();
  }
  function checkMetadata(requireComplete = false) {
    if (errors.length) throw Error('Runtime metadata error: ' + JSON.stringify(errors));
    for (const row of occurrences.values()) {
      // ExtraInfo for HTML/non-runtime fetches has no runtime URL and is outside the original JS/WASM contract.
      if (!row.url || !runtime(row.url)) continue;
      if(requireComplete) need(row.requestObserved && row.decision, 'Missing original runtime request/status ' + row.requestId);
      need(!row.loadingFailed || permitsOptionalRaw404Failure(row, expectedOrigin, pins), 'Actual raw runtime request failed ' + JSON.stringify(row.loadingFailureEvent));
      if (row.decision === 'required') need(row.statuses.every(value => value === 200), 'Required runtime status is not200 ' + row.requestId);
    }
    need(publicFailures.every(failure => permitsOptionalPublic404Failure(failure, publicResponses, expectedOrigin, pins)), 'Actual public runtime request failed: ' + JSON.stringify(publicFailures));
  }
  async function finishOriginalMetadata() {
    const deadline = Date.now() + 10000;
    for (;;) {
      const version = metadataVersion;
      await session.finishObservers();
      checkMetadata();
      const pending = [...occurrences.values()].some(row => row.url && runtime(row.url) && (!row.requestObserved || !row.decision));
      if (!pending) return;
      const remaining = deadline - Date.now();
      need(remaining > 0, 'Original runtime request/status metadata deadline');
      await raceWithTimeout(waitForMetadata(version), remaining, 'Original runtime request/status metadata');
    }
  }
  try {
    session = await independentPageAndChildren(context, page, endpoint);
    for (const method of ['Network.requestWillBeSent', 'Network.responseReceived', 'Network.responseReceivedExtraInfo', 'Network.loadingFinished', 'Network.loadingFailed'])
      session.on(method, event => route(method, event));
    const gated = {
      on(method, listener) { if (!handlers.has(method)) handlers.set(method, []); handlers.get(method).push(listener); },
      send: (method, params) => session.send(method, params),
      finishObservers: () => session.finishObservers(),
      cancel() { session.cancel(); },
      detach: () => session.detach(),
    };
    core = await installCore(context, page, origin, files, gated, retentionLimits);
  } catch (error) {
    context.off('request', onRequest); context.off('response', onResponse); context.off('requestfailed', onFailure);
    if (session) try { await session.detach(); }
    catch (cleanupError) { throw new AggregateError([error, cleanupError], 'Runtime setup and owned observer cleanup failed'); }
    throw error;
  }
  return {
    rows, observedRequests, publicResponses, publicFailures, ready: Promise.resolve(),
    async finishUntimedSetup() {
      need(stage === 'untimed-setup'&&!cancelled, 'Canonical setup may end once');
      // Drain every setup read before upload; a late setup response extends this drain.
      for (;;) {
        need(!cancelled,'Owned runtime observer retired during setup');
        const version=metadataVersion;
        await session.finishObservers(); checkMetadata();
        for (const request of core.requests.values()) retainSetup(request.requestId);
        await Promise.all([...setupPending.values()]);
        need(!setupErrors.length, 'Untimed original-body retention failed: '+JSON.stringify(setupErrors));
        if (core.requests.size===core.retainedSetupIDs().length&&setupResponsesRetained()) break;
        await waitForMetadata(version);
      }
      need(!cancelled,'Owned runtime observer retired before upload');
      stage = 'operation'; core.markWorkStarted();
    },
    async verify(wasmSHA256, completionWitness) {
      need(stage === 'operation' && !cancelled, 'Post-operation verification may run once');
      // The original wrapper has already required real completion, four-worker pool, content and no errors.
      core.markOperationCompleted(completionWitness); stage = 'post-operation';
      await finishOriginalMetadata(); checkMetadata(true);
      await core.verifyAll();
      const verified = core.verified;
      need(verified.some(row => row.path.endsWith('.wasm')), 'No actual WASM payload');
      for (const row of verified) if (row.path.endsWith('.wasm')) need(row.sha256 === wasmSHA256, 'Actual delivered WASM differs side pin');
      rows.push(...optionalRows, ...verified.map(row => ({ ...row, status: row.certificate.status,
        passiveBodyReadAfterTiming: row.bodyReadPhase !== 'setup', passiveBodyReadDuringUntimedSetup: row.bodyReadPhase === 'setup' })));
      need(new Set(rows.map(row => row.requestId)).size === rows.length, 'Duplicate runtime occurrence proof');
      need(counts(observedRequests) === counts(publicResponses) && counts(observedRequests) === counts(rows),
        'Every public request/response occurrence needs its own original-ID certificate');
      const expectedPublic = new Map(publicResponses.map(row => [row.publicRequestID, row]));
      need(expectedPublic.size === publicResponses.length && observedRequests.every(row => expectedPublic.has(row.publicRequestID)),
        'Public response occurrence ownership mismatch');
      for (const row of publicResponses) {
        const path = decodeURIComponent(new URL(row.url).pathname).replace(/^\//, '');
        need(new URL(row.url).origin === expectedOrigin &&
          (row.status === 200 || (path === '_vercel/insights/script.js' && row.status === 404 && !pins.has(path))),
          'Public runtime status/origin not permitted');
      }
      const negative = await core.negativeUnknownRequest(); need(negative.refused, 'Unknown-ID negative control failed');
      this.negativeUnknownRequest = negative;
      await finishOriginalMetadata(); checkMetadata(true);
      need(!core.errors.length && core.requests.size === core.verified.length, 'Late body/coverage failure');
      stage = 'verified';
    },
    snapshot() {
      return { stage, errors, setupErrors, retainedSetupIDs:core.retainedSetupIDs(), retentionLimits, publicFailures, publicResponses, optionalRows,
        occurrences: [...occurrences.values()].map(({ events, ...row }) => ({ ...row, pendingEventCount: events.length })),
        requests: [...core.requests.values()], responseCertificates: [...core.responseCertificates.values()],
        operationCompletionWitness: core.operationCompletionWitness, verified: core.verified,
        events: core.events, commands: core.commands, coreErrors: core.errors, childSessionAudit: session.audit };
    },
    async detach() {
      if (detached) return;
      detached = true; cancelled = true; core.cancel();changed();
      try { await Promise.all([...setupPending.values()]);await session.finishObservers(); checkMetadata(stage==='verified'); }
      finally {
        try { await core.detach(); }
        finally { context.off('request', onRequest); context.off('response', onResponse); context.off('requestfailed', onFailure); }
      }
      need(!session.audit.errors.length && !core.errors.length, 'Late observer error during retirement');
      if (stage === 'verified') need(core.requests.size === core.verified.length && counts(observedRequests) === counts(rows),
        'Late runtime occurrence after verified byte snapshot');
    },
  };
}

// Reused unchanged from the original canonical collector.
export function requireFourWorkerPool(trace) {
  const pools = trace?.spans.filter(s => s.name === 'geometry.pool') ?? [];
  if (trace?.attrs?.loadPath !== 'wasm' || trace.attrs.workerCount !== 4 || !pools.length ||
      pools.some(s => s.attrs?.workerCount !== 4 || typeof s.end !== 'number' || !Number.isFinite(s.end)))
    throw Error('Actual completed WASM geometry.pool with four workers required');
  return pools;
}
