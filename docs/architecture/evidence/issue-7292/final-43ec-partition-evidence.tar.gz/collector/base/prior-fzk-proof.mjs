/** Require an ACTUAL same-runtime prior FZK composite PASS, never a relabeled failed capture. */
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const need=(v,m)=>{if(!v)throw Error(m);};
export function verifyPriorFzk(c,readBytes){
 const pin=c.priorFzkComposite;need(pin&&/^[0-9a-f]{64}$/.test(pin.sha256),'Actual prior FZK composite pin required');
 const bytes=readBytes(pin.path);need(sha(bytes)===pin.sha256,'Prior FZK composite drift');const q=JSON.parse(bytes);
 const gates=['sourceBefore','nativeProcess','nativeCaptureCleanupProtected','sourceAfter','pinsUnchanged','supervisorNoError'];
 need(q.status==='NATIVE_CAPTURE_AND_FINAL_LINUX_SOURCE_VERIFICATION_COMPLETE_NOT_GEOMETRY_QUALIFICATION'&&gates.every(k=>q.gates?.[k]===true)&&q.nativeRequirements?.pass===true,'Prior FZK composite is not a complete real PASS');
 const rawBytes=readBytes(q.nativeRequirements.receiptPath);need(sha(rawBytes)===q.nativeRequirements.receiptSHA256,'Prior FZK native receipt drift');const raw=JSON.parse(rawBytes);
 need(raw.status==='FRESH_OWNED_CHROME_RUNTIME_CAPTURE_COMPLETE_NOT_GEOMETRY_QUALIFICATION'&&raw.compiledArtifactRevision===c.expectedHead&&raw.ownedCleanupError===null&&raw.records?.length===1&&raw.records[0].key==='FZK'&&raw.records[0].status==='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED','Prior actual FZK protocol/cleanup/source incomplete');
 const pb=readBytes(q.pinsPath);need(sha(pb)===q.pinsSHA256,'Prior FZK sealed pins drift');const pp=JSON.parse(pb);
 const bb=readBytes(c.buildReceiptPath);need(pp.head===c.expectedHead&&pp.files?.[c.buildReceiptPath]===sha(bb),'FZK belongs to another final build');const build=JSON.parse(bb);
 need(build.builtRevision===c.expectedHead&&build.wasmSha256===pp.wasmSha256&&build.distSha256===pp.distSha256&&pp.config.frozenDist===c.frozenDist,'FZK does not bind same source/frozen runtime');
 return [pin.path,q.nativeRequirements.receiptPath,q.pinsPath];
}
if(process.argv.includes('--verify-prior-fzk')){const a=n=>process.argv[process.argv.indexOf(n)+1];const fs=await import('node:fs');verifyPriorFzk(JSON.parse(fs.readFileSync(a('--config'))),fs.readFileSync);console.log('ACTUAL_SAME_RUNTIME_FZK_PASS_VERIFIED');}
