/** Shared private harness guard. Reading/sealing is filesystem-only; observe() is explicit Windows readonly CIM. */
import {createHash} from 'node:crypto';
import {join} from 'node:path/posix';
const sha=value=>createHash('sha256').update(value).digest('hex');
function need(value,message){if(!value)throw Error(message);}
function profileArgument(args){
 need(Array.isArray(args)&&args.length>0&&args.every(x=>typeof x==='string'),'Inventory must retain positively parsed Windows arguments');
 const values=[];
 for(let i=0;i<args.length;i++){
  if(args[i].startsWith('--user-data-dir='))values.push(args[i].slice('--user-data-dir='.length));
  else if(args[i]==='--user-data-dir'){need(i+1<args.length,'Incomplete explicit profile argument');values.push(args[++i]);}
 }
 need(values.length<=1&&values.every(x=>x.length>0),'Ambiguous or empty explicit profile argument');
 return values.length?values[0]:null;
}
function normalizedBrowser(value,args){
 need(value&&Number.isSafeInteger(value.pid)&&value.pid>0&&typeof value.creation==='string'&&Number.isFinite(Date.parse(value.creation)),'Current process creation identity required');
 need(typeof value.commandLine==='string'&&value.commandLine.length>0&&typeof value.executable==='string'&&value.executable.length>0,'Current command and executable observation required');
 need(value.profile===null||(typeof value.profile==='string'&&value.profile.length>0),'Observed explicit profile or positive absence required');
 if(args){need(!args.some(a=>a.startsWith('--type='))&&profileArgument(args)===value.profile,'Inventory root/profile does not match positively parsed Windows arguments');}
 need(value.port===null||(Number.isInteger(value.port)&&value.port>0&&value.port<=65535),'Actual listener port or positive no-CDP observation required');
 need(value.port===null||Array.isArray(value.targets),'Actual CDP target observation must accompany an observed listener');
 const targets=value.targets??[];
 need(Array.isArray(targets)&&targets.every(t=>t&&typeof t.id==='string'&&t.id.length>0&&typeof t.url==='string'),'Observed target identities required');
 need(value.port!==null||targets.length===0,'No CDP targets without an actual listener');
 return {pid:value.pid,creation:value.creation,profile:value.profile,commandLine:value.commandLine,executable:value.executable,port:value.port,targets};
}
export function readProtectedBinding(preparation,readFileSync){
 const bindingPath=join(preparation,'protected-user-binding.json');const binding=JSON.parse(readFileSync(bindingPath,'utf8'));
 need(binding.status==='REVIEWED_CURRENT_PROTECTED_BROWSER_INVENTORY'&&typeof binding.inventoryPath==='string'&&/^[a-f0-9]{64}$/.test(binding.inventorySHA256),'Actual reviewed private inventory binding required');
 const bytes=readFileSync(binding.inventoryPath);need(sha(bytes)===binding.inventorySHA256,'Protected inventory SHA drift');const inventory=JSON.parse(bytes.toString('utf8'));
 need(inventory.status==='COMPLETE_READONLY_CHROME_INVENTORY'&&inventory.completeCanonicalObservation===true&&typeof inventory.observedUtc==='string'&&Number.isFinite(Date.parse(inventory.observedUtc)),'Complete canonical readonly Chrome inventory required');
 need(Number.isSafeInteger(inventory.chromeProcessCount)&&inventory.chromeProcessCount>=0&&Number.isSafeInteger(inventory.rootCount)&&Array.isArray(inventory.browsers)&&inventory.rootCount===inventory.browsers.length&&inventory.chromeProcessCount>=inventory.rootCount,'Positive Chrome/root counts required');
 need(Array.isArray(binding.browsers)&&binding.browsers.length===inventory.rootCount,'Protected root set must match reviewed inventory');
 const browsers=inventory.browsers.map(row=>{need(Array.isArray(row.arguments),'Inventory must retain actual positively parsed arguments');return normalizedBrowser(row,row.arguments);});
 need(new Set(browsers.map(b=>b.pid)).size===browsers.length,'Duplicate protected root identity');
 need(new Set(binding.browsers.map(b=>b?.pid)).size===binding.browsers.length,'Duplicate bound protected root');
 for(const value of binding.browsers){const actual=normalizedBrowser(value);const expected=browsers.find(b=>b.pid===actual.pid);need(expected&&JSON.stringify(actual)===JSON.stringify(expected),'Binding differs from actual inventoried root identity');}
 if(inventory.rootCount===0)need(inventory.chromeProcessCount===0,'Missing root rows are not proof of zero Chrome');
 return {bindingPath,inventoryPath:binding.inventoryPath,inventorySHA256:binding.inventorySHA256,observedUtc:inventory.observedUtc,chromeProcessCount:inventory.chromeProcessCount,browsers,completeZeroChrome:inventory.chromeProcessCount===0};
}
export function createProtectedBrowserGuard(preparation,{readFileSync,execFileSync}){
 function observe(){
  const binding=readProtectedBinding(preparation,readFileSync),encoded=Buffer.from(JSON.stringify(binding),'utf8').toString('base64');
  const script=`$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';${readFileSync(join(preparation,'frame-gpu-owned-profile.ps1'),'utf8')}
$b=ConvertFrom-Json ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${encoded}')))
$all=@(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'")
# Return value ignored: the unchanged strict helper validates EVERY CIM row first.
# This observation-only label is never ownership evidence or a launched profile.
[void]@(Get-OwnedChromeProcesses -Profile '__IFCLITE_COMPLETE_OBSERVATION_ONLY__' -Processes $all -RequireCompleteObservation)
$roots=@();foreach($p in $all){$parsed=@([IfcChromeArgs]::Split($p.CommandLine));if(@($parsed|Where-Object {$_.StartsWith('--type=')}).Count -eq 0){$roots+=@{process=$p;arguments=$parsed}}}
if($b.completeZeroChrome){if($all.Count -ne 0 -or $roots.Count -ne 0){throw 'Expected positively observed zero Chrome changed'};@{completeCanonicalObservation=$true;chromeProcessCount=0;rootCount=0;browsers=@();observedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8 -Compress;exit 0}
if($roots.Count -ne @($b.browsers).Count){throw 'Protected current root set changed'}
$rows=@();foreach($w in $b.browsers){$rootMatches=@($roots|Where-Object {$_.process.ProcessId -eq $w.pid});if($rootMatches.Count -ne 1){throw 'Protected current root absent'};$row=$rootMatches[0];$p=$row.process
if($p.CreationDate.ToUniversalTime().ToString('o') -cne $w.creation -or $p.CommandLine -cne $w.commandLine -or $p.ExecutablePath -cne $w.executable){throw 'Protected current process identity changed'}
$profiles=@();for($i=0;$i -lt $row.arguments.Count;$i++){$arg=$row.arguments[$i];if($arg.StartsWith('--user-data-dir=')){$profiles+=$arg.Substring(16)}elseif($arg -ceq '--user-data-dir'){if($i+1 -ge $row.arguments.Count){throw 'Incomplete profile argument'};$i++;$profiles+=$row.arguments[$i]}}
if($null -eq $w.profile){if($profiles.Count -ne 0){throw 'Protected default-profile argument absence changed'}}elseif($profiles.Count -ne 1 -or $profiles[0] -cne $w.profile){throw 'Protected explicit profile argument changed'}
if($null -ne $w.port){$ls=@(Get-NetTCPConnection -State Listen -LocalPort $w.port);if($ls.Count -eq 0 -or @($ls|Where-Object {$_.OwningProcess -ne $w.pid}).Count -ne 0){throw 'Protected actual listener owner changed'}}
$rows+=@{pid=$p.ProcessId;creation=$p.CreationDate.ToUniversalTime().ToString('o');profile=$w.profile;commandLine=$p.CommandLine;executable=$p.ExecutablePath;port=$w.port}}
@{completeCanonicalObservation=$true;chromeProcessCount=$all.Count;rootCount=$roots.Count;browsers=$rows;observedUtc=[DateTime]::UtcNow.ToString('o')}|ConvertTo-Json -Depth 8 -Compress`;
  return JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{encoding:'utf8',timeout:15000}));
 }
 async function targets(){
  const results=[];
  for(const witness of readProtectedBinding(preparation,readFileSync).browsers){
   if(witness.port===null)continue;
   const response=await fetch(`http://127.0.0.1:${witness.port}/json/list`,{signal:AbortSignal.timeout(5000)});need(response.ok,'Protected actual CDP metadata unavailable');const rows=await response.json();need(Array.isArray(rows),'Protected actual CDP target list malformed');
   for(const target of witness.targets){const found=rows.filter(x=>x.id===target.id);need(found.length===1&&found[0].url===target.url,'Protected actual target identity changed');results.push({pid:witness.pid,port:witness.port,...found[0]});}
  }
  return results;
 }
 return {observe,targets};
}
