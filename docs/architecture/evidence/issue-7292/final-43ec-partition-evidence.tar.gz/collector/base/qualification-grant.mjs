/** Actual direct-user-authorized window plus full unchanged host-admission requirements. */
import {verifyTimingAuthority,timingBindingFromArgs} from './timing-authority.mjs';
export function verifyQualificationAuthorization(readBytes){
 if(!process.argv.includes('--cohort-sample'))throw Error('Only explicit NEW cohort launch accepted');
 const authority=verifyTimingAuthority(timingBindingFromArgs(),readBytes);
 const arg=n=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
 const path=arg('--pins'),hash=arg('--expected-pins-sha256');
 if(!Object.values(authority.sides).some(p=>p.pinsPath===path&&p.pinsSHA256===hash))throw Error('Capture pins differ from actual direct-user-authorized window');
 return {...authority,acceptedBenchmarkRows:0,timingAuthorized:true};
}
if(process.argv.includes('--verify-authorization')){verifyQualificationAuthorization((await import('node:fs')).readFileSync);console.log('NEW_COHORT_USER_AUTHORIZATION_AND_BROWSER_LEASE_VERIFIED');}
