/** Exact fresh931/final54d transferred producer identity; local clone mtimes never assert a rebuild. */
import {readFileSync,statSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {join,relative,resolve,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
const SPECS={
 'b0b670f0cfd704ceb7c78a622f5730d0cd9510de':{side:'base',root:'/home/louistrue/wt/7292-final931-baseline-v1',out:'/tmp/7292-final-merge-base-official-consumer-remote-v1',proof:'/tmp/7292-final-merge-base-official-consumer-transfer-v1'},
 '43ecf3aa3e240e1a7c41c5c799212b60df010ebd':{side:'candidate',root:'/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69',out:'/tmp/7292-final-merge-official-consumer-remote-v1',proof:'/tmp/7292-final-merge-official-consumer-transfer-v1'}};
const need=(v,m)=>{if(!v)throw Error(m);};
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export function verifyTransferredFreshness(c,sourceManifest){
 const s=SPECS[c.expectedHead];need(s,'Only exact reviewed931/final54d transfer may use producer freshness');
 need(c.root===s.root&&c.frozenDist===s.out+'/frozen-dist'&&c.wasmPath===s.out+'/generated-package/ifc-lite_bg.wasm','Exact external transferred source/runtime roots required');
 need(c.remoteBuildTransfer?.receiptPath===s.proof+'/receipt.json'&&/^[a-f0-9]{64}$/.test(c.remoteBuildTransfer.sha256),'Actual exact transfer receipt path/SHA required');
 const files=[fileURLToPath(import.meta.url)],pin=(p,h)=>{need(hash(p)===h,'Original transferred input changed: '+p);files.push(p);return p;};
 const t=JSON.parse(readFileSync(pin(c.remoteBuildTransfer.receiptPath,c.remoteBuildTransfer.sha256))),rawPath=s.out+'/receipt.json';
 const r=JSON.parse(readFileSync(pin(rawPath,t.originalReceiptSHA256)));
 need(t.compiledHead===c.expectedHead&&t.newLocalGitClean===true&&t.status.startsWith('REMOTE_COMPLETED_')&&t.status.includes('TRANSFER_VERIFIED_NOT_LOCAL_BUILD_OR_BROWSER_QUALIFICATION'),'Completed exact-source transfer proof required');
 need(c.qualification.path===rawPath&&c.qualification.sha256===t.originalReceiptSHA256&&c.candidatePreparation===rawPath&&c.candidatePreparationSHA256===t.originalReceiptSHA256&&c.qualification.acceptedStatus===r.status,'Original raw producer stays explicit; no fabricated qualification status');
 need(r.head===c.expectedHead&&r.sourceUnchanged===true&&r.fixturesUnchanged===true&&r.officialPackageUnchanged===true&&!r.sourceGuardError&&r.finishedNs>r.startedNs,'Actual completed producer source/runtime guards required');
 const complete=s.side==='base'?'BASE_OFFICIAL_WASM_VIEWER_BUILD_COMPLETE_NOT_CONSUMER_OR_GEOMETRY_QUALIFIED':'FINAL_OFFICIAL_WASM_AND_ALL_CONSUMERS_COMPLETE_NOT_GEOMETRY_BROWSER_OR_PERFORMANCE_QUALIFIED';
 const sizeOnly=s.side==='base'?'BASE_BUILD_COMPLETE_PRESERVED_ENGINE_SIZE_BREACH_NOT_QUALIFIED':'FINAL_CANDIDATE_BUILD_COMPLETE_PRESERVED_ENGINE_SIZE_BREACH_NOT_QUALIFIED';
 need((r.status===complete&&!r.error)||(r.status===sizeOnly&&r.engineSizeVerdict==='FAIL'&&r.engineOverAllowed>0&&r.error==="RuntimeError('Actual engine still exceeds unchanged ceiling')"),'Complete producer or explicit preserved size-only failure required');
 need(same(Object.entries(r.sourceManifest).sort(),Object.entries(sourceManifest).sort()),'Complete compiled source map must match remote producer');
 for(const[p,h]of Object.entries(sourceManifest))need(hash(join(c.root,p))===h,'Actual compiled source byte drift: '+p);
 function mapped(path){const matches=t.pathMappings.filter(m=>{const p=relative(m.remotePrefix,path);return !p.startsWith('../')&&p!=='..'&&!isAbsolute(p);}).sort((a,b)=>b.remotePrefix.length-a.remotePrefix.length);need(matches.length,'Missing explicit transfer mapping: '+path);return resolve(matches[0].localPrefix,relative(matches[0].remotePrefix,path));}
 need(mapped(r.root)===c.root,'Remote/current source map differs');
 const manifest=JSON.parse(readFileSync(pin(s.proof+'/remote-output-manifest.json',t.originalOutputManifestSHA256)));
 function originalOutput(m){const directory=mapped(m.remoteRoot);for(const[n,v]of Object.entries(m.files)){const p=join(directory,n);need(statSync(p).size===v.bytes,'Original output length differs');pin(p,v.sha256);}}
 originalOutput(manifest);
 need(same(JSON.parse(readFileSync(pin(s.out+'/source-before.json',r.sourceManifestSHA256))),sourceManifest),'Original full source-map file differs');
 let prior=null,rows=r.steps.map(step=>({owner:r,step}));
 if(s.side==='base'){
  const stages=r.steps.map(x=>x.stage),prefix=stages[0]==='install'?['install']:stages[1]==='install'?['install-offline','install']:['install-offline'];
  need(same(stages,prefix.concat(['build-wasm','engine-size','build-nonwasm-dry-run','build-nonwasm'])),'Fresh full BASE stage shape differs; historical continuation not admitted');
  if(prefix.length===2)need(r.offlineInstallFailurePreserved===true&&r.steps[0].exitCode===1&&readFileSync(mapped(r.steps[0].logPath),'utf8').includes('ERR_PNPM_NO_OFFLINE_TARBALL'),'Only exact missing-cache install failure admitted');
 }else{
  const stages=r.steps.map(x=>x.stage),prefix=stages[1]==='install'?['install-offline','install']:['install-offline'];
  need(same(stages,prefix.concat(['build-wasm','engine-size','build-nonwasm-dry-run','typecheck-only-dry-run','wasm-test-only-dry-run','build-nonwasm','typecheck','typecheck-tail','wasm-contract','wasm-package','viewer-storey-live-frame'])),'Actual candidate stage shape differs');
  if(prefix.length===2)need(r.offlineInstallFailurePreserved===true&&r.steps[0].exitCode===1&&readFileSync(mapped(r.steps[0].logPath),'utf8').includes('ERR_PNPM_NO_OFFLINE_TARBALL'),'Only exact missing-cache install failure admitted');
  need(same(r.consumerStagesCompleted,['build-nonwasm','typecheck','typecheck-tail','wasm-contract','wasm-package','viewer-storey-live-frame'])&&r.typecheckAndConsumerTestsClaim===true&&Number(r.wasmContractCounts[0])>0&&Number(r.wasmContractCounts[1])===0,'All actual root consumer stages required');
  need(r.targetedViewerTest.TEST_PATTERN==='storey-live-frame.test.ts$'&&r.targetedViewerTest.passed>0,'Actual selected viewer test required');
 }
 for(const{owner,step:x}of rows){
  const failure=(owner===r&&x.stage==='install-offline'&&x.exitCode===1);
  need((failure||x.exitCode===0)&&x.ownedChildReaped===true&&x.startedNs>0&&x.finishedNs>=x.startedNs&&x.finishedNs<=owner.finishedNs&&(failure||!x.boundExceeded),'Remote child incomplete/failed');
  need(x.cwd===r.root&&same(x.argv.slice(0,3),['/home/louistrue/build-workers/run-heavy','--cwd',r.root]),'Actual worker lock/cwd missing');
  const log=pin(mapped(x.logPath),x.logSHA256);if(x.stdoutSHA256)pin(log.replace(/\.log$/,'.json'),x.stdoutSHA256);
 }
 const build=rows.find(x=>x.step.stage==='build-wasm').step,viewer=r.steps.find(x=>x.stage==='build-nonwasm');
 need(same(build.argv.slice(-2),['bash','scripts/build-wasm.sh'])&&viewer.argv.includes('--filter=!@ifc-lite/wasm')&&viewer.argv.includes('--force'),'Actual official/viewer command changed');
 for(const[name,v]of Object.entries(r.artifacts)){const p=s.out+'/generated-package/'+name;need(statSync(p).size===v.bytes&&v.mtimeNs>=build.startedNs&&v.mtimeNs<=build.finishedNs,'Original artifact time/length differs');pin(p,v.sha256);}
 pin(join(c.root,'packages/wasm/pkg/ifc-lite.d.ts'),r.artifacts['ifc-lite.d.ts'].sha256);
 need(statSync(s.out+'/frozen-dist/index.html').mtimeMs*1e6>=viewer.startedNs&&viewer.startedNs>build.finishedNs,'Original viewer/official build ordering absent');
 const dist=JSON.parse(readFileSync(pin(s.out+'/dist-tree.json',r.frozenDistManifestSHA256)));need(dist.some(p=>p.path.endsWith('.wasm')&&p.sha256===r.artifacts['ifc-lite_bg.wasm'].sha256),'Frozen dist lacks exact own official WASM');
 pin(s.proof+'/target-owner.json',r.targetOwnerSHA256);pin(s.out+'/raw-pre-bindgen.wasm',r.rawPreBindgenWasm.sha256);
 for(const deps of Object.values(r.compiledDependencyBindings))for(const row of deps)pin(s.proof+'/'+row.path.split('/').at(-1),row.sha256);
 const helperMap=JSON.parse(readFileSync(pin(s.proof+'/execution-helper-path-map.json',t.executionHelperPathMapSHA256)));
 for(const owner of [r]){const preps=Object.keys(helperMap).filter(p=>p.endsWith('/preparation-sha256.json')&&hash(helperMap[p])===owner.preparationSHA256);need(preps.length===1,'Original mandatory prebuild source verifier pins absent/ambiguous');const prep=pin(helperMap[preps[0]],owner.preparationSHA256);for(const[p,h]of Object.entries(JSON.parse(readFileSync(prep)))){need(helperMap[p],'Original executing helper mapping absent');pin(helperMap[p],h);}}
 // Binding/validation still proves current committed source and canonical tree/dist/WASM.
 // All original producer inputs enter the seal; no source clone-mtime exception escapes byte identity.
 return [...new Set(files)];
}
