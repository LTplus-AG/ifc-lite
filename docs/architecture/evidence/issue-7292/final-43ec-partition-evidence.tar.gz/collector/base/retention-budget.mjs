/** Bounded provisioning from ACTUAL frozen bytes; never exempts a missing occurrence. */
export function deriveRuntimeRetention(files) {
 const runtime=files.filter(file=>/\.(?:m?js|wasm)$/.test(file.path));
 if(!runtime.length||!runtime.every(file=>Number.isSafeInteger(file.bytes)&&file.bytes>=0))throw Error('Actual frozen runtime lengths required');
 const unit=1024*1024,oneCopyBytes=runtime.reduce((sum,file)=>sum+file.bytes,0),largestBytes=Math.max(...runtime.map(file=>file.bytes));
 const maxTotalBufferSize=Math.max(128*unit,Math.ceil(2*oneCopyBytes/unit)*unit);
 const maxResourceBufferSize=Math.max(16*unit,Math.ceil((largestBytes+unit)/unit)*unit);
 if(maxTotalBufferSize>256*unit||maxResourceBufferSize>maxTotalBufferSize)throw Error('Final frozen payload budget exceeds reviewed256MiB local allowance; explicit review required');
 return {maxTotalBufferSize,maxResourceBufferSize,oneCopyBytes,largestBytes,
   provisioning:'Two complete frozen runtime copies plus retained setup buffers; this is capacity provisioning, not an assumed maximum request count. Every actual original-ID body still mandatory; global eviction fails.'};
}
