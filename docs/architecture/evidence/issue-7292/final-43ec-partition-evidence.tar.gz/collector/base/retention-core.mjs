/** Exact-ID status/completion/body certificates. Does not fabricate responseReceived events. */
import { createHash } from 'node:crypto';
import { raceWithTimeout } from './browser-cold-teardown.mjs';

export async function installPassivePageRetention(context, page, origin, files, sessionOverride, retentionLimits) {
  const session = sessionOverride ?? await raceWithTimeout(context.newCDPSession(page), 10000, 'Independent page CDP');
  const requests = new Map(), certificates = new Map(), observedResponses = new Map();
  const extraInfo = new Map(), finished = new Map(), setupRetained = new Map();
  const events = [], commands = [], verified = [], errors = [];
  let phase = 'setup', cancelled = false, completionWitness = null;
  const afterCompletion = () => ['after-worker-termination', 'after-operation-completion'].includes(phase);
  const runtime = url => /\.(?:m?js|wasm)$/.test(new URL(url).pathname);
  const fail = message => { throw Error(message); };
  async function send(method, params, allowUntimedSetup = false) {
    if (cancelled) fail('Collector cancelled during owned cleanup');
    if (method === 'Network.getResponseBody' && !afterCompletion() && !(allowUntimedSetup && phase === 'setup'))
      fail('Body read refused before operation completion');
    commands.push({ method, phase, params });
    return raceWithTimeout(session.send(method, params), 10000, method);
  }
  async function readPinnedBody(request, allowUntimedSetup = false) {
    const url = new URL(request.url);
    if (url.origin !== new URL(origin).origin) fail('Unexpected original request origin ' + request.url);
    const path = decodeURIComponent(url.pathname).replace(/^\//, '');
    const pin = files.find(file => file.path === path);
    if (!pin) fail('Request is not in frozen distribution ' + request.url);
    const dispatchedPhase = phase;
    const result = await send('Network.getResponseBody', { requestId: request.requestId }, allowUntimedSetup);
    if (cancelled || phase !== dispatchedPhase) fail('Original body read cancelled or crossed an operation phase; refusing hash/acceptance');
    const body = Buffer.from(result.body, result.base64Encoded ? 'base64' : 'utf8');
    const hash = createHash('sha256').update(body).digest('hex');
    if (hash !== pin.sha256 || body.length !== pin.bytes)
      fail('Original delivered bytes differ ' + JSON.stringify({ request, bytes: body.length, hash, pin }));
    return { body, hash, path, pin, bodyReadPhase: dispatchedPhase };
  }
  function status(requestId, code, source, metadata = {}) {
    const request = requests.get(requestId), response = observedResponses.get(requestId);
    const url = metadata.url ?? request?.url ?? response?.url;
    // ExtraInfo can precede its request; retain it until exact-ID runtime ownership is known.
    if (!url || !runtime(url)) return;
    if (request && response && request.url !== response.url)
      errors.push({ error: 'Conflicting same-ID request/response URL', requestId, request, response });
    if (code !== 200) errors.push({ error: 'Exact-ID runtime status is not 200 (304 is not promoted)', requestId, code, source });
    const old = certificates.get(requestId);
    if (old && (old.status !== code || old.url !== url))
      errors.push({ error: 'Conflicting exact-ID response certificate', old, requestId, code, source, url });
    const row = old ?? { requestId, url, status: code, type: metadata.type ?? request?.type,
      phase, statusSources: [] };
    if (!row.statusSources.includes(source)) row.statusSources.push(source);
    if (source === 'Network.responseReceived') row.ordinaryResponseEventObserved = true;
    if (source === 'Network.responseReceivedExtraInfo') row.extraInfo200Observed = code === 200;
    if (finished.has(requestId)) {
      row.loadingFinished = true;
      row.completionSource = 'Network.loadingFinished:same-requestId';
      row.encodedDataLength = finished.get(requestId).encodedDataLength;
    }
    certificates.set(requestId, row);
  }
  session.on('Network.requestWillBeSent', event => {
    if (!runtime(event.request.url)) return;
    const row = { requestId: event.requestId, url: event.request.url, type: event.type, phase };
    events.push({ event: 'request', ...row });
    if (requests.has(event.requestId) || event.redirectResponse)
      errors.push({ error: 'Duplicate/redirect runtime request ID', ...row });
    requests.set(event.requestId, row);
    const response = observedResponses.get(event.requestId);
    if (response && response.url !== row.url)
      errors.push({ error: 'Conflicting same-ID response/request URL', requestId: event.requestId, request: row, response });
    if (extraInfo.has(event.requestId)) status(event.requestId, extraInfo.get(event.requestId).statusCode,
      'Network.responseReceivedExtraInfo');
  });
  session.on('Network.responseReceived', event => {
    if (!runtime(event.response.url)) return;
    const row = { requestId: event.requestId, url: event.response.url, status: event.response.status,
      type: event.type, phase, fromDiskCache: event.response.fromDiskCache ?? false,
      fromServiceWorker: event.response.fromServiceWorker ?? false };
    events.push({ event: 'ordinary-response', ...row });
    if (observedResponses.has(event.requestId)) errors.push({ error: 'Duplicate runtime response event', ...row });
    observedResponses.set(event.requestId, row);
    status(event.requestId, row.status, 'Network.responseReceived', row);
    if (extraInfo.has(event.requestId)) status(event.requestId, extraInfo.get(event.requestId).statusCode,
      'Network.responseReceivedExtraInfo');
  });
  session.on('Network.responseReceivedExtraInfo', event => {
    const row = { requestId: event.requestId, statusCode: event.statusCode, phase };
    events.push({ event: 'extra-info-status', ...row });
    if (extraInfo.has(event.requestId)) errors.push({ error: 'Duplicate exact-ID ExtraInfo event', ...row });
    extraInfo.set(event.requestId, row);
    status(event.requestId, row.statusCode, 'Network.responseReceivedExtraInfo');
  });
  session.on('Network.loadingFinished', event => {
    finished.set(event.requestId, event);
    const row = certificates.get(event.requestId);
    if (row) {
      row.loadingFinished = true; row.completionSource = 'Network.loadingFinished:same-requestId';
      row.encodedDataLength = event.encodedDataLength;
    }
  });
  session.on('Network.loadingFailed', event => {
    if (requests.has(event.requestId)) errors.push({ event: 'loadingFailed', phase, ...event });
  });
  const limits = retentionLimits ?? { maxTotalBufferSize: 64 * 1024 * 1024, maxResourceBufferSize: 16 * 1024 * 1024 };
  if (!Object.values(limits).every(value => Number.isSafeInteger(value) && value > 0 && value <= 1024 * 1024 * 1024))
    fail('Explicit bounded durable storage limits required');
  await send('Network.enable', limits);
  await send('Network.configureDurableMessages', limits);
  return {
    requests, responseCertificates: certificates, observedResponseEvents: observedResponses,
    extraInfoStatuses: extraInfo, events, commands, verified, errors,
    get operationCompletionWitness() { return completionWitness; },
    async retainUntimedSetupBody(requestId) {
      if (phase !== 'setup') fail('Untimed setup retention refused during operation');
      if (setupRetained.has(requestId)) return;
      const request = requests.get(requestId), certificate = certificates.get(requestId);
      if (!request || certificate?.status !== 200) fail('Actual setup request/status200 required ' + requestId);
      setupRetained.set(requestId, await readPinnedBody(request, true));
    },
    retainedSetupIDs() { return [...setupRetained.keys()]; },
    cancel() { cancelled = true; session.cancel?.(); },
    markWorkStarted() { if (phase !== 'setup') fail('Unexpected controlled-work phase'); phase = 'controlled-work'; },
    markWorkersTerminated() {
      if (phase !== 'controlled-work') fail('Unexpected termination phase');
      completionWitness = { kind: 'controlled-workers-natural-close' };
      phase = 'after-worker-termination';
    },
    markOperationCompleted(witness) {
      if (phase !== 'controlled-work' || witness?.kind !== 'canonical-viewer-load' || !witness.trace || !witness.readiness)
        fail('Actual canonical completion witness required after original caller readiness guards');
      // The existing caller owns the canonical readiness/pool/error guards; retain its actual evidence.
      completionWitness = structuredClone(witness);
      phase = 'after-operation-completion';
    },
    async verifyAll() {
      if (!afterCompletion()) fail('Cannot verify before operation completion');
      await session.finishObservers?.();
      const failures = [...errors];
      for (const request of requests.values()) {
        const certificate = certificates.get(request.requestId);
        if (!certificate || certificate.status !== 200)
          failures.push({ error: 'Incomplete exact-ID runtime status certificate', request, certificate });
        let captured;
        try { captured = setupRetained.get(request.requestId) ?? await readPinnedBody(request); }
        catch (cause) { failures.push({ error: 'Original pinned body unavailable or different', request, cause: String(cause) }); continue; }
        const { body, hash, path, pin, bodyReadPhase } = captured;
        // Certify the complete expected ORIGINAL payload, not an unobserved network event.
        const payloadCompletion = { source: 'original-requestId-full-expected-body', requestId: request.requestId,
          expectedBytes: pin.bytes, actualBytes: body.length, expectedSHA256: pin.sha256, actualSHA256: hash,
          bodyReadPhase, operationCompletionKind: completionWitness.kind, rawLoadingFinishedObserved: certificate?.loadingFinished === true };
        verified.push({ ...request, certificate: certificate ?? null, payloadCompletion,
          bytes: body.length, sha256: hash, path,
          bodyReadPhase, reader: setupRetained.has(request.requestId) ?
            'public-CDP:retained-untimed-setup-original-requestId' : 'public-CDP-Network.getResponseBody:original-requestId' });
      }
      await session.finishObservers?.();
      if (errors.length) failures.push(...errors);
      if (certificates.size !== requests.size || verified.length !== requests.size)
        failures.push({ error: 'Exact-ID request/certificate/body coverage mismatch' });
      if (failures.length) fail('Passive retained-body certificate verification failed: ' + JSON.stringify(failures));
      return verified;
    },
    async negativeUnknownRequest() {
      try { await send('Network.getResponseBody', { requestId: '7292-deliberately-nonexistent-request' }); }
      catch (error) { return { refused: true, error: String(error) }; }
      fail('Unknown response ID unexpectedly supplied a body');
    },
    async detach() { await raceWithTimeout(session.detach(), 5000, 'Detach independent page CDP'); },
  };
}
