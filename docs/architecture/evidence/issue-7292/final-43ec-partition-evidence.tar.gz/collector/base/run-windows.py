"""WSL canonical verifier supervises one native Windows capture; explicit new composite required."""
from pathlib import Path
import argparse,subprocess,json,hashlib,os,shutil,fcntl
from capture_supervisor import supervise
D=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true',required=True);ap.add_argument('--pins',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--fixture',choices=['FZK','ISSUE129'],required=True);ap.add_argument('--timing-authority',required=True);ap.add_argument('--expected-timing-authority-sha256',required=True);a=ap.parse_args()
pins=a.pins.resolve();out=a.out.resolve();pb=pins.read_bytes();p=json.loads(pb);R=Path(p['config']['root'])
if out.exists():raise RuntimeError('Fresh external output required')
if out.is_relative_to(R):raise RuntimeError('Output must remain outside source')
authority_args=['--timing-authority',a.timing_authority,'--expected-timing-authority-sha256',a.expected_timing_authority_sha256]
authority_verify=['node',str(D/'qualification-grant.mjs'),'--verify-authorization','--cohort-sample','--pins',str(pins),'--expected-pins-sha256',hashlib.sha256(pb).hexdigest(),*authority_args]
subprocess.run(authority_verify,check=True,timeout=10)
owned_lock=open('/tmp/7292-owned-untimed-browser.lock','a')
fcntl.flock(owned_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
TOOLS=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69') # Existing canonical harness only; product source remains R.
loader=str(TOOLS/'node_modules/tsx/dist/loader.mjs')
verify=['node','--import',loader,str(D/'sample.mts'),'--verify-only','--pins',str(pins)]
if len([f for f in p['config']['fixtures'] if f['key']==a.fixture])!=1:raise RuntimeError('One sealed fixture key required')
def native_command():
 subprocess.run(authority_verify,check=True,timeout=10)
 consumed=out.with_name(out.name+'.actual-app-attempt-reservation.json')
 with consumed.open('x')as marker:marker.write(json.dumps({'status':'ONE_ACTUAL_APP_LAUNCH_RESERVED','authorization':'NEW_COHORT_ONLY_NO_OLD_ROWS','pinsSHA256':hashlib.sha256(pb).hexdigest(),'out':str(out)})+'\n')
 version=json.loads((TOOLS/'node_modules/@playwright/test/package.json').read_text())['version']
 core=(TOOLS/f'node_modules/.pnpm/playwright-core@{version}/node_modules/playwright-core').resolve(strict=True)
 if json.loads((core/'package.json').read_text())['version']!=version:raise RuntimeError('Playwright-core version mismatch')
 win=lambda path:subprocess.check_output(['wslpath','-w',str(path)],text=True).strip()
 node=Path('/mnt/c/Program Files/nodejs/node.exe')
 if not node.is_file():raise RuntimeError('Proven native Windows Node missing; no install or WSL CDP fallback')
 if any(k.startswith('VIEWER_BENCHMARK_')for k in os.environ):raise RuntimeError('Inherited benchmark overrides refused')
 return [str(node),win(D/'windows-capture.mjs'),*authority_args,'--cohort-sample','--run','--pins',str(pins),'--expected-pins-sha256',hashlib.sha256(pb).hexdigest(),'--out',str(out),'--fixture',a.fixture,'--playwright-core',win(core),'--owned-helper',str(D/'frame-gpu-owned-profile.ps1'),'--wsl-root-win',win('/'),'--wsl-distro',os.environ['WSL_DISTRO_NAME'],'--wsl-node',str(Path(shutil.which('node')).resolve(strict=True))]
raise SystemExit(supervise(pins,out,verify,native_command,a.fixture))
