/** Explicit future owned static-server launch only; never starts Chrome. */
import { startStaticServer } from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/scripts/perf/browser-static-server.ts';
import { validateBuildReceipt } from '/tmp/7292-build-receipt-validation.mts';
import { readFileSync,readdirSync,statSync,writeFileSync,existsSync } from 'node:fs';
import { join,relative,resolve } from 'node:path';
import { createHash } from 'node:crypto';
const arg=(n:string)=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
if(!process.argv.includes('--run'))throw Error('Explicit later authorized --run required');
const rootArg=arg('--dist'),buildPath=arg('--build-receipt'),receipt=arg('--receipt'),portArg=arg('--port'),buildSHA=arg('--build-receipt-sha256');if(!rootArg||!buildPath||!receipt||!portArg||!buildSHA)throw Error('Explicit --dist --build-receipt --receipt --port --build-receipt-sha256 required');
const port=Number(portArg);if(!Number.isSafeInteger(port)||port<1024||port>65535||[5273,5274,5276,5277,56792].includes(port)||existsSync(receipt))throw Error('Fresh unprotected port/receipt required');
const root=resolve(rootArg),h=(x:Uint8Array|string)=>createHash('sha256').update(x).digest('hex');
const walk=(p:string):string[]=>readdirSync(p,{withFileTypes:true}).flatMap(x=>x.isDirectory()?walk(join(p,x.name)):[join(p,x.name)]).sort();
const buildBytes=readFileSync(buildPath);if(h(buildBytes)!==buildSHA)throw Error('Actual reviewed build receipt hash mismatch');const build=JSON.parse(buildBytes.toString('utf8'))as{version:number;builtRevision:string;productionTreeSha256:string;wasmSha256:string;distSha256:string;steps:Array<{kind:string;cwd:string}>};const cwd=build.steps.find(s=>s.kind==='wasm')?.cwd;if(!cwd)throw Error('Actual WASM build cwd absent');validateBuildReceipt(buildPath,{builtRevision:build.builtRevision,productionTreeSha256:build.productionTreeSha256,wasmSha256:build.wasmSha256,distSha256:build.distSha256},['wasm','viewer'],cwd);if(h(readFileSync(buildPath))!==buildSHA)throw Error('Build receipt changed during validation');
const files=walk(root).map(p=>({path:relative(root,p),bytes:statSync(p).size,sha256:h(readFileSync(p))}));if(h(files.map(f=>`${f.path}\0${f.bytes}\0${f.sha256}\n`).join(''))!==build.distSha256||!files.some(f=>f.path.endsWith('.wasm')&&f.sha256===build.wasmSha256))throw Error('Frozen dist/WASM differs successful build');
const server=await startStaticServer({port,host:'0.0.0.0',root:()=>root,extra:new Map([['/_vercel/insights/script.js',join(root,'_vercel/insights/script.js')]])});
writeFileSync(receipt,JSON.stringify({status:'OWNED_SOURCE_CURRENT_FROZEN_SERVER_NOT_BROWSER_QUALIFICATION',pid:process.pid,ppid:process.ppid,startedAt:new Date().toISOString(),port,root,buildReceiptSHA256:buildSHA,distSha256:build.distSha256,wasmSha256:build.wasmSha256,productionTreeSha256:build.productionTreeSha256,preservedPorts:[5273,5274,5276,5277,56792]},null,2),{flag:'wx'});
const stop=()=>{const timer=setTimeout(()=>server.closeAllConnections(),10000);timer.unref();server.close(e=>{clearTimeout(timer);if(e){console.error(e);process.exitCode=1;}});};process.once('SIGINT',stop);process.once('SIGTERM',stop);
