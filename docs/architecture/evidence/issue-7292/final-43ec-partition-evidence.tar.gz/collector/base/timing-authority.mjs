/** New explicit affinity-controlled protocol; no whole-host idle or shared-hold claim. */
import{createHash}from'node:crypto';
const OWNER='c6115f2d-994d-4e97-8720-c5793076c258',POLICY='/tmp/7292-partition-research-v2/protocol.json';
const sha=b=>createHash('sha256').update(b).digest('hex'),need=(v,m)=>{if(!v)throw Error(m)},hash=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
export function timingBindingFromArgs(argv=process.argv){const arg=n=>{const i=argv.indexOf(n);return i<0?undefined:argv[i+1]};return{path:arg('--timing-authority'),sha256:arg('--expected-timing-authority-sha256')}}
export function verifyTimingAuthority(binding,readBytes,now=Date.now()){
 need(binding&&typeof binding.path==='string'&&binding.path.startsWith('/')&&hash(binding.sha256),'Actual partition authority path/hash required');const raw=readBytes(binding.path);need(sha(raw)===binding.sha256,'Partition authority changed');
 let revoked=false;try{readBytes(binding.path+'.revoked');revoked=true}catch(e){if(e?.code!=='ENOENT')throw e}need(!revoked,'Partition authority revoked');const d=JSON.parse(raw.toString());
 need(d.status==='DIRECT_USER_AUTHORIZED_7292_PARTITION_TIMING'&&d.timingOwnerThreadId===OWNER&&d.noConcurrentOwnedBrowserCapture===true,'Wrong partition authority/owner');
 const opens=Date.parse(d.opensUTC),until=Date.parse(d.untilUTC);need(Number.isFinite(opens)&&Number.isFinite(until)&&until>opens&&until-opens<=1800000&&opens<=now&&now<until,'Partition window not open/expired');
 need(d.partitionPolicy.path===POLICY&&hash(d.partitionPolicy.sha256)&&sha(readBytes(POLICY))===d.partitionPolicy.sha256,'Predeclared partition policy changed');
 need(d.grantEvidence&&hash(d.grantEvidence.sha256)&&sha(readBytes(d.grantEvidence.path))===d.grantEvidence.sha256,'Actual current user instruction changed');const grant=JSON.parse(readBytes(d.grantEvidence.path).toString());need(grant.item?.createdBy==='user'&&grant.item.text==='Find a way, partition or similar. Research! T3 tooling too','Actual partition instruction required');
 const heads={base:'b0b670f0cfd704ceb7c78a622f5730d0cd9510de',branch:'43ecf3aa3e240e1a7c41c5c799212b60df010ebd'};need(d.base===heads.base&&d.candidate===heads.branch,'Wrong frozen pair');
 for(const side of ['base','branch']){const p=d.sides?.[side];need(p&&p.expectedHead===heads[side]&&hash(p.pinsSHA256)&&sha(readBytes(p.pinsPath))===p.pinsSHA256&&JSON.parse(readBytes(p.pinsPath).toString()).head===heads[side],'Actual partition side seal changed')}
 return{mode:'EXPLICIT_AFFINITY_CONTROLLED_OWNED_WINDOW',owner:OWNER,authorityPath:binding.path,authoritySHA256:binding.sha256,opensUTC:d.opensUTC,untilUTC:d.untilUTC,sides:d.sides,partitionPolicy:d.partitionPolicy,wholeHostIdleClaim:false,sharedHoldRequired:false,resourceConditionsWaived:false};
}
