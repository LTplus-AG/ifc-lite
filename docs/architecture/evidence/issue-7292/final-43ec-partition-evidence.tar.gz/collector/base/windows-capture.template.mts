import {createProtectedBrowserGuard} from './protected-browser-guard.mjs';
import { verifyQualificationAuthorization } from './qualification-grant.mjs';
/** Windows native transport of the existing capture body; generated only after final build binding. */
import { chromium, launchWindowsChrome, findWindowsChrome } from './windows-lifecycle.mjs';
import { ViewerBenchmarkPage } from './viewer-benchmark-page.mjs';
import { runColdSample } from './browser-cold-sample.mjs';
import { readGpuHealth } from './gpu-health.mjs';
import { probeMetadataRenderTrace } from './metadata-render-readiness.mjs';
import { raceWithTimeout } from './browser-cold-teardown.mjs';
import { installRuntimeProof, requireFourWorkerPool } from './passive-runtime.mjs';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, nativePath } from './windows-filesystem.mjs';
import { join, relative, resolve } from 'node:path/posix';
import { execFileSync } from 'node:child_process';
const D='/tmp/7292-current-passive-worker-pool-preparation-v27/base';
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
const fileSha=(p:string)=>sha(readFileSync(p));
function structuredError(value:unknown){
 const e=value as {message?:unknown;code?:unknown;status?:unknown;signal?:unknown;stdout?:unknown;stderr?:unknown};
 const field=(v:unknown)=>v===undefined?null:Buffer.isBuffer(v)?{encoding:'base64',data:v.toString('base64')}:typeof v==='string'||typeof v==='number'||v===null?v:String(v);
 return {message:typeof e?.message==='string'?e.message:String(value),code:field(e?.code),status:field(e?.status),signal:field(e?.signal),stdout:field(e?.stdout),stderr:field(e?.stderr)};
}
function need(value:unknown,message:string):asserts value {if(!value)throw Error(message);}
const save=(p:string,v:unknown)=>writeFileSync(p,JSON.stringify(v,null,2),{flag:'wx'});
const arg=(n:string)=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
type FilePin={path:string;bytes:number;sha256:string};
type Fixture={key:string;kind:'real'|'reporter';path:string;selectedIds:number[];requireFourWorkers:boolean;timeoutMs:number};
type Config={root:string;frozenDist:string;wasmPath:string;origin:string;serverReceiptPath:string;buildReceiptPath:string;
 qualification:{path:string;sha256:string;acceptedStatus:string};candidatePreparation:string;candidatePreparationSHA256:string;
 runtimeRetention:{maxTotalBufferSize:number;maxResourceBufferSize:number};chromeExecutable?:string;fixtures:Fixture[]};
type Pins={version:1;config:Config;files:Record<string,string>;productionTreeSha256:string;distFiles:FilePin[];distSha256:string;wasmSha256:string;head:string};
const walk=(p:string):string[]=>readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(p,e.name)):[join(p,e.name)]).sort();
const expectedPinsSHA=arg('--expected-pins-sha256');
function verify(p:Pins){
 const pins=arg('--pins');need(pins&&expectedPinsSHA&&fileSha(pins)===expectedPinsSHA,'Runtime pins hash drift');
 const result=execFileSync('wsl.exe',['-d',arg('--wsl-distro')!,'--exec',arg('--wsl-node')!,'--import','/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/node_modules/tsx/dist/loader.mjs',D+'/sample.mts','--verify-only','--pins',pins],{encoding:'utf8',timeout:120000});
 need(result.trim()==='SOURCE_RUNTIME_PINS_VERIFIED','Canonical WSL source/build/fixture/helper verification failed');
}
async function verifyHttp(p:Pins){for(const f of p.distFiles.filter(x=>x.path==='index.html'||x.path.endsWith('.wasm'))){const u=new URL(f.path==='index.html'?'':f.path,p.config.origin+'/');const r=await fetch(u,{redirect:'error',signal:AbortSignal.timeout(15000)});need(r.ok&&sha(Buffer.from(await r.arrayBuffer()))===f.sha256,'Actual served index/WASM hash '+f.path);}}
const protectedGuard=createProtectedBrowserGuard(D,{readFileSync,execFileSync});
function preserve(){return protectedGuard.observe();}
async function preservedTarget(){return protectedGuard.targets();}
function physicalGpu(v:{gpu:{devices:Array<{vendorId:number;deviceString:string}>;auxAttributes:Record<string,unknown>;featureStatus:Record<string,string>;videoDecoding?:Array<{profile:string}>}}){const renderer=String(v.gpu.auxAttributes.glRenderer??'');need(/nvidia/i.test(renderer)&&!/swiftshader|llvmpipe|software|microsoft basic/i.test(renderer)&&v.gpu.featureStatus.webgpu?.startsWith('enabled')&&v.gpu.devices.some(d=>d.vendorId===0x10de),'Actual NVIDIA hardware WebGPU not proved');return renderer;}
async function rendererAdapter(page:Page){return raceWithTimeout(page.evaluate(()=>{const host=globalThis as unknown as{__ifc_lite_render_stats__?:()=>{adapter?:{vendor?:string;architecture?:string}|null}};return host.__ifc_lite_render_stats__?.()?.adapter??null;}),10000,'Actual initialized renderer adapter');}
async function ownedWitness(profile:string,port:number){
 const literal=profile.replace(/'/g,"''");const script=`$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';${readFileSync(join(D,'frame-gpu-owned-profile.ps1'),'utf8')}\n$rows=@(Get-OwnedChromeProcesses -Profile '${literal}' -BrowserRoot -RequireCompleteObservation);if($rows.Count -ne 1){throw 'Unique owned root required'};$p=$rows[0];$ls=@(Get-NetTCPConnection -State Listen -LocalPort ${port});if($ls.Count -eq 0 -or @($ls|Where-Object {$_.OwningProcess -ne $p.ProcessId}).Count -ne 0){throw 'Owned endpoint mismatch'};@{pid=$p.ProcessId;creation=$p.CreationDate.ToUniversalTime().ToString('o');profile='${literal}';commandLine=$p.CommandLine;executable=$p.ExecutablePath;port=${port}}|ConvertTo-Json -Compress`;
 const observationFailures:string[]=[];
 for(let attempt=0;attempt<5;attempt++){
  try{
   const value=JSON.parse(execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{encoding:'utf8',timeout:15000}))as Record<string,unknown>;
   return {...value,readonlyObservationFailures:observationFailures};
  }catch(error){
   if(!String(error).includes('Chrome command-line observation incomplete')||attempt===4)throw error;
   observationFailures.push(String(error));await new Promise(resolve=>setTimeout(resolve,100));
  }
 }
 throw Error('Complete owned identity observation not established');
}
function rawPage(ids:number[]){
 type M={expressId:number;geometryItemId?:number;positions:Float32Array;normals:Float32Array;indices:Uint32Array;origin?:ArrayLike<number>;localToWorld?:ArrayLike<number>};
 type G={meshes:M[];coordinateInfo:unknown;totalTriangles:number;totalVertices:number;instancedGeometryHashes?:Map<number,bigint>;instancedGeometryAabbs?:Map<number,unknown>;instancedGeometryVolumes?:Map<number,number>};type Model={geometryResult?:G;ifcDataStore?:{entities:{count:number;expressId:ArrayLike<number>}}};
 const s=(globalThis as unknown as{__ifc_lite_viewer_store__?:{getState():{models:Map<string,Model>;geometryResult?:G;ifcDataStore?:Model['ifcDataStore']}}}).__ifc_lite_viewer_store__?.getState();if(!s||s.models.size!==1)throw Error('One canonical model required');const m=[...s.models.values()][0],g=m.geometryResult??s.geometryResult,data=m.ifcDataStore??s.ifcDataStore;if(!g||!data||!g.coordinateInfo)throw Error('Missing actual geometry/frame/datastore');
 const selected=g.meshes.filter(x=>ids.length===0||ids.includes(x.expressId));
 const rawMeshes=[];
 for(const x of selected){
  if(!(x.positions instanceof Float32Array)||!(x.normals instanceof Float32Array)||!(x.indices instanceof Uint32Array))throw Error('Actual typed-array contract');
  const origin=Array.from(x.origin??[0,0,0]);const originF64BitsDecimal:string[]=[];
  for(const value of origin){const buffer=new ArrayBuffer(8);const view=new DataView(buffer);view.setFloat64(0,value,true);originF64BitsDecimal.push(view.getBigUint64(0,true).toString());}
  let localToWorldF64BitsDecimal:string[]|null=null;
  if(x.localToWorld){localToWorldF64BitsDecimal=[];for(const value of Array.from(x.localToWorld)){const buffer=new ArrayBuffer(8);const view=new DataView(buffer);view.setFloat64(0,value,true);localToWorldF64BitsDecimal.push(view.getBigUint64(0,true).toString());}}
  rawMeshes.push({expressId:x.expressId,geometryItemId:x.geometryItemId??null,positions:Array.from(x.positions),positionF32Bits:Array.from(new Uint32Array(x.positions.buffer,x.positions.byteOffset,x.positions.length)),normals:Array.from(x.normals),normalF32Bits:Array.from(new Uint32Array(x.normals.buffer,x.normals.byteOffset,x.normals.length)),indices:Array.from(x.indices),origin,originF64BitsDecimal,localToWorldF64BitsDecimal,localToWorld:x.localToWorld?Array.from(x.localToWorld):null});
 }
 return {coordinateFrame:'Canonical viewer Y-up; raw positions/origin and already-baked localToWorld metadata retained without reconstruction',coordinateInfo:g.coordinateInfo,entityCount:data.entities.count,entityIds:Array.from(data.entities.expressId).sort((a,b)=>a-b),totalTriangles:g.totalTriangles,totalVertices:g.totalVertices,meshCount:g.meshes.length,allMeshOwnerIds:[...new Set(g.meshes.map(x=>x.expressId))].sort((a,b)=>a-b),instancedOnlyIds:[...(g.instancedGeometryHashes?.keys()??[])].sort((a,b)=>a-b),selectedIds:ids,instancedCanonicalHashes:[...(g.instancedGeometryHashes??[])].map(([id,h])=>[id,h.toString()]).sort((a,b)=>Number(a[0])-Number(b[0])),instancedAabbs:[...(g.instancedGeometryAabbs??[])].sort((a,b)=>a[0]-b[0]),instancedVolumes:[...(g.instancedGeometryVolumes??[])].sort((a,b)=>a[0]-b[0]),rawMeshes};
}
export async function runSample(p:Pins,out:string){
 const benchmarkEnv=['VIEWER_BENCHMARK_GEOM_WORKERS','VIEWER_BENCHMARK_GPU_UPLOADS','VIEWER_BENCHMARK_CACHE_MODE'];
 need(p.config.fixtures.length===1&&['FZK','ISSUE129'].includes(p.config.fixtures[0].key),"One fresh first-load cohort sample only");
 need(p.version===1,'Pin schema');verify(p);mkdirSync(out,{recursive:false});save(join(out,'pins.json'),p);
 verifyQualificationAuthorization(readFileSync);await verifyHttp(p);const records:Record<string,unknown>[]=[];let owned:WindowsChrome|undefined;let browser:Awaited<ReturnType<typeof chromium.connectOverCDP>>|undefined;let context:BrowserContext|undefined;let page:Page|undefined;
 const receipt:Record<string,unknown>={status:'RUNNING_NOT_QUALIFIED',performanceClaim:false,geometryAcceptanceClaim:false,acceptedBenchmarkRows:0,artifactScope:'FINAL_SOURCE_CURRENT_WORKER_POOL_COHORT_SAMPLE',compiledArtifactRevision:p.head,observedCheckoutHead:p.head,records};
 try{
  receipt.preservedBefore=preserve();receipt.preservedTargetBefore=await preservedTarget();
  for(const k of Object.keys(process.env))if(k.startsWith('VIEWER_BENCHMARK_'))throw Error('Unexpected inherited benchmark override '+k);
  process.env.VIEWER_BENCHMARK_GEOM_WORKERS='4';process.env.VIEWER_BENCHMARK_GPU_UPLOADS='0';process.env.VIEWER_BENCHMARK_CACHE_MODE='cold';
  receipt.qualificationAuthorization=verifyQualificationAuthorization(readFileSync);
  owned=await launchWindowsChrome(findWindowsChrome(p.config.chromeExecutable),1);need(owned.cdpUrl!=='http://127.0.0.1:56792','Owned endpoint must be fresh');receipt.ownedBefore=owned.startupWitness;receipt.ownedEndpoint=owned.cdpUrl;
  browser=await chromium.connectOverCDP(owned.cdpUrl,{timeout:15000});receipt.browserVersion=browser.version();const session=await raceWithTimeout(browser.newBrowserCDPSession(),10000,'Owned CDP session');
  for(const fixture of p.config.fixtures){
   const dir=join(out,fixture.key);mkdirSync(dir);const record:Record<string,unknown>={key:fixture.key,kind:fixture.kind,fixtureSHA256:fileSha(fixture.path),status:'RUNNING_NOT_QUALIFIED'};records.push(record);const errors:string[]=[];const requests:string[]=[];let bp:ViewerBenchmarkPage|undefined;let proof:Awaited<ReturnType<typeof installRuntimeProof>>|undefined;
   try{
    verify(p);const before=await raceWithTimeout(session.send('SystemInfo.getInfo'),10000,'CDP GPU before');record.gpuBefore=before;physicalGpu(before);
    context=await raceWithTimeout(browser.newContext({viewport:{width:1400,height:1000},deviceScaleFactor:1.5}),10000,'Owned context');page=await raceWithTimeout(context.newPage(),10000,'Owned page');proof=await installRuntimeProof(context,page,p.config.origin,p.distFiles,owned.cdpUrl,{maxTotalBufferSize:p.config.runtimeRetention.maxTotalBufferSize,maxResourceBufferSize:p.config.runtimeRetention.maxResourceBufferSize});await raceWithTimeout(proof.ready,10000,'Independent runtime setup before first navigation');page.on('pageerror',e=>errors.push(String(e)));page.on('requestfailed',r=>{if(!r.url().endsWith('/_vercel/insights/script.js'))requests.push(`${r.url()}: ${r.failure()?.errorText}`);});bp=new ViewerBenchmarkPage(page,p.config.origin);
    const metrics=await raceWithTimeout(runColdSample(bp,{fixturePath:nativePath(fixture.path),timeoutMs:fixture.timeoutMs,afterSetup:async()=>{await proof!.finishUntimedSetup();await page!.bringToFront();const s=await page!.evaluate(()=>{const store=(globalThis as unknown as{__ifc_lite_viewer_store__?:{getState():{models:Map<unknown,unknown>;geometryMode:string;geometryModePendingReload:boolean;setGeometryMode(mode:'exact'):void}}}).__ifc_lite_viewer_store__;if(!store||store.getState().models.size!==0)throw Error('Exact policy requires canonical empty store');store.getState().setGeometryMode('exact');const s=store.getState();return{models:s.models.size,geometryMode:s.geometryMode,geometryModePendingReload:s.geometryModePendingReload,persistedMode:localStorage.getItem('ifc-lite-geometry-mode'),dpr:devicePixelRatio,visible:document.visibilityState,focused:document.hasFocus(),crossOriginIsolated,sab:typeof SharedArrayBuffer!=='undefined'};});record.partitionBefore=await owned!.partitionAffinitySnapshot();record.preUpload=s;need(s.models===0&&s.geometryMode==='exact'&&!s.geometryModePendingReload&&s.persistedMode==='exact'&&s.dpr===1.5&&s.visible==='visible'&&s.focused&&s.crossOriginIsolated&&s.sab,'Fresh foreground isolated empty canonical model required');}}),fixture.timeoutMs+30000,'Canonical target FIRST fresh load');record.metrics=metrics;record.metricsUse='FRESH_COHORT_SAMPLE_REQUIRES_PRE_POST_HOST_AND_PAIR_ADMISSION';
    await page.waitForFunction(()=>((globalThis as unknown as{__ifc_lite_render_stats__?:()=>{frame?:{drawCalls?:number}}}).__ifc_lite_render_stats__?.()?.frame?.drawCalls??0)>0,{}, {timeout:15000});await raceWithTimeout(bp.refreshLoadTrace(),10000,'Trace refresh');const trace=bp.getLoadTrace();record.trace=trace;const ready=await probeMetadataRenderTrace(page);record.readiness=ready;need(ready&&!ready.invalid&&!ready.failed.length&&ready.ended&&['parser.complete','geometry.streamComplete','scene.finalize'].every(x=>ready.done.includes(x)),'Canonical completion/readiness');need(trace?.attrs?.loadPath==='wasm'&&!trace.spans.some(s=>s.name==='parser.failed'||s.attrs?.success===false)&&metrics.canvasHasContent,'Actual WASM and canvas content');if(fixture.requireFourWorkers)record.actualPool=requireFourWorkerPool(trace);
    const adapter=await rendererAdapter(page);record.adapterSource='actual initialized renderer GPUAdapter.info snapshot';record.adapter=adapter;record.postLoadDpr=await page.evaluate(()=>devicePixelRatio);record.partitionAfter=await owned.partitionAffinitySnapshot();need(record.postLoadDpr===1.5,'Actual postloadDPR1.5 required');need(adapter&&/nvidia/i.test(adapter.vendor??''),'UNKNOWN actual initialized renderer NVIDIA adapter not proved');
    const raw=await raceWithTimeout(page.evaluate(rawPage,fixture.selectedIds),30000,'Bounded selected raw arrays');save(join(dir,'browser-raw.json'),raw);need(fixture.selectedIds.every(id=>raw.rawMeshes.some(m=>m.expressId===id)),'UNKNOWN selected raw absent or instanced-only; no invented transform/mesh');need(raw.rawMeshes.every(m=>m.positions.length===m.normals.length&&m.indices.length%3===0&&m.origin.length===3),'Actual buffer shape');record.rawSHA256=fileSha(join(dir,'browser-raw.json'));
    need(!errors.length&&!requests.length,'Actual page/network errors before byte verification');await raceWithTimeout(proof.verify(p.wasmSha256,{kind:'canonical-viewer-load',trace,readiness:ready,actualPool:record.actualPool,canvasHasContent:metrics.canvasHasContent,drawCallsObserved:true}),20000,'Actual delivered runtime bytes');record.passiveProof=proof.snapshot();record.runtimeResponses=proof.rows;record.runtimeRequests=proof.observedRequests;record.gpuHealth=await readGpuHealth(page,bp.getConsoleLogs());const health=record.gpuHealth as Awaited<ReturnType<typeof readGpuHealth>>;need(!health.contaminated&&!health.deviceLost&&!health.deviceReplacements&&!health.uncapturedErrors&&!health.instanceErrors,'GPU health');const after=await raceWithTimeout(session.send('SystemInfo.getInfo'),10000,'CDP GPU after');record.gpuAfter=after;physicalGpu(after);need(!errors.length&&!requests.length,'Actual page/network errors');await page.screenshot({path:nativePath(join(dir,'viewer.png')),fullPage:true,timeout:10000});record.consoleLogs=bp.getConsoleLogs();need(bp.getConsoleLogs().some(line=>line.includes('geomMode=exact tier=medium')),'Actual loader exact/medium policy not observed');record.trace=bp.getLoadTrace();const finalHealth=await raceWithTimeout(readGpuHealth(page,bp.getConsoleLogs()),10000,'GPU after screenshot');record.gpuHealthAfterScreenshot=finalHealth;record.adapterAfterScreenshot=await rendererAdapter(page);need(record.adapterAfterScreenshot&&/nvidia/i.test((record.adapterAfterScreenshot as{vendor?:string}).vendor??''),'UNKNOWN late renderer NVIDIA adapter not proved');need(!finalHealth.contaminated&&!finalHealth.deviceLost&&!finalHealth.deviceReplacements&&!finalHealth.uncapturedErrors&&!finalHealth.instanceErrors,'Late GPU failure');verify(p);record.status='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED';
   }catch(error){record.status='PRESERVED_FAILURE_OR_UNKNOWN';record.error=String(error);record.errorDetails=structuredError(error);record.failedObserverSetupAudit=(error as{observerAudit?:unknown})?.observerAudit??null;if(page)try{await page.screenshot({path:nativePath(join(dir,'failure.png')),timeout:5000});}catch(e){record.screenshotError=String(e);record.screenshotErrorDetails=structuredError(e);}throw error;
   }finally{record.runtimeResponses=proof?.rows??[];record.runtimeRequests=proof?.observedRequests??[];record.pageErrors=errors;record.requestFailures=requests;if(proof){try{await proof.detach();}catch(error){record.observerRetirementError=structuredError(error);record.status='PRESERVED_FAILURE_OR_UNKNOWN';process.exitCode=2;}record.passiveProof=proof.snapshot();}if(context){await raceWithTimeout(context.close(),10000,'Close owned sample context');context=undefined;page=undefined;}save(join(dir,'receipt.json'),record);}
  }
  await raceWithTimeout(session.detach(),5000,'Detach owned browser session');need(!process.exitCode&&records.every(record=>record.status==='BROWSER_RUNTIME_CAPTURE_COMPLETE_GEOMETRY_ADJUDICATION_REQUIRED'),'Observer or case failure preserved');receipt.status='FRESH_OWNED_CHROME_RUNTIME_CAPTURE_COMPLETE_NOT_GEOMETRY_QUALIFICATION';
 }catch(error){receipt.status='PRESERVED_FAILURE_OR_UNKNOWN';receipt.error=String(error);receipt.errorDetails=structuredError(error);process.exitCode=2;}
 finally{
  if(context)try{await raceWithTimeout(context.close(),10000,'Bounded fallback owned context cleanup');}catch(e){receipt.contextCleanupError=String(e);receipt.contextCleanupErrorDetails=structuredError(e);process.exitCode=2;}
  if(owned){try{receipt.ownedAfter=await ownedWitness(owned.profileWin,Number(new URL(owned.cdpUrl).port));}catch(e){receipt.ownedIdentityError=String(e);receipt.ownedIdentityErrorDetails=structuredError(e);process.exitCode=2;}let cleanupError=await owned.dispose();const attempts=[{attempt:1,error:cleanupError}];for(let attempt=2;cleanupError&&attempt<=3&&cleanupError.includes('Chrome command-line observation incomplete');attempt++){await new Promise(resolve=>setTimeout(resolve,1000));cleanupError=await owned.dispose();attempts.push({attempt,error:cleanupError});}receipt.ownedCleanupAttempts=attempts;receipt.originalCleanupError=attempts[0].error;receipt.cleanupAddendum=attempts.length>1?{sameStrictUtility:true,originalFailurePreserved:true,finalError:cleanupError}:null;receipt.ownedCleanupError=cleanupError;if(cleanupError)process.exitCode=2;}
  // No browser.close: only lifecycle utility retires verified fresh profile; never attach existing Chrome.
  try{receipt.preservedAfter=preserve();receipt.preservedTargetAfter=await preservedTarget();}catch(e){receipt.finalGuardError=String(e);receipt.finalGuardErrorDetails=structuredError(e);process.exitCode=2;}
  for(const key of benchmarkEnv)delete process.env[key];if(process.exitCode)receipt.status='PRESERVED_FAILURE_OR_UNKNOWN';receipt.outputFileSHA256=Object.fromEntries(walk(out).map(x=>[x,fileSha(x)]));save(join(out,'receipt.json'),receipt);
 }
}
need(process.platform==='win32','Windows native Node required; never retry WSL CDP');
const pinsPath=arg('--pins'),out=arg('--out'),fixture=arg('--fixture');
need(process.argv.includes('--run')&&pinsPath&&out&&fixture,'Explicit --run --pins FILE --out NEW_DIR --fixture KEY');
const original=JSON.parse(readFileSync(pinsPath,'utf8')) as Pins;verify(original);
const selected=original.config.fixtures.filter(f=>f.key===fixture);
need(selected.length===1,'One sealed fixture required for a fresh sample');
await runSample({...original,config:{...original.config,fixtures:selected}},resolve(out));
