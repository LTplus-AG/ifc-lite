/** Logical Linux evidence paths mapped to the same files over Windows WSL UNC. */
import * as fs from 'node:fs';
const arg=n=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1]};
const root=arg('--wsl-root-win');
if(process.platform!=='win32'||!root?.startsWith('\\\\'))throw Error('Explicit WSL UNC root and native Windows Node required');
export const nativePath=p=>typeof p==='string'&&p.startsWith('/')?root.replace(/[\\/]$/,'')+'\\'+p.slice(1).replaceAll('/','\\'):p;
export const readFileSync=(p,...a)=>fs.readFileSync(nativePath(p),...a);
export const writeFileSync=(p,...a)=>fs.writeFileSync(nativePath(p),...a);
export const readdirSync=(p,...a)=>fs.readdirSync(nativePath(p),...a);
export const statSync=(p,...a)=>fs.statSync(nativePath(p),...a);
export const mkdirSync=(p,...a)=>fs.mkdirSync(nativePath(p),...a);
