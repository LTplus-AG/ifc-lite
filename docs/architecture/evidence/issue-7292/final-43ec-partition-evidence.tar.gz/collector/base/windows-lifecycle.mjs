/** 6940 proven Windows-node/native-CDP route, with v6 port0 ownership/cleanup policy. */
import * as fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import cp from 'node:child_process';
import {createRequire} from 'node:module';
import {readFileSync} from './windows-filesystem.mjs';
const arg=n=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1]};
const core=arg('--playwright-core'),helper=arg('--owned-helper');
if(process.platform!=='win32'||!core||!helper)throw Error('Native Windows core/helper paths required');
export const {chromium}=createRequire(import.meta.url)(core);
const ownedHelper=readFileSync(helper,'utf8');
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function ps(script,timeout=15000){
 const r=cp.spawnSync('powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from("$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';"+ownedHelper+'\n'+script,'utf16le').toString('base64')],{encoding:'utf8',timeout});
 if(r.error||r.status!==0)throw Error(`Owned Windows operation failed: ${r.error?.message??r.stderr}`);
 return r.stdout.trim();
}
export function findWindowsChrome(override){
 const candidates=[override,'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe','C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'];
 const exe=candidates.find(p=>p&&fs.existsSync(p));if(!exe)throw Error('Windows Chrome absent');return exe;
}
export async function launchWindowsChrome(exe,attempts=1){
 if(attempts!==1)throw Error('Exactly one owned startup attempt; failed launches are retained');
 ps(`$self=Get-Process -Id ${process.pid};$self.ProcessorAffinity=[IntPtr]4095;if($self.ProcessorAffinity.ToInt64() -ne 4095){throw 'Owned native Node partition affinity failed'}`);
 const profile=fs.mkdtempSync(path.join(os.tmpdir(),'ifclite-7292-functional-'));
 const lit=profile.replaceAll("'","''");let witness=null,spawnError=null,spawned=false;
 async function partitionAffinitySnapshot(){
  const readonlyObservationFailures=[];for(let attempt=0;attempt<5;attempt++){try{
  const data=JSON.parse(ps(`$rows=@(Get-OwnedChromeProcesses -Profile '${lit}' -RequireCompleteObservation);if($rows.Count -eq 0){throw 'Owned partition root absent'};$values=@();foreach($row in $rows){try{$p=Get-Process -Id $row.ProcessId -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){throw 'Owned affinity process exited during readonly observation'};throw};$mask=$p.ProcessorAffinity.ToInt64();$again=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+$row.ProcessId));if($again.Count -eq 0){throw 'Owned affinity process exited during readonly observation'};if($again.Count -ne 1 -or $again[0].CreationDate -ne $row.CreationDate -or $again[0].CommandLine -cne $row.CommandLine -or $again[0].ExecutablePath -cne $row.ExecutablePath){throw 'Owned affinity process identity changed'};if($mask -ne 4095){throw 'Owned Chrome child escaped fixed partition'};$values+=@{pid=$row.ProcessId;creation=$row.CreationDate.ToUniversalTime().ToString('o');mask=$mask}};@{mask=4095;rows=$values}|ConvertTo-Json -Depth 5 -Compress`));
  if(data.mask!==4095||!Array.isArray(data.rows)||!data.rows.length||data.rows.some(r=>r.mask!==4095))throw Error('Actual complete owned partition witness required');return {...data,readonlyObservationFailures};
  }catch(error){const message=String(error);if(!message.includes('Owned affinity process exited during readonly observation')&&!message.includes('Chrome command-line observation incomplete'))throw error;readonlyObservationFailures.push(message);if(attempt===4)throw Error('Owned affinity observation deadline: '+JSON.stringify(readonlyObservationFailures));await delay(100);}}throw Error('Owned affinity observation incomplete');
 }

 async function dispose(){
  try{
   ps(`Invoke-OwnedChromeCleanup -Profile '${lit}' -DeadlineMs 15000 -ObservedRootPid ${witness?.pid??0} -ObservedRootCreated '${witness?.created??''}'`);
   // Same v6 policy: delete only this unique allocated profile after verified owned cleanup.
   const r=cp.spawnSync(process.execPath,['-e','const fs=require("node:fs");fs.rmSync(process.argv[1],{recursive:true,force:true});if(fs.existsSync(process.argv[1]))process.exit(2)',profile],{encoding:'utf8',timeout:15000});
   if(r.error||r.status!==0)throw Error(`Owned profile removal failed: ${r.error?.message??r.stderr}`);
   return null;
  }catch(error){return `Owned profile cleanup failed (${profile}): ${String(error)}`;}
 }
 try{
  const child=cp.spawn(exe,['--remote-debugging-port=0',`--user-data-dir=${profile}`,'--no-first-run','--no-default-browser-check','--disable-extensions','--disable-background-timer-throttling','--disable-renderer-backgrounding','--disable-backgrounding-occluded-windows','--enable-unsafe-webgpu','--window-size=1280,800','--window-position=0,0','--disable-features=BatterySaverModeAvailable,HighEfficiencyModeAvailable','about:blank'],{stdio:'ignore',detached:true});
  spawned=true;child.once('error',error=>{spawnError=error});child.unref();let port=0,lastError=null;
  const end=Date.now()+30000;
  while(Date.now()<end){
   if(spawnError)throw spawnError;
   try{
    if(!port){const active=path.join(profile,'DevToolsActivePort');if(!fs.existsSync(active)){await delay(500);continue}const lines=fs.readFileSync(active,'utf8').trim().split(/\r?\n/);port=Number(lines[0]);if(!/^[0-9]+$/.test(lines[0])||!Number.isSafeInteger(port)||port<1||port>65535||!lines[1]?.startsWith('/devtools/browser/'))throw Error('Invalid owned DevToolsActivePort')}
    const r=await fetch(`http://127.0.0.1:${port}/json/version`,{signal:AbortSignal.timeout(1000)});
    if(!r.ok)throw Error('Owned endpoint HTTP '+r.status);
    witness=JSON.parse(ps(`$owners=@(Get-OwnedChromeProcesses -Profile '${lit}' -BrowserRoot -RequireCompleteObservation);if($owners.Count -ne 1 -or -not ([IfcChromeArgs]::Split($owners[0].CommandLine) -contains '--remote-debugging-port=0')){throw 'Missing unique owned port0 root'};$listeners=@(Get-NetTCPConnection -LocalPort ${port} -State Listen -ErrorAction Stop);if($listeners.Count -eq 0 -or @($listeners|Where-Object {$_.OwningProcess -ne $owners[0].ProcessId}).Count -ne 0){throw 'Unowned endpoint'};@{pid=$owners[0].ProcessId;created=$owners[0].CreationDate.Ticks.ToString();creation=$owners[0].CreationDate.ToUniversalTime().ToString('o');profile='${lit}';commandLine=$owners[0].CommandLine;executable=$owners[0].ExecutablePath;port=${port}}|ConvertTo-Json -Compress`,5000));
    if(!Number.isSafeInteger(witness.pid)||witness.pid<=0||!/^[1-9][0-9]*$/.test(witness.created)||typeof witness.creation!=='string'||typeof witness.commandLine!=='string'||typeof witness.executable!=='string'||witness.profile!==profile||witness.port!==port)throw Error('Invalid observed root identity');
    return {cdpUrl:`http://127.0.0.1:${port}`,profileWin:profile,startupWitness:Object.freeze(witness),startupFailures:[],partitionAffinitySnapshot,dispose};
   }catch(error){lastError=error;}
   await delay(500);
  }
  throw Error('Windows-local owned endpoint deadline: '+String(lastError));
 }catch(error){
  const cleanupError=spawned?await dispose():null;
  const receipt={profileWin:profile,error:String(error),cleanupError};
  const failure=Error('Native Windows Chrome startup failed: '+JSON.stringify(receipt));failure.receipt=receipt;throw failure;
 }
}
