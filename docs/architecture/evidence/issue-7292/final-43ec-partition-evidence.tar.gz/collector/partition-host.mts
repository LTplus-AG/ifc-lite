/** Physical affinity-domain admission; explicitly not whole-host idle or exclusive OS core reservation. */
import {readLinuxHostObservation} from '/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/scripts/perf/frame-gpu-host.ts';
import {execFileSync} from 'node:child_process';
export const HOST_POLICY={version:'physical-ccd0-integrated-budget-v1',minimumLinuxKiB:41943040,maximumWindowsCpuPercent:10,windowsCpuScope:'group0 logical processors0..11, six physical cores, one cache domain',wholeHostIdleClaim:false,foreignGraphsObservedNotSilentlyDropped:true,aggregation:'mean of all three consecutive equal-duration one-second partition CPU observations'} as const;
const script=`$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$s=@(Get-Counter '\\Processor Information(*)\\% Processor Time' -SampleInterval 1 -MaxSamples 3);@($s|ForEach-Object{@{capturedAt=$_.Timestamp.ToUniversalTime().ToString('o');counters=@($_.CounterSamples|ForEach-Object{@{instance=$_.InstanceName;value=$_.CookedValue;status=$_.Status}})}})|ConvertTo-Json -Depth 6 -Compress`;
export async function readHostAdmission(){
 const linux=await readLinuxHostObservation();
 const raw=execFileSync('/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',['-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{encoding:'utf8',timeout:15000});
 const observations=JSON.parse(raw) as Array<{capturedAt:string;counters:Array<{instance:string;value:number;status:number}>}>;
 if(!Array.isArray(observations)||observations.length!==3)throw Error('Exactly three actual PDH intervals required');
 const windows=observations.map(s=>{
  const processors=s.counters.filter(x=>/^0,\d+$/.test(x.instance));
  if(processors.length!==24||new Set(processors.map(x=>x.instance)).size!==24||processors.some(x=>![0,1].includes(x.status)||!Number.isFinite(x.value)||x.value<0||x.value>100))throw Error('Complete valid physical processor counters required');
  const partition=processors.filter(x=>Number(x.instance.split(',')[1])<12);if(partition.length!==12)throw Error('Exactly twelve benchmark logical processors');
  const total=s.counters.find(x=>x.instance==='_total');if(!total||![0,1].includes(total.status)||!Number.isFinite(total.value))throw Error('Actual whole-host observation required');
  return {capturedAt:s.capturedAt,totalProcessorPercent:total.value,benchmarkPartitionProcessorPercent:partition.reduce((a,x)=>a+x.value,0)/12,physicalProcessorCounters:processors};
 });
 const partitionMeanCPU=windows.reduce((a,x)=>a+x.benchmarkPartitionProcessorPercent,0)/windows.length;return {policy:HOST_POLICY,capturedAt:new Date().toISOString(),linux,windows,partitionMeanCPU,partitionPointwiseMaximumCPU:Math.max(...windows.map(x=>x.benchmarkPartitionProcessorPercent)),quiet:linux.MemAvailableKiB>=HOST_POLICY.minimumLinuxKiB&&partitionMeanCPU<=HOST_POLICY.maximumWindowsCpuPercent,scope:'Actual integrated three-second same-CCD CPU budget and memory admission; every individual processor counter is retained; no instantaneous-max gate claim; whole-host CPU and every Linux graph retained as observations. Only owned browser processes are affinitized. Same-source controls are separately required; no claim of OS-exclusive reservation.'};
}
