from pathlib import Path
import json,statistics,subprocess,os,hashlib
R=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69');A=Path(__file__).resolve().parent;C=Path('/tmp/7292-partition-research-v2/actual-window-v2/capture/receipt.json');D=A/'scratch-existing-regression-check';D.mkdir();(D/'scripts/lib').mkdir(parents=True);(D/'tests/benchmark/benchmark-results').mkdir(parents=True);(D/'package.json').write_text('{"type":"module"}\n')
for rel in ['scripts/check-benchmark-regression.js','scripts/lib/benchmark-upload-mode.mjs']:(D/rel).write_bytes((R/rel).read_bytes())
r=json.loads(C.read_text());assert len(r['rows'])==20 and r['status']=='FIVE_MATCHED_INTERLEAVED_PAIRS_CAPTURED_REPORT_REQUIRED';base={};fields=['firstBatchWaitMs','firstVisibleGeometryMs','streamCompleteMs','spatialReadyMs','metadataCompleteMs','totalWallClockMs']
for fixture in ['FZK','ISSUE129']:
 source={}
 for side in ['base','branch']:
  rows=[x for x in r['rows']if x['fixture']==fixture and x['side']==side];assert len(rows)==5;metrics={k:statistics.median(x['metrics'][k]for x in rows)for k in fields};source[side]={'file':fixture,'timestamp':max(x['hostAfter']['capturedAt']for x in rows),'metrics':metrics,'environment':'LOCAL native Windows NVIDIA Blackwell DPR1.5 six-core affinity; explicit integrated CPU protocol','gpuHealth':{'contaminated':False},'loadCounters':{'uploadMode':'timed'}}
 base[fixture]=source['base'];(D/f'tests/benchmark/benchmark-results/viewer-{fixture}.json').write_text(json.dumps(source['branch'],indent=2)+'\n')
(D/'scratch-baseline.json').write_text(json.dumps(base,indent=2)+'\n');env=os.environ.copy();env['BENCHMARK_BASELINE']=str(D/'scratch-baseline.json')
with(D/'actual-check.log').open('wb')as log:p=subprocess.run(['node',D/'scripts/check-benchmark-regression.js','--markdown',D/'actual-check.md'],env=env,cwd=D,stdout=log,stderr=subprocess.STDOUT)
result={'status':'PASS'if p.returncode==0 else'FAIL','exitCode':p.returncode,'checkerExactlyCopiedFromQualifiedSource':True,'sixExistingThresholdsUnchangedPercent':50,'noCommittedCiBaselineUsed':True,'actualSameHostSameProtocolBaseMedians':True,'allSixMetricsAvailable':True,'originalReceiptSHA256':hashlib.sha256(C.read_bytes()).hexdigest(),'checkerSHA256':hashlib.sha256((D/'scripts/check-benchmark-regression.js').read_bytes()).hexdigest()};(A/'existing-regression-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(p.returncode)
