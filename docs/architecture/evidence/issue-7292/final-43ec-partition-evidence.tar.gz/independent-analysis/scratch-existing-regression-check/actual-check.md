<!-- viewer-benchmark-report -->
## Viewer benchmark

✅ No threshold regressions detected.

### FZK

Baseline recorded 2026-10-18T10:15:57.809Z on LOCAL native Windows NVIDIA Blackwell DPR1.5 six-core affinity; explicit integrated CPU protocol.

> ⚠ This baseline is not CI-recorded (no CI environment tag), so the deltas below may reflect a machine/metric-era mismatch rather than a code change. Refresh it via the Benchmark workflow (`record_baseline`).

| Metric | Current | Baseline | Delta | Threshold | Status |
|---|---|---|---|---|---|
| firstBatchWaitMs | 99ms | 102ms | -2.9% | +50% | ✅ |
| firstVisibleGeometryMs | 231ms | 241ms | -4.1% | +50% | ✅ |
| streamCompleteMs | 255ms | 257ms | -0.8% | +50% | ✅ |
| spatialReadyMs | 305ms | 312ms | -2.2% | +50% | ✅ |
| metadataCompleteMs | 367ms | 369ms | -0.5% | +50% | ✅ |
| totalWallClockMs | 386ms | 390ms | -1.0% | +50% | ✅ |

### ISSUE129

Baseline recorded 2026-10-18T10:22:49.067Z on LOCAL native Windows NVIDIA Blackwell DPR1.5 six-core affinity; explicit integrated CPU protocol.

> ⚠ This baseline is not CI-recorded (no CI environment tag), so the deltas below may reflect a machine/metric-era mismatch rather than a code change. Refresh it via the Benchmark workflow (`record_baseline`).

| Metric | Current | Baseline | Delta | Threshold | Status |
|---|---|---|---|---|---|
| firstBatchWaitMs | 409ms | 398ms | +2.8% | +50% | ✅ |
| firstVisibleGeometryMs | 826ms | 823ms | +0.4% | +50% | ✅ |
| streamCompleteMs | 1924ms | 1681ms | +14.5% | +50% | ✅ |
| spatialReadyMs | 477ms | 461ms | +3.5% | +50% | ✅ |
| metadataCompleteMs | 569ms | 560ms | +1.6% | +50% | ✅ |
| totalWallClockMs | 1991ms | 1740ms | +14.4% | +50% | ✅ |

Refresh the baseline from a CI run: dispatch the Benchmark workflow with `record_baseline`, download the `benchmark-baseline` artifact, and commit `baseline.json` (see tests/benchmark/README.md).
