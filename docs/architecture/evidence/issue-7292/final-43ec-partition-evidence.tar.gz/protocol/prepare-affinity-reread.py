from pathlib import Path
import hashlib,json,subprocess
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=Path('/tmp/7292-current-passive-worker-pool-preparation-v25');new=Path('/tmp/7292-current-passive-worker-pool-preparation-v27');new.mkdir();pins=json.loads((old/'preparation-pins.json').read_text())
for rel,h in pins.items():
 p=old/rel;assert H(p)==h;q=new/rel;q.parent.mkdir(parents=True,exist_ok=True);s=p.read_text().replace(str(old),str(new))
 if rel.endswith('windows-lifecycle.mjs'):
  s=s.replace(' function partitionAffinitySnapshot(){',' async function partitionAffinitySnapshot(){\n  const readonlyObservationFailures=[];for(let attempt=0;attempt<5;attempt++){try{')
  s=s.replace('$p=Get-Process -Id $row.ProcessId -ErrorAction Stop;',"try{$p=Get-Process -Id $row.ProcessId -ErrorAction Stop}catch{if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){throw 'Owned affinity process exited during readonly observation'};throw};")
  s=s.replace("if($again.Count -ne 1 -or", "if($again.Count -eq 0){throw 'Owned affinity process exited during readonly observation'};if($again.Count -ne 1 -or")
  s=s.replace("throw Error('Actual complete owned partition witness required');return data;", "throw Error('Actual complete owned partition witness required');return {...data,readonlyObservationFailures};\n  }catch(error){const message=String(error);if(!message.includes('Owned affinity process exited during readonly observation')&&!message.includes('Chrome command-line observation incomplete'))throw error;readonlyObservationFailures.push(message);if(attempt===4)throw Error('Owned affinity observation deadline: '+JSON.stringify(readonlyObservationFailures));await delay(100);}}throw Error('Owned affinity observation incomplete');")
 if rel.endswith('windows-capture.template.mts'):s=s.replace('record.partitionBefore=owned!.partitionAffinitySnapshot()','record.partitionBefore=await owned!.partitionAffinitySnapshot()').replace('record.partitionAfter=owned.partitionAffinitySnapshot()','record.partitionAfter=await owned.partitionAffinitySnapshot()')
 q.write_text(s)
for side in ['base','branch']:
 p=new/side/'preparation-pins.json';d=json.loads(p.read_text());p.write_text(json.dumps({rel:H(new/side/rel)for rel in d},indent=2)+'\n')
(new/'preparation-pins.json').write_text(json.dumps({rel:H(new/rel)for rel in pins},indent=2)+'\n');d=Path('/tmp/7292-partition-research-v2/binding-v27');d.mkdir();s=Path('/tmp/7292-partition-research-v2/binding/bind-timing.py').read_text().replace(str(old),str(new));(d/'bind-timing.py').write_text(s);(d/'preparation-sha256.json').write_text(json.dumps({str(d/'bind-timing.py'):H(d/'bind-timing.py')}))
prior={'base':Path('/tmp/7292-finalb0-base-fzk-passive-qualification-v3/composite-receipt.json'),'branch':Path('/tmp/7292-final43ec-candidate-fzk-passive-qualification-v1/composite-receipt.json')};inv=Path('/tmp/7292-partition-protected-inventory-v1/protected-user-binding.json')
for side in ['base','branch']:subprocess.run(['python3',str(d/'bind-timing.py'),'--side',side,'--prior-fzk',str(prior[side]),'--prior-fzk-sha256',H(prior[side]),'--inventory-binding',str(inv),'--inventory-sha256',H(inv),'--out',str(d/(side+'-binding'))],check=True)
s=Path('/tmp/7292-partition-research-v2/run-approved-window.py').read_text().replace(str(old),str(new)).replace('actual-window-v1','actual-window-v2').replace('until=now+datetime.timedelta(minutes=20)',"until=datetime.datetime.fromisoformat('2026-10-18T10:27:23.294+00:00')")
Path('/tmp/7292-partition-research-v2/run-approved-window-v2.py').write_text(s)
print('BOTH_SIDES_BOUND_READONLY_PROCESS_EXIT_REREAD_NO_TIMED_BODY_OR_RUNTIME_CHANGE')
