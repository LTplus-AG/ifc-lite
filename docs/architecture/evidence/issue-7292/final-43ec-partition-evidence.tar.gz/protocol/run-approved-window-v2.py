from pathlib import Path
import subprocess,json,hashlib,datetime,statistics
D=Path('/tmp/7292-partition-research-v1');P=Path('/tmp/7292-current-passive-worker-pool-preparation-v27');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();utc=lambda:datetime.datetime.now(datetime.timezone.utc);iso=lambda x:x.isoformat(timespec='milliseconds').replace('+00:00','Z');O=Path('/tmp/7292-partition-research-v2/actual-window-v2');O.mkdir()
now=utc();until=datetime.datetime.fromisoformat('2026-10-18T10:27:23.294+00:00');sides={}
for s in ['base','branch']:
 p=P/s/'pins.json';r=json.loads(p.read_text());sides[s]={'expectedHead':r['head'],'pinsPath':str(p),'pinsSHA256':H(p)}
amendment=p_amend=Path('/tmp/7292-partition-research-v2/actual-user-amendment.json');approval=json.loads(amendment.read_text());assert approval['item']['createdBy']=='user' and approval['item']['text'].endswith('Approve integrated CPU protocol')
a={'measurementProtocolAmendment':{'path':str(amendment),'sha256':H(amendment)},'status':'DIRECT_USER_AUTHORIZED_7292_PARTITION_TIMING','timingOwnerThreadId':'c6115f2d-994d-4e97-8720-c5793076c258','noConcurrentOwnedBrowserCapture':True,'opensUTC':iso(now),'untilUTC':iso(until),'partitionPolicy':{'path':'/tmp/7292-partition-research-v2/protocol.json','sha256':H('/tmp/7292-partition-research-v2/protocol.json')},'grantEvidence':{'path':str(D/'actual-user-grant.json'),'sha256':H(D/'actual-user-grant.json')},'sides':sides,'base':sides['base']['expectedHead'],'candidate':sides['branch']['expectedHead'],'noSharedHostHold':True,'newProtocolOriginalRefusalsUnchanged':True};f=O/'actual-authority.json';f.write_text(json.dumps(a,indent=2)+'\n');c={'purpose':'EXPLICIT_NEW_DIRECT_USER_7292_TIMING_SCHEDULE_NOT_OLD_CAPTURE','seed':7292,'iters':5,'notBeforeUTC':a['opensUTC'],'notAfterUTC':a['untilUTC'],'sides':sides,'timingAuthority':{'path':str(f),'sha256':H(f)}};cf=O/'cohort-config.json';cf.write_text(json.dumps(c,indent=2)+'\n');base=['node','--import','/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69/node_modules/tsx/dist/loader.mjs',str(P/'perf.mts'),'--run-new-cohort','--base-pins',sides['base']['pinsPath'],'--branch-pins',sides['branch']['pinsPath'],'--cohort-config',str(cf)];phases=[]
def run(phase,args):
 cmd=base+args+['--out',str(O/phase)];r={'phase':phase,'command':cmd,'startedUTC':iso(utc())};phases.append(r);(O/'processes.json').write_text(json.dumps(phases,indent=2)+'\n')
 with(O/(phase+'.log')).open('wb')as log:
  child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT);r['pid']=child.pid;(O/'processes.json').write_text(json.dumps(phases,indent=2)+'\n');r['exitCode']=child.wait()
 r.update(reaped=True,finishedUTC=iso(utc()));(O/'processes.json').write_text(json.dumps(phases,indent=2)+'\n');assert r['exitCode']==0,phase+' refused; originals preserved'
print('PARTITION_WINDOW_OPEN '+a['opensUTC']+' UNTIL '+a['untilUTC'],flush=True)
try:
 controls=json.loads((D/'actual-window-v2/same-source-controls/receipt.json').read_text());assert controls['status']=='SAME_SOURCE_PARTITION_CONTROLS_CAPTURED_REPORT_REQUIRED'and len(controls['rows'])==6
 report={}
 for fixture in ['FZK','ISSUE129']:
  values=[r['metrics']['totalWallClockMs']for r in controls['rows']if r['fixture']==fixture];assert len(values)==3;ratio=(max(values)-min(values))/statistics.median(values);report[fixture]={'threeSameSourceValuesMs':values,'rangeOverMedian':ratio,'maximumAllowed':0.10,'pass':ratio<=0.10}
 (O/'same-source-stability.json').write_text(json.dumps(report,indent=2)+'\n');assert all(r['pass']for r in report.values()),'Same-source controls not stable enough; no AB starts'
 print('SAME_SOURCE_PARTITION_CONTROLS_PASS_FRESH_AB_STARTS',flush=True);run('capture',[]);r=json.loads((O/'capture/receipt.json').read_text());assert r['status']=='FIVE_MATCHED_INTERLEAVED_PAIRS_CAPTURED_REPORT_REQUIRED'and len(r['rows'])==20
 result={'status':'COMPLETE_PARTITION_CONTROL_AND_TWENTY_ROW_CAPTURE_REPORT_REQUIRED','untilUTC':a['untilUTC'],'allChildrenReaped':True,'sharedHoldCreated':False,'verdictPendingAnalysis':True}
except BaseException as e:
 result={'status':'PRESERVED_PARTITION_FAILURE_NO_VERDICT','error':str(e),'untilUTC':a['untilUTC'],'allChildrenReaped':all(p.get('reaped')for p in phases),'sharedHoldCreated':False};raise
finally:
 result['finishedUTC']=iso(utc());(O/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
