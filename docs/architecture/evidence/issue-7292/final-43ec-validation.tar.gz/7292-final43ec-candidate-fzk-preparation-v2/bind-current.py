"""Bind ONE actual completed final source/runtime; no build, server or browser launch."""
from pathlib import Path
import argparse, hashlib, json, subprocess
from committed_source import verify_committed_source

D = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--config', type=Path, required=True)
ap.add_argument('--config-sha256', required=True)
ap.add_argument('--expected-head', required=True)
a = ap.parse_args()
sha = lambda data: hashlib.sha256(data).hexdigest()
data = a.config.read_bytes()
if sha(data) != a.config_sha256:
    raise RuntimeError('Actual reviewed config bytes required')
c = json.loads(data)
if 'DEFERRED' in json.dumps(c) or (D / 'config.json').exists():
    raise RuntimeError('Complete final config and fresh binding required')
root = Path(c['root'])
head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
if head != a.expected_head or c['expectedHead'] != head:
    raise RuntimeError('Exact explicit final committed revision required')
if subprocess.check_output(['git', '-C', str(root), 'status', '--porcelain', '--untracked-files=no'], text=True):
    raise RuntimeError('Clean committed source required')
qb = Path(c['qualification']['path']).read_bytes()
q = json.loads(qb)
bb = Path(c['buildReceiptPath']).read_bytes()
build = json.loads(bb)
if sha(qb) != c['qualification']['sha256'] or sha(qb) != c['candidatePreparationSHA256'] or c['candidatePreparation'] != c['qualification']['path']:
    raise RuntimeError('Exact completed qualification/candidate bytes required')
if q['status'] != c['qualification']['acceptedStatus'] or q.get('sourceUnchanged') is not True or not (q.get('wasmUnchanged') is True or q.get('officialPackageUnchanged') is True):
    raise RuntimeError('Completed unchanged actual source/runtime qualification required')
if build['builtRevision'] != head:
    raise RuntimeError('Actual build receipt differs exact current revision')
verify_committed_source(root, head, q['sourceManifest'])
fixtures = c['fixtures']
if len(fixtures) != 1 or fixtures[0]['key'] != 'FZK' or not fixtures[0]['requireFourWorkers'] or fixtures[0]['kind'] != 'real':
    raise RuntimeError('One real FZK four-worker load only')
with (D / 'config.json').open('x') as f:
    f.write(json.dumps(c, indent=2) + '\n')
with (D / 'binding.json').open('x') as f:
    f.write(json.dumps({'status': 'ONE_ACTUAL_FINAL_BUILD_BOUND_NOT_BROWSER_QUALIFIED',
                        'configPath': str(a.config.resolve()), 'configSHA256': sha(data),
                        'compiledHead':c['expectedHead'],'observedCheckoutHead':head,'scope':'final-source-current', 'qualificationSHA256': sha(qb), 'buildReceiptSHA256': sha(bb),
                        'performanceClaim': False}, indent=2) + '\n')
print('Actual final source/runtime config bound; no translation, seal, server, browser or model action.')
