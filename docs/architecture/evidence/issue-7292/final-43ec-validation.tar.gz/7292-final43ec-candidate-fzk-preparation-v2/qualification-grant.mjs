/** Current user-authorized untimed finishing. No timing lease or launch on import. */
import {createHash} from 'node:crypto';
const HOLD='/home/louistrue/wt/.bench-hold';
const DRAIN={"coordinatorThreadId":"b61983f5-e0be-4bdb-b83e-f910098f5ac4","approvalItemPosition":2496,"approvalUpdatedAtUTC":"2026-10-17T18:58:11.404Z","receiptSHA256":"a64285c43fa9c652d684e128fcff322aded989bea13166d87a84a00ea0d0af8b","holdSHA256":"8801d1c2a60dc6234d2dbcbaa15094768ee92db4406f20443b8ed7cc21f5f3ce","candidateHead":"ba457b1283e85f1f09ea1eec23926b92b98cbc38","baseHead":"592d84c9709a10360b788af021965ee38d5bba86","notBeforeUTC":"2026-10-17T18:58:11.404Z","expiresUTC":"2026-10-17T19:58:11.404Z","permittedCaptures":["serial-untimed-candidate-FZK","serial-untimed-base-FZK","serial-untimed-five-functional"],"timingAuthorized":false,"acceptedBenchmarkRows":0};
export function verifyQualificationAuthorization(readBytes,now=Date.now()){
 let absent=false,held;
 try{held=readBytes(HOLD);}catch(error){if(error?.code==='ENOENT')absent=true;else throw error;}
 if(!absent){
  const digest=createHash('sha256').update(held).digest('hex');
  if(digest!==DRAIN.holdSHA256||!Number.isFinite(now)||now<Date.parse(DRAIN.notBeforeUTC)||now>=Date.parse(DRAIN.expiresUTC))throw Error('Shared benchmark hold exists; no authorized current drain exception');
  return {authorization:'PINNED_CURRENT_DRAIN_SERIAL_UNTIMED_QUALIFICATION',sharedBenchHoldAbsent:false,sharedBenchHoldSHA256:digest,recordedDrainApproval:DRAIN,acceptedBenchmarkRows:0,timingAuthorized:false};
 }
 return {authorization:'CURRENT_USER_AUTHORIZED_ORDINARY_UNTIMED_QUALIFICATION',sharedBenchHoldAbsent:true,acceptedBenchmarkRows:0,timingAuthorized:false};
}
if(process.argv.includes('--verify-authorization')){verifyQualificationAuthorization((await import('node:fs')).readFileSync);console.log('USER_UNTIMED_AUTHORIZATION_AND_HOLD_VERIFIED');}
