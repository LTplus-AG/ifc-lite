"""WSL canonical verifier supervises one native Windows capture; explicit new composite required."""
from pathlib import Path
import argparse,subprocess,json,hashlib,os,shutil,fcntl
from capture_supervisor import supervise
D=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true',required=True);ap.add_argument('--pins',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--fixture',choices=['FZK'],required=True);a=ap.parse_args()
pins=a.pins.resolve();out=a.out.resolve();pb=pins.read_bytes();p=json.loads(pb);R=Path(p['config']['root'])
if out.exists():raise RuntimeError('Fresh external output required')
if out.is_relative_to(R):raise RuntimeError('Output must remain outside source')
subprocess.run(['node',str(D/'qualification-grant.mjs'),'--verify-authorization'],check=True,timeout=10)
owned_lock=open('/tmp/7292-owned-untimed-browser.lock','a')
fcntl.flock(owned_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
loader=str(R/'node_modules/tsx/dist/loader.mjs')
verify=['node','--import',loader,str(D/'sample.mts'),'--verify-only','--pins',str(pins)]
if len([f for f in p['config']['fixtures'] if f['key']==a.fixture])!=1:raise RuntimeError('One sealed fixture key required')
def native_command():
 subprocess.run(['node',str(D/'qualification-grant.mjs'),'--verify-authorization'],check=True,timeout=10)
 consumed=out.with_name(out.name+'.actual-app-attempt-reservation.json')
 with consumed.open('x')as marker:marker.write(json.dumps({'status':'ONE_ACTUAL_APP_LAUNCH_RESERVED','authorization':'CURRENT_USER_AUTHORIZED_UNTIMED','pinsSHA256':hashlib.sha256(pb).hexdigest(),'out':str(out)})+'\n')
 version=json.loads((R/'node_modules/@playwright/test/package.json').read_text())['version']
 core=(R/f'node_modules/.pnpm/playwright-core@{version}/node_modules/playwright-core').resolve(strict=True)
 if json.loads((core/'package.json').read_text())['version']!=version:raise RuntimeError('Playwright-core version mismatch')
 win=lambda path:subprocess.check_output(['wslpath','-w',str(path)],text=True).strip()
 node=Path('/mnt/c/Program Files/nodejs/node.exe')
 if not node.is_file():raise RuntimeError('Proven native Windows Node missing; no install or WSL CDP fallback')
 if any(k.startswith('VIEWER_BENCHMARK_')for k in os.environ):raise RuntimeError('Inherited benchmark overrides refused')
 return [str(node),win(D/'windows-capture.mjs'),'--run','--pins',str(pins),'--expected-pins-sha256',hashlib.sha256(pb).hexdigest(),'--out',str(out),'--fixture',a.fixture,'--playwright-core',win(core),'--owned-helper',str(D/'frame-gpu-owned-profile.ps1'),'--wsl-root-win',win('/'),'--wsl-distro',os.environ['WSL_DISTRO_NAME'],'--wsl-node',str(Path(shutil.which('node')).resolve(strict=True))]
raise SystemExit(supervise(pins,out,verify,native_command,a.fixture))
