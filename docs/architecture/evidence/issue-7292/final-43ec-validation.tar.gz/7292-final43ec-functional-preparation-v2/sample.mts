import {verifyTransferredFreshness} from './remote_freshness.mjs';
import {verifyPriorFzk} from './prior-fzk-proof.mjs';
import {deriveRuntimeRetention} from './retention-budget.mjs';
import {readProtectedBinding} from '/tmp/7292-protected-browser-guard-v1/protected-browser-guard.mjs';
const PROTECTION_SOURCE="/tmp/7292-protected-browser-guard-v1/protected-browser-guard.mjs",PROTECTION_SHA256="b1911a3a4494eb7f19373fa10ab0ac791a8b38c3dec8e253add2609f6c558c42";
/** INERT source/build seal controller; runtime uses Windows native Node. */
import { validateBuildReceipt } from '/tmp/7292-build-receipt-validation.mts';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const D=dirname(fileURLToPath(import.meta.url));
const sha=(b:Uint8Array|string)=>createHash('sha256').update(b).digest('hex');
const fileSha=(p:string)=>sha(readFileSync(p));
const CANONICAL_ROOT="/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69";
const CANONICAL_PINS_SHA256="cdeec6d0a16b38da98b1d182b3f6b39c24d82c2cdde7494ac5dda1712ec3df12";
function boundJson<T>(p:string,expected:string):T{const bytes=readFileSync(p);need(sha(bytes)===expected,'Consumed JSON hash '+p);return JSON.parse(bytes.toString('utf8')) as T;}
function need(value:unknown,message:string):asserts value {if(!value)throw Error(message);}
const save=(p:string,v:unknown)=>writeFileSync(p,JSON.stringify(v,null,2),{flag:'wx'});
const arg=(n:string)=>{const i=process.argv.indexOf(n);return i<0?undefined:process.argv[i+1];};
type FilePin={path:string;bytes:number;sha256:string};
type Fixture={key:string;kind:'real'|'reporter';path:string;selectedIds:number[];requireFourWorkers:boolean;timeoutMs:number};
type Config={remoteBuildTransfer?:{receiptPath:string;sha256:string};root:string;frozenDist:string;wasmPath:string;origin:string;serverReceiptPath:string;buildReceiptPath:string;
 qualification:{path:string;sha256:string;acceptedStatus:string};candidatePreparation:string;candidatePreparationSHA256:string;
 priorFzkComposite:{path:string;sha256:string};expectedHead:string;runtimeRetention:ReturnType<typeof deriveRuntimeRetention>;chromeExecutable?:string;fixtures:Fixture[]};
type Pins={version:1;config:Config;files:Record<string,string>;productionTreeSha256:string;distFiles:FilePin[];distSha256:string;wasmSha256:string;head:string};
const walk=(p:string):string[]=>readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(p,e.name)):[join(p,e.name)]).sort();
const git=(r:string,...a:string[])=>execFileSync('git',['-C',r,...a],{encoding:'utf8',timeout:10000});
function sourceFiles(root:string){return [...new Set(git(root,'ls-files','--cached','--others','--exclude-standard','-z','rust','packages','apps/viewer','scripts/build-wasm.sh','scripts/build-wasm-postprocess.mjs','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','pnpm-lock.yaml','package.json','turbo.json','tsconfig.json','tsconfig.packages.json').split('\0').filter(Boolean))].filter(p=>!/(^|\/)(tests?|examples|benches|evidence|__snapshots__)\//.test(p)&&!/(\.test\.|\.spec\.|_tests\.rs$|(^|\/)(README|CHANGELOG)\.)/.test(p)).sort();}
function tree(root:string,files:string[]){const rows=files.map(path=>({path,bytes:statSync(join(root,path)).size,sha256:fileSha(join(root,path))}));return {rows,sha256:sha(rows.map(f=>`${f.path}\0${f.bytes}\0${f.sha256}\n`).join(''))};}
function configChecks(c:Config){
 need(new URL(c.origin).hostname==='localhost'&&new URL(c.origin).protocol==='http:','Fresh localhost HTTP origin only');
 need(![5273,5274,5276,5277,56792].includes(Number(new URL(c.origin).port)),'Preserve old listener ports');
 need(JSON.stringify(c.fixtures.map(f=>f.key))===JSON.stringify(['soffice-target-first','literal2pct','derived5pct','stacked2pct','stacked5pct'])&&c.fixtures[0].kind==='real'&&c.fixtures[0].requireFourWorkers&&c.fixtures.slice(1).every(f=>f.kind==='reporter'),'Exactly original five functional fixtures, SOffice first/four workers');
 verifyPriorFzk(c,readFileSync);

 need(new Set(c.fixtures.map(f=>f.key)).size===c.fixtures.length,'Unique fixture keys');
 for(const f of c.fixtures){need(/^[a-zA-Z0-9_-]+$/.test(f.key)&&f.selectedIds.length>0&&new Set(f.selectedIds).size===f.selectedIds.length&&f.selectedIds.every(i=>Number.isSafeInteger(i)&&i>0),'Explicit selected IDs/key');need(f.timeoutMs>=10000&&f.timeoutMs<=180000,'Bounded fixture timeout');}
}
function verifyArtifacts(c:Config){
 configChecks(c);
 need(fileSha(PROTECTION_SOURCE)===PROTECTION_SHA256,'Shared protected guard source drift');readProtectedBinding(D,readFileSync);
 const protocol=boundJson<Record<string,string>>(join(D,'canonical-helper-pins.json'),CANONICAL_PINS_SHA256);for(const [rel,h]of Object.entries(protocol)){need(fileSha(join(CANONICAL_ROOT,rel))===h,'Executing current canonical helper changed '+rel);need(fileSha(join(c.root,rel))===h,'Build checkout canonical helper differs '+rel);}
 const qualification=boundJson(c.qualification.path,c.qualification.sha256) as {status:string;candidateManifest?:Record<string,string>;sourceManifest?:Record<string,string>;candidatePreparationSHA256?:string};need(qualification.status===c.qualification.acceptedStatus,'Explicit reviewed qualification status');
 // Parse exactly the candidate bytes whose reviewed hash is required.
 const candidate=boundJson(c.candidatePreparation,c.candidatePreparationSHA256) as {sourceManifest?:Record<string,string>;candidateManifest?:Record<string,string>};const manifest=candidate.sourceManifest??candidate.candidateManifest;need(manifest&&Object.keys(manifest).length,'Candidate full source map required');
 const qualified=qualification.candidateManifest??qualification.sourceManifest;need(qualified&&JSON.stringify(Object.entries(qualified).sort())===JSON.stringify(Object.entries(manifest).sort()),'Qualification receipt does not bind exact compiled candidate source manifest');if(qualification.candidatePreparationSHA256!==undefined)need(qualification.candidatePreparationSHA256===c.candidatePreparationSHA256,'Qualification candidate prep mismatch');
 for(const [p,h]of Object.entries(manifest))need(fileSha(join(c.root,p))===h,'Build source differs candidate '+p);
 const source=tree(c.root,sourceFiles(c.root)),dist=tree(c.frozenDist,walk(c.frozenDist).map(p=>relative(c.frozenDist,p))),wasm=fileSha(c.wasmPath),head=git(c.root,'rev-parse','HEAD').trim();
 need(head===c.expectedHead&&/^[a-f0-9]{40}$/.test(c.expectedHead),'Explicit final compiled/current HEAD required');
 need(JSON.stringify(c.runtimeRetention)===JSON.stringify(deriveRuntimeRetention(dist.rows)),'Actual final frozen runtime capacity differs reviewed formula');
 need(dist.rows.some(p=>p.path.endsWith('.wasm')&&p.sha256===wasm),'Frozen dist must include exact pkg WASM');
 const remoteFreshnessFiles:string[]=c.remoteBuildTransfer?verifyTransferredFreshness(c,manifest):[];
 if(!c.remoteBuildTransfer){const rust=source.rows.filter(p=>p.path.startsWith('rust/')&&p.path.endsWith('.rs'));need(rust.length>0&&statSync(c.wasmPath).mtimeMs>=Math.max(...rust.map(p=>statSync(join(c.root,p.path)).mtimeMs)),'WASM predates source');need(statSync(join(c.frozenDist,'index.html')).mtimeMs>=statSync(c.wasmPath).mtimeMs,'Dist predates WASM');}
 const buildBytes=readFileSync(c.buildReceiptPath),buildSHA256=sha(buildBytes);const build=JSON.parse(buildBytes.toString('utf8')) as {steps:Array<{logPath:string;logSha256:string}>};
 validateBuildReceipt(c.buildReceiptPath,{builtRevision:head,productionTreeSha256:source.sha256,wasmSha256:wasm,distSha256:dist.sha256},['wasm','viewer'],c.root);
 need(fileSha(c.buildReceiptPath)===buildSHA256,'Build receipt changed during validation');return {source,dist,wasm,head,build,buildSHA256,remoteFreshnessFiles};
}
function seal(c:Config,out:string){
 const a=verifyArtifacts(c),files:Record<string,string>={};
 const helperRoot=CANONICAL_ROOT;
 const protectedBinding=readProtectedBinding(D,readFileSync);
 for(const p of [...a.remoteFreshnessFiles,...walk(D).filter(p=>/\.(mts|ts|ps1|mjs|py)$/.test(p)),...walk(join(helperRoot,'tests/benchmark')).filter(p=>/\.(ts|mts)$/.test(p)),...walk(join(helperRoot,'scripts/perf')).filter(p=>/\.(ts|mts)$/.test(p)),join(D,'canonical-helper-pins.json'),join(D,'preparation-pins.json'),join(D,'binding.json'),join(D,'runtime-transport.json'),join(D,'protected-user-binding.json'),protectedBinding.inventoryPath,join(D,'protected-guard-pins.json'),PROTECTION_SOURCE,join(helperRoot,'scripts/perf/ab-order.mjs'),join(helperRoot,'scripts/lib/is-main-entry.mjs'),join(helperRoot,'scripts/lib/benchmark-upload-mode.mjs'),c.qualification.path,c.candidatePreparation,c.buildReceiptPath,c.serverReceiptPath,...c.fixtures.map(f=>f.path),...verifyPriorFzk(c,readFileSync),'/tmp/7292-build-receipt-validation.mts'])files[p]=fileSha(p);
 files[c.buildReceiptPath]=a.buildSHA256;for(const s of a.build.steps){need(fileSha(s.logPath)===s.logSha256,'Actual build log drift');files[s.logPath]=s.logSha256;}
 save(out,{version:1,config:c,files,productionTreeSha256:a.source.sha256,distFiles:a.dist.rows,distSha256:a.dist.sha256,wasmSha256:a.wasm,head:a.head} satisfies Pins);
}
function verify(p:Pins){
 for(const [path,h]of Object.entries(p.files))need(fileSha(path)===h,'Sealed input drift '+path);
 const a=verifyArtifacts(p.config);need(a.source.sha256===p.productionTreeSha256&&a.dist.sha256===p.distSha256&&a.wasm===p.wasmSha256&&a.head===p.head,'Compiled source/runtime drift');
 const s=boundJson(p.config.serverReceiptPath,p.files[p.config.serverReceiptPath]!)as{root:string;port:number;buildReceiptSHA256:string;distSha256:string;wasmSha256:string};need(s.root===p.config.frozenDist&&s.port===Number(new URL(p.config.origin).port)&&s.buildReceiptSHA256===fileSha(p.config.buildReceiptPath)&&s.distSha256===p.distSha256&&s.wasmSha256===p.wasmSha256,'Owned server/build binding');
}
const configPath=arg('--config'),pinsPath=arg('--pins');
if(process.argv.includes('--seal')){need(configPath&&pinsPath,'--seal --config FILE --pins NEW_FILE');seal(JSON.parse(readFileSync(configPath,'utf8')) as Config,resolve(pinsPath));}
else if(process.argv.includes('--verify-only')){need(pinsPath,'--verify-only --pins FILE');verify(JSON.parse(readFileSync(pinsPath,'utf8')) as Pins);console.log('SOURCE_RUNTIME_PINS_VERIFIED');}
else throw Error('Filesystem-only --seal/--verify-only controller; no browser launch route.');
