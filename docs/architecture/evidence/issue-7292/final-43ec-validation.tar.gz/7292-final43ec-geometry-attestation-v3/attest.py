from pathlib import Path
import argparse,json,hashlib,struct,math,time
D=Path(__file__).resolve().parent;O=Path('/tmp/7292-final43ec-functional-capture-v1');OLD=Path('/tmp/7292-final0151-functional-capture-v1');PREP=Path('/tmp/7292-final43ec-geometry-adjudication-prep-v1');R=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69');HEAD='43ecf3aa3e240e1a7c41c5c799212b60df010ebd'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());pins={}
def pin(p,expected=None):
 p=Path(p);h=H(p)
 if expected is not None:assert h==expected,(p,h,expected)
 pins[str(p)]=h;return h
ap=argparse.ArgumentParser();ap.add_argument('--composite-sha256',required=True);args=ap.parse_args();assert len(args.composite_sha256)==64 and all(c in '0123456789abcdef'for c in args.composite_sha256)
start=time.time_ns();comp=read(O/'composite-receipt.json');pin(O/'composite-receipt.json',args.composite_sha256);assert all(comp['gates'].values())and comp['nativeRequirements']['pass']and comp['nativeProcess']['status']==0 and comp['sourceBefore']['status']==comp['sourceAfter']['status']==0
native=read(O/'receipt.json');pin(O/'receipt.json',comp['nativeRequirements']['receiptSHA256']);assert native.get('error')is None and native['ownedCleanupError']is None and native['compiledArtifactRevision']==HEAD and native['observedCheckoutHead']==HEAD
p=read(O/'pins.json');pin(O/'pins.json',comp['pinsSHA256']);assert p['head']==HEAD and H(comp['pinsPath'])==comp['pinsSHA256']
assert [r['key']for r in native['records']]==['soffice-target-first','literal2pct','derived5pct','stacked2pct','stacked5pct']
prior=read('/tmp/7292-final0151-geometry-attestation-v1/attestation.json');pin('/tmp/7292-final0151-geometry-attestation-v1/attestation.json');pin(PREP/'preparation.json','03ce3c653e74d97d599f63336e5ad0b7ff581aabc91ca11a13801597526e889a')
for name,h in read(PREP/'preparation.json')['files'].items():pin(PREP/name,h)
historicalCode=read(PREP/'historical-code-map.json');pin(PREP/'historical-code-map.json','36ba4f81728012116ece7a13ba7dd3e1a6fdff5cfb78ae415cebbc33435d0daa')
for f,h in read(PREP/'prior-proof-input-pins.json').items():
 if f in historicalCode:
  item=historicalCode[f];assert item['sha256']==h;pin(item['snapshotPath'],h)
 else:pin(f,h)
assert 'remoteBuildTransfer'not in p['config'],'LOCAL capture must not invent remote transfer provenance'
for f in [p['config']['qualification']['path'],p['config']['buildReceiptPath'],p['config']['serverReceiptPath'],p['config']['wasmPath']]:pin(f,p['files'].get(f))
assert H(p['config']['wasmPath'])==p['wasmSha256']
build=read(p['config']['buildReceiptPath']);assert build['builtRevision']==HEAD and build['wasmSha256']==p['wasmSha256']
producer=read(p['config']['qualification']['path']);assert producer['head']==HEAD and producer['executionHost']=='LOCAL_WINDOWS_WSL'and producer['status']=='ACTUAL_SAME_HEAD_PARTIAL_PLUS_CONTINUATION_CONSUMERS_COMPLETE_NOT_BROWSER_OR_PERFORMANCE_QUALIFIED'and producer['sourceUnchanged']is True and producer['officialPackageUnchanged']is True and producer['fixturesUnchanged']is True and not producer.get('error')
assert build['localBuildClaim']is True and build['executionHost']=='LOCAL_WINDOWS_WSL'and build['actualRawReceiptPath']==p['config']['qualification']['path']and build['actualRawReceiptSHA256']==H(p['config']['qualification']['path'])and build['actualGitMetadataIdentity']==producer['actualGitMetadataIdentity']
for name,h in producer['sourceManifest'].items():pin(Path(p['config']['root'])/name,h)
for k in ['sourceBefore','sourceAfter']:
 for output in ['stdout','stderr']:
  row=comp[k][output];pin(row['path'],row['sha256'])
assert Path(comp['sourceBefore']['stdout']['path']).read_bytes()==Path(comp['sourceAfter']['stdout']['path']).read_bytes()==b'SOURCE_RUNTIME_PINS_VERIFIED\n'
def consumed(raw):
 result=[]
 for m in raw.get('rawMeshes',[raw]):
  if m.get('expressId',107)!=107:continue
  pos=m.get('positions_native_rtc_frame',m.get('positions'));origin=m.get('origin')or[0,0,0];idx=m['indices'];assert len(pos)%3==len(idx)%3==0 and len(origin)==3 and idx
  assert all(math.isfinite(float(x))for x in pos+origin)and all(type(i)is int and 0<=i<len(pos)//3 for i in idx)
  result.append(b''.join([struct.pack('<Q',len(pos)),*(struct.pack('<d',float(x))for x in pos),*(struct.pack('<d',float(x))for x in origin),struct.pack('<Q',len(idx)),*(struct.pack('<Q',i)for i in idx)]))
 assert result
 return b''.join(struct.pack('<Q',len(x))+x for x in result)
def structure(m):
 pos=m['positions'];norm=m['normals'];idx=m['indices'];assert pos and idx and len(pos)%3==len(idx)%3==0 and len(norm)==len(pos)
 assert all(math.isfinite(float(x))for x in pos+norm+m['origin'])and all(type(i)is int and 0<=i<len(pos)//3 for i in idx)
 assert len(m['positionF32Bits'])==len(pos)and all(struct.unpack('<f',struct.pack('<I',b))[0]==x for b,x in zip(m['positionF32Bits'],pos))
 assert len(m['normalF32Bits'])==len(norm)and all(struct.unpack('<f',struct.pack('<I',b))[0]==x for b,x in zip(m['normalF32Bits'],norm))
 assert len(m['originF64BitsDecimal'])==len(m['origin'])and all(struct.unpack('<d',struct.pack('<Q',int(b)))[0]==x for b,x in zip(m['originF64BitsDecimal'],m['origin']))
 if m.get('localToWorld')is not None:assert all(math.isfinite(float(x))for x in m['localToWorld'])
 return {'expressId':m['expressId'],'vertices':len(pos)//3,'triangles':len(idx)//3,'finiteTypedArraysAndIndexRange':True,'finiteNumericValuesMatchRetainedF32AndOriginF64Bits':True,'signedZeroScope':'Raw bit arrays retain sign; JSON numeric zero loses sign. Numeric agreement checks do not rewrite either.','bounds':{'min':[min(pos[k::3])for k in range(3)],'max':[max(pos[k::3])for k in range(3)]}}
reporters=[]
for key in ['literal2pct','derived5pct','stacked2pct','stacked5pct']:
 rawpath=O/key/'browser-raw.json';oldpath=OLD/key/'browser-raw.json';raw=read(rawpath);old=read(oldpath);rawhash=pin(rawpath);pin(oldpath)
 assert rawpath.read_bytes()==oldpath.read_bytes();newbytes=consumed(raw);oldbytes=consumed(old);assert newbytes==oldbytes
 case=read(O/key/'receipt.json');pin(O/key/'receipt.json');assert case['error']is None if'error'in case else True
 assert case['pageErrors']==[] and case['readiness']['ended']and case['readiness']['failed']==[]and case['passiveProof']['errors']==[]and case['gpuHealth']['contaminated']is False and case['gpuHealthAfterScreenshot']['contaminated']is False
 fixture=next(f for f in p['config']['fixtures']if f['key']==key);oldcase=next(c for c in prior['reporterCases']if c['key']==key);assert pin(fixture['path'],p['files'][fixture['path']])==oldcase['fixtureSHA256']==case['fixtureSHA256']
 origin=Path('/tmp/7292-final0151-two-reporter-finite-v1')/key if key in ['literal2pct','derived5pct']else Path('/tmp/7292-finish-finite-oracles-v1')/key
 receipt=read(origin/'receipt.json');pin(origin/'receipt.json',oldcase.get('freshOracleReceiptSHA256')or oldcase['originalOracleReceiptSHA256']);assert receipt['passed']is True;assert receipt.get('comparator_version','finite-coverage-v3')=='finite-coverage-v3'
 pin(origin/'oracle-diagnostics/receipt.json')
 reporters.append({'key':key,'verdict':'FINITE_FILLED_SURFACE_PASS_TRANSFERRED_BY_EXACT_WHOLE_RAW_AND_CONSUMED_INPUT_IDENTITY','rawSHA256':rawhash,'priorRawPath':str(oldpath),'entireRawFileIdentical':True,'exactComparatorConsumedMeshInputIdentical':True,'comparatorConsumedBinarySHA256':hashlib.sha256(newbytes).hexdigest(),'consumedEncoding':'Ordered selected107 effectivepositions and effectiveorigin IEEE754binary64littleendian plus exact indices/lengths uint64littleendian; includes signedzero. Every original selectedmesh/vertex/index order retained.','fixtureSHA256':case['fixtureSHA256'],'priorActualFiniteReceipt':str(origin/'receipt.json'),'priorActualFiniteReceiptSHA256':H(origin/'receipt.json'),'priorAttestationSHA256':H('/tmp/7292-final0151-geometry-attestation-v1/attestation.json'),'comparatorVersion':'finite-coverage-v3','toleranceMetres':0.0001,'maxWorkUnits':2000000,'freshOracleRun':False,'meshes':[structure(m)for m in raw['rawMeshes']]})
s=read(O/'soffice-target-first/receipt.json');sraw=read(O/'soffice-target-first/browser-raw.json');pin(O/'soffice-target-first/receipt.json');pin(O/'soffice-target-first/browser-raw.json');ids=[94664,473458,489647,798142,794361,437170]
actualArrivalOrder=[m['expressId']for m in sraw['rawMeshes']]
assert len(actualArrivalOrder)==len(set(actualArrivalOrder))==len(ids)and set(actualArrivalOrder)==set(ids)
previousSofficePath=Path('/tmp/7292-final6ca-functional-capture-v1/soffice-target-first/browser-raw.json');previousSoffice=read(previousSofficePath);pin(previousSofficePath,'ff9fabce82e9f6a5f26469ab322e5f5b6ac73ca26a01ce7f7c950182bdacc20d')
previousArrivalOrder=[m['expressId']for m in previousSoffice['rawMeshes']]
assert len(previousArrivalOrder)==len(set(previousArrivalOrder))==len(ids)and set(previousArrivalOrder)==set(ids)
canonicalPayload=lambda value:json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
currentByOwner={m['expressId']:m for m in sraw['rawMeshes']};previousByOwner={m['expressId']:m for m in previousSoffice['rawMeshes']}
sofficePerOwnerPayloadIdentity=[]
for owner in ids:
 currentPayload=canonicalPayload(currentByOwner[owner]);previousPayload=canonicalPayload(previousByOwner[owner]);assert currentPayload==previousPayload
 sofficePerOwnerPayloadIdentity.append({'expressId':owner,'allFieldsAndTypedBitsIndicesExact':True,'canonicalWholePayloadSHA256':hashlib.sha256(currentPayload).hexdigest()})
assert canonicalPayload({k:v for k,v in sraw.items()if k!='rawMeshes'})==canonicalPayload({k:v for k,v in previousSoffice.items()if k!='rawMeshes'})
assert s['readiness']['ended']and s['readiness']['failed']==[]and set(s['readiness']['done'])=={'parser.complete','geometry.streamComplete','scene.finalize'}and s['metrics']['canvasHasContent']is True and s['metrics']['renderCompleteMs']is not None
assert any(x['name']=='geometry.pool'and x['attrs']['workerCount']==4 for x in s['actualPool'])and s['adapter']['vendor']=='nvidia'and s['pageErrors']==[] and s['passiveProof']['errors']==[]and s['gpuHealth']['contaminated']is False and s['gpuHealthAfterScreenshot']['contaminated']is False
shot=O/'soffice-target-first/screenshot.png';shots={}
for case in ['soffice-target-first','literal2pct','derived5pct','stacked2pct','stacked5pct']:
 for f in (O/case).glob('*.png'):shots[str(f)]=pin(f)
assert native['preservedBefore']['completeCanonicalObservation']and native['preservedAfter']['completeCanonicalObservation']and native['preservedBefore']['rootCount']==native['preservedAfter']['rootCount']and native['preservedAfter']['chromeProcessCount']==0
cleanup={'actualAttempts':len(native['ownedCleanupAttempts']),'attemptErrorsPresent':[bool(a['error'])for a in native['ownedCleanupAttempts']],'originalCleanupErrorPreserved':bool(native.get('originalCleanupError')),'finalOwnedCleanupError':native['ownedCleanupError'],'configuredMaximumAttempts':3,'sameStrictUtility':native['cleanupAddendum']['sameStrictUtility'],'completeProtectedBefore':True,'completeProtectedAfter':True,'protectedRootCountsEqual':True,'finalChromeProcessCount':0}
a={'status':'FOUR_REPORTER_FINITE_SURFACE_PASSES_TRANSFERRED_BY_EXACT_INPUT_IDENTITY_SOFFICE_STRUCTURAL_RENDER_PASS','sourceRevision':HEAD,'createdNs':time.time_ns(),'compositeSHA256':H(O/'composite-receipt.json'),'nativeReceiptSHA256':H(O/'receipt.json'),'pinsSHA256':H(O/'pins.json'),'canonicalBuildReceiptSHA256':H(p['config']['buildReceiptPath']),'officialProducerReceiptSHA256':H(p['config']['qualification']['path']),'executionHost':'LOCAL_WINDOWS_WSL','actualGitMetadataIdentity':producer['actualGitMetadataIdentity'],'actualBuildNodeVersion':producer['actualBuildNodeVersion'],'remoteExecutionOrTransferClaim':False,'runtimeWasmSHA256':p['wasmSha256'],'reporterCases':reporters,'soffice':{'verdict':'SELECTED_TYPED_PAYLOAD_STRUCTURE_AND_ACTUAL_RENDER_READINESS_NOT_FULL_SOLID_ORACLE','rawSHA256':H(O/'soffice-target-first/browser-raw.json'),'actualArrivalOrder':actualArrivalOrder,'priorActualArrivalOrder':previousArrivalOrder,'exactUniqueSelectedOwnerCoverage':True,'perOwnerWholePayloadIdentity':sofficePerOwnerPayloadIdentity,'priorActualRawPath':str(previousSofficePath),'priorActualRawSHA256':H(previousSofficePath),'onlyArrivalOrderDiffersNonMeshMetadataIdentical':True,'meshes':[structure(m)for m in sraw['rawMeshes']],'fourActualWorkers':True,'actualNvidiaRenderer':True,'canonicalReadinessAndCanvas':True,'gpuErrorFreeBeforeAfterScreenshot':True,'rootScreenshotReview':'Root independently reviewing current actual screenshots; this machine attestation does not substitute for human view.'},'screenshots':shots,'cleanup':cleanup,'oracleRerun':False,'historicalProofCodeSnapshots':historicalCode,'historicalProofCodeScope':'Original pinned D1 gitblob bytes, not a claim that current main comparator/requirements are unchanged. No fresh oracle execution.','performanceClaim':False,'mergeReadinessClaim':False,'limits':'Four exact reporter finite filled-surface proof transfers at unchanged100um/2M and samecheckedreference/code/version/fixture/frame contract. No neworacleexecution, topology/winding/multiplicity/volume/global scene guarantee or independentSOffice solid oracle. Originalfailed cleanupattempt remains preserved; strictretry succeeded. No performance/merge/universal geometry claim.'}
(D/'attestation.json').write_text(json.dumps(a,indent=2,allow_nan=False)+'\n');pin(D/'attest.py');(D/'input-pins.json').write_text(json.dumps({'files':pins,'attestationSHA256':H(D/'attestation.json')},indent=2)+'\n')
for f,h in pins.items():assert H(f)==h,(f,'postflightdrift')
receipt={'status':'ACTUAL_COMPLETED_CAPTURE_GEOMETRY_ADJUDICATION_COMPLETE_SCOPED_EXACT_TRANSFERS','startedNs':start,'finishedNs':time.time_ns(),'attestationSHA256':H(D/'attestation.json'),'inputPinsSHA256':H(D/'input-pins.json'),'reporterPasses':4,'freshOracleRuns':0,'exactWholeRawAndConsumedInputTransfers':4,'sofficeStructuralPayloads':6,'allCompositeGatesTrue':True,'cleanupFinalError':None,'sourceRevision':HEAD,'noBrowserBuildHostObservationOrPerformanceClaim':True}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
