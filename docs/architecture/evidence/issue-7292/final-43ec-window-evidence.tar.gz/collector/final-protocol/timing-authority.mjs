/** Explicit fresh direct-user-authorized owned window; never substitutes for host admission. */
import {createHash} from 'node:crypto';
const HOLD='/home/louistrue/wt/.bench-hold';
const OWNER='c6115f2d-994d-4e97-8720-c5793076c258';
const COORDINATOR='c6115f2d-994d-4e97-8720-c5793076c258';
const HEADS={base:'b0b670f0cfd704ceb7c78a622f5730d0cd9510de',branch:'43ecf3aa3e240e1a7c41c5c799212b60df010ebd'};
const need=(v,m)=>{if(!v)throw Error(m);};
const sha=b=>createHash('sha256').update(b).digest('hex');
const hash=s=>typeof s==='string'&&/^[0-9a-f]{64}$/.test(s);
const utc=s=>{need(typeof s==='string'&&s.endsWith('Z')&&Number.isFinite(Date.parse(s)),'Explicit valid UTC required');return Date.parse(s);};
export function timingBindingFromArgs(argv=process.argv){
 const arg=n=>{const i=argv.indexOf(n);return i<0?undefined:argv[i+1];};
 return {path:arg('--timing-authority'),sha256:arg('--expected-timing-authority-sha256')};
}
export function verifyTimingAuthority(binding,readBytes,now=Date.now()){
 need(binding&&typeof binding.path==='string'&&binding.path.startsWith('/')&&hash(binding.sha256),'Actual timing authority path/hash required');
 const raw=readBytes(binding.path);need(sha(raw)===binding.sha256,'Timing authority changed');
 let revoked=false;try{readBytes(binding.path+'.revoked');revoked=true;}catch(e){if(e?.code!=='ENOENT')throw e;}
 need(!revoked,'Timing authority revoked');
 const d=JSON.parse(raw.toString());
 need(d.status==='DIRECT_USER_AUTHORIZED_7292_TIMING'&&d.approvingUserDelegateThreadId===COORDINATOR&&d.timingOwnerThreadId===OWNER,'Wrong timing authority/owner');
 need(Array.isArray(d.concurrentOwnerThreadIds)&&d.concurrentOwnerThreadIds.length===0&&d.noConcurrentOwnerConfirmed===true&&d.noHeavyPeersConfirmed===true,'Exclusive owner and drained peers required');
 const opens=utc(d.opensUTC),until=utc(d.untilUTC),confirmed=utc(d.noHeavyPeersConfirmedUTC);
 need(until>opens&&until-opens<=30*60*1000&&opens<=confirmed&&confirmed<=now&&opens<=now&&now<until,'Window absent/not open/expired or peer confirmation invalid');
 need(d.candidate===HEADS.branch&&d.base===HEADS.base,'Wrong exact source pair');
 need(hash(d.sharedHoldSHA256)&&sha(readBytes(HOLD))===d.sharedHoldSHA256,'Owned shared hold absent or changed');
 need(d.grantEvidence&&typeof d.grantEvidence.path==='string'&&d.grantEvidence.path.startsWith('/')&&hash(d.grantEvidence.sha256)&&sha(readBytes(d.grantEvidence.path))===d.grantEvidence.sha256,'Actual direct user grant evidence changed/missing');
 for(const side of ['base','branch']){
  const p=d.sides?.[side];need(p&&p.expectedHead===HEADS[side]&&typeof p.pinsPath==='string'&&p.pinsPath.startsWith('/')&&hash(p.pinsSHA256),'Actual side binding required');
  const bytes=readBytes(p.pinsPath);need(sha(bytes)===p.pinsSHA256&&JSON.parse(bytes.toString()).head===HEADS[side],'Approved side pins changed');
 }
 return {mode:'EXPLICIT_DIRECT_USER_AUTHORIZED_OWNED_WINDOW',owner:OWNER,authorityPath:binding.path,authoritySHA256:binding.sha256,sharedHoldSHA256:d.sharedHoldSHA256,opensUTC:d.opensUTC,untilUTC:d.untilUTC,sides:d.sides,resourceConditionsWaived:false};
}
