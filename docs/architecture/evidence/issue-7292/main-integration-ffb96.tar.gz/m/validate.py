from pathlib import Path
import hashlib,json,os,re,subprocess,time,traceback

R=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69')
O=Path(__file__).resolve().parent/'validation'
O.mkdir(exist_ok=False)
T=Path('/tmp/7292-main2d-primary-native-target-v1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse','HEAD').decode().strip()=='1761202310643fb6fb967e8afb91f20f6c622bfb'
assert git('rev-parse','MERGE_HEAD').decode().strip()=='ffb96cc3932e44c1d89e56270144c6693f6c1c49'
assert not git('diff','--name-only','--diff-filter=U')
owner=json.loads((T/'.ifclite-owned-repo.json').read_text())
assert owner['repoAbsoluteIdentity']==str(R)
assert owner['role']=='PRIMARY_MAIN2D_NATIVE_VALIDATION_ONLY_NEVER_CANDIDATE_OR_BASELINE'
owner_hash=sha(T/'.ifclite-owned-repo.json')
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:
        if proc.joinpath('comm').read_text().strip() not in ['cargo','rustc','rustdoc','wasm-pack']:continue
        env=proc.joinpath('environ').read_bytes().split(b'\0')
        assert ('CARGO_TARGET_DIR='+str(T)).encode() not in env,'Owned target is already active'
    except (FileNotFoundError,ProcessLookupError):pass
assert not Path('/home/louistrue/wt/.bench-hold').exists(),'Respect active benchmark hold'
paths=[p.decode() for p in git('ls-files','-z').split(b'\0') if p]
paths=[p for p in paths if (p.startswith(('rust/','apps/server/')) and (p.endswith('.rs') or p.endswith('/Cargo.toml') or p.endswith('/Cargo.lock'))) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo/config.toml','packages/wasm/pkg/ifc-lite.d.ts']]
source={p:sha(R/p) for p in sorted(paths)}
(O/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
tree=git('write-tree').decode().strip()
record={'status':'RUNNING_MERGE_VALIDATION','parentHead':git('rev-parse','HEAD').decode().strip(),'mergeHead':git('rev-parse','MERGE_HEAD').decode().strip(),'mergedIndexTree':tree,'sourceBeforeSHA256':sha(O/'source-before.json'),'target':str(T),'targetOwnerSHA256':owner_hash,'jobs':1,'rayonThreads':1,'nice':19,'commands':[]}
def save():(O/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
def stable():
    assert git('write-tree').decode().strip()==tree,'Staged merge changed'
    assert sha(T/'.ifclite-owned-repo.json')==owner_hash
    assert all((R/p).is_file() and sha(R/p)==h for p,h in source.items()),'Frozen source changed'
env=os.environ.copy()
env.update(PATH='/home/louistrue/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='1',IFC_LITE_REQUIRE_FIXTURES='1')
for key in ['IFC_LITE_REPIN_GOLDEN','IFC_GOLDEN_UPDATE','INSTA_UPDATE']:env.pop(key,None)
common=['cargo','test','--locked','-p','ifc-lite-processing','--features','triangulation-alt','--test']
queue=[('module-ratchet',8,common+['module_size_ratchet','--','--nocapture','--test-threads=1']),
       ('reporter',7,common+['issue_7292_sloped_coplanar_difference','--','--nocapture','--test-threads=1']),
       ('local-frame',1,common+['issue_5739_local_frame_voided_wall','--','--nocapture','--test-threads=1']),
       ('clippy',None,['cargo','clippy','--workspace','--all-targets','--','-D','warnings'])]
save()
try:
    for name,minimum,args in queue:
        stable()
        assert not Path('/home/louistrue/wt/.bench-hold').exists(),'New benchmark hold blocks next heavy command'
        log=O/(name+'.log')
        cmd=['nice','-n','19',*args]
        with log.open('w') as output:
            child=subprocess.Popen(cmd,cwd=R,env=env,stdout=output,stderr=subprocess.STDOUT)
            entry={'name':name,'command':args,'ownedPID':child.pid,'startedNs':time.time_ns(),'log':str(log),'minimumPassed':minimum}
            record['commands'].append(entry);save();print('START',name,'pid',child.pid,'jobs1',flush=True)
            code=child.wait()
        entry.update(exit=code,ownedChildReaped=True,finishedNs=time.time_ns(),logSHA256=sha(log))
        counts=[{'passed':int(a),'failed':int(b)} for a,b in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed;',log.read_text(),re.M)]
        entry['testCounts']=counts;save();stable()
        print('DONE',name,'exit',code,'passed',sum(c['passed'] for c in counts),flush=True)
        assert code==0,name+' failed; inspect preserved log'
        if minimum is not None:assert sum(c['passed'] for c in counts)>=minimum and all(c['failed']==0 for c in counts),name+' did not execute expected tests'
    stable()
    (O/'source-after.json').write_text(json.dumps({p:sha(R/p) for p in source},indent=2)+'\n')
    assert (O/'source-before.json').read_bytes()==(O/'source-after.json').read_bytes()
    record['sourceAfterSHA256']=sha(O/'source-after.json')
    record['status']='PASS_16_TARGETED_TESTS_AND_EXACT_WORKSPACE_CLIPPY_ON_MERGED_SOURCE'
    save()
except BaseException as error:
    record.update(status='STOPPED_NO_WAIVER',error=repr(error),traceback=traceback.format_exc());save();raise
