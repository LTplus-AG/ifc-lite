from pathlib import Path
import argparse,os,json,hashlib,subprocess,time,traceback,re
A=argparse.ArgumentParser();A.add_argument('--released',action='store_true');A.add_argument('--expected-head',required=True);A.add_argument('--expected-classify-sha256',required=True);a=A.parse_args();assert a.released,'Explicit root resource/source release required'
O=Path(__file__).resolve().parent;R=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-cac82c69');T=Path('/tmp/7292-main2d-primary-native-target-v1');P=Path('/tmp/7292-main2d-primary-native-validation-v1');V=O/'run';V.mkdir(exist_ok=False)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
prep=json.loads((O/'preparation.json').read_text());assert H(Path(__file__))==prep['driverSHA256']
for p,h in prep['priorEvidenceSHA256'].items():assert H(Path(p))==h,'Prior evidence changed'
owner=json.loads((T/'.ifclite-owned-repo.json').read_text());assert owner['repoAbsoluteIdentity']==str(R) and owner['role']=='PRIMARY_MAIN2D_NATIVE_VALIDATION_ONLY_NEVER_CANDIDATE_OR_BASELINE';ownerHash=H(T/'.ifclite-owned-repo.json');assert ownerHash==prep['targetOwnerSHA256']
head=git('rev-parse','HEAD').decode().strip();assert head==a.expected_head
for ancestor in ['2491d6eb4b10a91561d66567a77ca168dbfbd637','53308dbdf04c897866b540395114dffc7451bcb9']:subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',ancestor,head],check=True)
classify=R/'rust/geometry/src/kernel/arrangement/classify.rs';assert H(classify)==a.expected_classify_sha256
paths=set((R/'rust').rglob('*.rs'))|set((R/'rust').rglob('Cargo.toml'))|set((R/'apps/server').rglob('*.rs'))|{R/n for n in ['Cargo.toml','Cargo.lock','rust/python/Cargo.lock','rust-toolchain.toml','.cargo/config.toml','docs/guide/geometry.md','apps/server/Cargo.toml']}
source={str(p.relative_to(R)):H(p) for p in sorted(paths) if p.is_file()};(V/'source-before.json').write_text(json.dumps(source,indent=2)+'\n');(V/'source-before.patch').write_bytes(git('diff','HEAD','--binary'));(V/'committed-changes-from-prior.txt').write_bytes(git('diff','--name-status','2491d6eb4b10a91561d66567a77ca168dbfbd637',head));(V/'head-lineage.txt').write_bytes(git('log','--oneline','--first-parent','2491d6eb4b10a91561d66567a77ca168dbfbd637..'+head))
prior=json.loads((P/'source-before.json').read_text());changes={p:{'before':prior.get(p),'after':source.get(p)} for p in sorted(set(prior)|set(source)) if prior.get(p)!=source.get(p)}
bridge={'earlierEvidenceScopeHead':'2491d6eb4b10a91561d66567a77ca168dbfbd637','resumedHead':head,'knownHistory':'Zone budget fix committed25be5af626; main540a1f1a1a merged in53308dbdf0; finalroot-approvedf64cachechange follows. Actual file-level hash differences and first-parent lineage retained.','zoneSourceBytesMatchEarlierFinal':source['rust/geometry/src/zone_split.rs']==prior['rust/geometry/src/zone_split.rs'],'zoneTestBytesMatchEarlierFinal':source['rust/geometry/src/zone_split_tests.rs']==prior['rust/geometry/src/zone_split_tests.rs'],'priorNegativeAnd20ZonePassNotClaimedAsNewRevisionRuns':True,'changesFromPriorSource':changes}
assert bridge['zoneSourceBytesMatchEarlierFinal'] and bridge['zoneTestBytesMatchEarlierFinal'],'Zone changed: root must review scope before reusing prior zone proof'
(V/'scope-bridge.json').write_text(json.dumps(bridge,indent=2)+'\n')
r={'status':'RUNNING_APPROVED_REMAINING_QUEUE','repo':str(R),'head':head,'classifySHA256':H(classify),'target':str(T),'targetOwnerSHA256':ownerHash,'sourceBeforeSHA256':H(V/'source-before.json'),'scopeBridgeSHA256':H(V/'scope-bridge.json'),'priorEvidenceSHA256':prep['priorEvidenceSHA256'],'priorDriverParserErrorPreserved':True,'numericTestCountParser':'^test result: ok. (digits) passed; (digits) failed; using numeric values, no substring rejection','commands':[]}
def save():(V/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
def stable():
 assert git('rev-parse','HEAD').decode().strip()==head
 assert H(T/'.ifclite-owned-repo.json')==ownerHash
 assert all((R/p).is_file() and H(R/p)==h for p,h in source.items()),'Frozen source changed'
 for p,h in prep['priorEvidenceSHA256'].items():assert H(Path(p))==h,'Prior evidence changed'
env=os.environ.copy();env.update(PATH='/home/louistrue/.cargo/bin:/usr/local/bin:/usr/bin:/bin',CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='1',IFC_LITE_REQUIRE_FIXTURES='1')
common=['cargo','test','--locked','-p','ifc-lite-geometry','--features','triangulation-alt,test-support']
queue=[('mesh-bridge',18,common+['--lib','kernel::mesh_bridge::tests::','--','--nocapture','--test-threads=1']),('exact-boundary-budget',1,common+['--lib','kernel::arrangement::classify::surface::tests::issue_7292_exact_boundary_work_reports_budget_and_returns_no_partial_faces','--','--exact','--nocapture','--test-threads=1']),('issue-7677',1,common+['--test','issue_7677_kernel_reachable_panics','--','--nocapture','--test-threads=1']),('reporter-processing',7,['cargo','test','--locked','-p','ifc-lite-processing','--features','triangulation-alt','--test','issue_7292_sloped_coplanar_difference','--','--nocapture','--test-threads=1']),('issue-1007',2,common+['--test','issue_1007_opening_sliver','--','--nocapture','--test-threads=1']),('issue-5739',1,['cargo','test','--locked','-p','ifc-lite-processing','--features','triangulation-alt','--test','issue_5739_local_frame_voided_wall','--','--nocapture','--test-threads=1']),('module-size-ratchet',1,['cargo','test','--locked','-p','ifc-lite-processing','--features','triangulation-alt','--test','module_size_ratchet','--','--nocapture','--test-threads=1']),('clippy',None,['cargo','clippy','--workspace','--all-targets','--','-D','warnings'])]
save()
try:
 for name,minimum,args in queue:
  stable();log=V/(name+'.log');print('START '+name,flush=True);start=time.time_ns()
  with log.open('w') as f:code=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
  counts=[{'passed':int(x),'failed':int(y)} for x,y in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed;',log.read_text(),re.M)]
  r['commands'].append({'name':name,'argv':args,'cwd':str(R),'target':str(T),'jobs':2,'incremental':0,'rayonThreads':1,'exit':code,'testCounts':counts,'minimumPassed':minimum,'log':str(log),'logSHA256':H(log),'startedNs':start,'finishedNs':time.time_ns()});save();print('DONE '+name+' '+str(code),flush=True);stable()
  assert code==0,name+' failed: stop for diagnosis'
  if minimum is not None:assert sum(x['passed'] for x in counts)>=minimum and all(x['failed']==0 for x in counts),name+' did not execute the required positive test count'
 stable();(V/'source-after.json').write_text(json.dumps({p:H(R/p) for p in source},indent=2)+'\n');assert (V/'source-before.json').read_bytes()==(V/'source-after.json').read_bytes();r['sourceAfterSHA256']=H(V/'source-after.json');r['sourceUnchanged']=True;r['status']='ALL_APPROVED_REMAINING_TARGETS_MODULE_RATCHET_AND_CLIPPY_PASS';save()
except BaseException as e:
 r['status']='STOPPED_NO_ACCEPTANCE_WAIVER';r['error']=repr(e);r['traceback']=traceback.format_exc();save();print(r['traceback'],flush=True);raise
