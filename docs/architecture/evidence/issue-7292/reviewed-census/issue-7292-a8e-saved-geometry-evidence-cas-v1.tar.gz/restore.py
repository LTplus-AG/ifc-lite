"""Restore immutable evidence bytes from a locally extracted CAS archive."""
from pathlib import Path
import argparse,hashlib,json
D=Path(__file__).resolve().parent
a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);args=a.parse_args()
m=json.loads((D/'object-map.json').read_bytes())
assert not args.out.exists();args.out.mkdir(parents=True)
seen=set()
for r in m['logicalFiles']:
 p=Path(r['path']);assert not p.is_absolute()and '..'not in p.parts and str(p)not in seen
 seen.add(str(p));assert p.suffix.lower()not in {'.ifc','.ifczip','.ifcxml'}
 obj=Path(r['object']);assert obj==Path('objects')/r['sha256'] and len(r['sha256'])==64
 raw=(D/obj).read_bytes();assert len(raw)==r['bytes']and hashlib.sha256(raw).hexdigest()==r['sha256']
 out=args.out/p;out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb')as f:f.write(raw)
print('RESTORED_AND_HASH_VERIFIED',len(seen),'logical files')
