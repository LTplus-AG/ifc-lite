from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
ROOT=Path('/tmp/ifc-7635-admission-trace-818b');OUT=Path(__file__).resolve().parent
TARGET=ROOT/'rust/geometry/tests/triangulation_invariance.rs'
FIXTURE=ROOT/'tests/models/georeferencer/MiniBIM-3.1-DO_01_VORM.ifc'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args],text=True)
def snapshot():
 names=subprocess.check_output(['git','-C',str(ROOT),'ls-files','-z','--cached','--others','--exclude-standard','--','rust','Cargo.lock','Cargo.toml']).decode().split('\0');return {'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain','--','rust','Cargo.lock','Cargo.toml'),'sourceSHA256':{n:sha(ROOT/n)for n in sorted(set(names))if n and (ROOT/n).is_file()}}
assert FIXTURE.is_file();assert sha(FIXTURE)=='7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b';original=TARGET.read_bytes();(OUT/'triangulation_invariance.rs.original').write_bytes(original);before=snapshot();(OUT/'source-before.json').write_text(json.dumps(before,indent=2));assert not(OUT/'canonical-mini-row.tsv').exists()
test=r'''

// Temporary evidence-only #7635 actual canonical row export. No golden edit.
#[cfg(feature = "triangulation-alt")]
#[test]
fn diagnostic_7635_closed_admission_canonical_mini_row() {
    let _serial = CENSUS_SWEEP_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let _reset = AltTriangulatorReset;
    let rel = "georeferencer/MiniBIM-3.1-DO_01_VORM.ifc";
    let path = crate_dir().join("../..").join("tests/models").join(rel);
    if !oracle_fixture_present(&path) {
        eprintln!("Skipping temporary #7635 row export: run pnpm fixtures");
        return;
    }
    let content = std::fs::read_to_string(&path).expect("read actual MiniBIM fixture");
    let voids = void_index(&content);
    let frame = ModelFrame::new(&content);
    let lines = line_index(&content);
    let id = 135923;
    set_alt(false);
    let base = process(&frame, id, &voids).expect("actual MiniBIM host meshes");
    set_alt(true);
    let alt = process(&frame, id, &voids);
    set_alt(false);
    let stats = edge_stats(&base);
    let pre = if stats.open == 0 {
        PreVoid::NotTaken
    } else {
        match process_no_voids(&frame, id).map(|m| open_boundary_edges(&m)) {
            Some(v) => PreVoid::Open(v),
            None => PreVoid::Failed,
        }
    };
    let row = row_from_mesh(rel, id, representation_type(&content, &lines, id),
        &base, &stats, alt.as_ref().map(open_boundary_edges), pre);
    let rendered = census_golden::render(&[row]);
    println!("ACTUAL_CANONICAL_MINI_ROW\n{rendered}");
    let output = std::env::var_os("IFC_7635_CANONICAL_ROW_OUTPUT")
        .expect("explicit temporary row output path");
    std::fs::write(output, rendered).expect("write evidence-only TSV, not a golden");
}
'''
(OUT/'temporary-test.rs').write_text(test);command=['cargo','test','--locked','-p','ifc-lite-geometry','--features','triangulation-alt','--test','triangulation_invariance','diagnostic_7635_closed_admission_canonical_mini_row','--','--exact','--nocapture'];env=os.environ|{'PATH':'/home/louistrue/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','IFC_LITE_REQUIRE_FIXTURES':'1','CARGO_TARGET_DIR':str(ROOT/'target'),'IFC_7635_CANONICAL_ROW_OUTPUT':str(OUT/'canonical-mini-row.tsv')};env.pop('IFCLITE_CENSUS_BLESS',None);env.pop('IFC_7635_ADMISSION_TRACE',None)
started=time.time();proc=None;result={'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'cwd':str(ROOT),'fixtureSHA256':sha(FIXTURE),'fixtureBytes':FIXTURE.stat().st_size,'temporaryTestSHA256':sha(OUT/'temporary-test.rs'),'originalIntegrationTestSHA256':sha(TARGET),'scriptSHA256':sha(Path(__file__)),'expectedOutputPath':str(OUT/'canonical-mini-row.tsv'),'noBless':True,'noGoldenEdit':True,'sourceHeadIsHistorical77aWithFrozenV2NumericalWorkingChanges':True}
try:
 TARGET.write_bytes(original+test.encode());(OUT/'source-with-temp-test.json').write_text(json.dumps(snapshot(),indent=2))
 with (OUT/'run.log').open('w')as log:
  proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:result['exitCode']=proc.wait(timeout=900)
  except BaseException:
   if proc.poll() is None:
    os.killpg(proc.pid,signal.SIGTERM)
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   raise
 result['outputExists']=(OUT/'canonical-mini-row.tsv').is_file();assert result['exitCode']==0 and result['outputExists'];result['outputSHA256']=sha(OUT/'canonical-mini-row.tsv');result['outputText']=(OUT/'canonical-mini-row.tsv').read_text()
except BaseException as e:result['error']=repr(e);raise
finally:
 TARGET.write_bytes(original);after=snapshot();(OUT/'source-after.json').write_text(json.dumps(after,indent=2));result['sourceRestoredByteExact']=before==after;result['seconds']=time.time()-started;result['fixtureUnchanged']=sha(FIXTURE)==result['fixtureSHA256'];(OUT/'result.json').write_text(json.dumps(result,indent=2));assert before==after,'source restoration must match whole original source fence';assert result['fixtureUnchanged']
print(json.dumps(result,indent=2))
