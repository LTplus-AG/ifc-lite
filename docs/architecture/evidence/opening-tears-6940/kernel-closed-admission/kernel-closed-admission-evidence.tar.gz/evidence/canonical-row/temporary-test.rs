

// Temporary evidence-only #7635 actual canonical row export. No golden edit.
#[cfg(feature = "triangulation-alt")]
#[test]
fn diagnostic_7635_closed_admission_canonical_mini_row() {
    let _serial = CENSUS_SWEEP_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let _reset = AltTriangulatorReset;
    let rel = "georeferencer/MiniBIM-3.1-DO_01_VORM.ifc";
    let path = crate_dir().join("../..").join("tests/models").join(rel);
    if !oracle_fixture_present(&path) {
        eprintln!("Skipping temporary #7635 row export: run pnpm fixtures");
        return;
    }
    let content = std::fs::read_to_string(&path).expect("read actual MiniBIM fixture");
    let voids = void_index(&content);
    let frame = ModelFrame::new(&content);
    let lines = line_index(&content);
    let id = 135923;
    set_alt(false);
    let base = process(&frame, id, &voids).expect("actual MiniBIM host meshes");
    set_alt(true);
    let alt = process(&frame, id, &voids);
    set_alt(false);
    let stats = edge_stats(&base);
    let pre = if stats.open == 0 {
        PreVoid::NotTaken
    } else {
        match process_no_voids(&frame, id).map(|m| open_boundary_edges(&m)) {
            Some(v) => PreVoid::Open(v),
            None => PreVoid::Failed,
        }
    };
    let row = row_from_mesh(rel, id, representation_type(&content, &lines, id),
        &base, &stats, alt.as_ref().map(open_boundary_edges), pre);
    let rendered = census_golden::render(&[row]);
    println!("ACTUAL_CANONICAL_MINI_ROW\n{rendered}");
    let output = std::env::var_os("IFC_7635_CANONICAL_ROW_OUTPUT")
        .expect("explicit temporary row output path");
    std::fs::write(output, rendered).expect("write evidence-only TSV, not a golden");
}
