//! Evidence-only bounded replay of the actual corpus ModelFrame and router APIs.
#[path = "diag7633rvt_rtc.rs"]
mod census_rtc;
use ifc_lite_core::{EntityDecoder, EntityScanner};
use ifc_lite_geometry::{propagate_voids_to_parts, set_alt_triangulator};
use rustc_hash::FxHashMap;
use serde_json::json;
fn trace_stage(host: u32, alternate: bool, context: &str, event: &str) {
    if let Some(path)=std::env::var_os("IFC_DIAG_7631_RVT_TRACE") {
        use std::io::Write as _;
        let mut file=std::fs::OpenOptions::new().create(true).append(true).open(path).expect("stage trace file");
        writeln!(file,"{}",json!({"event":event,"host":host,"alternate":alternate,"context":context})).expect("write stage trace");
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut args=std::env::args().skip(1);
    let fixture=args.next().ok_or("fixture")?;
    let output=args.next().ok_or("new output")?;
    let hosts:Vec<u32>=args.map(|s|s.parse::<u32>()).collect::<Result<_,_>>()?;
    assert!(!hosts.is_empty());
    let content=std::fs::read_to_string(&fixture)?;
    let mut voids:FxHashMap<u32,Vec<u32>>=FxHashMap::default();
    let mut scanner=EntityScanner::new(&content);
    let mut decoder=EntityDecoder::new(&content);
    while let Some((id,name,start,end))=scanner.next_entity() {
        if name=="IFCRELVOIDSELEMENT" {
            if let Ok(entity)=decoder.decode_at_with_id(id,start,end) {
                if let (Some(host),Some(opening))=(entity.get_ref(4),entity.get_ref(5)) {voids.entry(host).or_default().push(opening);}
            }
        }
    }
    let _=propagate_voids_to_parts(&mut voids,&content,&mut decoder);
    let frame=census_rtc::ModelFrame::new(&content);
    let offset=frame.diagnostic_offset();
    let offset_bits=[offset.0,offset.1,offset.2].map(|v|format!("{:016x}",v.to_bits()));
    let mut rows=Vec::new();
    for host in hosts {
        assert!(voids.get(&host).is_some_and(|v|!v.is_empty()));
        for alternate in [false,true] {
            set_alt_triangulator(alternate);
            for context in ["source","all"] {
                let mut decoder=frame.decoder();
                let entity=decoder.decode_by_id(host)?;
                let router=frame.router(&mut decoder);
                eprintln!("[rvt-stage] host={host} alternate={alternate} context={context} BEGIN");
                trace_stage(host,alternate,context,"begin");
                let mesh=if context=="source" {router.process_element(&entity,&mut decoder)?} else {router.process_element_with_voids(&entity,&mut decoder,&voids)?};
                trace_stage(host,alternate,context,"end");
                let volume=ifc_lite_geometry::kernel::mesh_volume::mesh_volume(&mesh);
                rows.push(json!({"host":host,"alternate":alternate,"context":context,"allOpenings":voids[&host],"positionsBits":mesh.positions.iter().map(|v|v.to_bits()).collect::<Vec<_>>(),"normalsBits":mesh.normals.iter().map(|v|v.to_bits()).collect::<Vec<_>>(),"indices":mesh.indices,"originBits":mesh.origin.map(|v|format!("{:016x}",v.to_bits())),"rtcApplied":mesh.rtc_applied,"localBoundsBits":mesh.local_bounds.map(|a|a.map(f32::to_bits)),"localToWorldBits":mesh.local_to_world.map(|a|a.map(|v|format!("{:016x}",v.to_bits()))),"kernelGridDivergenceVolumeBits":format!("{:016x}",volume.to_bits()),"hostOpeningDiagnostics":format!("{:?}",router.take_host_opening_diagnostics()),"rectFastStats":format!("{:?}",router.take_rect_fast_stats()),"csgFailures":format!("{:?}",router.take_csg_failures())}));
                eprintln!("[rvt-stage] host={host} alternate={alternate} context={context} END triangles={}",mesh.indices.len()/3);
            }
        }
    }
    set_alt_triangulator(false);
    let file=std::fs::OpenOptions::new().write(true).create_new(true).open(output)?;
    serde_json::to_writer_pretty(file,&json!({"purpose":"Actual ordinary-census primary/alternate source/cut router payloads; volumes require independent closure classification","fixture":fixture,"modelFrameRtcOffsetBits":offset_bits,"rows":rows}))?;
    Ok(())
}
