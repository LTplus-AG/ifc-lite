# Closed-operand finite-incidence candidate (#7635)

**Local candidate, not a landing or expected-data approval.** Base is kernel head `77a594c2987087cb34fe89cbb2092f9743bff360`. Copy only the six files under `candidate/`; `unit/final-restored-source.json` records their exact SHA256 values. No temporary hooks remain in those files. Source branches, runtime artifacts, fixtures and expectations were not changed.

The additional finite-wall refusal requires both complete original triangle streams to have finite, noncollapsed faces and exactly one opposite pair of edge uses. It reuses the existing adjacency maps and preserves their lazy host construction. Uncertified operands retain the established coincidence rule. This is a necessary closed-edge prerequisite, not a proof of embedding, vertex manifoldness, or valid solids. Ordinary Boolean/union welding retains its existing specialization.

## Executed evidence

- `unit/plane-weld-tests.log`: **23 passed**: 22 permanent local/call-path tests plus one temporary exact-hex replay of an earlier 700/12-triangle closed pair. The replay leaves every cutter occurrence unchanged and produces 724 closed, noncollapsed triangles with `changed=false`, `conforming=true`. Its source and original bits are included; the hook was removed afterward.
- Public admission tests distinguish the actual established-only specialization from the new rule. They cover open operands, same-direction edges, 2+2 duplicate uses, distinct collinear vertices, repeated vertices, NaN/Infinity, finite predicate overflow, signed-zero equality, and valid local edges alongside unrelated invalid faces.
- `intermediate/`: actual ordinary-census `ModelFrame`, primary and alternate triangulators, MiniBIM #135923 source/all13. Source remains 440 triangles/28 strict unmatched edges. The candidate all13 output is **1348 triangles, zero strict unmatched edges, zero collapsed triangles**, in both the 1/65536 and 1mm readings.
- `trace/`: same diagnostic executable runs candidate and actual established-only specializations. Original operand coordinates are hex f64 bit strings; the trace is mutex-protected. Independent rational incidence classification shows early torn operands never admit a new refusal. The first new refusal occurs later on a closed 700-triangle host (9 refusals), then closed 762 (9) and 924 (4). The established arm instead tears the next host (744 triangles/25 unmatched edges) and ends at 1084 triangles/27 **coarse unbalanced** edges (28 coarse strict edges, 30 fine strict edges). Do not conflate these measures.
- Instrumented candidate rows equal the uninstrumented rows in every field. The newly captured 700/12 stream is **not bit-identical** to the historical unit replay; both are separately certified and retained.
- `combined/`: the same corrected kernel plus exact final cap production/tests passes all **four existing tests**: the two eight-slab tests, the ninth slab all-frame/source-hygiene/shape test, and the 18-context wall test #5739. Fixtures were required.
- `combined-mini/`: all four primary/alternate source/all rows equal the prior final payload **in every field**, with 452 source and 892 final triangles. This comparison is limited to that actual ModelFrame context; it is not the canonical FFI/browser payload.

## Limits and open qualification

The intermediate 1348 output is intentionally **not yet approved for an expected-row migration**. Its area/volume and one-component Euler accounting are diagnostics, not a complete authored finite-surface/holes/material proof. Physical qualification, full ordinary corpus, fresh canonical native/WASM/browser parity, strict final-source Clippy and performance remain separate work. No claim transfers from the combined 892 output merely because IDs match.

`superseded-v1/` preserves the first 21-test candidate, which passed but was rejected in review because an unrelated invalid face erased all local cutter arrises. V2 preserves valid local queries and performs the host certificate after the local finite query. No failed test or expectation was rewritten to manufacture acceptance.

## Reproduction

Fetch catalogued MiniBIM `tests/models/georeferencer/MiniBIM-3.1-DO_01_VORM.ifc` with `pnpm fixtures`; exact fixture SHA and RTC data are in the run receipts. No IFC is bundled. Use the pinned repository Rust toolchain, jobs2, incremental off, dev/test debug0 and `IFC_LITE_REQUIRE_FIXTURES=1`.

Apply the six candidate files to exact77a. Run `cargo test -p ifc-lite-geometry --lib plane_weld -- --nocapture` for the **22 permanent** tests. The 23-test historical run additionally used `unit/captured-positive.rs`, included temporarily from the finite test module. Run commands, toolchain versions, source maps, adapter/RTC helper, binary hash, execution logs and finally-restoration checks accompany each actual payload. Evidence runners retain their original absolute paths and must be relocated explicitly; they are diagnostic adapters, not installed production tools.

For the combined check, use the same candidate kernel over the final cap assembly recorded in `combined/source-assembly.json`, then run the three processing test targets listed in `combined/producer-and-5739.log` (four tests total). `verify.py <unpacked-packet-directory>` verifies packet hashes and recomputes raw topology/admission claims without compiling Rust; it does not recreate an execution or independently approve physical shape.
