"""Evidence-only actual Mini135923 closed-intermediate shape analysis.
No production edits, acceptance thresholds, snapping in physical comparisons, or golden changes.
Run phases serially after shared-heavy-token admission. Topology is explicitly grid-domain.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
import argparse,hashlib,json,math,struct,time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
PATHS={
 'intermediate':Path('/tmp/ifc-7635-admission-trace-818b/work/7635/closed-admission-mini-v1/mini-payload.json'),
 'finalCap':ROOT/'final-cap-needle-only-proof-v1/mini-needle-alternate-v1/payload.json',
}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def f64(x):return struct.unpack('>d',bytes.fromhex(x))[0]
def f32(x):return struct.unpack('<f',struct.pack('<I',x))[0]
def decode(doc,context,alt):
 r=next(r for r in doc['rows'] if r['host']==135923 and r['context']==context and r['alternate']==alt)
 o=tuple(F(f64(x)) for x in r['originBits']);p=[tuple(F(f32(r['positionsBits'][i+j]))+o[j] for j in range(3)) for i in range(0,len(r['positionsBits']),3)]
 return r,[tuple(p[j] for j in r['indices'][i:i+3]) for i in range(0,len(r['indices']),3)]
def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross3(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def area(poly):return abs(sum(cross(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly))))/2 if len(poly)>2 else F(0)
def intersect(poly,tri):
 for i in range(3):
  if not poly:return []
  a,b=tri[i],tri[(i+1)%3];e=sub(b,a);out=[];ds=[cross(e,sub(p,a)) for p in poly]
  for j,p in enumerate(poly):
   q=poly[(j+1)%len(poly)];d,f=ds[j],ds[(j+1)%len(poly)]
   if d>=0:out.append(p)
   if (d>=0)!=(f>=0):
    h=d/(d-f);out.append(tuple(p[k]+h*(q[k]-p[k]) for k in range(2)))
  poly=out
 return poly

def topology(ts):
 def grid(x):
  y=x*65536
  return (y.numerator*2+y.denominator)//(2*y.denominator) if y>=0 else -grid(-x)
 faces=[tuple(tuple(grid(v) for v in p) for p in t) for t in ts];edges=defaultdict(list);links=defaultdict(list);collapsed=[]
 for ti,t in enumerate(faces):
  if not any(cross3(sub(t[1],t[0]),sub(t[2],t[0]))):collapsed.append(ti)
  for j in range(3):
   a,b=t[j],t[(j+1)%3];edges[min(a,b),max(a,b)].append((ti,1 if a<b else -1));links[a].append((t[(j+1)%3],t[(j+2)%3]))
 bad=[(e,u) for e,u in edges.items() if len(u)!=2 or sum(s for _,s in u)!=0]
 neighbors=[set() for _ in faces]
 for uses in edges.values():
  for a,_ in uses:
   neighbors[a].update(b for b,_ in uses if b!=a)
 unseen=set(range(len(faces)));components=[]
 while unseen:
  stack=[unseen.pop()];count=0
  while stack:
   a=stack.pop();count+=1;fresh=neighbors[a]&unseen;unseen-=fresh;stack.extend(fresh)
  components.append(count)
 badlinks=[]
 for v,pairs in links.items():
  adj=defaultdict(list)
  for a,b in pairs:adj[a].append(b);adj[b].append(a)
  seen=set();stack=[next(iter(adj))]
  while stack:
   a=stack.pop()
   if a in seen:continue
   seen.add(a);stack.extend(adj[a])
  if len(seen)!=len(adj) or any(len(q)!=2 for q in adj.values()):badlinks.append(v)
 chi=len(links)-len(edges)+len(faces)
 return {'vertices':len(links),'edges':len(edges),'faces':len(faces),'eulerCharacteristic':chi,'edgeConnectedComponentFaces':sorted(components),'strictOnePlusOneBadEdges':len(bad),'collapsedTriangles':collapsed,'nonCircularVertexLinks':len(badlinks),'genusIfSingleClosedOrientableManifold':(2-chi)//2 if not bad and not collapsed and not badlinks and len(components)==1 else None}

def groups(ts):
 g=defaultdict(Counter);counts=Counter()
 for ti,t in enumerate(ts):
  n=cross3(sub(t[1],t[0]),sub(t[2],t[0]));axis=max(range(3),key=lambda j:abs(n[j]));assert n[axis],(ti,t)
  key=(axis,1 if n[axis]>0 else -1);axes=[j for j in range(3) if j!=axis];p=[tuple(v[j] for j in axes) for v in t]
  if cross(sub(p[1],p[0]),sub(p[2],p[0]))<0:p.reverse()
  p=min(tuple(p[i:]+p[:i]) for i in range(3));g[key][p]+=1;counts[key]+=1
 assert sum(counts.values())==len(ts)
 return g

def l2(old,new):
 d=old.copy();d.subtract(new);items=[(p,c) for p,c in d.items() if c];boxes=[(min(x for x,y in p),min(y for x,y in p),max(x for x,y in p),max(y for x,y in p)) for p,c in items];value=F(0);pairs=0
 for i,(p,c) in enumerate(items):
  value+=c*c*area(p)
  for j in range(i):
   a,b=boxes[i],boxes[j]
   if a[0]>=b[2] or b[0]>=a[2] or a[1]>=b[3] or b[1]>=a[3]:continue
   q,e=items[j];value+=2*c*e*area(intersect(list(p),q));pairs+=1
 assert value>=0
 return {'oldInstances':sum(old.values()),'newInstances':sum(new.values()),'uncancelledProjectedTriangles':len(items),'intersectedPairs':pairs,'exactSquaredMultiplicityDifferenceIntegral':str(value),'integralFloat':float(value),'projectedMultiplicityIdenticalAlmostEverywhere':value==0,'mismatchAreaUpperBound':float(value)}

def controls():
 a=((F(0),F(0)),(F(2),F(0)),(F(0),F(2)));b=((F(0),F(0)),(F(2),F(0)),(F(1),F(1)));c=((F(0),F(0)),(F(1),F(1)),(F(0),F(2)))
 assert l2(Counter({a:1}),Counter({b:1,c:1}))['integralFloat']==0
 assert l2(Counter({a:1}),Counter({a:2}))['integralFloat']==2
 assert area(intersect(list(a),tuple((x+3,y) for x,y in a)))==0

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['topology','projections'],required=True);args=ap.parse_args();start=time.time();docs={k:json.loads(p.read_text()) for k,p in PATHS.items()};controls()
 assert docs['intermediate']['modelFrameRtcOffsetBits']==docs['finalCap']['modelFrameRtcOffsetBits']
 rows=[]
 for alt in [False,True]:
  decoded={k:decode(d,'all',alt) for k,d in docs.items()};assert decoded['intermediate'][0]['originBits']==decoded['finalCap'][0]['originBits'];assert decoded['intermediate'][0]['allOpenings']==decoded['finalCap'][0]['allOpenings']
  if args.phase=='topology':
   rows.append({'alternate':alt,'outputs':{k:topology(t) for k,(r,t) in decoded.items()}})
  else:
   ts={k:t for k,(r,t) in decoded.items()};ts['authoredSource452']=decode(docs['finalCap'],'source',alt)[1];gs={k:groups(t) for k,t in ts.items()}
   for a,b in [('finalCap','intermediate'),('authoredSource452','intermediate'),('authoredSource452','finalCap')]:
    for key in sorted(set(gs[a])|set(gs[b])):
     row={'alternate':alt,'comparison':a+'→'+b,'dominantAxis':key[0],'normalSign':key[1],**l2(gs[a].get(key,Counter()),gs[b].get(key,Counter()))};rows.append(row);print({k:v for k,v in row.items() if k!='exactSquaredMultiplicityDifferenceIntegral'},flush=True)
  result={'phase':args.phase,'scriptSHA256':digest(Path(__file__)),'inputSHA256':{k:digest(p) for k,p in PATHS.items()},'sameActualModelFrameRtc':True,'seconds':time.time()-start,'rows':rows,'limits':'Topology uses incoming-coordinate exact kernel grid, not physical surface equivalence. Projections use EXACT actual f32+f64origin Fractions, preserve orientation/multiplicity and dominant-axis attribution. L2 integral upper-bounds any mismatch projected area; six axis/sign totals do NOT certify depth pairing, finite 3D shape, material bijection, or authored-hole identity. No tolerance/acceptance threshold.'};(HERE/(args.phase+'.json')).write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
