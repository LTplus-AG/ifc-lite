"""Exact simple cap-ring domain checks, no tolerance; complements edge cancellation.
For positive planar triangles, their directed boundary chain determines their sheet
multiplicity by winding (zero outside the bounded triangulated support).
"""
from pathlib import Path
from fractions import Fraction as F
import json,hashlib,time
HERE=Path(__file__).resolve().parent

def orient(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
def on(a,b,p):return orient(a,b,p)==0 and all(min(a[k],b[k])<=p[k]<=max(a[k],b[k]) for k in range(2))
def contact(a,b,c,d):
 o=[orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)]
 return (o[0]*o[1]<0 and o[2]*o[3]<0) or on(a,b,c) or on(a,b,d) or on(c,d,a) or on(c,d,b)
def inside(p,ring):
 hit=False
 for i,a in enumerate(ring):
  b=ring[(i+1)%len(ring)];assert not on(a,b,p)
  if (a[1]>p[1])!=(b[1]>p[1]):
   x=a[0]+(p[1]-a[1])*(b[0]-a[0])/(b[1]-a[1])
   if x>p[0]:hit=not hit
 return hit

def main():
 start=time.time();path=HERE/'cap-rings.json';doc=json.loads(path.read_text());rows=[]
 # Independent segment contact and containment controls.
 assert contact((0,0),(1,1),(0,1),(1,0));assert not contact((0,0),(1,0),(0,1),(1,1));assert contact((0,0),(1,0),(1,0),(2,0))
 for row in doc['rows']:
  rings=[[tuple(F(v) for v in p[:2]) for p in r['exactVertices']] for r in row['rings']];pairs=0
  for ri,r in enumerate(rings):
   assert len(r)>=3 and len(set(r))==len(r)
   for i,a in enumerate(r):
    b=r[(i+1)%len(r)];c=r[(i+2)%len(r)]
    if orient(a,b,c)==0:assert sum((b[k]-a[k])*(c[k]-b[k]) for k in range(2))>0,'adjacent boundary backtracks'
    for j in range(i+1,len(r)):
     if j==i+1 or (i==0 and j==len(r)-1):continue
     assert not contact(a,b,r[j],r[(j+1)%len(r)]),(ri,i,j);pairs+=1
   for sj in range(ri):
    s=rings[sj]
    for i,a in enumerate(r):
     for j,c in enumerate(s):assert not contact(a,r[(i+1)%len(r)],c,s[(j+1)%len(s)]),(ri,sj,i,j);pairs+=1
  outer=[i for i,r in enumerate(row['rings']) if not r['isHole']];assert len(outer)==1;oi=outer[0]
  for i,r in enumerate(rings):
   if i==oi:continue
   assert inside(r[0],rings[oi])
   for j,s in enumerate(rings):
    if j not in [i,oi]:assert not inside(r[0],s)
  rows.append({k:row[k] for k in ['source','context','alternate','normalSign','ringCount','holeCount']}|{'exactNonAdjacentSegmentPairsChecked':pairs,'simpleDisjointNonNestedBoundaryDomain':True,'positiveTriangleBoundaryWindingImpliesMultiplicityOneInsideOuterExceptFourteenHoles':True})
 result={'scope':'Exact rational source/raw stored-coordinate cap domain. Per prior cap-rings receipt all directed cap edges cancel except these cycles. Every planar cap triangle has correct nonzero orientation. Exact nonintersection/nonnesting and outer/hole winding imply the cap projected sheet multiplicity is one inside the simple outer ring excluding the14holes, zero elsewhere; no hidden duplicate cap sheets. Domains differ by measured boundary-coordinate changes; no exact cross-arm equality asserted.','scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'capRingsSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.time()-start,'rows':rows};(HERE/'cap-domain-validation.json').write_text(json.dumps(result,indent=2));print(len(rows),'domains valid',result['seconds'])
if __name__=='__main__':main()
