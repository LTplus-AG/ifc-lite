"""Exact stored-coordinate horizontal-cap boundary rings; evidence-only, no tolerance.
Refuse non-cycle boundary graphs, unmatched cap orientations, or negative/duplicate uses.
"""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
import json,hashlib,time
HERE=Path(__file__).resolve().parent
ns={'__file__':str(HERE/'analyze.py')};exec((HERE/'analyze.py').read_text().split('def main():')[0],ns)

def rings(ts,sign):
 edges=Counter();count=0;zlevels=set()
 for t in ts:
  n=ns['cross3'](ns['sub'](t[1],t[0]),ns['sub'](t[2],t[0]))
  if n[0] or n[1] or n[2]*sign<=0:continue
  count+=1;zlevels.add(t[0][2])
  for i in range(3):edges[t[i],t[(i+1)%3]]+=1
 assert len(zlevels)==1,zlevels
 boundary=Counter()
 for (a,b),uses in edges.items():
  d=uses-edges[b,a]
  if d>0:boundary[a,b]=d
 assert all(v==1 for v in boundary.values()),boundary
 adj=defaultdict(list);incoming=Counter()
 for a,b in boundary:adj[a].append(b);incoming[b]+=1
 assert all(len(bs)==1 for bs in adj.values()) and set(adj)==set(incoming) and all(v==1 for v in incoming.values())
 unseen=set(adj);result=[]
 while unseen:
  start=min(unseen);p=start;loop=[]
  while p in unseen:unseen.remove(p);loop.append(p);p=adj[p][0]
  assert p==start
  twice=sum(loop[i][0]*loop[(i+1)%len(loop)][1]-loop[i][1]*loop[(i+1)%len(loop)][0] for i in range(len(loop)));assert twice
  result.append({'vertices':[[float(v) for v in p] for p in loop],'exactVertices':[[str(v) for v in p] for p in loop],'signedXYArea':float(twice/2),'exactSignedXYArea':str(twice/2),'isHole':twice*sign<0,'bounds':[[float(min(p[k] for p in loop)),float(max(p[k] for p in loop))] for k in range(3)]})
 result.sort(key=lambda r:(r['isHole'],r['bounds']))
 return {'horizontalCapTriangles':count,'z':float(next(iter(zlevels))),'boundaryEdges':len(boundary),'ringCount':len(result),'holeCount':sum(r['isHole'] for r in result),'rings':result}

def main():
 start=time.time();docs={k:json.loads(p.read_text()) for k,p in ns['PATHS'].items()};rows=[]
 for alt in [False,True]:
  for source,context in [('finalCap','source'),('finalCap','all'),('intermediate','all')]:
   _,ts=ns['decode'](docs[source],context,alt)
   for sign in [-1,1]:
    rows.append({'source':source,'context':context,'alternate':alt,'normalSign':sign,**rings(ts,sign)})
 result={'scope':'Exact raw stored f32+f64origin directed cap-edge cancellation, no grid/snap/tolerance. All cap-boundary uses must form disjoint simple graph cycles. Horizontal-cap ring count and coordinates are evidence, not full finite-surface correspondence or nonintersection proof.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputSHA256':{k:ns['digest'](p) for k,p in ns['PATHS'].items()},'rows':rows};(HERE/'cap-rings.json').write_text(json.dumps(result,indent=2));print([{k:v for k,v in r.items() if k!='rings'} for r in rows])
if __name__=='__main__':main()
