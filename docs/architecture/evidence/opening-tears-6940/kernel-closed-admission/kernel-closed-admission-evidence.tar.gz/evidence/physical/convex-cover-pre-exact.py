"""Exact convex partition + diagnostic finite-triangle bounds, evidence only.
Every source polygon is partitioned into covered intersections and explicit leftovers.
No cell representative-point membership, GEOS noding, or vertex-to-union bound.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,time,hashlib,argparse
import numpy as np
HERE=Path(__file__).resolve().parent
ns={'__file__':str(HERE/'analyze.py')};exec((HERE/'analyze.py').read_text().split('def main():')[0],ns)
base={'__file__':str(HERE.parent/'analyze-rvt13797-full-triangle-support-v2.py')};exec((HERE.parent/'analyze-rvt13797-full-triangle-support-v2.py').read_text().split('started=time.time();')[0],base)
def clip(poly,a,e,positive):
 ds=[ns['cross'](e,ns['sub'](p,a)) for p in poly];out=[]
 for j,p in enumerate(poly):
  q=poly[(j+1)%len(poly)];d,f=ds[j],ds[(j+1)%len(poly)];inside=d>=0 if positive else d<=0;nextinside=f>=0 if positive else f<=0
  if inside:out.append(p)
  if inside!=nextinside:
   h=d/(d-f);out.append(tuple(p[k]+h*(q[k]-p[k]) for k in range(2)))
 return out

def subtract(poly,tri):
 rem=poly;outside=[]
 for i,a in enumerate(tri):
  if not rem:break
  e=ns['sub'](tri[(i+1)%3],a);out=clip(rem,a,e,False);rem=clip(rem,a,e,True)
  if ns['area'](out)>0:outside.append(out)
 return rem,outside

def partition(source,targets):
 remaining=[source];covered=[]
 for j,t in enumerate(targets):
  fresh=[];lo=[min(p[k] for p in t) for k in range(2)];hi=[max(p[k] for p in t) for k in range(2)]
  for poly in remaining:
   if any(max(p[k] for p in poly)<=lo[k] or min(p[k] for p in poly)>=hi[k] for k in range(2)):fresh.append(poly);continue
   inside,outside=subtract(poly,t)
   if ns['area'](inside)>0:covered.append((inside,j));fresh.extend(outside)
   else:fresh.append(poly)
  remaining=fresh
  assert len(remaining)+len(covered)<=20000,'exact partition budget exceeded; no acceptance'
 total=sum(ns['area'](p) for p,j in covered)+sum(ns['area'](p) for p in remaining);assert total==ns['area'](source),(total,ns['area'](source))
 return covered,remaining

def finite_bound(points,targets):
 d=base['distances'](np.array(points,dtype=float),targets).max(0);j=int(d.argmin());return float(d[j]),j

def refine_leftover(poly,projected,lift,targets):
 # This partition is exact and only selects work. It is NOT a new acceptance
 # threshold: all resulting whole-cell bounds are recorded, including excesses.
 axes=sorted(range(2),key=lambda k:max(p[k] for p in poly)-min(p[k] for p in poly),reverse=True);pieces=[poly]
 for axis in axes:
  levels=sorted(set(p[axis] for t in projected for p in t if min(q[axis] for q in poly)<p[axis]<max(q[axis] for q in poly)))
  for level in levels:
   a=(level,F(0)) if axis==0 else (F(0),level);e=(F(0),F(1)) if axis==0 else (F(1),F(0));fresh=[]
   for piece in pieces:
    lo=min(p[axis] for p in piece);hi=max(p[axis] for p in piece)
    if lo<level<hi:
     for sign in [True,False]:
      child=clip(piece,a,e,sign)
      if ns['area'](child)>0:fresh.append(child)
    else:fresh.append(piece)
   pieces=fresh;assert len(pieces)<=20000,'leftover refinement budget exceeded'
  if axis==axes[0]:
   quick=[finite_bound([lift(p) for p in piece],targets)[0] for piece in pieces]
   if max(quick,default=0)<=1/65536:break
 assert sum(ns['area'](p) for p in pieces)==ns['area'](poly)
 records=[]
 for piece in pieces:
  value,j=finite_bound([lift(p) for p in piece],targets);records.append({'exactProjectedVertices':[[str(v) for v in p] for p in piece],'projectedArea':float(ns['area'](piece)),'finiteTarget':j,'wholeCellDistanceUpperBound':value})
 return records

def cap_run():
 start=time.time();docs={k:json.loads(p.read_text()) for k,p in ns['PATHS'].items()};allts={'source452':ns['decode'](docs['finalCap'],'source',False)[1],'intermediate':ns['decode'](docs['intermediate'],'all',False)[1]};rows=[]
 for source,target in [('source452','intermediate'),('intermediate','source452')]:
  for sign in [-1,1]:
   def choose(ts):return [t for t in ts if all(p[2]==t[0][2] for p in t) and ns['cross'](ns['sub'](t[1][:2],t[0][:2]),ns['sub'](t[2][:2],t[0][:2]))*sign>0]
   st,tt=choose(allts[source]),choose(allts[target]);assert st and tt;targets=np.array(tt,dtype=float);projected=[]
   for t in tt:
    p=[v[:2] for v in t]
    if ns['cross'](ns['sub'](p[1],p[0]),ns['sub'](p[2],p[0]))<0:p.reverse()
    projected.append(p)
   records=[]
   for i,t in enumerate(st):
    p=[v[:2] for v in t]
    if ns['cross'](ns['sub'](p[1],p[0]),ns['sub'](p[2],p[0]))<0:p.reverse()
    covered,leftover=partition(p,projected);lift=lambda q:(q[0],q[1],t[0][2]);cs=[]
    for cell,j in covered:
     # Affine vertical correspondence is inside this ONE finite target triangle.
     value=abs(float(t[0][2]-tt[j][0][2]));cs.append({'target':j,'exactProjectedArea':str(ns['area'](cell)),'wholeCellDistanceUpperBound':value})
    ls=[]
    for poly in leftover:ls.extend(refine_leftover(poly,projected,lift,targets))
    rec={'sourceTriangle':i,'coveredCells':cs,'explicitLeftoverCells':ls,'exactSourceProjectedArea':str(ns['area'](p)),'exactLeftoverProjectedArea':str(sum(ns['area'](v) for v in leftover)),'maximumWholeFaceDistanceUpperBound':max([v['wholeCellDistanceUpperBound'] for v in cs+ls],default=0)};records.append(rec)
    if len(records)%20==0:print(source,target,sign,len(records),len(st),flush=True)
   row={'source':source,'target':target,'normalSign':sign,'sourceTriangles':len(st),'targetTriangles':len(tt),'maximumWholeFaceDistanceUpperBound':max(r['maximumWholeFaceDistanceUpperBound'] for r in records),'leftoverProjectedArea':sum(float(F(r['exactLeftoverProjectedArea'])) for r in records),'records':records};rows.append(row)
   result={'scope':'EXACT Fraction convex source-minus-target partition. Every source triangle projected area accounted exactly, covered intersections each use ONE positive target finite triangle with vertical affine correspondence. All remaining polygons retained and EXACTLY subdivided along target vertex coordinate levels; each cell uses ONE fixed finite convex target with diagnostic Float64 distance bound. Both directions and both cap normal signs. Computational 1/grid selection only short-circuits further refinement; no acceptance threshold. No sheet-multiplicity inference; separate exact L2 receipts retain that.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputSHA256':{k:ns['digest'](p) for k,p in ns['PATHS'].items()},'rows':rows};(HERE/'cap-convex-cover.json').write_text(json.dumps(result,indent=2,allow_nan=False))
if __name__=='__main__':cap_run()
