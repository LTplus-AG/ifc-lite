"""Exact rational squared distances; upward-rounded display roots.
Floating selection may propose a target, never computes the certified bound.
"""
from fractions import Fraction as F
import math

def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def segment(p,a,b):
 e=sub(b,a);q=sub(p,a);den=dot(e,e);assert den>0
 s=max(F(0),min(F(1),dot(q,e)/den));r=sub(q,tuple(s*x for x in e));return dot(r,r)
def triangle(p,t):
 a,b,c=t;e=sub(b,a);f=sub(c,a);q=sub(p,a);n=cross(e,f);den=dot(n,n);assert den>0
 u=dot(cross(q,f),n)/den;v=dot(cross(e,q),n)/den
 values=[segment(p,a,b),segment(p,b,c),segment(p,c,a)]
 if u>=0 and v>=0 and u+v<=1:values.append(dot(q,n)**2/den)
 return min(values)
def upper_root(s):
 assert s>=0
 r=math.sqrt(float(s))
 while F(r)**2<s:r=math.nextafter(r,math.inf)
 return r
# Invariant controls independent of selection heuristics.
a=(F(0),F(0),F(0));b=(F(1),F(0),F(0));c=(F(0),F(1),F(0))
assert triangle((F(1,4),F(1,4),F(2)),(a,b,c))==4
assert triangle((F(2),F(2),F(0)),(a,b,c))==F(9,2)
assert segment((F(2),F(0),F(0)),a,b)==1
assert F(upper_root(F(2)))**2>=2
