"""Prepared diagnostic full finite-face bound using previously reviewed v2 construction.
Run only under the coordinated CPU-heavy slot. No chosen acceptance tolerance.
"""
from pathlib import Path
import argparse,json,hashlib,time,collections
HERE=Path(__file__).resolve().parent
ns={'__file__':str(HERE/'analyze.py')}
exec((HERE/'analyze.py').read_text().split('def main():')[0],ns)
base={'__file__':str(HERE.parent/'analyze-rvt13797-full-triangle-support-v2.py')}
exec((HERE.parent/'analyze-rvt13797-full-triangle-support-v2.py').read_text().split('started=time.time();')[0],base)
np=base['np'];face_bound=base['face_bound'];key=base['key']

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pair',choices=['final','source'],required=True);ap.add_argument('--sidefaces-only',action='store_true');args=ap.parse_args()
 start=time.time();docs={k:json.loads(p.read_text()) for k,p in ns['PATHS'].items()};assert docs['intermediate']['modelFrameRtcOffsetBits']==docs['finalCap']['modelFrameRtcOffsetBits']
 # Both alternate outputs have an identical complete oriented triangle multiset,
 # otherwise execute each separately instead of transferring the primary result.
 allts={}
 relevant=[('intermediate','all'),('finalCap','all' if args.pair=='final' else 'source')]
 for k,context in relevant:
   d=docs[k]
   a=ns['decode'](d,context,False);b=ns['decode'](d,context,True)
   assert a[0]['originBits']==b[0]['originBits']
   def fkey(t):return min(t[i:]+t[:i] for i in range(3))
   assert collections.Counter(map(fkey,a[1]))==collections.Counter(map(fkey,b[1])),(k,context)
   allts[k,context]=np.array(a[1],dtype=float)
 ts={'intermediate':allts['intermediate','all'],'reference':allts['finalCap','all' if args.pair=='final' else 'source']};rows=[]
 for source,target in [('reference','intermediate'),('intermediate','reference')]:
  remaining=collections.Counter(map(key,ts[target]));changed=[];common=0;omittedcaps=0
  for i,t in enumerate(ts[source]):
   if args.sidefaces_only and np.all(t[:,2]==t[0,2]):omittedcaps+=1;continue
   k=key(t)
   if remaining[k]:remaining[k]-=1;common+=1
   else:changed.append((i,t))
  targets=ts[target];normals=np.cross(targets[:,1]-targets[:,0],targets[:,2]-targets[:,0]);assert np.all((normals*normals).sum(1)>0)
  records=[]
  for i,t in changed:
   records.append(face_bound(i,t,targets,normals))
   if len(records)%25==0:print(source,target,len(records),len(changed),flush=True)
   if len(records)%25==0 or len(records)==len(changed):
    row={'direction':source+'→'+target,'exactCommonOrientedTriangleInstances':common,'changedTriangleInstances':len(changed),'completedTriangles':len(records),'omittedHorizontalCaps':omittedcaps,'fullTriangleMaximumDistanceUpperBound':max(r['maximumBound'] for r in records),'sameHemisphereMaximumDistanceUpperBound':max(r['maximumSameHemisphereBound'] for r in records),'wholeFaceConservativeFallbacks':sum(r['fallbackWholeFace'] for r in records),'records':records}
    result={'scope':'Diagnostic floating GEOS/Float64 complete-cell finite-triangle bound, previously reviewed v2 construction, explicit leftovers and whole-face conservative fallback. One convex finite target per cell; no vertex-to-union shortcut. Same hemisphere is not material identity. Both triangulators exact full oriented triangle multisets verified equal. Source and target origins/ModelFrame exact; no RTC subtraction needed in common actual frame. No acceptance threshold or 3D identity/multiplicity claim.','pair':args.pair,'sidefacesOnly':args.sidefaces_only,'complete':len(rows)==1 and len(records)==len(changed),'seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'baseConstructionScriptSHA256':hashlib.sha256((HERE.parent/'analyze-rvt13797-full-triangle-support-v2.py').read_bytes()).hexdigest(),'inputSHA256':{k:ns['digest'](p) for k,p in ns['PATHS'].items()},'rows':rows+[row]};(HERE/('full-support-'+args.pair+('-sidefaces' if args.sidefaces_only else '')+'.json')).write_text(json.dumps(result,indent=2,allow_nan=False))
  rows.append(row)
if __name__=='__main__':main()
