"""Prepared finite-polyline correspondence for every authored slab hole.
Every source subsegment is bounded against ONE finite convex target segment.
No endpoint-to-union shortcut, nearest-centroid acceptance, or chosen tolerance.
"""
from pathlib import Path
from fractions import Fraction as F
import argparse,json,hashlib,math,time
import numpy as np
HERE=Path(__file__).resolve().parent

def dist(points,segments):
 a=segments[:,0];e=segments[:,1]-a;den=(e*e).sum(1);assert (den>0).all();out=[]
 for p in points:
  u=np.clip(((p-a)*e).sum(1)/den,0,1);out.append(np.linalg.norm(p-(a+u[:,None]*e),axis=1))
 return np.array(out)
def one_way(a,b):
 target=np.stack([b,np.roll(b,-1,axis=0)],axis=1);maximum=0.;records=[]
 for i,p in enumerate(a):
  q=a[(i+1)%len(a)];e=q-p;den=e@e;assert den>0
  # Projection parameters only partition work. Any finite partition is sound:
  # distance to one fixed target segment is convex along each source segment.
  parameters=sorted(set([0.,1.]+[float(v) for v in np.clip(((b-p)*e).sum(1)/den,0,1)]));local=[]
  for u,v in zip(parameters,parameters[1:]):
   if u==v:continue
   ends=np.array([p+u*e,p+v*e]);bounds=dist(ends,target).max(0);j=int(bounds.argmin());value=float(bounds[j]);maximum=max(maximum,value);local.append({'parameters':[u,v],'targetEdge':j,'bound':value})
  records.append({'sourceEdge':i,'pieces':local})
 return {'wholePolylineDistanceUpperBound':maximum,'edges':records}
def bbox_match(a,b):
 aa=np.array(a['vertices'])[:,:2];bb=np.array(b['vertices'])[:,:2]
 return float(np.linalg.norm(aa.min(0)-bb.min(0))+np.linalg.norm(aa.max(0)-bb.max(0)))
def main():
 start=time.time();p=HERE/'cap-rings.json';doc=json.loads(p.read_text());rows=[]
 for sign in [-1,1]:
  source=next(r for r in doc['rows'] if r['source']=='finalCap' and r['context']=='source' and not r['alternate'] and r['normalSign']==sign)
  for arm in ['intermediate','finalCap']:
   target=next(r for r in doc['rows'] if r['source']==arm and r['context']=='all' and not r['alternate'] and r['normalSign']==sign)
   assert source['ringCount']==target['ringCount']==15 and source['holeCount']==target['holeCount']==14
   chosen=[];records=[]
   for si,s in enumerate(source['rings']):
    candidates=sorted((bbox_match(s,t),ti) for ti,t in enumerate(target['rings']) if s['isHole']==t['isHole']);_,ti=candidates[0];chosen.append(ti);t=target['rings'][ti];a=np.array(s['vertices'])[:,:2];b=np.array(t['vertices'])[:,:2]
    forward=one_way(a,b);reverse=one_way(b,a);records.append({'authoredSourceRing':si,'outputRing':ti,'isHole':s['isHole'],'boundsRanking':candidates,'sourceToOutput':forward,'outputToSource':reverse,'bound':max(forward['wholePolylineDistanceUpperBound'],reverse['wholePolylineDistanceUpperBound'])})
   assert len(set(chosen))==15,'nearest-bounds proposal was not bijective; refuse interpretation'
   rows.append({'arm':arm,'normalSign':sign,'proposalBijective':True,'maximumBoundaryCurveDistanceUpperBound':max(r['bound'] for r in records),'rings':records})
 out={'scope':'All 15 rings including 14 authored holes, unique bbox-ranked proposal then full bidirectional finite-polyline distance bound. Rank is only correspondence proposal, not acceptance. Each actual source edge split by target endpoint projection parameters; each subsegment uses ONE fixed convex target segment, and max endpoint distances bounds entire subsegment by convexity. Floating arithmetic diagnostic, not exact spatial equivalence or guaranteed nearest Hausdorff distance. No acceptance threshold. Horizontal source/cut Z separation handled separately in finite-face analysis.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows};(HERE/'ring-correspondence.json').write_text(json.dumps(out,indent=2,allow_nan=False));print([{k:v for k,v in r.items() if k!='rings'} for r in rows])
if __name__=='__main__':main()
