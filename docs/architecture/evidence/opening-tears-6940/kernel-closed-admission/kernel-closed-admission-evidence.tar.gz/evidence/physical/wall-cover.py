"""Reverse complete finite coverage of every authored source452 wall rectangle.
Exact convex partitions and explicit leftovers; no chosen acceptance threshold.
"""
from pathlib import Path
from fractions import Fraction as F
import json,time,hashlib,math
import numpy as np
HERE=Path(__file__).resolve().parent
cc={'__file__':str(HERE/'convex-cover.py')};exec((HERE/'convex-cover.py').read_text().split('def cap_run():')[0],cc)
wp={'__file__':str(HERE/'wall-patches.py')};exec((HERE/'wall-patches.py').read_text().split('\ndef main():\n')[0],wp)
ns=cc['ns']
def lift_triangle(p,t2,t3):
 e=ns['sub'](t2[1],t2[0]);f=ns['sub'](t2[2],t2[0]);q=ns['sub'](p,t2[0]);den=ns['cross'](e,f);assert den>0
 u=ns['cross'](q,f)/den;v=ns['cross'](e,q)/den
 return tuple(t3[0][k]+u*(t3[1][k]-t3[0][k])+v*(t3[2][k]-t3[0][k]) for k in range(3))
def main():
 start=time.time();docs={k:json.loads(p.read_text()) for k,p in ns['PATHS'].items()};rings=json.loads((HERE/'cap-rings.json').read_text());source=next(r for r in rings['rows'] if r['source']=='finalCap' and r['context']=='source' and not r['alternate'] and r['normalSign']==1);bottom=next(r for r in rings['rows'] if r['source']=='finalCap' and r['context']=='source' and not r['alternate'] and r['normalSign']==-1);zlo=F(bottom['z']);zhi=F(source['z']);patches=[]
 for ri,r in enumerate(source['rings']):
  xy=wp['collinear_reduce']([tuple(F(v) for v in p[:2]) for p in r['exactVertices']])
  for ei,a in enumerate(xy):
   b=xy[(ei+1)%len(xy)];e=ns['sub'](b,a);patches.append({'ring':ri,'edge':ei,'a':a,'e':e,'lengthSquared':sum(v*v for v in e)})
 assignments=json.loads((HERE/'wall-patches.json').read_text());rows=[]
 for arm in ['intermediate','finalCap']:
  ar=next(r for r in assignments['rows'] if r['arm']==arm);_,ts=ns['decode'](docs[arm],'all',False);records=[]
  for j,p in enumerate(patches):
   indices=[v['triangle'] for v in ar['assignments'] if v['patch']==j];tt=[ts[i] for i in indices];assert tt
   projected=[]
   for t in tt:projected.append([(sum((v[k]-p['a'][k])*p['e'][k] for k in range(2))/p['lengthSquared'],v[2]) for v in t])
   assert all(ns['cross'](ns['sub'](t[1],t[0]),ns['sub'](t[2],t[0]))>0 for t in projected)
   rectangle=[(F(0),zlo),(F(1),zlo),(F(1),zhi),(F(0),zhi)];covered,leftover=cc['partition'](rectangle,projected);lift=lambda q:(p['a'][0]+q[0]*p['e'][0],p['a'][1]+q[0]*p['e'][1],q[1]);cs=[]
   for cell,k in covered:
    ds=[]
    for v in cell:
     a=lift(v);b=lift_triangle(v,projected[k],tt[k]);ds.append(cc['exact']['upper_root'](sum((a[i]-b[i])**2 for i in range(3))))
    cs.append({'targetTriangle':indices[k],'exactProjectedArea':str(ns['area'](cell)),'wholeCellDistanceUpperBound':max(ds)})
   ls=[]
   for poly in leftover:
    for rec in cc['refine_leftover'](poly,projected,lift,np.array(tt,dtype=float)):
     rec['targetTriangle']=indices[rec.pop('finiteTarget')];ls.append(rec)
   record={'patch':j,'ring':p['ring'],'edge':p['edge'],'targetTriangles':indices,'coveredCells':cs,'explicitLeftoverCells':ls,'exactAuthoredRectangleProjectedArea':str(zhi-zlo),'exactLeftoverProjectedArea':str(sum(ns['area'](v) for v in leftover)),'maximumWholeRectangleDistanceUpperBound':max([v['wholeCellDistanceUpperBound'] for v in cs+ls],default=0)};records.append(record)
  row={'arm':arm,'authoredRectangles':len(records),'maximumWholeRectangleDistanceUpperBound':max(r['maximumWholeRectangleDistanceUpperBound'] for r in records),'records':records};rows.append(row);print(arm,row['authoredRectangles'],row['maximumWholeRectangleDistanceUpperBound'],flush=True)
  result={'scope':'Every one of the source452 finite authored wall rectangles. Exact Fraction convex partition against the output triangles explicitly assigned to that wall; exact area conservation. Each covered piece has affine correspondence to ONE actual finite target triangle and convex norm max evaluated on every cell vertex. All uncovered pieces retained and exactly coordinate-partitioned, bounded against ONE finite convex target per cell. Per-wall assignment/multiplicity is separately documented; no aggregate cancellation or triangle-to-union endpoint shortcut. Exact rational squared covered affine distances and leftover point-to-finite-triangle distances, upward-rounded display roots. No acceptance threshold.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'wallAssignmentsSHA256':hashlib.sha256((HERE/'wall-patches.json').read_bytes()).hexdigest(),'convexPartitionScriptSHA256':hashlib.sha256((HERE/'convex-cover.py').read_bytes()).hexdigest(),'inputSHA256':{k:ns['digest'](p) for k,p in ns['PATHS'].items()},'rows':rows};(HERE/'wall-cover.json').write_text(json.dumps(result,indent=2,allow_nan=False))
if __name__=='__main__':main()
