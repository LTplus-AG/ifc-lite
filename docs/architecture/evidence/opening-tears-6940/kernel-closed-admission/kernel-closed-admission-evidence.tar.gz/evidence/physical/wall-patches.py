"""Prepared per-authored-wall projected multiplicity; no chosen tolerances.
Each output face assigned to the same-hemisphere authored finite convex wall rectangle
with the smallest whole-face conservative vertex distance bound. The assignment's
actual bounds and all per-wall multiplicity differences remain visible.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
import json,hashlib,time
import numpy as np
HERE=Path(__file__).resolve().parent
ns={'__file__':str(HERE/'analyze.py')};exec((HERE/'analyze.py').read_text().split('def main():')[0],ns)
exact={};exec((HERE/'exact-distance.py').read_text(),exact)
def collinear_reduce(loop):
 p=list(loop);changed=True
 while changed:
  changed=False
  for i in range(len(p)):
   a,b,c=p[(i-1)%len(p)],p[i],p[(i+1)%len(p)]
   if ns['cross'](ns['sub'](b,a),ns['sub'](c,b))==0 and sum((b[k]-a[k])*(c[k]-b[k]) for k in range(2))>0:
    del p[i];changed=True;break
 return p

def main():
 start=time.time();docs={k:json.loads(p.read_text()) for k,p in ns['PATHS'].items()};rings=json.loads((HERE/'cap-rings.json').read_text());source=next(r for r in rings['rows'] if r['source']=='finalCap' and r['context']=='source' and not r['alternate'] and r['normalSign']==1);bottom=next(r for r in rings['rows'] if r['source']=='finalCap' and r['context']=='source' and not r['alternate'] and r['normalSign']==-1);zlo=F(bottom['z']);zhi=F(source['z']);patches=[]
 for ri,r in enumerate(source['rings']):
  xy=collinear_reduce([tuple(F(v) for v in p[:2]) for p in r['exactVertices']])
  for ei,a in enumerate(xy):
   b=xy[(ei+1)%len(xy)];e=ns['sub'](b,a);n=(e[1],-e[0],F(0));patches.append({'ring':ri,'edge':ei,'isHole':r['isHole'],'a':a,'b':b,'e':e,'normal':n,'lengthSquared':sum(x*x for x in e)})
 aa=np.array([p['a'] for p in patches],dtype=float);ee=np.array([p['e'] for p in patches],dtype=float);nn=np.array([p['normal'] for p in patches],dtype=float);ll=(ee*ee).sum(1);rows=[]
 for arm in ['intermediate','finalCap','authoredSource452']:
  _,triangles=ns['decode'](docs['finalCap'] if arm=='authoredSource452' else docs[arm],'source' if arm=='authoredSource452' else 'all',False);groups=defaultdict(Counter);assignments=[];skipped=[]
  for ti,t in enumerate(triangles):
   if all(p[2]==t[0][2] for p in t):skipped.append(ti);continue
   n=ns['cross3'](ns['sub'](t[1],t[0]),ns['sub'](t[2],t[0]));tf=np.array(t,dtype=float);eligible=(nn*np.array(n,dtype=float)).sum(1)>0;ds=[]
   for p in tf:
    s=np.clip(((p[:2]-aa)*ee).sum(1)/ll,0,1);closest=np.column_stack([aa+s[:,None]*ee,np.full(len(aa),np.clip(p[2],float(zlo),float(zhi)))]);ds.append(np.linalg.norm(p-closest,axis=1))
   bounds=np.array(ds).max(0);bounds[~eligible]=np.inf;j=int(bounds.argmin());assert np.isfinite(bounds[j]);patch=patches[j];assert sum(n[k]*patch['normal'][k] for k in range(3))>0;projected=[]
   exact_squared=[]
   for v in t:
    parameter=max(F(0),min(F(1),sum((v[k]-patch['a'][k])*patch['e'][k] for k in range(2))/patch['lengthSquared']));closest=(patch['a'][0]+parameter*patch['e'][0],patch['a'][1]+parameter*patch['e'][1],max(zlo,min(zhi,v[2])));exact_squared.append(sum((v[k]-closest[k])**2 for k in range(3)))
   exact_bound=exact['upper_root'](max(exact_squared))
   for p in t:projected.append((sum((p[k]-patch['a'][k])*patch['e'][k] for k in range(2))/patch['lengthSquared'],p[2]))
   orientation=ns['cross'](ns['sub'](projected[1],projected[0]),ns['sub'](projected[2],projected[0]));assert orientation>0
   key=min(tuple(projected[i:]+projected[:i]) for i in range(3));groups[j][key]+=1;assignments.append({'triangle':ti,'patch':j,'wholeFaceDistanceToFiniteAuthoredWallUpperBound':exact_bound,'exactSquaredWholeFaceBound':str(max(exact_squared))})
  before_triangles=ns['decode'](docs['finalCap'],'source',False)[1]
  coordinate_error=F(2,65536)+F(2,8388608)*max(abs(v) for tri in triangles+before_triangles for point in tri for v in point)
  per=[];rectangle=[(F(0),zlo),(F(1),zlo),(F(1),zhi),(F(0),zhi)];old=Counter({tuple(rectangle[:3]):1,tuple([rectangle[0],rectangle[2],rectangle[3]]):1})
  for j,p in enumerate(patches):
   value=ns['l2'](old,groups[j]);delta_s=coordinate_error*sum(abs(v) for v in p['e'])/p['lengthSquared'];interior=[(delta_s,zlo+coordinate_error),(1-delta_s,zlo+coordinate_error),(1-delta_s,zhi-coordinate_error),(delta_s,zhi-coordinate_error)]
   assert delta_s<F(1,2) and coordinate_error<(zhi-zlo)/2
   def clipped(counter):
    out=Counter()
    for tri,c in counter.items():
     poly=ns['intersect'](list(interior),tri)
     for k in range(1,len(poly)-1):
      t=(poly[0],poly[k],poly[k+1])
      if ns['area'](t)>0:out[t]+=c
    return out
   interior_value=ns['l2'](clipped(old),clipped(groups[j]));per.append({'patch':j,'ring':p['ring'],'edge':p['edge'],'isHole':p['isHole'],'edgeLength':float(p['lengthSquared'])**.5,'existingCoordinateErrorBudget':str(coordinate_error),'derivedParameterBoundaryBand':str(delta_s),'interiorMultiplicityIdentical':interior_value['projectedMultiplicityIdenticalAlmostEverywhere'],'interiorExactSquaredMultiplicityDifferenceIntegral':interior_value['exactSquaredMultiplicityDifferenceIntegral'],**value})
  row={'arm':arm,'sideTriangles':len(assignments),'horizontalTriangles':len(skipped),'allTrianglesAccounted':len(assignments)+len(skipped)==len(triangles),'patchesWithNoAssignedTriangle':[j for j in range(len(patches)) if not groups[j]],'maximumWholeFaceDistanceToFiniteAuthoredWallUpperBound':max(a['wholeFaceDistanceToFiniteAuthoredWallUpperBound'] for a in assignments),'assignments':assignments,'perAuthoredWallProjectedMultiplicity':per};rows.append(row);print(arm,row['sideTriangles'],row['maximumWholeFaceDistanceToFiniteAuthoredWallUpperBound'],row['patchesWithNoAssignedTriangle'],flush=True)
 result={'scope':'Exact source452 horizontal cap ring edges, merging ONLY exact-collinear consecutive subdivisions, define each finite authored rectangular wall. Every nonhorizontal output face assigned by minimum finite-convex-wall bound with same-hemisphere normal, then exact projected oriented sheet-multiplicity L2 computed separately per authored wall. Assignment is a proposal, NOT material bijection proof; any large bound/missing patch remains explicit. Tangential projected area is parameter s times height, so multiply reported integral by wall edge length for physical projected area. No tolerance or acceptance threshold. Finite-wall target selection is floating only; the selected finite rectangle exact rational squared point distances and exact hemisphere predicate determine the whole-face bound, with upward-rounded display roots. Projection/intersection/count arithmetic exact Fraction. Primary only; alternate transfer requires separate exact full-surface equivalence proof.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputSHA256':{k:ns['digest'](p) for k,p in ns['PATHS'].items()},'authoredWallPatchCount':len(patches),'rows':rows};(HERE/'wall-patches.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
