"""Exact dyadic closed-edge-incidence diagnostic, not solid-validity proof."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import argparse,json,struct,hashlib,math

def classify(encoded):
 tris=[[[struct.unpack('>d',bytes.fromhex(v))[0] for v in p] for p in t] for t in encoded]
 invalid=sum(not math.isfinite(v) for t in tris for p in t for v in p)
 if invalid:return {'triangles':len(tris),'invalidCoordinates':invalid,'closedEdgeIncidence':False}
 edges=defaultdict(lambda:[0,0]);collapsed=[]
 for i,t in enumerate(tris):
  t=[tuple(F(v) for v in p) for p in t];a,b,c=t;ab=[b[k]-a[k] for k in range(3)];ac=[c[k]-a[k] for k in range(3)]
  cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
  if not any(cross):collapsed.append(i)
  for a,b in [(a,b),(b,c),(c,a)]:edges[tuple(sorted((a,b)))][int(a>b)]+=1
 bad=[{'edge':[[str(v) for v in p] for p in k],'counts':v}for k,v in edges.items() if v!=[1,1]]
 return {'triangles':len(tris),'invalidCoordinates':0,'exactCollinearTriangles':len(collapsed),'collapsedIndices':collapsed,'strictUnpairedOrRepeatedEdges':len(bad),'firstBadEdges':bad[:8],'closedEdgeIncidence':bool(tris) and not collapsed and not bad}

def main():
 p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');a=p.parse_args();src=Path(a.input);raw=src.read_bytes()
 if src.suffix=='.jsonl':
  events=[json.loads(line) for line in raw.splitlines()];events=[e for e in events if e.get('event')=='first-new-finite-refusal']
 else:events=[json.loads(raw)]
 rows=[{'call':e.get('call'),'host':classify(e['host']),'cutter':classify(e['cutter']),'filteredHostFaces':e.get('filteredHostFaces')} for e in events]
 out={'scope':'Original exact f64 values decoded from hexstrings. Fraction collinearity and exact1forward+1reverse incidence including duplicate/zero edges. No snapping/tolerances. Does not certify embedding, vertex manifoldness, winding consistency between components, or physical solid validity.','input':str(src.resolve()),'inputSHA256':hashlib.sha256(raw).hexdigest(),'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows}
 with Path(a.output).open('x') as f:json.dump(out,f,indent=2);f.write('\n')
 print(json.dumps([{'call':r['call'],'host':{k:v for k,v in r['host'].items() if k not in ['firstBadEdges','collapsedIndices']},'cutter':{k:v for k,v in r['cutter'].items() if k not in ['firstBadEdges','collapsedIndices']}}for r in rows],indent=2))
if __name__=='__main__':main()
