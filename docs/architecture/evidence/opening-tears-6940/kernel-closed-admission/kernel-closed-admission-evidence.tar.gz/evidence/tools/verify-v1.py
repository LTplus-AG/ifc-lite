"""Offline numerical recheck; no Rust execution or physical acceptance claim."""
from pathlib import Path
import sys,json,hashlib,importlib.util
root=Path(sys.argv[1]).resolve(); data=root/'evidence'
for name,row in json.loads((root/'manifest.json').read_text()).items():
 p=data/name; assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],name

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
stream=module('streams',data/'tools/classify-streams.py');mesh=module('meshes',data/'unit/classify-mesh.py')
for name in ['kernel-streams.jsonl','established-streams.jsonl']:
 events=[json.loads(s)for s in(data/'trace'/name).read_text().splitlines()];inputs={e['call']:e for e in events if e.get('event')=='original-operands'}
 for e in events:
  if e.get('event')=='weld-summary' and e['newFiniteRefusals']:
   for operand in ['host','cutter']:assert stream.classify(inputs[e['call']][operand])['closedEdgeIncidence']
inter=json.loads((data/'intermediate/mini-payload.json').read_text())
for r in inter['rows']:
 if r['context']=='all':
  for scale in [65536,1000]:
   m=mesh.metrics(r,scale);assert (m['triangles'],m['strictBadEdges'],m['collapsedTriangles'])==(1348,0,0)
trace=json.loads((data/'trace/candidate-mini-payload.json').read_text());assert trace['rows']==inter['rows']
combined=json.loads((data/'combined-mini/mini-payload.json').read_text());prior=json.loads((data/'prior-final/mini-payload.json').read_text());assert combined['rows']==prior['rows'];assert combined['modelFrameRtcOffsetBits']==prior['modelFrameRtcOffsetBits']
print('PASS packet hashes, original-operand admission, intermediate topology, trace equivalence and four-row combined equality. Physical migration remains separately qualified.')
