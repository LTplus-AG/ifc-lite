//! Temporary evidence only; observes the first NEW finite refusal in each weld.
use super::Tri;
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::io::Write;
static CALL: AtomicUsize = AtomicUsize::new(0);
static OUTPUT_LOCK: Mutex<()> = Mutex::new(());
pub(super) struct Capture {
    path: PathBuf,
    id: usize,
    host: Vec<Tri>,
    cutter: Vec<Tri>,
    old: usize,
    finite: usize,
}
fn bits(tris: &[Tri]) -> Vec<Vec<Vec<String>>> {
    tris.iter().map(|t| t.iter().map(|p| p.iter().map(|v| format!("{:016x}",v.to_bits())).collect()).collect()).collect()
}
impl Capture {
    pub(super) fn new(opening: bool, cutter: &[Tri], host: &[Tri]) -> Option<Self> {
        if !opening { return None; }
        let path = std::env::var_os("IFC_7635_ADMISSION_TRACE")?;
        let id = CALL.fetch_add(1, Ordering::Relaxed);
        assert!(id < 512, "diagnostic weld-call budget exceeded");
        let capture=Self { path: path.into(), id, host: host.to_vec(), cutter: cutter.to_vec(), old: 0, finite: 0 };
        capture.write(format!(r#"{{"event":"original-operands","call":{},"host":{:?},"cutter":{:?}}}"#, capture.id,bits(host),bits(cutter)));
        Some(capture)
    }
    fn write(&self, value: String) {
        let _lock=OUTPUT_LOCK.lock().expect("diagnostic output lock");
        let mut f=std::fs::OpenOptions::new().create(true).append(true).open(&self.path).expect("diagnostic output");
        writeln!(f,"{value}").expect("diagnostic write");
    }
    pub(super) fn observe(&mut self, old: bool, finite: bool, v: &[f64;3], w: &[f64;3], target: usize, on: &[usize], face_count: usize) {
        self.old += usize::from(old);
        if finite {
            self.finite += 1;
            if self.finite == 1 {
                self.write(format!(r#"{{"event":"first-new-finite-refusal","call":{},"host":{:?},"cutter":{:?},"vBits":{:?},"wBits":{:?},"targetFilteredFace":{},"exactOnFilteredFaces":{:?},"filteredHostFaces":{},"originalHostTriangles":{},"originalCutterTriangles":{}}}"#,
                    self.id, bits(&self.host), bits(&self.cutter),
                    v.map(|x|format!("{:016x}",x.to_bits())), w.map(|x|format!("{:016x}",x.to_bits())),
                    target, on, face_count, self.host.len(), self.cutter.len()));
            }
        }
    }
}
impl Drop for Capture {
    fn drop(&mut self) {
        self.write(format!(r#"{{"event":"weld-summary","call":{},"hostTriangles":{},"cutterTriangles":{},"oldRefusals":{},"newFiniteRefusals":{}}}"#,
            self.id, self.host.len(), self.cutter.len(), self.old, self.finite));
    }
}
