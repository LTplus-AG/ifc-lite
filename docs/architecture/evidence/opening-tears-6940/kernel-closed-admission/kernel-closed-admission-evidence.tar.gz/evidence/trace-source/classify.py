from pathlib import Path
import importlib.util,json,hashlib
helper=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/kernel-closed-admission-preparation-v1/classify-streams.py')
spec=importlib.util.spec_from_file_location('streams',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path(__file__).resolve().parent/'run'; allrows={}
for arm,name in [('candidate','kernel-streams.jsonl'),('established','established-streams.jsonl')]:
 events=[json.loads(s) for s in (out/name).read_text().splitlines()]; inputs={e['call']:e for e in events if e.get('event')=='original-operands'};summaries=[e for e in events if e.get('event')=='weld-summary'];rows=[]
 for e in summaries:
  orig=inputs[e['call']];h=m.classify(orig['host']);c=m.classify(orig['cutter']);rows.append(e|{'hostClosed':h['closedEdgeIncidence'],'hostBadEdges':h.get('strictUnpairedOrRepeatedEdges'),'hostCollapsed':h.get('exactCollinearTriangles'),'cutterClosed':c['closedEdgeIncidence']})
  if e['newFiniteRefusals']:assert h['closedEdgeIncidence'] and c['closedEdgeIncidence']
 allrows[arm]=rows
 print(arm,json.dumps(rows))
with(out/'per-call-admission.json').open('x')as f:json.dump({'method':'Independent Fraction exact incidence on captured original f64 bit streams, no snap/filter. Every admitted new refusal requires both original closed/noncollapsed operands.','traceSHA256':{n:hashlib.sha256((out/n).read_bytes()).hexdigest()for n in ['kernel-streams.jsonl','established-streams.jsonl']},'rows':allrows},f,indent=2)
prior=json.loads((out.parents[1]/'closed-admission-mini-v1/mini-payload.json').read_text());current=json.loads((out/'candidate-mini-payload.json').read_text());assert prior['rows']==current['rows']
with(out/'diagnostic-equivalence.json').open('x')as f:json.dump({'allFourCandidateRowsEntirelyEqualUninstrumented':True},f)
