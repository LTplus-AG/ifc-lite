from pathlib import Path
import json,struct,math
from collections import defaultdict
paths=[Path('/tmp/ifc-7635-admission-trace-818b/work/7635/closed-admission-mini-v1/mini-payload.json'),Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/final-cap-needle-only-proof-v1/mini-needle-alternate-v1/payload.json')]
def rnd(v):return math.floor(v+0.5)if v>=0 else math.ceil(v-0.5)
results=[]
for path in paths:
 d=json.loads(path.read_text())
 for row in d['rows']:
  if row['context']!='all':continue
  flat=[struct.unpack('>f',struct.pack('>I',v))[0]for v in row['positionsBits']];pts=[tuple(rnd(x*65536)for x in flat[i:i+3])for i in range(0,len(flat),3)];tris=[tuple(pts[j]for j in row['indices'][i:i+3])for i in range(0,len(row['indices']),3)];edges=defaultdict(list)
  for i,t in enumerate(tris):
   for j in range(3):edges[tuple(sorted((t[j],t[(j+1)%3])))].append(i)
  adj=[set()for _ in tris]
  for uses in edges.values():
   assert len(uses)==2
   a,b=uses;adj[a].add(b);adj[b].add(a)
  seen=set();components=[]
  for seed in range(len(tris)):
   if seed in seen:continue
   todo=[seed];members=[];seen.add(seed)
   while todo:
    i=todo.pop();members.append(i)
    for j in adj[i]-seen:seen.add(j);todo.append(j)
   v=set(p for i in members for p in tris[i]);es=set(tuple(sorted((tris[i][k],tris[i][(k+1)%3])))for i in members for k in range(3));euler=len(v)-len(es)+len(members)
   components.append({'triangles':len(members),'vertices':len(v),'edges':len(es),'eulerCharacteristic':euler,'orientableClosedGenusIfVertexManifold':(2-euler)//2})
  results.append({'path':str(path),'alternate':row['alternate'],'components':components})
out=Path(__file__).with_name('component-topology.json');out.write_text(json.dumps({'scope':'Exact kernel-grid edge-connected component/Euler accounting. Strict1+1 closure already independently checked. Genus inference explicitly conditional on vertex manifoldness; no embedding or finite-surface equality claim.','rows':results},indent=2)+'\n');print(json.dumps(results,indent=2))
