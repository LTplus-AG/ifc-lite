"""Unexecuted bounded immutable77a diagnostic; owned clone/target; finally restore."""
from pathlib import Path
import subprocess,os,json,time,hashlib
P=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671/work/6940/kernel-closed-admission-preparation-v1');ROOT=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3code-818b4671');clone=Path('/tmp/ifc-7635-admission-trace-818b');head='77a594c2987087cb34fe89cbb2092f9743bff360'
assert clone.exists()
fixture=clone/'tests/models/georeferencer/MiniBIM-3.1-DO_01_VORM.ifc'
out=clone/'work/7635/closed-admission-stage-v1/run';out.mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=clone,text=True).strip()
assert git('rev-parse','HEAD')==head
files=sorted({p for p in git('ls-files','rust/').splitlines() if p.endswith('.rs')} | {'rust/geometry/src/kernel/plane_weld/admission_tests.rs'})
def hashes():return {p:sha(clone/p) for p in files}
before=hashes();plane=clone/'rust/geometry/src/kernel/plane_weld.rs';original=plane.read_bytes()
example=clone/'rust/processing/examples/diag7635admission.rs';helper=clone/'rust/processing/examples/diag7633rvt_rtc.rs';assert not example.exists() and not helper.exists()
env=os.environ|{'PATH':'/home/louistrue/.cargo/bin:'+os.environ['PATH'],'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','IFC_LITE_REQUIRE_FIXTURES':'1','RUST_TEST_THREADS':'1','CARGO_TARGET_DIR':str(clone/'target'),'IFC_7635_ADMISSION_TRACE':str(out/'kernel-streams.jsonl'),'IFC_DIAG_7631_RVT_TRACE':str(out/'kernel-streams.jsonl')}
results=[]
def run(label,cmd):
 start=time.time()
 with (out/(label+'.log')).open('x') as f:code=subprocess.run(cmd,cwd=clone,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 row={'label':label,'command':cmd,'exitCode':code,'seconds':time.time()-start};results.append(row);(out/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
 if code:raise RuntimeError(label)
try:
 plane.write_bytes((out.parent/'plane-weld-diagnostic.rs').read_bytes())
 adapter=(ROOT/'work/6940/rvt-census-payload.rs').read_text()
 example.write_text(adapter);helper.write_text((clone/'rust/geometry/tests/corpus/rtc_frame.rs').read_text()+"\nimpl ModelFrame<'_> { pub fn diagnostic_offset(&self) -> (f64,f64,f64) { self.offset } }\n")
 (out/'adapter.rs').write_bytes(example.read_bytes());(out/'rtc-helper.rs').write_bytes(helper.read_bytes());(out/'instrumented-source.patch').write_text(git('diff','--binary','HEAD'))
 (out/'source-before.json').write_text(json.dumps({'head':head,'rustSHA256':before,'fixtureSHA256':sha(fixture),'fixtureBytes':fixture.stat().st_size,'diagnosticHashes':{p.name:sha(p) for p in [plane,example,helper]},'sourcePolicy':'77a plus frozen closed-edge-incidence candidate; no numerical instrumentation.','frame':'Actual ordinary-census ModelFrame helper copied verbatim, only adds offset accessor.','environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUST_TEST_THREADS','CARGO_TARGET_DIR','IFC_7635_ADMISSION_TRACE']}},indent=2))
 (out/'rustc-version.txt').write_bytes(subprocess.check_output(['rustc','-Vv'],cwd=clone,env=env));(out/'cargo-version.txt').write_bytes(subprocess.check_output(['cargo','-Vv'],cwd=clone,env=env))
 run('build',['cargo','build','--locked','-p','ifc-lite-processing','--example','diag7635admission','--features','ifc-lite-geometry/triangulation-alt,ifc-lite-geometry/debug_geometry'])
 binary=clone/'target/debug/examples/diag7635admission';(out/'binary.json').write_text(json.dumps({'path':str(binary),'sha256':sha(binary)}))
 run('candidate-payload',[str(binary),str(fixture),str(out/'candidate-mini-payload.json'),'135923'])
 env['IFC_7635_DIAG_ESTABLISHED_ONLY']='1'
 env['IFC_7635_ADMISSION_TRACE']=str(out/'established-streams.jsonl')
 env['IFC_DIAG_7631_RVT_TRACE']=str(out/'established-streams.jsonl')
 run('established-payload',[str(binary),str(fixture),str(out/'established-mini-payload.json'),'135923'])

finally:
 plane.write_bytes(original);example.unlink(missing_ok=True);helper.unlink(missing_ok=True);after=hashes();assert before==after and git('rev-parse','HEAD')==head
 (out/'restoration.json').write_text(json.dumps({'sourceUnchanged':True,'headUnchanged':True,'temporaryExamplesRemoved':True,'sourceSHA256':after},indent=2))
