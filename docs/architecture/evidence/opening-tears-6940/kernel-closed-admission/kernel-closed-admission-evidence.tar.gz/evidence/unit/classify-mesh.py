"""Exact integer topology of saved f32 mesh payload; no validity/volume claim."""
import argparse,json,struct,math,hashlib
from pathlib import Path
from collections import defaultdict

def bits32(v):return struct.unpack('>f',struct.pack('>I',v))[0]
def rnd(v):return math.floor(v+0.5) if v>=0 else math.ceil(v-0.5)
def metrics(row,scale):
 p=[bits32(v) for v in row['positionsBits']]; assert all(map(math.isfinite,p)); assert len(p)%3==0
 q=[tuple(rnd(v*scale) for v in p[i:i+3]) for i in range(0,len(p),3)]
 ix=row['indices'];assert len(ix)%3==0 and all(0<=i<len(q)for i in ix)
 edges=defaultdict(lambda:[0,0]);collapsed=0
 for i in range(0,len(ix),3):
  a,b,c=[q[j]for j in ix[i:i+3]];u=[b[k]-a[k]for k in range(3)];v=[c[k]-a[k]for k in range(3)]
  collapsed+=not any([u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]])
  for x,y in [(a,b),(b,c),(c,a)]:
   if x!=y:edges[tuple(sorted((x,y)))][int(x>y)]+=1
 return {'triangles':len(ix)//3,'strictBadEdges':sum(v!=[1,1]for v in edges.values()),'unbalancedEdges':sum(a!=b for a,b in edges.values()),'collapsedTriangles':collapsed}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');a=p.parse_args();src=Path(a.input);d=json.loads(src.read_text());rows=[{'alternate':r['alternate'],'context':r['context'],'kernel':metrics(r,65536),'census':metrics(r,1000)}for r in d['rows']]
 result={'input':str(src.resolve()),'inputSHA256':hashlib.sha256(src.read_bytes()).hexdigest(),'method':'Actual stored f32 coordinates; Rust ties-away rounding; exact integer cross products and directed 1+1 multiplicity. No discarded invalid triangles. Origin not added because these topology readers operate on stored mesh coordinates.','rows':rows}
 with Path(a.output).open('x')as f:json.dump(result,f,indent=2)
 print(json.dumps(rows,indent=2))
