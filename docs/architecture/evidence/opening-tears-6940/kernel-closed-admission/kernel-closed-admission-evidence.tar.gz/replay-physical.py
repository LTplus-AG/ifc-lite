"""Explicit serial numerical replay into a new directory; never overwrites historical evidence."""
from pathlib import Path
import sys,shutil,json,hashlib,subprocess
packet=Path(__file__).resolve().parent;out=Path(sys.argv[1]).resolve();python=Path(sys.argv[2]).resolve();out.mkdir()
p=out/'physical';shutil.copytree(packet/'evidence/physical',p,ignore=shutil.ignore_patterns('__pycache__'))
shutil.copyfile(packet/'evidence/physical-dependencies/analyze-rvt13797-full-triangle-support-v2.py',out/'analyze-rvt13797-full-triangle-support-v2.py')
final=out/'final-cap-needle-only-proof-v1/mini-needle-alternate-v1';final.mkdir(parents=True);shutil.copyfile(packet/'evidence/physical-final-input/payload.json',final/'payload.json')
a=p/'analyze.py';original=a.read_text();old="Path('/tmp/ifc-7635-admission-trace-818b/work/7635/closed-admission-mini-v1/mini-payload.json')";assert original.count(old)==1
replacement="HERE/'actual-intermediate-input/mini-payload.json'";a.write_text(original.replace(old,replacement))
receipt={'originalAnalyzeSHA256':hashlib.sha256(original.encode()).hexdigest(),'relocatedAnalyzeSHA256':hashlib.sha256(a.read_bytes()).hexdigest(),'onlyReplacement':[old,replacement],'python':str(python),'phases':[]}
for name in ['cap-rings.py','cap-domain-validation.py','ring-correspondence.py','wall-patches.py','wall-cover.py','convex-cover.py']:
 with (out/(name+'.log')).open('x') as log:r=subprocess.run([str(python),str(p/name)],stdout=log,stderr=subprocess.STDOUT)
 receipt['phases'].append({'script':name,'exitCode':r.returncode});(out/'replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print(out/'replay.json')
