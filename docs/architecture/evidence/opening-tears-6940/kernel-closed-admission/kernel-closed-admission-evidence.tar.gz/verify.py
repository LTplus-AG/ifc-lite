"""Lightweight saved-evidence verification; not an execution or universal-shape certificate."""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sys
root=Path(sys.argv[1]).resolve();data=root/'evidence'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=read(root/'manifest.json')
for name,row in manifest.items():
 p=data/name;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],name
physical=data/'physical'
for name in ['final-manifest.json','final-manifest-v2.json','final-manifest-v3.json']:
 m=read(physical/name)
 for group in ['scripts','reports']:
  for p,h in m.get(group,{}).items():assert sha(physical/p)==h,p
count=[]
for file,total in [('cap-convex-cover.json','exactSourceProjectedArea'),('wall-cover.json','exactAuthoredRectangleProjectedArea')]:
 n=0
 for row in read(physical/file)['rows']:
  for r in row['records']:
   assert sum(F(c['exactProjectedArea']) for c in r['coveredCells'])+F(r['exactLeftoverProjectedArea'])==F(r[total]);n+=1
 count.append(n)
assert count==[1172,200],count
binding=read(physical/'final-input-frame-binding.json')
assert sha(data/'intermediate/mini-payload.json')==binding['inputSHA256']['intermediate']
assert sha(data/'physical-final-input/payload.json')==binding['inputSHA256']['finalCap']
for path,contexts in [(data/'intermediate/mini-payload.json',['all']),(data/'physical-final-input/payload.json',['source','all'])]:
 d=read(path);assert d['modelFrameRtcOffsetBits']==binding['modelFrameRtcOffsetBits']
 for context in contexts:
  a=next(r for r in d['rows'] if r['context']==context and not r['alternate']);b=next(r for r in d['rows'] if r['context']==context and r['alternate'])
  assert a['originBits']==['0000000000000000']*3
  for k in ['positionsBits','normalsBits','indices','originBits','localToWorldBits','localBoundsBits','rtcApplied']:assert a[k]==b[k],(context,k)
clippy=read(data/'clippy/result.json');assert clippy['ok'] and clippy['exitCode']==0 and clippy['sourceUnchanged'];assert clippy['command']==['cargo','clippy','--workspace','--all-targets','--','-D','warnings'];assert sha(data/'clippy/run.log')==clippy['logSHA256']
assert read(data/'combined-mini/mini-payload.json')['rows']==read(data/'prior-final/mini-payload.json')['rows']
print(json.dumps({'ok':True,'evidenceFiles':len(manifest),'exactPartitionRecords':count,'scope':'Hashes, recorded partition conservation, actual source/input bindings, Clippy completion and saved payload equality; no fresh Rust or physical solver execution.'}))
