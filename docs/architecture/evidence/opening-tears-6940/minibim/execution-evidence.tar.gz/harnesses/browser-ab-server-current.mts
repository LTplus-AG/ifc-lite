// Evidence-only server. Run explicitly with local tsx; never starts a browser.
import { startStaticServer } from '../../scripts/perf/browser-static-server.ts';
import { readFileSync, writeFileSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import type { IncomingMessage, ServerResponse } from 'node:http';

const root = resolve(process.cwd());
function arm(name: 'BASE' | 'BRANCH') {
  const path = process.env[`IFC_6940_${name}_ROOT`];
  const head = process.env[`IFC_6940_${name}_SHA`];
  if (!path?.startsWith('/') || !head || !/^[0-9a-f]{40}$/.test(head)) {
    throw new Error(`Explicit absolute checkout and immutable SHA required for ${name}`);
  }
  return { checkout: resolve(path), expectedHead: head };
}
const arms = { base: arm('BASE'), branch: arm('BRANCH') };
const roots = { base: join(arms.base.checkout, 'apps/viewer/dist'), branch: join(arms.branch.checkout, 'apps/viewer/dist') };
const receipts = process.env.IFC_6940_BROWSER_RECEIPTS;
if (!receipts?.startsWith('/')) throw new Error('Explicit absolute receipt directory required');
const output = resolve(receipts);
mkdirSync(output, { recursive: true });
const sha = (bytes: Uint8Array | string) => createHash('sha256').update(bytes).digest('hex');
const identity = (path: string) => ({ path, bytes: statSync(path).size, sha256: sha(readFileSync(path)) });
const fixturePaths = {
  fzk: 'ara3d/AC20-FZK-Haus.ifc',
  issue129: 'ara3d/ISSUE_129_N1540_17_EXE_MOD_448200_02_09_11SMC_IGC_V17.ifc',
  holter: 'ara3d/ISSUE_053_20181220Holter_Tower_10.ifc',
  minibim: 'georeferencer/MiniBIM-3.1-DO_01_VORM.ifc',
};
const fixtures = Object.fromEntries(Object.entries(fixturePaths).map(([key, relative]) => {
  const path = join(root, 'tests/models', relative);
  return [key, { ...identity(path), url: `/__6940/fixtures/${key}.ifc`, name: relative.split('/').at(-1) }];
}));
const extras = new Map<string, string>(Object.values(fixtures).map(file => [file.url, file.path]));
for (const name of readdirSync(join(root, 'work/6940/browser-modules'))) {
  if (/^[a-zA-Z0-9._-]+\.(js|mjs|html)$/.test(name)) extras.set(`/__6940/modules/${name}`, join(root, 'work/6940/browser-modules', name));
}
extras.set('/__6940/cohort.mjs', join(root, 'work/6940/browser-ab-cohort.mjs'));
function manifest(side: keyof typeof roots) {
  const dist = roots[side];
  const checkout = resolve(dist, '../../..');
  const files: Array<{ path: string; bytes: number; sha256: string }> = [];
  function walk(directory: string) {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.isFile()) files.push({ ...identity(path), path: path.slice(dist.length + 1) });
      else throw new Error(`Unexpected symlink in frozen dist: ${path}`);
    }
  }
  walk(dist);
  files.sort((a, b) => a.path.localeCompare(b.path));
  const git = (...args: string[]) => execFileSync('git', ['-C', checkout, ...args], { maxBuffer: 32 * 1024 * 1024 }).toString().trim();
  const head = git('rev-parse', 'HEAD');
  const diff = git('diff', 'HEAD', '--binary');
  if (checkout !== arms[side].checkout || head !== arms[side].expectedHead || diff) {
    throw new Error(`Checkout/source fence failed for ${side}`);
  }
  const packageWasm = identity(join(checkout, 'packages/wasm/pkg/ifc-lite_bg.wasm'));
  const servedWasm = files.filter(file => /^ifc-lite_bg(?:-[A-Za-z0-9_-]+)?\.wasm$/.test(file.path.split('/').at(-1) ?? ''));
  if (servedWasm.length !== 1 || servedWasm[0].sha256 !== packageWasm.sha256) {
    throw new Error(`Served WASM does not exactly match source-built package for ${side}`);
  }
  return { side, dist, checkout, head, tree: git('rev-parse', 'HEAD^{tree}'), trackedDiffSha256: sha(diff),
    packageWasm, distManifestSha256: sha(JSON.stringify(files)), files };
}
const manifests = { base: manifest('base'), branch: manifest('branch') };
let side: keyof typeof roots = 'branch';
let epoch = randomUUID();
const pending = new Set<string>();
const json = (res: ServerResponse, code: number, body: unknown) => {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store',
    'Cross-Origin-Opener-Policy': 'same-origin', 'Cross-Origin-Embedder-Policy': 'credentialless' });
  res.end(JSON.stringify(body));
};
async function body(req: IncomingMessage, limit: number) {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new Error(`POST exceeds ${limit} bytes`);
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
const server = await startStaticServer({ port: 5194, host: '127.0.0.1', root: () => roots[side], extra: extras });
server.requestTimeout = 120_000;
const original = server.listeners('request')[0] as (req: IncomingMessage, res: ServerResponse) => void;
server.removeAllListeners('request');
server.on('request', (req, res) => { void (async () => {
  const path = (req.url ?? '/').split('?')[0];
  if (!path.startsWith('/__6940/') || path.startsWith('/__6940/fixtures/') ||
    path.startsWith('/__6940/modules/') || path === '/__6940/cohort.mjs') return original(req, res);
  try {
    if (req.method === 'GET' && path === '/__6940/state') return json(res, 200, { side, epoch, manifest: manifests[side], fixtures, pending: [...pending] });
    if (req.method === 'POST' && path === '/__6940/control') {
      if (pending.size) return json(res, 409, { error: 'Samples still pending', pending: [...pending] });
      const input = await body(req, 4096);
      if (input.side !== 'base' && input.side !== 'branch') return json(res, 400, { error: 'side must be base or branch' });
      side = input.side; epoch = randomUUID();
      return json(res, 200, { side, epoch, manifest: manifests[side] });
    }
    const match = /^\/__6940\/(begin|receipt)\/([a-zA-Z0-9_-]{1,120})$/.exec(path);
    if (req.method !== 'POST' || !match) return json(res, 404, { error: 'Unknown evidence endpoint' });
    const [, action, id] = match;
    const input = await body(req, action === 'begin' ? 32_768 : 32 * 1024 * 1024);
    if (action === 'begin') {
      if (pending.size) return json(res, 409, { error: 'Only one sample at a time', pending: [...pending] });
      if (input.epoch !== epoch || input.side !== side) return json(res, 409, { error: 'Requested root is stale', side, epoch });
      writeFileSync(join(output, `${id}.begin.json`), JSON.stringify({ at: new Date().toISOString(), input, side, epoch,
        manifest: manifests[side], fixtures }, null, 2), { flag: 'wx' });
      pending.add(id);
      return json(res, 201, { id, side, epoch });
    }
    if (!pending.has(id)) return json(res, 409, { error: 'No matching pending intent', id });
    writeFileSync(join(output, `${id}.result.json`), JSON.stringify({ ...input, received: new Date().toISOString(), servingStateAtReceipt: { side, epoch } }, null, 2), { flag: 'wx' });
    pending.delete(id);
    json(res, 201, { id, saved: true });
  } catch (error) {
    console.error('[6940 evidence]', error);
    json(res, 400, { error: error instanceof Error ? error.message : String(error) });
  }
})().catch(error => { console.error('[6940 request]', error); if (!res.headersSent) json(res, 500, { error: String(error) }); else res.destroy(error); }); });
writeFileSync(join(output, `server-${process.pid}-${Date.now()}.json`), JSON.stringify({ at: new Date().toISOString(), pid: process.pid, root, manifests, fixtures,
  helpers: [...extras.entries()].filter(([url]) => url.includes('/modules/') || url.includes('cohort')).map(([url, path]) => ({ url, ...identity(path) })),
  port: 5194, proxy: 'Existing HTTPS :8448 must forward to :5194; server does not configure or launch it' }, null, 2), { flag: 'wx' });
console.log(JSON.stringify({ port: 5194, output, side, epoch }));
