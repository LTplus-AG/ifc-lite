#!/usr/bin/env python3
"""Explicit evidence build; dedicated target, no cache fallback, create-new receipts."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
arm=Path(sys.argv[1]).resolve();expected=sys.argv[2];record=Path(sys.argv[3]).resolve()
assert len(expected)==40 and all(c in '0123456789abcdef' for c in expected)
git=lambda *args:subprocess.check_output(['git',*args],cwd=arm).decode().strip()
assert git('rev-parse','HEAD')==expected and not git('status','--porcelain','--untracked-files=no')
record.mkdir(exist_ok=False)
source={str(p.relative_to(arm)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (arm/'rust').rglob('*.rs')}
env=os.environ.copy();env.update(PATH='/home/louistrue/.cargo/bin:'+env['PATH'],CI='1',CARGO_BUILD_JOBS='2',CARGO_TARGET_DIR=str(arm/'target'))
cmd=['pnpm','exec','turbo','run','build','--filter=@ifc-lite/viewer...','--concurrency=2','--force']
receipt={'command':cmd,'cwd':str(arm),'head':expected,'tree':git('rev-parse','HEAD^{tree}'),'sourceBefore':source,'started':time.time(),'environment':{k:env.get(k)for k in ['CI','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']},'rustc':subprocess.check_output(['rustup','run','nightly-2025-11-15','rustc','-Vv'],cwd=arm,env=env).decode()}
(record/'intent.json').write_text(json.dumps(receipt,indent=2)+'\n');start=time.time()
with (record/'build.log').open('xb') as log:result=subprocess.run(cmd,cwd=arm,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exitCode=result.returncode,seconds=time.time()-start,trackedSourceUnchanged=not git('status','--porcelain','--untracked-files=no'),rustSourceUnchanged=all(hashlib.sha256((arm/p).read_bytes()).hexdigest()==h for p,h in source.items()))
if result.returncode==0:
 paths=[arm/'packages/wasm/pkg'/name for name in ['ifc-lite.js','ifc-lite_bg.wasm','ifc-lite.d.ts']];paths+=sorted((arm/'apps/viewer/dist').rglob('*'))
 receipt['artifacts']=[{'path':str(p.relative_to(arm)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in paths if p.is_file()]
 wasm=arm/'packages/wasm/pkg/ifc-lite_bg.wasm';receipt['wasmNewerThanRustSources']=wasm.stat().st_mtime_ns>=max((arm/p).stat().st_mtime_ns for p in source)
 served=[p for p in receipt['artifacts']if p['path'].startswith('apps/viewer/dist/')and Path(p['path']).name.startswith('ifc-lite_bg') and p['path'].endswith('.wasm')]
 receipt['singleServedIfcGeometryWasmExactlyMatchesPackage']=len(served)==1 and served[0]['sha256']==hashlib.sha256(wasm.read_bytes()).hexdigest()
receipt['logSha256']=hashlib.sha256((record/'build.log').read_bytes()).hexdigest();(record/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items()if k not in ['sourceBefore','artifacts','rustc']}))
if result.returncode:print((record/'build.log').read_text()[-6000:])
raise SystemExit(result.returncode or int(not receipt['trackedSourceUnchanged'] or not receipt['rustSourceUnchanged'] or not receipt['singleServedIfcGeometryWasmExactlyMatchesPackage'] or not receipt['wasmNewerThanRustSources']))
