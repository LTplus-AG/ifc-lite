// Local evidence harness for #6940. No builds, source edits, or fixture changes.
// node work/6940/canonical-wasm.mjs [checkout-root] [receipt.json]
// Optional: IFC_6940_HOSTS=135923 IFC_6940_CONTEXTS=none,one,all
import { readFileSync, writeFileSync, statSync, mkdirSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const root = resolve(process.argv[2] ?? process.cwd());
const output = resolve(process.argv[3] ?? join(root, 'work/6940/canonical-wasm-receipt.json'));
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', ['-C', root, ...args], { maxBuffer: 32 * 1024 * 1024 }).toString().trim();
const fileIdentity = path => {
  const bytes = readFileSync(path);
  return { path, bytes: bytes.length, sha256: sha256(bytes), mtime: statSync(path).mtime.toISOString() };
};
// Serialize every visible typed byte, rather than a possibly larger backing buffer.
function snapshot(value) {
  if (value === undefined) return { undefined: true };
  if (ArrayBuffer.isView(value)) {
    const bytes = Buffer.from(value.buffer, value.byteOffset, value.byteLength);
    return { type: value.constructor.name, length: value.length, byteLength: value.byteLength,
      sha256: sha256(bytes), base64: bytes.toString('base64') };
  }
  if (typeof value === 'bigint') return { bigint: value.toString() };
  if (Array.isArray(value)) return value.map(snapshot);
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, snapshot(child)]));
  }
  return value;
}

function incidence(meshes) {
  const edges = new Map();
  let triangles = 0;
  let collapsed = 0;
  let repeatedVertexTriangles = 0;
  let collinearGridTriangles = 0;
  const worldBytes = [];
  for (const { positions, indices, origin } of meshes) {
    const world = new Float64Array(positions.length);
    for (let i = 0; i < positions.length; i++) {
      world[i] = positions[i] + origin[i % 3];
      assert(Number.isFinite(world[i]), 'nonfinite world position');
    }
    worldBytes.push(snapshot(world));
    const key = vertex => {
      assert(vertex * 3 + 2 < world.length, 'index outside positions');
      return [0, 1, 2].map(axis => {
        const scaled = world[vertex * 3 + axis] * 65536;
        // Rust f64::round uses ties away from zero; JS rounds negative ties up.
        const value = scaled < 0 ? -Math.round(-scaled) : Math.round(scaled);
        assert(Number.isSafeInteger(value), 'grid coordinate outside JS exact integer range');
        return value;
      });
    };
    assert.equal(indices.length % 3, 0);
    for (let i = 0; i < indices.length; i += 3) {
      triangles++;
      const points = [key(indices[i]), key(indices[i + 1]), key(indices[i + 2])];
      const keys = points.map(point => point.join(','));
      if (new Set(keys).size !== 3) { collapsed++; repeatedVertexTriangles++; continue; }
      const delta = (a, b) => a.map((value, axis) => BigInt(value) - BigInt(b[axis]));
      const u = delta(points[1], points[0]);
      const v = delta(points[2], points[0]);
      const cross = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
      if (cross.every(value => value === 0n)) { collapsed++; collinearGridTriangles++; continue; }
      for (const [from, to] of [[0, 1], [1, 2], [2, 0]]) {
        // Numeric lexicographic comparison: string ordering is not coordinate ordering.
        const a = points[from]; const b = points[to];
        const comparison = a[0] - b[0] || a[1] - b[1] || a[2] - b[2];
        const forward = comparison < 0;
        const lo = forward ? a : b; const hi = forward ? b : a;
        const edgeKey = `${lo.join(',')}|${hi.join(',')}`;
        const edge = edges.get(edgeKey) ?? { endpoints: [lo, hi], forward: 0, reverse: 0 };
        edge[forward ? 'forward' : 'reverse']++;
        edges.set(edgeKey, edge);
      }
    }
  }
  const unmatched = [...edges.values()].filter(edge => edge.forward !== 1 || edge.reverse !== 1);
  unmatched.sort((a, b) => JSON.stringify(a.endpoints).localeCompare(JSON.stringify(b.endpoints)));
  return { grid: '1/65536 metre', frame: 'viewer Y-up world = origin + positions', triangles,
    collapsed, repeatedVertexTriangles, collinearGridTriangles,
    undirectedEdges: edges.size, unmatchedEdges: unmatched.length, unmatched, worldBytes,
    directedIncidenceSha256: sha256(JSON.stringify([...edges.entries()].sort(([a], [b]) => a.localeCompare(b)))) };
}

const runtimeJs = join(root, 'packages/wasm/pkg/ifc-lite.js');
const runtimeWasm = join(root, 'packages/wasm/pkg/ifc-lite_bg.wasm');
const fixture = join(root, 'tests/models/georeferencer/MiniBIM-3.1-DO_01_VORM.ifc');
const hosts = (process.env.IFC_6940_HOSTS ?? '135923,137627,139545,141434,143323,145212,151760,154626,150890')
  .split(',').map(Number);
const contexts = (process.env.IFC_6940_CONTEXTS ?? 'none,one,all').split(',');
for (const context of contexts) assert(['none', 'one', 'all'].includes(context));
const receipt = {
  schema: 1, purpose: '#6940 canonical host-only WASM functional diagnosis; not timing evidence',
  started: new Date().toISOString(), root, node: process.version,
  source: { head: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'),
    status: git('status', '--short'), trackedDiffSha256: sha256(git('diff', 'HEAD', '--binary')) },
  harness: fileIdentity(fileURLToPath(import.meta.url)),
  runtime: { javascript: fileIdentity(runtimeJs), wasm: fileIdentity(runtimeWasm),
    declarations: fileIdentity(join(root, 'packages/wasm/pkg/ifc-lite.d.ts')) },
  fixture: fileIdentity(fixture), hosts, contexts, calls: [], cleanup: {},
};
assert.equal(receipt.fixture.bytes, 7459201, 'fixture byte count differs from catalogue');
assert.equal(receipt.fixture.sha256, '7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b');
let api;
let bindings;
const drain = () => typeof bindings.takeOpeningPerfCounters === 'function'
  ? snapshot(bindings.takeOpeningPerfCounters()) : null;
let failure;
try {
  const wasm = await import(pathToFileURL(runtimeJs).href);
  bindings = wasm.IfcAPI ? wasm : wasm.default;
  assert(bindings?.IfcAPI, 'generated bindings must export IfcAPI');
  if (bindings.initSync) bindings.initSync({ module: readFileSync(runtimeWasm) });
  api = new bindings.IfcAPI();
  receipt.initialCounters = drain();
  const bytes = new Uint8Array(readFileSync(fixture));
  const pre = api.buildPrePassOnce(bytes);
  receipt.prepass = snapshot(pre);
  receipt.prepassCounters = drain();
  for (const field of ['jobs', 'rtcOffset', 'voidKeys', 'voidCounts', 'voidValues', 'styleIds',
    'styleColors', 'styleFinishes', 'materialElementIds', 'materialColorCounts', 'materialColors']) {
    assert(pre[field] !== undefined, `missing canonical prepass field ${field}`);
  }
  api.setStyleFinishes(pre.styleIds, pre.styleFinishes);
  const voids = new Map();
  let offset = 0;
  for (let i = 0; i < pre.voidKeys.length; i++) {
    voids.set(pre.voidKeys[i], pre.voidValues.slice(offset, offset + pre.voidCounts[i]));
    offset += pre.voidCounts[i];
  }
  assert.equal(offset, pre.voidValues.length);
  assert.equal(voids.get(135923)?.length, 13, 'residual slab must have its actual 13 openings');
  assert([...voids.get(135923)].includes(135934), 'residual opening missing');
  for (const host of hosts) {
    const job = [];
    for (let i = 0; i < pre.jobs.length; i += 3) {
      if (pre.jobs[i] === host) job.push(...pre.jobs.slice(i, i + 3));
    }
    assert.equal(job.length, 3, `expected exactly one canonical job for host ${host}`);
    const all = voids.get(host);
    assert(all?.length, `host ${host} has no actual opening wires`);
    for (const context of contexts) {
      const selected = context === 'none' ? new Uint32Array() : context === 'all'
        ? all : new Uint32Array([host === 135923 ? 135934 : all[0]]);
      const call = { host, context, actualAllOpenings: [...all], selectedOpenings: [...selected], job };
      receipt.calls.push(call);
      let collection;
      try {
        collection = api.processGeometryBatch(bytes, new Uint32Array(job), pre.unitScale,
          pre.rtcOffset[0], pre.rtcOffset[1], pre.rtcOffset[2], pre.needsShift,
          selected.length ? new Uint32Array([host]) : new Uint32Array(),
          selected.length ? new Uint32Array([selected.length]) : new Uint32Array(), selected,
          pre.styleIds, pre.styleColors, pre.planeAngleToRadians,
          pre.materialElementIds, pre.materialColorCounts, pre.materialColors);
        call.diagnostics = snapshot(collection.diagnostics);
        call.buildingRotation = snapshot(collection.buildingRotation);
        call.hasRtcOffset = collection.hasRtcOffset();
        call.meshes = [];
        const geometry = [];
        for (let i = 0; i < collection.length; i++) {
          const mesh = collection.get(i);
          assert(mesh, `missing mesh ${i}`);
          try {
            const record = {};
            for (const field of ['expressId', 'geometryItemId', 'geometryClass', 'ifcType', 'materialId',
              'positions', 'normals', 'indices', 'origin', 'color', 'vertexCount', 'triangleCount',
              'localBounds', 'localToWorld', 'metallic', 'roughness', 'shadingColor', 'uvs',
              'hasTexture', 'textureHeight', 'textureWidth', 'textureId', 'textureRgba',
              'textureUrl', 'textureRepeatS', 'textureRepeatT']) record[field] = mesh[field];
            assert.equal(record.expressId, host);
            call.meshes.push(snapshot(record));
            geometry.push(record);
          } finally { mesh.free(); }
        }
        assert(call.meshes.length, `host ${host}/${context} produced no meshes`);
        call.incidence = incidence(geometry);
        call.meshPayloadSha256 = sha256(JSON.stringify(call.meshes));
      } finally {
        collection?.free();
        call.counters = drain();
      }
      process.stderr.write(`${host}/${context}: ${call.incidence.triangles} triangles, ${call.incidence.unmatchedEdges} unmatched edges\n`);
    }
  }
} catch (error) {
  failure = error;
  receipt.error = { name: error.name, message: error.message, stack: error.stack };
} finally {
  try {
    if (api) {
      try { api.clearPrePassCache(); receipt.cleanup.prepassCacheCleared = true; }
      finally { api.free(); receipt.cleanup.apiFreed = true; }
    }
  } catch (error) {
    receipt.cleanup.error = { message: error.message, stack: error.stack };
    failure ??= error;
  }
  receipt.finished = new Date().toISOString();
  mkdirSync(dirname(output), { recursive: true });
  writeFileSync(output, `${JSON.stringify(receipt, null, 2)}\n`);
}
if (failure) throw failure;
process.stdout.write(`${output}\n`);
