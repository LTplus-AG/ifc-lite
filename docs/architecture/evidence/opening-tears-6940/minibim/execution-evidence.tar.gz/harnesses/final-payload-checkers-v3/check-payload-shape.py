"""Evidence-only #6940 checker for saved canonical payloads; no geometry production."""
from pathlib import Path
import argparse, base64, collections, hashlib, json, math, struct, sys
import fences

HOSTS = {135923,137627,139545,141434,143323,145212,151760,154626,150890}
GRID = 1 / 65536
EPSILON = 2 ** -23

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(name):
    return json.loads(Path(name).read_text())

def decode(view, code, size):
    raw = base64.b64decode(view['base64'], validate=True)
    assert len(raw) == view['byteLength'] == view['length'] * size
    assert hashlib.sha256(raw).hexdigest() == view['sha256']
    return list(struct.unpack('<' + code * view['length'], raw))

def round_away(x):
    assert math.isfinite(x)
    a = abs(x)
    integer = math.floor(a)
    integer += int(a - integer >= .5)
    return -integer if x < 0 else integer

def key(p):
    q = tuple(round_away(v / GRID) for v in p)
    assert all(-(2**63) <= v < 2**63 for v in q)
    return q

def sub(a,b): return tuple(a[k]-b[k] for k in range(3))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b): return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def norm(a): return math.sqrt(dot(a,a))

def incidence(tris):
    edges = collections.defaultdict(lambda:[0,0])
    collapsed = 0
    for a,b,c in tris:
        collapsed += cross(sub(b,a),sub(c,a)) == (0,0,0)
        for x,y in [(a,b),(b,c),(c,a)]:
            edges[(min(x,y),max(x,y))][int(x>y)] += 1
    return {'triangles':len(tris),'unmatchedEdges':sum(v != [1,1] for v in edges.values()),'collapsed':collapsed}

def measure(call):
    area = perimeter = volume = magnitude = 0.
    triangle_count = 0
    world = []
    local = []
    meshes = []
    assert call['meshes']
    for mesh in call['meshes']:
        positions = decode(mesh['positions'],'f',4)
        normals = decode(mesh['normals'],'f',4)
        indices = decode(mesh['indices'],'I',4)
        origin = decode(mesh['origin'],'d',8)
        assert mesh['expressId'] == call['host']
        assert len(positions) % 3 == 0 and len(indices) % 3 == 0
        assert len(normals) == len(positions) and len(origin) == 3
        assert all(math.isfinite(x) for x in positions + normals + origin)
        assert len(positions) // 3 == mesh['vertexCount']
        assert len(indices) // 3 == mesh['triangleCount']
        assert all(i < len(positions) // 3 for i in indices)
        points = list(zip(positions[::3],positions[1::3],positions[2::3]))
        magnitude = max(magnitude,*(abs(x) for x in positions))
        stored_triangles = []
        for off in range(0,len(indices),3):
            a,b,c = [points[i] for i in indices[off:off+3]]
            area += norm(cross(sub(b,a),sub(c,a))) * .5
            perimeter += norm(sub(b,a)) + norm(sub(c,b)) + norm(sub(a,c))
            triangle_count += 1
            stored_triangles.append(tuple(key(p) for p in [a,b,c]))
            world.append(tuple(key(tuple(p[k]+origin[k] for k in range(3))) for p in [a,b,c]))
        stored_metrics = incidence(stored_triangles)
        # The public mesh_volume quantizes stored positions. Require closedness
        # in that exact domain before using an origin-independent integral.
        assert stored_metrics['triangles'] > 0
        assert stored_metrics['unmatchedEdges'] == stored_metrics['collapsed'] == 0
        six_volume = sum(dot(a,cross(b,c)) for a,b,c in stored_triangles)
        mesh_volume = six_volume * GRID**3 / 6
        volume += mesh_volume
        local.extend(stored_triangles)
        meshes.append({'expressId':mesh['expressId'],'triangles':len(stored_triangles),
            'storedIncidence':stored_metrics,'exactStoredGridSignedSixVolume':str(six_volume),
            'signedVolume':mesh_volume,'origin':origin})
    world_metrics = incidence(world)
    stored_metrics = incidence(local)
    assert world_metrics['triangles'] > 0
    assert world_metrics['unmatchedEdges'] == world_metrics['collapsed'] == 0
    assert stored_metrics['unmatchedEdges'] == stored_metrics['collapsed'] == 0
    assert math.isfinite(volume) and math.isfinite(area) and area > 0
    assert volume > 0, 'actual captured slabs are outward-wound'
    return {'host':call['host'],'context':call['context'],
        'selectedOpenings':call['selectedOpenings'],'meshCount':len(meshes),
        'meshes':meshes,'storedIncidence':stored_metrics,'worldIncidence':world_metrics,
        'signedVolume':volume,'absoluteVolume':abs(volume),'area':area,
        'perimeterSum':perimeter,'triangles':triangle_count,'maxStoredCoordinate':magnitude}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    fences.args(parser,native=True)
    parser.add_argument('--comparison',required=True)
    a=parser.parse_args()
    fence=fences.native(a)
    receipt_name=Path(a.wasm); native_name=Path(a.native)
    receipt=load(receipt_name); comparison=load(a.comparison)
    assert comparison['exactPayloadEqual']
    assert comparison['wasmReceiptSha256']==sha(receipt_name)
    assert comparison['nativeReceiptSha256']==sha(native_name)
    assert comparison['validationFence']==fence, 'comparison must use the same source and inputs'
    assert len(comparison['calls'])==27 and all(c['equal'] and not c['differences'] for c in comparison['calls'])
    assert {(c['host'],c['context']) for c in comparison['calls']} == {(h,c) for h in HOSTS for c in ['none','one','all']}
    STACK=Path(a.checkout)
    assert receipt['cleanup'] == {'prepassCacheCleared':True,'apiFreed':True}
    assert len(receipt['calls']) == 27
    assert {(c['host'],c['context']) for c in receipt['calls']} == {(h,c) for h in HOSTS for c in ['none','one','all']}
    for c in receipt['calls']:
        selected = c['selectedOpenings']; actual = c['actualAllOpenings']
        assert len(set(actual)) == len(actual) > 0
        assert selected == ([] if c['context']=='none' else ([135934 if c['host']==135923 else actual[0]] if c['context']=='one' else actual))
    rows = [measure(c) for c in receipt['calls']]
    by_key = {(r['host'],r['context']):r for r in rows}
    comparisons = []
    for host in sorted(HOSTS):
        before = by_key[host,'none']
        for context in ['one','all']:
            after = by_key[host,context]
            d = math.sqrt(3) * (2*GRID + 2*EPSILON*max(before['maxStoredCoordinate'],after['maxStoredCoordinate']))
            area_tolerance = (before['perimeterSum']+after['perimeterSum'])*d + 2*(before['triangles']+after['triangles'])*d**2
            # Preserve the two existing Rust tests' slightly different bounds.
            volume_tolerance = (before['area']+after['area']+(0 if host==135923 else area_tolerance))*d
            assert before['area'] > 0 and abs(before['signedVolume']) > volume_tolerance
            assert before['signedVolume'] * after['signedVolume'] > 0
            area_delta = abs(after['area']-before['area'])
            signed_delta = abs(after['signedVolume']-before['signedVolume'])
            absolute_delta = abs(after['absoluteVolume']-before['absoluteVolume'])
            passed = area_delta<=area_tolerance and signed_delta<=volume_tolerance and absolute_delta<=volume_tolerance
            comparisons.append({'host':host,'context':context,'passed':passed,'displacementBudget':d,
                'areaDelta':area_delta,'areaAllowance':area_tolerance,
                'signedVolumeDelta':signed_delta,'absoluteVolumeDelta':absolute_delta,'volumeAllowance':volume_tolerance,
                'areaAllowanceFractionUsed':area_delta/area_tolerance,'volumeAllowanceFractionUsed':signed_delta/volume_tolerance})
            assert passed, comparisons[-1]
    sources = ['rust/processing/tests/issue_6940_opening_filling_a_profile_hole.rs',
        'rust/processing/tests/issue_6940_profile_cap_boundaries.rs',
        'rust/geometry/src/kernel/mesh_volume.rs']
    report={'schema':1,'source':receipt['source']['head'],'all27FiniteValidClosedNoncollapsed':True,
        'all18RetainedShapeComparisonsPass':True,'all27Outward':True,
        'inputReceipts':{str(n):sha(n) for n in [receipt_name,native_name,Path(a.comparison)]},
        'validationFence':fence,'fencesSha256':fences.sha(Path(fences.__file__)),
        'scriptSha256':sha(Path(__file__)),'rustOracleSourceSha256':{n:sha(STACK/n) for n in sources},
        'coordinateFrame':'Actual flat FFI Y-up stored f32 plus f64 mesh origins; (x,z,-y) is orientation-preserving.',
        'volumeMethod':'Exact integer stored-grid signed tetrahedron6V, requiring per-mesh and host stored-grid closure first. Translation-invariant on these closed inputs; same quantization domain as public mesh_volume.',
        'rounding':'Rust f64 ties away from zero; no Python round and no add-.5 shortcut.',
        'allowance':'Exactly the established per-host Rust area/volume formulas, with no percentage or enlarged tolerance.',
        'limitations':['Aggregate area/volume and closure are measured invariants, not a universal exact-surface or self-intersection proof.',
            'Checks actual browser-selected prepass frame only; other three policy frames are separately covered by native fixture tests.',
            'No GPU/pixel, full-model native, styling/texture, performance or CI acceptance claim.'],
        'rows':rows,'comparisons':comparisons}
    output = Path(a.output)
    with output.open('x') as f: json.dump(report,f,indent=2)
    print(json.dumps({'receipt':str(output),'sha256':sha(output),'rows':len(rows),'comparisons':len(comparisons),
        'maxAreaAllowanceFractionUsed':max(c['areaAllowanceFractionUsed'] for c in comparisons),
        'maxVolumeAllowanceFractionUsed':max(c['volumeAllowanceFractionUsed'] for c in comparisons)}))

if __name__ == '__main__': main()
