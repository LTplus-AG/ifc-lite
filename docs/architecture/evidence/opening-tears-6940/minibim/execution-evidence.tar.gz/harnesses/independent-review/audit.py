"""Read-only audit of actual current build/native/WASM27/shape receipts."""
from pathlib import Path
import hashlib,json,sys,importlib.util,math
R=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
sys.path.insert(0,str(R/'final-payload-checkers-v3'))
spec=importlib.util.spec_from_file_location('shape_checker',R/'final-payload-checkers-v3/check-payload-shape.py');shape_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(shape_module)
review={'scope':'Independent source review plus read-only replay of reviewed saved-payload checker; not an independent triangulator, browser execution, or performance test.','inputs':{},'builds':[]}
for name in ['browser-build-selected-d034-v1','browser-build-needle-1cb4-v1']:
 p=R/name/'result.json';x=load(p);root=Path(x['cwd']);review['inputs'][str(p)]=sha(p)
 assert x['exitCode']==0 and x['trackedSourceUnchanged']and x['rustSourceUnchanged']and x['wasmNewerThanRustSources']and x['singleServedIfcGeometryWasmExactlyMatchesPackage']
 for source,digest in x['sourceBefore'].items():assert sha(root/source)==digest,(name,source)
 assert sha(p.parent/'build.log')==x['logSha256']
 artifacts={r['path']:r for r in x['artifacts']}
 selected=[v for k,v in artifacts.items()if k.startswith('packages/wasm/pkg/ifc-lite')or(k.startswith('apps/viewer/dist/assets/ifc-lite_bg-')and k.endswith('.wasm'))]
 for a in selected:
  actual=root/a['path'];assert sha(actual)==a['sha256']and actual.stat().st_size==a['bytes']
 served=[a for a in selected if a['path'].startswith('apps/')];assert len(served)==1 and served[0]['sha256']==artifacts['packages/wasm/pkg/ifc-lite_bg.wasm']['sha256']
 review['builds'].append({'head':x['head'],'sourceFilesRehashed':len(x['sourceBefore']),'runtimeArtifactsRehashed':selected,'actualSourceBuildCommand':x['command'],'exitCode':0,'servedGeometryWasmMatches':True})
wpath=R/'canonical-wasm-needle-1cb4-v1.json';w=load(wpath)
runpath=R/'native-parity-needle-1cb4-v1/result.json';run=load(runpath);folder=runpath.parent;before=load(folder/'source-before.json');after=load(folder/'source-after.json');assert before==after
for source,digest in before['buildInputsSha256'].items():assert sha(Path(run['checkout'])/source)==digest
for file,key in [('rustc-version.txt','rustc'),('cargo-version.txt','cargo')]:assert sha(folder/file)==run['toolchainReceiptSha256'][key]
assert sha(folder/'run.log')==run['logSha256']and sha(R/'final-payload-checkers-v3/run-native-payload.py')==run['runnerSha256']
wirepath=R/'matched-native-wire-needle-1cb4-v1.json';wire=load(wirepath);m=__import__('fences');assert wire['sourceReceiptSha256']==sha(wpath)
import base64,struct
fields={'jobs':'I','rtcOffset':'d','styleIds':'I','styleColors':'B','materialElementIds':'I','materialColorCounts':'I','materialColors':'B','voidKeys':'I','voidCounts':'I','voidValues':'I'}
for field,code in fields.items():
 view=w['prepass'][field];raw=base64.b64decode(view['base64'],validate=True)
 assert hashlib.sha256(raw).hexdigest()==view['sha256']and len(raw)==view['byteLength']
 assert list(struct.unpack('<'+code*view['length'],raw))==wire[field]
for field in ['unitScale','planeAngleToRadians','needsShift']:assert wire[field]==w['prepass'][field]
shapepath=R/'saved-payload-shape-needle-1cb4-v1.json';shape=load(shapepath);rows=[shape_module.measure(c)for c in w['calls']];assert rows==shape['rows']
by={(r['host'],r['context']):r for r in rows};fractions=[]
for host in shape_module.HOSTS:
 for context in ['one','all']:
  b=by[host,'none'];a=by[host,context];d=math.sqrt(3)*(2*shape_module.GRID+2*shape_module.EPSILON*max(b['maxStoredCoordinate'],a['maxStoredCoordinate']))
  area=(b['perimeterSum']+a['perimeterSum'])*d+2*(b['triangles']+a['triangles'])*d*d
  volume=(b['area']+a['area']+(0 if host==135923 else area))*d
  assert all(mesh['signedVolume']>0 for mesh in a['meshes']+b['meshes'])
  assert abs(a['area']-b['area'])<=area and abs(a['signedVolume']-b['signedVolume'])<=volume and abs(a['absoluteVolume']-b['absoluteVolume'])<=volume
  fractions.append([abs(a['area']-b['area'])/area,abs(a['signedVolume']-b['signedVolume'])/volume])
review.update(all27RowsRemeasuredExactly=True,all18OriginalRustShapeAllowancesPass=True,allIndividualMeshesOutward=True,maxAreaAllowanceFraction=max(x[0]for x in fractions),maxVolumeAllowanceFraction=max(x[1]for x in fractions),nativeBuildInputsAndToolchainLogsRehashed=True,actualPreparedWireFieldsDecodedAndMatched=list(fields),nativeSelectedOpeningAndStyleMaterialPrepassAssertions='Actual adapter canonical API assertions inspected; completed27-context command proves their execution.',deterministicCleanup='Mesh and collection finally blocks inspected; final prepass cache/API cleanup flags true. No allocator-leak or browser memory measurement claimed.',bridgeReviewIndependence='v3/v4 field bridge was authored by this same candidate_audit agent; any review by this agent is self-review. Root supplies independent review.',qualification=False)
for p in [wpath,runpath,wirepath,shapepath,R/'native-wasm-comparison-needle-1cb4-v1.json',R/'browser-needle-1cb4-node-parity-v1.json']:review['inputs'][str(p)]=sha(p)
review['checkerSha256']=sha(__file__)
out=Path(__file__).with_name('review-v2.json');assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(out)
