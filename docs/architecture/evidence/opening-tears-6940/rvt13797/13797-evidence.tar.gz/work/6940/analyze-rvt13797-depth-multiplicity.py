"""Evidence-only all-axis oriented finite-sheet depth/multiplicity diagnostic."""
from pathlib import Path
import json,hashlib,time,collections
import numpy as np
from shapely.geometry import Polygon,LineString
from shapely.ops import unary_union,polygonize,split
base=Path(__file__).resolve().parent;ns={'__file__':str(base/'analyze-rvt13797-projected-coverage.py')}
exec((base/'analyze-rvt13797-projected-coverage.py').read_text().split('rows=[]')[0],ns)
files=ns['files'];docs=ns['docs'];f64=ns['f64'];rotation=ns['rotation'];translation=ns['translation']
def grouped(doc,alt):
 r=next(r for r in doc['rows'] if r['host']==13797 and r['alternate']==alt and r['context']=='all');p=np.array(r['positionsBits'],dtype=np.uint32).view(np.float32).astype(float).reshape(-1,3);rtc=np.array([f64(v) for v in doc['modelFrameRtcOffsetBits']]);p=(p+np.array([f64(v) for v in r['originBits']])+(rtc-translation))@rotation;groups=collections.defaultdict(list)
 for i,ids in enumerate(np.array(r['indices']).reshape(-1,3)):
  t=p[ids];n=np.cross(t[1]-t[0],t[2]-t[0]);assert np.any(n);axis=int(abs(n).argmax());axes=[j for j in range(3) if j!=axis];xy=t[:,axes];poly=Polygon(xy);assert poly.is_valid and poly.area>0
  # Depth solved from actual triangle plane, no authored-plane fit.
  coeff=-n[axes]/n[axis];constant=t[0,axis]-np.dot(coeff,t[0,axes]);groups[(axis,1 if n[axis]>0 else -1)].append({'id':i,'polygon':poly,'coeff':np.array([*coeff,constant])})
 return groups

def depth(c,p):return p@c[:2]+c[2]
def split_depth(poly,c):
 coords=np.array(poly.exterior.coords[:-1]);d=depth(c,coords)
 if not ((d>0).any() and (d<0).any()):return [poly]
 points=[]
 for i in range(len(coords)):
  j=(i+1)%len(coords)
  if d[i]==0:points.append(coords[i])
  if d[i]*d[j]<0:points.append(coords[i]+(coords[j]-coords[i])*(d[i]/(d[i]-d[j])))
 if len(points)<2:return [poly]
 pts=np.array(points);direction=np.array([-c[1],c[0]]);norm=np.linalg.norm(direction)
 if norm==0:return [poly]
 direction/=norm;center=pts.mean(0);size=np.linalg.norm(np.array(poly.bounds[2:])-np.array(poly.bounds[:2]))*2+1
 return [p for p in split(poly,LineString([center-direction*size,center+direction*size])).geoms if p.geom_type=='Polygon' and p.area>0]
start=time.time();rows=[]
for alt in [False,True]:
 groups={k:grouped(doc,alt) for k,doc in docs.items()};out={'alternate':alt,'groups':[]}
 for key in sorted(set(groups['bfa'])|set(groups['needle'])):
  ts={k:g.get(key,[]) for k,g in groups.items()};cells=list(polygonize(unary_union([t['polygon'].boundary for v in ts.values() for t in v])));hist=collections.Counter();mismatches=[];partial=[];maxgap=0.;maxwitness=None;pairedarea=0.;countcells=0;rankpieces=0
  for ci,cell in enumerate(cells):
   pt=cell.representative_point();active={k:[t for t in v if t['polygon'].covers(pt)] for k,v in ts.items()};counts={k:len(v) for k,v in active.items()};hist[(counts['bfa'],counts['needle'])]+=cell.area
   # Audit membership over full cell, not merely one probe. GEOS residuals retained verbatim.
   for arm,v in ts.items():
    ids={t['id'] for t in active[arm]}
    for t in v:
     inter=cell.intersection(t['polygon']).area
     missing=cell.difference(t['polygon']).area if t['id'] in ids else inter
     if missing>0:partial.append({'cell':ci,'arm':arm,'triangle':t['id'],'active':t['id'] in ids,'nonconstantMembershipArea':missing,'cellArea':cell.area})
   if counts['bfa']!=counts['needle']:
    mismatches.append({'cell':ci,'area':cell.area,'bounds':list(cell.bounds),'bfaTriangles':[t['id'] for t in active['bfa']],'needleTriangles':[t['id'] for t in active['needle']]});continue
   if not counts['bfa']:continue
   parts=[cell]
   for arm,v in active.items():
    for i in range(len(v)):
     for j in range(i):
      c=v[i]['coeff']-v[j]['coeff'];parts=[p for part in parts for p in split_depth(part,c)]
   for part in parts:
    p=np.array(part.exterior.coords[:-1]);probe=np.array(part.representative_point().coords[0]);ranks={k:sorted(v,key=lambda t:float(depth(t['coeff'],probe))) for k,v in active.items()}
    for old,new in zip(ranks['bfa'],ranks['needle']):
     value=float(abs(depth(old['coeff']-new['coeff'],p)).max())
     if value>maxgap:maxgap=value;maxwitness={'cell':ci,'bfaTriangle':old['id'],'needleTriangle':new['id'],'vertices2D':p.tolist(),'depthGap':value}
    pairedarea+=part.area;rankpieces+=1
   countcells+=1
  row={'droppedAxis':key[0],'normalSign':key[1],'triangleCounts':{k:len(v) for k,v in ts.items()},'arrangementCells':len(cells),'pairedCells':countcells,'rankStablePieces':rankpieces,'pairedProjectedArea':pairedarea,'maximumPairedDepthGap':maxgap,'maximumWitness':maxwitness,'coverageMultiplicityAreaTable':[{'bfa':a,'needle':b,'area':area} for (a,b),area in sorted(hist.items())],'unmatchedCells':mismatches,'weightedUnmatchedProjectedArea':sum(abs(len(c['bfaTriangles'])-len(c['needleTriangles']))*c['area'] for c in mismatches),'nonconstantMembershipRecords':partial,'nonconstantMembershipAreaSum':sum(p['nonconstantMembershipArea'] for p in partial)};out['groups'].append(row);print(alt,key,'cells',len(cells),'mismatch',row['weightedUnmatchedProjectedArea'],'gap',maxgap,'partial',len(partial),flush=True)
 rows.append(out)
 result={'scope':'Floating GEOS diagnostic, NOT exact certificate. All actual cutfaces assigned dominant authored-frame normal axis and sign; finite projected arrangements retain multiplicity. Each equal-count cell split at every active same-arm depth crossing, pair sorted depths and bound affine differences at all cell vertices. Every nonconstant full-cell membership residual retained, invalidating certificate status rather than silently ignored. Opposite winding separate; axis reassignment may conservatively mismatch. No tolerance, coordinate snapping or acceptance band.','seconds':time.time()-start,'scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sourceSHA256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in files.items()},'rows':rows};(base/'rvt-causal/13797-all-axis-depth-multiplicity-v1.json').write_text(json.dumps(result,indent=2,allow_nan=False))
