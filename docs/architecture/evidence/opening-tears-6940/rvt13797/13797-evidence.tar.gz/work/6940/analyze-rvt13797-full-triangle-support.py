"""Evidence-only full-triangle correspondence upper bounds via finite projection cells.
Every cell uses ONE finite target triangle; no vertex-to-union shortcut or acceptance band.
Floating GEOS/barycentric arithmetic is diagnostic, not an exact rational certificate.
"""
from pathlib import Path
import json,struct,hashlib,collections,time
import numpy as np
from shapely.geometry import Polygon,LineString
from shapely.ops import unary_union,polygonize
root=Path(__file__).resolve().parent
paths={'bfa':root/'rvt-causal/kernel-no-cap-primary-alt-source-cut/rvt-payload.json','needle':root/'final-cap-needle-only-proof-v1/rvt-needle-only-counterfactual-v1/rvt-payload.json'}
def f64(v):return struct.unpack('>d',bytes.fromhex(v))[0]
def mesh(doc,alt):
 r=next(r for r in doc['rows'] if r['host']==13797 and r['alternate']==alt and r['context']=='all');p=np.frombuffer(struct.pack('<'+'I'*len(r['positionsBits']),*r['positionsBits']),dtype='<f4').astype(float).reshape(-1,3)+np.array([f64(v) for v in r['originBits']]);return p[np.array(r['indices']).reshape(-1,3)]
def key(t):
 points=[tuple(p) for p in t];return min(tuple(points[i:]+points[:i]) for i in range(3))
def weights(p,t):
 e=t[1]-t[0];f=t[2]-t[0];q=p-t[0];den=e[0]*f[1]-e[1]*f[0];return np.stack([(q[:,0]*f[1]-q[:,1]*f[0])/den,(e[0]*q[:,1]-e[1]*q[:,0])/den],axis=-1)
def lift(p,t2,t3):
 w=weights(p,t2);return t3[0]+w[:,0,None]*(t3[1]-t3[0])+w[:,1,None]*(t3[2]-t3[0])
def distances(points,triangles):
 a,b,c=triangles[:,0],triangles[:,1],triangles[:,2];ab=b-a;ac=c-a;n=np.cross(ab,ac);n2=(n*n).sum(1);out=[]
 for p in points:
  ap=p-a;off=(ap*n).sum(1);q=ap-n*(off/n2)[:,None];v=(np.cross(q,ac)*n).sum(1)/n2;w=(np.cross(ab,q)*n).sum(1)/n2;d=np.where((v>=0)&(w>=0)&(v+w<=1),off*off/n2,np.inf)
  for u,z in [(a,b),(b,c),(c,a)]:
   e=z-u;parameter=np.clip(((p-u)*e).sum(1)/(e*e).sum(1),0,1);delta=p-(u+e*parameter[:,None]);d=np.minimum(d,(delta*delta).sum(1))
  out.append(np.sqrt(d))
 return np.array(out)
def fixed_bound(p,targets,eligible):
 m=distances(p,targets).max(axis=0);m=np.where(eligible,m,np.inf);i=int(m.argmin());return float(m[i]),i

def face_bound(index,t,targets,normals):
 n=np.cross(t[1]-t[0],t[2]-t[0]);axis=int(abs(n).argmax());axes=[i for i in range(3) if i!=axis];a=t[:,axes];shape=Polygon(a);b=targets[:,:,axes];den=(b[:,1,0]-b[:,0,0])*(b[:,2,1]-b[:,0,1])-(b[:,1,1]-b[:,0,1])*(b[:,2,0]-b[:,0,0]);eligible=(normals*n).sum(1)>0
 out={'sourceTriangle':index,'projectionDroppedAxis':axis,'cells':0,'uncoveredProjectionCells':0,'orientedFallbackCells':0,'projectionArea':shape.area,'fallbackWholeFace':False,'maximumBound':0.,'maximumSameHemisphereBound':0.,'worstCell':None}
 try:
  assert shape.is_valid and shape.area>0
  lo=a.min(0);hi=a.max(0);overlap=(b.max(1)>=lo).all(1)&(b.min(1)<=hi).all(1)&(den!=0);lines=[shape.boundary]
  for j in np.nonzero(overlap)[0]:
   poly=Polygon(b[j]);assert poly.is_valid
   clipped=poly.boundary.intersection(shape)
   if not clipped.is_empty:lines.append(clipped)
  cells=[]
  for cell in polygonize(unary_union(lines)):
   clipped=cell.intersection(shape)
   if clipped.is_empty:continue
   parts=list(clipped.geoms) if clipped.geom_type=='MultiPolygon' else [clipped]
   cells.extend(p for p in parts if p.geom_type=='Polygon' and p.area>0)
  leftover=shape.difference(unary_union(cells));out['projectionCoverageLeftoverArea']=leftover.area
  assert leftover.is_empty and cells
  for cell in cells:
   p=np.array(cell.exterior.coords[:-1]);source=lift(p,a,t);candidates=[];oriented=[]
   for j in np.nonzero(overlap)[0]:
    w=weights(p,b[j]);inside=(w>=0).all() and (w.sum(1)<=1).all()
    if not inside:continue
    target=targets[j,0]+w[:,0,None]*(targets[j,1]-targets[j,0])+w[:,1,None]*(targets[j,2]-targets[j,0]);value=float(np.linalg.norm(source-target,axis=1).max());candidates.append((value,int(j)))
    if eligible[j]:oriented.append((value,int(j)))
   if candidates:value,target=min(candidates)
   else:value,target=fixed_bound(source,targets,np.ones(len(targets),dtype=bool));out['uncoveredProjectionCells']+=1
   if oriented:ovalue,otarget=min(oriented)
   else:ovalue,otarget=fixed_bound(source,targets,eligible);out['orientedFallbackCells']+=1
   out['cells']+=1
   if value>out['maximumBound']:out['maximumBound']=value;out['worstCell']={'targetTriangle':target,'sourceCellVertices3D':source.tolist(),'projectedCellArea':cell.area,'construction':'affine finite triangle graph' if candidates else 'one fixed convex finite target triangle distance bound'}
   out['maximumSameHemisphereBound']=max(out['maximumSameHemisphereBound'],ovalue)
 except Exception as error:
  value,target=fixed_bound(t,targets,np.ones(len(targets),dtype=bool));ovalue,otarget=fixed_bound(t,targets,eligible);out.update(fallbackWholeFace=True,error=f'{type(error).__name__}: {error}',maximumBound=value,maximumSameHemisphereBound=ovalue,worstCell={'targetTriangle':target,'sourceCellVertices3D':t.tolist(),'construction':'conservative one fixed finite target triangle bound for entire sourceface'})
 return out
started=time.time();docs={k:json.load(open(p)) for k,p in paths.items()};rows=[]
for alt in [False,True]:
 ts={k:mesh(d,alt) for k,d in docs.items()}
 for source,target in [('bfa','needle'),('needle','bfa')]:
  remaining=collections.Counter(map(key,ts[target]));changed=[];common=0
  for i,t in enumerate(ts[source]):
   k=key(t)
   if remaining[k]:remaining[k]-=1;common+=1
   else:changed.append((i,t))
  targets=ts[target];normals=np.cross(targets[:,1]-targets[:,0],targets[:,2]-targets[:,0]);assert np.all((normals*normals).sum(1)>0)
  records=[]
  for i,t in changed:records.append(face_bound(i,t,targets,normals))
  row={'alternate':alt,'direction':source+'→'+target,'exactCommonOrientedTriangleInstances':common,'changedTriangleInstances':len(records),'fullTriangleMaximumDistanceUpperBound':max(r['maximumBound'] for r in records),'sameHemisphereMaximumDistanceUpperBound':max(r['maximumSameHemisphereBound'] for r in records),'wholeFaceConservativeFallbacks':sum(r['fallbackWholeFace'] for r in records),'records':records};rows.append(row);print({k:v for k,v in row.items() if k!='records'},flush=True)
out=root/'rvt-causal/13797-full-triangle-support-needle-v1.json';out.write_text(json.dumps({'scope':'All changedtriangles in commonactualRTC+origin frame; common orientedtriangles matchedwithmultiplicity give zero. Complete projectedfinite-target arrangements subdivide eachsourceface; eachcell assignedonefinite target triangle and allcellvertices evaluated afteraffinelifting. Norm ofaffine difference isconvex; fixedtarget convexdistances boundfallbackcells. Bothdirections. No chosenacceptanceband. FloatingGEOS/Float64 arithmetic is diagnostic, NOT an exactrational proof. Samehemisphere means rawcrossnormaldot>0, notmaterialidentity; orientedmultiplicity planeanalysis is separate.','scriptSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'sourceSHA256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()},'seconds':time.time()-started,'rows':rows},indent=2,allow_nan=False))
