#!/usr/bin/env python3
"""Bounded pinned authoring oracle; no reference, source, or tolerance changes."""
import base64,collections,hashlib,json,math,platform,re,sys,time,traceback
from pathlib import Path
import ifcopenshell,ifcopenshell.geom,ifcopenshell.util.placement,ifcopenshell.util.unit
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools/ifcopenshell_reference'))
import canonical
OUT=ROOT/'work/6940/rvt-four-wall-authoring-oracle-085-v1'
OUT.mkdir(exist_ok=False)
PATH=Path('/tmp/ifc-6940-consol-818b/tests/models/various/rvt01.ifc')
DATA=PATH.read_bytes();SHA=hashlib.sha256(DATA).hexdigest()
MANIFEST={x['path']:x for x in json.loads((ROOT/'tests/models/manifest.json').read_text())['files']}
assert len(DATA)==MANIFEST['various/rvt01.ifc']['size'] and SHA==MANIFEST['various/rvt01.ifc']['sha256']
assert ifcopenshell.version=='0.8.5' and np.__version__=='2.0.2'
MODEL=ifcopenshell.open(str(PATH));SCALE=ifcopenshell.util.unit.calculate_unit_scale(MODEL)
STARTS={int(m[1]):m.start() for m in re.finditer(rb'(?m)^[ \t]*#(\d+)\s*=',DATA)}

def authored_step(id):
    start=STARTS[id];p=start;quoted=False
    while p<len(DATA):
        if DATA[p:p+1]==b"'":
            if quoted and DATA[p:p+2]==b"''":p+=2;continue
            quoted=not quoted
        elif not quoted and DATA[p:p+2]==b'/*':
            end=DATA.index(b'*/',p+2);p=end+2;continue
        elif not quoted and DATA[p:p+1]==b';':
            raw=DATA[start:p+1]
            return {'offset':start,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'base64':base64.b64encode(raw).decode(),'text':raw.decode('utf-8')}
        p+=1
    raise ValueError('unterminated entity')

def authored_graph(host):
    openings=[r.RelatedOpeningElement for r in host.HasOpenings]
    stack=[host.Representation,host.ObjectPlacement]
    for opening in openings:stack.extend([opening.Representation,opening.ObjectPlacement])
    for rel in host.HasAssociations:
        if rel.is_a('IfcRelAssociatesMaterial'):stack.append(rel.RelatingMaterial)
    seen={}
    while stack:
        value=stack.pop()
        if isinstance(value,(tuple,list)):stack.extend(value)
        elif isinstance(value,ifcopenshell.entity_instance) and value.id():
            if value.id() in seen:continue
            assert len(seen)<100000,'bounded authoring graph budget exhausted'
            seen[value.id()]={'id':value.id(),'type':value.is_a(),'originalStep':authored_step(value.id())}
            stack.extend(value)
    items=[{'representationId':rep.id(),'identifier':rep.RepresentationIdentifier,'type':rep.RepresentationType,
        'items':[{'id':item.id(),'type':item.is_a()} for item in rep.Items]} for rep in host.Representation.Representations]
    return {'host':host.id(),'ifcType':host.is_a(),'GlobalId':host.GlobalId,'originalHostStep':authored_step(host.id()),
        'representationItems':items,'placementInIfcUnits':ifcopenshell.util.placement.get_local_placement(host.ObjectPlacement).tolist(),
        'openingIds':[o.id() for o in openings],'openingPlacementsInIfcUnits':{str(o.id()):ifcopenshell.util.placement.get_local_placement(o.ObjectPlacement).tolist() for o in openings},
        'reachableEntities':list(sorted(seen.values(),key=lambda e:e['id'])),'fixtureSha256':SHA,'unitScaleToMetres':SCALE}

def round_away(v):
    a=abs(v);i=math.floor(a);i+=a-i>=.5
    return -i if v<0 else i

def metric(vertices,faces):
    v=np.asarray(vertices,dtype=np.float64).reshape(-1,3);f=np.asarray(faces,dtype=np.int64).reshape(-1,3)
    assert np.all(np.isfinite(v)) and len(f)>0 and np.all(f>=0) and np.all(f<len(v))
    crosses=np.cross(v[f[:,1]]-v[f[:,0]],v[f[:,2]]-v[f[:,0]])
    edges=collections.defaultdict(lambda:[0,0]);collapsed=0
    for face in f:
        q=[tuple(round_away(float(x)*65536) for x in v[i]) for i in face]
        a,b,c=q;ab=[b[k]-a[k] for k in range(3)];ac=[c[k]-a[k] for k in range(3)]
        collapsed+=(ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0])==(0,0,0)
        for a,b in [(a,b),(b,c),(c,a)]:edges[(min(a,b),max(a,b))][a>b]+=1
    bad=sum(x!=[1,1] for x in edges.values())
    return {'triangles':len(f),'area':math.fsum(np.linalg.norm(crosses,axis=1).tolist())*.5,
        'signedVolume':canonical.signed_volume(vertices,faces),'zeroAreaTriangles':int(np.count_nonzero(np.all(crosses==0,axis=1))),
        'strictGridUnmatchedEdges':bad,'strictGridCollapsed':collapsed,'strictGridClosedNoncollapsed':bad==collapsed==0,
        'volumeInterpretation':'closed oriented boundary' if bad==collapsed==0 else 'algebraic surface integral; not a certified solid volume'}

summary={'engine':ifcopenshell.version,'python':platform.python_version(),'numpy':np.__version__,'fixturePath':str(PATH),'fixtureSha256':SHA,'fixtureBytes':len(DATA),'unitScaleToMetres':SCALE,
    'scriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'requirementsLockSha256':hashlib.sha256((ROOT/'tools/ifcopenshell_reference/requirements.lock').read_bytes()).hexdigest(),
    'scope':'Independent pinned source/cut world-coordinate oracle. Representation-item groups are reported separately; touching layers can make aggregate strict incidence nonmanifold without an individual-layer defect.',
    'rows':[],'errors':[]}
for id in [8997,13735,13797,14132]:
    host=MODEL.by_id(id)
    (OUT/f'{id}-authored.json').write_text(json.dumps(authored_graph(host),indent=2,allow_nan=False))
    for disable in [True,False]:
        row={'model':'various/rvt01.ifc','fixtureSha256':SHA,'host':id,'ifcType':host.is_a(),'disableOpeningSubtractions':disable,'unitScaleToMetres':SCALE,
            'placementInIfcUnits':ifcopenshell.util.placement.get_local_placement(host.ObjectPlacement).tolist()}
        try:
            settings=ifcopenshell.geom.settings();settings.set(settings.USE_WORLD_COORDS,True);settings.set(settings.WELD_VERTICES,True);settings.set(settings.DISABLE_OPENING_SUBTRACTIONS,disable)
            settings_snapshot={}
            for name in settings.setting_names():
                try:settings_snapshot[name]={'valueRepr':repr(settings.get(name))}
                except RuntimeError as e:settings_snapshot[name]={'unsetError':str(e)}
            started=time.monotonic();shape=ifcopenshell.geom.create_shape(settings,host)
            vertices=list(shape.geometry.verts);faces=list(shape.geometry.faces);item_ids=list(shape.geometry.item_ids);material_ids=list(shape.geometry.material_ids)
            assert len(item_ids)==len(faces)//3 and len(material_ids)==len(item_ids)
            groups=[]
            for item in sorted(set(item_ids)):
                offsets=[i for i,x in enumerate(item_ids) if x==item];part_faces=[k for i in offsets for k in faces[i*3:i*3+3]]
                groups.append({'representationItemId':item,'faceIndices':offsets,'metrics':metric(vertices,part_faces)})
            row.update(canonical=canonical.element_record(id,host.is_a(),vertices,faces),metrics=metric(vertices,faces),
                settings=settings_snapshot,engineSeconds=time.monotonic()-started,vertices=vertices,faces=faces,faceItemIds=item_ids,faceMaterialIds=material_ids,
                representationItemGroups=groups,geometryId=shape.geometry.id)
            name=f'{id}-'+('source' if disable else 'cut')+'.json';raw=json.dumps(row,indent=2,allow_nan=False).encode();(OUT/name).write_bytes(raw)
            summary['rows'].append({k:v for k,v in row.items() if k not in ['vertices','faces','faceItemIds','faceMaterialIds','settings']}|{'payload':name,'payloadSha256':hashlib.sha256(raw).hexdigest()})
            print(id,'source' if disable else 'cut',row['metrics'],'items',[(g['representationItemId'],g['metrics']['triangles'],g['metrics']['strictGridUnmatchedEdges']) for g in groups],flush=True)
        except Exception as e:
            row.update(error=repr(e),traceback=traceback.format_exc());summary['errors'].append(row);print(row['traceback'],flush=True)
        (OUT/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
assert len(summary['rows'])==8 and not summary['errors'],summary['errors']
