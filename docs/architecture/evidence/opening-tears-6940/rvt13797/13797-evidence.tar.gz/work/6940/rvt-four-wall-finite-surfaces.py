"""Evidence only: finite per-item oracle + authored local opening correspondence.
No geometry repair, tolerance acceptance, or production path changes.
"""
import json, hashlib, math
from pathlib import Path
from fractions import Fraction as F
import ifcopenshell
import ifcopenshell.util.placement as placement
from shapely.geometry import Polygon
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'rvt-four-wall-authoring-oracle-085-v1'
OUT=ROOT/'rvt-four-wall-finite-surfaces-v1'
OUT.mkdir(exist_ok=False)
MODEL=Path('/tmp/ifc-6940-consol-818b/tests/models/various/rvt01.ifc')
f=ifcopenshell.open(str(MODEL))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,data):
 with (OUT/name).open('x') as o: json.dump(data,o,indent=2,allow_nan=False)
def matrix(p):
 m=placement.get_axis2placement(p).tolist()
 assert all(x in (-1.,0.,1.) for row in m[:3] for x in row[:3])
 return [[F(x) for x in row] for row in m]
def mul(a,b): return [[sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
def apply(m,p):
 q=[F(x) for x in p]+[F(0)]*(3-len(p))+[F(1)]
 return [sum(m[i][k]*q[k] for k in range(4)) for i in range(3)]
def ring(m,c):
 assert c.is_a('IfcIndexedPolyCurve') and c.Segments is None
 return [apply(m,p) for p in c.Points.CoordList]
def floats(p): return [[float(v) for v in row] for row in p]
def solid(i,m):
 assert tuple(i.ExtrudedDirection.DirectionRatios)==(0.,0.,1.)
 points=ring(m,i.SweptArea.OuterCurve)
 assert all(p[1]==points[0][1] for p in points)
 lo,hi=sorted([points[0][1],points[0][1]+m[1][2]*F(i.Depth)])
 holes=[ring(m,c) for c in getattr(i.SweptArea,'InnerCurves',[])]
 return {'item':i.id(),'outer':points,'holes':holes,'y':[lo,hi]}
def poly(points): return Polygon([(float(p[0]),float(p[2])) for p in points])
def area2(p): return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))
def exact_convex_intersection(a,b):
 a=[(p[0],p[2]) for p in a]; b=[(p[0],p[2]) for p in b]
 if a[0]==a[-1]:a.pop()
 if b[0]==b[-1]:b.pop()
 if area2(b)<0:b.reverse()
 def cross(u,v,p):return (v[0]-u[0])*(p[1]-u[1])-(v[1]-u[1])*(p[0]-u[0])
 if any(cross(u,v,p)<0 for u,v in zip(b,b[1:]+b[:1]) for p in b): return None
 original=abs(area2(a))/2
 for u,v in zip(b,b[1:]+b[:1]):
  output=[]
  for p,q in zip(a,a[1:]+a[:1]):
   cp,cq=cross(u,v,p),cross(u,v,q)
   if cp>=0:output.append(p)
   if (cp<0 and cq>0) or(cp>0 and cq<0):
    t=cp/(cp-cq);output.append(tuple(p[j]+t*(q[j]-p[j]) for j in (0,1)))
  a=output
  if not a:break
 return original-(abs(area2(a))/2 if a else 0)
report=[]
for hid in [8997,13735,13797,14132]:
 h=f.by_id(hid);items=[i for rep in h.Representation.Representations if rep.RepresentationIdentifier=='Body' for i in rep.Items]
 openings=[]
 for rel in h.HasOpenings:
  o=rel.RelatedOpeningElement
  assert o.ObjectPlacement.PlacementRelTo==h.ObjectPlacement
  om=matrix(o.ObjectPlacement.RelativePlacement)
  for rep in o.Representation.Representations:
   for i in rep.Items:
    s=solid(i,mul(om,matrix(i.Position)));s['opening']=o.id();openings.append(s)
 authored=[];pairs=[]
 for i in items:
  if i.is_a('IfcExtrudedAreaSolid'):
   s=solid(i,matrix(i.Position));authored.append({'item':i.id(),'type':i.is_a(),'outerHost':floats(s['outer']),'holesHost':[floats(p) for p in s['holes']],'depthIntervalHostY':[float(x) for x in s['y']]})
   for o in openings:
    overlap=max(F(0),min(s['y'][1],o['y'][1])-max(s['y'][0],o['y'][0]))
    row={'item':i.id(),'opening':o['opening'],'depthOverlap':float(overlap)}
    if overlap:
     op=poly(o['outer']); hs=[poly(p) for p in s['holes']]; best=min(range(len(hs)),key=lambda k:op.hausdorff_distance(hs[k]))
     excess=exact_convex_intersection(o['outer'],s['holes'][best])
     row.update({'matchedHoleIndex':best,'footprintBoundaryHausdorffMetres':op.boundary.hausdorff_distance(hs[best].boundary),'openingMinusMatchedHoleAreaShapely':op.difference(hs[best]).area,'matchedHoleMinusOpeningAreaShapely':hs[best].difference(op).area,'openingOutsideOuterAreaShapely':op.difference(poly(s['outer'])).area,'exactDyadicOpeningMinusConvexHoleArea':None if excess is None else {'numerator':str(excess.numerator),'denominator':str(excess.denominator),'float':float(excess)}})
    pairs.append(row)
  else:
   assert i.is_a('IfcPolygonalFaceSet')
   authored.append({'item':i.id(),'type':i.is_a(),'coordinatesHost':[list(p) for p in i.Coordinates.CoordList],'faces':[{'id':v.id(),'outerIndices1Based':list(v.CoordIndex),'innerIndices1Based':[list(x) for x in getattr(v,'InnerCoordIndices',[])]} for v in i.Faces]})
 for mode in ['source','cut']:
  path=SRC/f'{hid}-{mode}.json';d=json.loads(path.read_text());vertices=d['vertices'];faces=d['faces'];ids=d['faceItemIds']
  # Oracle original arrays are flat; retain source index correspondence exactly.
  assert len(vertices)%3==0 and len(faces)%3==0 and len(ids)==len(faces)//3
  layers=[]
  for iid in sorted(set(ids)):
   offsets=[j for j,item in enumerate(ids) if item==iid]
   layers.append({'item':iid,'originalFaceOffsets':offsets,'triangleIndices':[faces[3*j:3*j+3] for j in offsets]})
  dump(f'{hid}-{mode}-finite-surfaces.json',{'host':hid,'mode':mode,'sourceReceipt':str(path),'sourceSha256':sha(path),'coordinateFrame':'IFC world metres, f64 as emitted by pinned IfcOpenShell0.8.5; no recentering or snapping','placementInIfcUnits':d['placementInIfcUnits'],'worldVerticesFlat':vertices,'layers':layers,'limitations':'Use finite triangles, not infinite supporting planes. Layers can touch; preserve item membership. These are engine f64 surfaces, not exact authored decimal arithmetic.'})
 dump(f'{hid}-authored-correspondence.json',{'host':hid,'sourceAuthoredReceiptSha256':sha(SRC/f'{hid}-authored.json'),'arithmetic':'Host-local transforms use exact rational arithmetic over decoded IFC f64 values; transforms are signed permutations+translations. Float JSON presentation can round. Exact dyadic clipping is provided only for convex hole rings. Shapely metrics are numerical diagnostics, not an exact no-op certificate.','items':authored,'openings':[{'opening':o['opening'],'item':o['item'],'outerHost':floats(o['outer']),'depthIntervalHostY':[float(x) for x in o['y']]} for o in openings],'pairs':pairs})
 report.append({'host':hid,'items':len(items),'openings':len(openings),'pairs':pairs})
dump('summary.json',{'fixtureSha256':sha(MODEL),'scriptSha256':sha(Path(__file__)),'rows':report,'verdict':'No universal exact no-op assertion: literal decoded authored boundaries have small nonzero footprint differences. Per-item independent finite source/cut surfaces and exact local placements are supplied for physical comparisons. Polygonal item13842/reveal13864 is separately authored and requires finite face analysis, not an extrusion-hole inference.'})
print(json.dumps(report,indent=2))
