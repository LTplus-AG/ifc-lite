// Browser-side evidence adapter. Import through the owned HTTPS viewer origin.
// await import('/__6940/cohort.mjs').then(m => m.startSample({ id, side, fixture:'fzk', pair:1 }))
// Returns immediately; inspect globalThis.__IFC_6940_SAMPLE__. Close the tab only
// after persistence='saved'. A crash leaves the durable .begin intent unfinished.
import { waitForMetadataRenderReadiness, probePageLoadTrace, READINESS_SPANS } from '/__6940/modules/metadata-render-readiness.js';
import { metricsFromLoadTrace, countersFromLoadTrace, settleKey } from '/__6940/modules/load-trace-metrics.js';
import { gpuHealthFrom } from '/__6940/modules/gpu-health.js';
import { requireTimingUploads } from '/__6940/modules/benchmark-upload-mode.mjs';

const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const must = (test, message) => { if (!test) throw new Error(message); };
async function sha(bytes) {
  // WebCrypto rejects views backed by SharedArrayBuffer. Hash an owned copy;
  // this runs outside the measurement window and cannot mutate worker payloads.
  const view = ArrayBuffer.isView(bytes)
    ? new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength)
    : new Uint8Array(bytes);
  const digest = await crypto.subtle.digest('SHA-256', Uint8Array.from(view));
  return [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
}
async function request(path, body) {
  const response = await fetch(path, body === undefined ? { cache: 'no-store' } : {
    method: 'POST', cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const value = await response.json();
  must(response.ok, `${path}: HTTP${response.status}: ${JSON.stringify(value)}`);
  return value;
}
const traceApi = () => globalThis.__IFC_LITE_LOAD_TRACE__;
const trace = () => traceApi()?.latest?.() ?? null;
const storeState = () => globalThis.__ifc_lite_viewer_store__?.getState();
// Lossless structural encoder: every own data field is retained; exact typed
// bytes are hashed from owned copies (including SharedArrayBuffer views).
// Unknown prototypes, accessors, symbols and cycles fail explicitly.
function captureValue(value, path = '$', active = new WeakSet()) {
  if (value === undefined) return { type: 'undefined' };
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number') return Number.isFinite(value) && !Object.is(value, -0)
    ? value : { type: 'number', value: Object.is(value, -0) ? '-0' : String(value) };
  if (typeof value === 'bigint') return { type: 'bigint', value: value.toString() };
  must(typeof value === 'object', `Unsupported ${typeof value} at ${path}`);
  must(!active.has(value), `Cycle at ${path}`);
  active.add(value);
  try {
    const name = value.constructor?.name;
    if (ArrayBuffer.isView(value)) return { type: name, length: value.length ?? null,
      byteLength: value.byteLength, ownedBytes: Uint8Array.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) };
    if (value instanceof ArrayBuffer || typeof SharedArrayBuffer !== 'undefined' && value instanceof SharedArrayBuffer) {
      return { type: 'ArrayBufferBytes', byteLength: value.byteLength, ownedBytes: Uint8Array.from(new Uint8Array(value)) };
    }
    if (value instanceof Map) return { type: 'Map', entries: [...value].map(([key, child], index) =>
      [captureValue(key, `${path}.key${index}`, active), captureValue(child, `${path}.value${index}`, active)]) };
    if (value instanceof Set) return { type: 'Set', values: [...value].map((child, index) => captureValue(child, `${path}.set${index}`, active)) };
    const keys = Reflect.ownKeys(value);
    must(keys.every(key => typeof key === 'string'), `Symbol key at ${path}`);
    if (Array.isArray(value)) {
      const unexpected = keys.filter(key => key !== 'length' && !/^(0|[1-9][0-9]*)$/.test(key));
      must(unexpected.length === 0, `Extra array fields at ${path}: ${unexpected}`);
      return { type: 'Array', values: Array.from({ length: value.length }, (_, index) =>
        Object.hasOwn(value, index) ? captureValue(value[index], `${path}[${index}]`, active) : { type: 'hole' }) };
    }
    must(Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null,
      `Unsupported prototype ${name} at ${path}`);
    return { type: 'Object', entries: keys.sort().map(key => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      must(Object.hasOwn(descriptor, 'value'), `Accessor at ${path}.${key}`);
      return [key, captureValue(descriptor.value, `${path}.${key}`, active)];
    }) };
  } finally { active.delete(value); }
}
const canonicalCompare = (a, b) => { const x = JSON.stringify(a); const y = JSON.stringify(b); return x < y ? -1 : x > y ? 1 : 0; };
async function finishCapture(node) {
  if (!node || typeof node !== 'object') return node;
  if (node.ownedBytes instanceof Uint8Array) {
    const { ownedBytes, ...metadata } = node;
    return { ...metadata, sha256: await sha(ownedBytes) };
  }
  if (Array.isArray(node)) {
    const result = [];
    for (const child of node) result.push(await finishCapture(child));
    return result;
  }
  const result = {};
  for (const [key, value] of Object.entries(node)) result[key] = await finishCapture(value);
  if (result.type === 'Map') result.entries.sort((a, b) => canonicalCompare(a[0], b[0]));
  return result;
}
const encoded = value => finishCapture(captureValue(value));
const objectHash = value => sha(new TextEncoder().encode(JSON.stringify(value)));

function residentScene() {
  const canvas = document.querySelector('canvas');
  must(canvas, 'Viewport canvas absent');
  const key = Object.keys(canvas).find(key => key.startsWith('__reactFiber$'));
  must(key, 'Read-only renderer inspection unavailable: canvas React fiber absent');
  const renderers = new Set();
  for (let fiber = canvas[key], depth = 0; fiber && depth < 40; fiber = fiber.return, depth++) {
    for (let hook = fiber.memoizedState, depth = 0; hook && depth < 200; hook = hook.next, depth++) {
      const ref = hook.memoizedState?.current;
      if (typeof ref?.getScene === 'function' && ref.canvas === canvas) renderers.add(ref);
    }
  }
  must(renderers.size === 1, `Expected one canvas renderer ref, found ${renderers.size}`);
  return [...renderers][0].getScene();
}

export async function payloadIdentity() {
  const state = storeState();
  must(state?.models instanceof Map && state.models.size === 1, 'Exactly one model required');
  must(state.pendingInstancedShards == null, 'Unconsumed instanced shards: geometry not settled');
  const scene = residentScene();
  must(Array.isArray(scene.instancedTemplateCpu) && scene.instancedEntityMap instanceof Map,
    'Renderer CPU instance graph absent: complete geometry identity unavailable');
  const model = [...state.models.values()][0];
  const result = model.geometryResult;
  must(result?.meshes?.length > 0, 'No retained flat payload');
  for (const mesh of result.meshes) must(mesh.positions?.length && mesh.indices?.length, 'CPU flat payload pruned');
  const liveSlots = scene.instancedTemplateCpu.map((template, index) => template ? index : null).filter(index => index !== null);
  const gpuSlots = scene.instancedTemplates.map((template, index) => template ? index : null).filter(index => index !== null);
  must(JSON.stringify(liveSlots) === JSON.stringify(gpuSlots), 'GPU instance template lacks CPU payload');
  const rawInstances = captureValue({ templates: scene.instancedTemplateCpu, entities: scene.instancedEntityMap });
  const normalizedInstances = [];
  const recordUses = new Set();
  const templateRows = [];
  for (const slot of liveSlots) {
    const template = scene.instancedTemplateCpu[slot];
    const gpu = scene.instancedTemplates[slot];
    must(template.positions?.length && template.indices?.length, 'Instance geometry pruned');
    must(template.instanceData instanceof ArrayBuffer && template.instanceData.byteLength === gpu.instanceCount * 88,
      'Packed instance stride/count mismatch (source contract88 bytes)');
    must(template.canonicalAnchors.length === gpu.instanceCount * 3 && template.canonicalMatrixTranslations.length === gpu.instanceCount * 3,
      'Instance canonical anchor/translation count mismatch');
    const { instanceData, canonicalAnchors, canonicalMatrixTranslations, ...geometry } = template;
    templateRows[slot] = { template, geometry: captureValue(geometry), count: gpu.instanceCount };
  }
  for (const [entityId, occurrences] of scene.instancedEntityMap) {
    for (const occurrence of occurrences) {
      const { templateIndex, byteOffset, ...provenance } = occurrence;
      const row = templateRows[templateIndex];
      must(row && Number.isInteger(byteOffset) && byteOffset >= 0 && byteOffset % 88 === 0 && byteOffset + 88 <= row.template.instanceData.byteLength,
        `Invalid instance addressing for entity${entityId}`);
      const recordKey = `${templateIndex}:${byteOffset}`;
      must(!recordUses.has(recordKey), 'Duplicate occurrence record reference'); recordUses.add(recordKey);
      const ordinal = byteOffset / 88;
      must(new DataView(row.template.instanceData).getUint32(byteOffset + 64, true) === entityId, 'Occurrence entity id lane mismatch');
      normalizedInstances.push({ entityId: captureValue(entityId), provenance: captureValue(provenance),
        template: row.geometry,
        record: captureValue(new Uint8Array(row.template.instanceData, byteOffset, 88)),
        canonicalAnchor: captureValue(row.template.canonicalAnchors.subarray(ordinal * 3, ordinal * 3 + 3)),
        canonicalMatrixTranslation: captureValue(row.template.canonicalMatrixTranslations.subarray(ordinal * 3, ordinal * 3 + 3)) });
    }
  }
  must(recordUses.size === templateRows.reduce((total, row) => total + (row?.count ?? 0), 0), 'Unreferenced instance records');
  // Hash one mesh/field at a time: the complete typed payload participates,
  // while a heavy model does not expand into hundreds of MB of JSON receipts.
  const meshRows = [];
  for (const mesh of result.meshes) {
    const full = await encoded(mesh);
    meshRows.push({ expressId: mesh.expressId, geometryItemId: mesh.geometryItemId ?? null,
      geometryClass: mesh.geometryClass ?? null, vertices: mesh.positions.length / 3,
      triangles: mesh.indices.length / 3, sha256: await objectHash(full) });
  }
  meshRows.sort(canonicalCompare);
  const geometryResultFields = [];
  const resultKeys = Reflect.ownKeys(result);
  must(resultKeys.every(key => typeof key === 'string'), 'Symbol geometryResult key');
  for (const key of resultKeys.sort()) {
    const descriptor = Object.getOwnPropertyDescriptor(result, key);
    must(Object.hasOwn(descriptor, 'value'), `geometryResult accessor${key}`);
    const value = key === 'meshes' ? { type: 'SortedMeshMerkleRows', rows: meshRows }
      : await encoded(descriptor.value);
    geometryResultFields.push({ field: key, sha256: await objectHash(value) });
  }
  const instances = [];
  for (const row of normalizedInstances) instances.push({ entityId: row.entityId,
    sha256: await objectHash(await finishCapture(row)) });
  instances.sort(canonicalCompare);
  const rawInstanceGraphSha256 = await objectHash(await finishCapture(rawInstances));
  const geometry = { schema: 'ifc6940-complete-cpu-geometry-merkle-v3', geometryResultFields,
    flatMeshMerkleRows: meshRows, normalizedInstanceMerkleRows: instances };
  const specialSlabs = [];
  for (const id of [135923, 137627, 139545, 141434, 143323, 145212, 151760, 154626, 150890]) {
    const rows = [];
    for (const mesh of result.meshes.filter(mesh => mesh.expressId === id)) rows.push({
      expressId: mesh.expressId, geometryItemId: mesh.geometryItemId ?? null, geometryClass: mesh.geometryClass ?? null,
      positions: await sha(mesh.positions), normals: await sha(mesh.normals), indices: await sha(mesh.indices),
      origin: [...(mesh.origin ?? [0, 0, 0])], vertices: mesh.positions.length / 3, triangles: mesh.indices.length / 3,
    });
    rows.sort(canonicalCompare); specialSlabs.push({ expressId: id, meshes: rows });
  }
  return { schema: 3, scope: 'Every own geometryResult field, all exact flat-mesh data/material/texture/provenance fields; complete resident CPU instance geometry, packed transforms/colors/finish flags, canonical anchors/translations and occurrence provenance',
    normalization: 'Object and Map keys sorted; flat mesh and normalized occurrence rows sorted with duplicates retained. Transient templateIndex/byteOffset addressing replaced by exact referenced template/record content. Raw instance graph addressing is hashed separately. Complete values are traversed before compact Merkle summaries are emitted; per-mesh/instance hashes retain all fields.',
    limitations: ['CPU source payload identity; no GPU buffer readback or pixel identity.', 'Private scene access through read-only canvas React ref; absent/pruned/unknown fields fail closed.'],
    models: [{ name: model.name, loadPath: model.loadPath, cacheState: model.cacheState, meshCount: result.meshes.length,
      flatVertices: result.meshes.reduce((sum, mesh) => sum + mesh.positions.length / 3, 0),
      flatTriangles: result.meshes.reduce((sum, mesh) => sum + mesh.indices.length / 3, 0),
      instanceEntities: scene.instancedEntityMap.size, instanceTemplates: liveSlots.length, instanceOccurrences: instances.length,
      geometry, completeGeometryPayloadSha256: await objectHash(geometry),
      rawInstanceGraph: { templateSlots: scene.instancedTemplateCpu.length, instanceEntities: scene.instancedEntityMap.size,
        instanceOccurrences: recordUses.size, addressingRetainedInSha256: true }, rawInstanceGraphSha256, specialSlabs }],
  };
}

export function startSample(options) {
  must(!globalThis.__IFC_6940_SAMPLE__, 'One sample per fresh tab; existing sample retained');
  must(/^[a-zA-Z0-9_-]{1,120}$/.test(options.id), 'Unique bounded sample id required');
  must(['base', 'branch'].includes(options.side), 'Explicit base/branch required');
  must(Number.isInteger(options.pair) && options.pair >= 1, 'Pair number required');
  must(options.timeoutMs === undefined || Number.isFinite(options.timeoutMs) && options.timeoutMs > 0 && options.timeoutMs <= 600_000,
    'Readiness timeout must be positive and at most600000ms');
  const status = globalThis.__IFC_6940_SAMPLE__ = { id: options.id, stage: 'preparing', persistence: 'pending' };
  void run(options, status);
  return { ...status };
}

// The controller reads canonical host admission AFTER the fixture fetch/hash,
// immediately before releasing the first product upload. Refused observations
// leave this unlaunched sample prepared and are retained in its final receipt.
const preparedSamples = new Map();
export function releasePreparedSample({ id, admission }) {
  const pending = preparedSamples.get(id);
  must(pending, 'No matching prepared sample');
  pending.receipt.admissionObservations.push(admission);
  if (admission?.quiet !== true) return { released: false, reason: 'Canonical host admission refused; no upload launched' };
  must(admission.policy?.version === 'native-host-v12-departure-observation'
    && admission.policy?.minimumLinuxKiB === 41_943_040 && admission.policy?.maximumWindowsCpuPercent === 10,
  'Canonical host admission policy identity differs');
  must(admission.linux?.activeGraphs?.length === 0 && admission.linux.MemAvailableKiB >= 41_943_040
    && admission.windows?.length === 3 && admission.windows.every(row => row.totalProcessorPercent <= 10),
  'Host observation does not meet unchanged canonical policy');
  const age = Date.now() - Date.parse(admission.capturedAt);
  must(Number.isFinite(age) && age >= 0 && age <= 30_000, 'Host observation is stale or from a different clock');
  pending.receipt.externalAdmission = admission;
  pending.resolve();
  return { released: true };
}
export function cancelPreparedSample({ id, reason }) {
  const pending = preparedSamples.get(id);
  must(pending && typeof reason === 'string' && reason.length > 0, 'Matching prepared id and explicit reason required');
  pending.reject(new Error(`Prepared sample cancelled before upload: ${reason}`));
}

async function run(options, status) {
  const receipt = { schema: 1, id: options.id, side: options.side, pair: options.pair, fixture: options.fixture,
    started: new Date().toISOString(), ok: false, environment: { url: location.href, userAgent: navigator.userAgent,
      secureContext: isSecureContext, crossOriginIsolated, visibility: document.visibilityState,
      hasFocus: document.hasFocus(), previewStatus: options.previewStatus ?? null,
      uploadMode: 'timed', geomWorkersRequested: 4 }, logs: [], errors: [],
    externalAdmission: options.admission ?? null,
    coldStorageAdmission: options.coldStorageAdmission ?? null,
    lifecycle: options.lifecycle ?? null,
    admissionObservations: [],
    interference: { visibility: [], focus: [], trustedInputCounts: {}, trustedInputCountsAfterUpload: {}, trustedInputs: [], performanceEntries: [],
      performanceEntryDropped: 0, supportedEntryTypes: globalThis.PerformanceObserver?.supportedEntryTypes ?? [] }, limitations: [
      'Root must retain fresh-tab/cold-storage admission and external host admission receipts.',
      'Console capture starts at sample preparation, after viewer boot; boot console witness is external.',
      'OS caches and browser-process lifetime are not reset by this adapter.',
      'Successful execution alone is not an A/B noise/performance verdict.',
    ] };
  let began = false;
  const originals = {};
  const onError = event => receipt.errors.push({ type: 'error', message: event.message ?? String(event.error) });
  const onRejection = event => receipt.errors.push({ type: 'unhandledrejection', message: String(event.reason) });
  const onVisibility = () => {
    receipt.interference.visibility.push({ at: performance.now(), visibility: document.visibilityState, hasFocus: document.hasFocus() });
    // Preparation may wait without foreground focus. Actual measured work
    // starts only at uploadStart, after the explicit host/focus release gate.
    if (receipt.uploadStart !== undefined && document.visibilityState !== 'visible') receipt.errors.push({ type: 'visibility', at: performance.now(), state: document.visibilityState });
  };
  const onFocus = event => receipt.interference.focus.push({ at: performance.now(), type: event.type, hasFocus: document.hasFocus() });
  const inputEvents = ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart'];
  const onInput = event => {
    if (!event.isTrusted) return;
    const counts = receipt.interference.trustedInputCounts;
    counts[event.type] = (counts[event.type] ?? 0) + 1;
    if (receipt.uploadStart !== undefined) {
      const timed = receipt.interference.trustedInputCountsAfterUpload;
      timed[event.type] = (timed[event.type] ?? 0) + 1;
    }
    if (receipt.interference.trustedInputs.length < 1000) receipt.interference.trustedInputs.push({ at: performance.now(), type: event.type });
  };
  let observer;
  try {
    const state = await request('/__6940/state');
    receipt.server = state;
    must(state.side === options.side, 'Wrong served root before sample');
    const fixture = state.fixtures[options.fixture];
    must(fixture, 'Unknown exact fixture key');
    receipt.epoch = state.epoch;
    await request(`/__6940/begin/${options.id}`, { side: options.side, epoch: state.epoch, fixture: options.fixture, pair: options.pair });
    began = true;
    const collectorResponse = await fetch('/__6940/cohort.mjs?collector-source-identity', { cache: 'no-store' });
    must(collectorResponse.ok, 'Collector source identity fetch failed');
    receipt.collectorSha256 = await sha(await collectorResponse.arrayBuffer());
    if (options.collectorSha256) must(receipt.collectorSha256 === options.collectorSha256, 'Collector changed after finite plan freeze');
    for (const level of ['log', 'warn', 'error']) {
      originals[level] = console[level];
      console[level] = (...args) => {
        receipt.logs.push(`[${level}] ${args.map(value => typeof value === 'string' ? value : String(value)).join(' ')}`);
        originals[level].apply(console, args);
      };
    }
    addEventListener('error', onError); addEventListener('unhandledrejection', onRejection);
    document.addEventListener('visibilitychange', onVisibility);
    addEventListener('focus', onFocus); addEventListener('blur', onFocus);
    for (const event of inputEvents) addEventListener(event, onInput, { capture: true, passive: true });
    const entryTypes = ['long-animation-frame', 'longtask'].filter(type => globalThis.PerformanceObserver?.supportedEntryTypes?.includes(type));
    if (entryTypes.length) {
      observer = new PerformanceObserver(list => {
        for (const entry of list.getEntries()) {
          if (receipt.interference.performanceEntries.length < 1000) receipt.interference.performanceEntries.push(entry.toJSON());
          else receipt.interference.performanceEntryDropped++;
        }
      });
      observer.observe({ entryTypes });
    }
    must(isSecureContext && crossOriginIsolated, 'Secure cross-origin-isolated viewer required');
    if (options.waitForAdmission !== true) {
      must(document.visibilityState === 'visible', 'Tab must remain visible');
      must(document.hasFocus(), 'Fresh timing tab must have focus');
    }
    const params = new URL(location.href).searchParams;
    must(params.get('geomWorkers') === '4' && params.get('perfTrace') === '1', 'Navigate with ?geomWorkers=4&perfTrace=1');
    must(!params.has('model'), 'File-input cohort cannot include model URL autoload');
    must(!globalThis.__IFC_LITE_BENCHMARK_UPLOADS, 'Count-upload global is active');
    must(trace() === null, 'Fresh tab must not contain a previous load trace');
    const initial = storeState();
    must(initial?.models?.size === 0 && !initial.geometryResult?.meshes?.length, 'Fresh tab must contain no model');
    must(typeof traceApi()?.sessionCounters === 'function', 'GPU session counters required; boot console capture is external');
    const sessionBefore = traceApi().sessionCounters();
    receipt.sessionBefore = sessionBefore;
    must(!gpuHealthFrom(receipt.logs, sessionBefore).contaminated, 'GPU contaminated before upload');
    const response = await fetch(fixture.url, { cache: 'no-store' });
    must(response.ok, `Fixture fetch failed HTTP${response.status}`);
    const bytes = await response.arrayBuffer();
    receipt.fixtureIdentity = { name: fixture.name, bytes: bytes.byteLength, sha256: await sha(bytes), expected: fixture };
    must(bytes.byteLength === fixture.bytes && receipt.fixtureIdentity.sha256 === fixture.sha256, 'Fixture identity mismatch');
    const input = document.querySelector('#file-input-open');
    must(input instanceof HTMLInputElement, 'Canonical File input missing');
    const transfer = new DataTransfer();
    transfer.items.add(new File([bytes], fixture.name, { type: 'application/x-step', lastModified: 0 }));
    if (options.waitForAdmission === true) {
      receipt.preparedAt = new Date().toISOString();
      status.stage = 'prepared-awaiting-host-admission';
      try {
        await new Promise((resolve, reject) => preparedSamples.set(options.id, { resolve, reject, receipt }));
      } finally { preparedSamples.delete(options.id); }
    }
    receipt.environment.viewport = { innerWidth, innerHeight, devicePixelRatio };
    must(innerWidth === 1280 && innerHeight === 800, 'Actual viewport must be1280x800');
    must(document.visibilityState === 'visible' && document.hasFocus(), 'Foreground status lost before upload');
    must(!gpuHealthFrom(receipt.logs, traceApi().sessionCounters()).contaminated, 'GPU contaminated before upload');
    // Fixture/network/hash/helper imports are outside the measured window.
    status.stage = 'loading';
    receipt.uploadStart = performance.now();
    input.files = transfer.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    const ready = await waitForMetadataRenderReadiness({
      trace: async () => probePageLoadTrace({ key: '__IFC_LITE_LOAD_TRACE__', names: READINESS_SPANS }),
      logs: () => receipt.logs, canvasReady: async () => {
        const canvas = document.querySelector('canvas');
        return !!canvas && canvas.width > 0 && canvas.height > 0;
      }, now: () => performance.now(), pause: () => pause(100), timeoutMs: options.timeoutMs ?? 600_000,
      completionMode: 'metadata-render',
    });
    receipt.metadataRenderReadyMs = ready - receipt.uploadStart;
    receipt.observedReady = ready;
    receipt.environment.visibilityAtReady = document.visibilityState;
    receipt.environment.hasFocusAtReady = document.hasFocus();
    receipt.readinessTrace = structuredClone(trace());
    receipt.metrics = metricsFromLoadTrace(receipt.readinessTrace);
    must(receipt.readinessTrace.attrs?.loadPath === 'wasm', 'Expected real WASM load path; cache/server samples refused');
    must(!receipt.readinessTrace.spans.some(span => span.name === 'cache.storeReady'), 'Cache hit completion present');
    const pool = receipt.readinessTrace.spans.find(span => span.name === 'geometry.pool');
    must(pool?.attrs?.workerCount === 4, `Actual worker count must be 4; observed ${pool?.attrs?.workerCount}`);
    receipt.environment.geomWorkersActual = pool.attrs.workerCount;
    const countMode = receipt.readinessTrace.spans.some(span => span.attrs?.uploadMode === 'count');
    requireTimingUploads({ environment: { uploadMode: countMode ? 'count' : 'timed' } });
    status.stage = 'settling';
    const deadline = performance.now() + 30_000;
    let last = ''; let quiet = 0;
    for (;;) {
      const key = settleKey(trace());
      quiet = key === last ? quiet + 1 : 0; last = key;
      if (quiet >= 6) break;
      must(performance.now() < deadline, 'Counters did not settle within30s; sample retained incomplete');
      await pause(250);
    }
    receipt.fullTrace = structuredClone(trace());
    receipt.counters = countersFromLoadTrace(receipt.fullTrace);
    receipt.sessionAfter = traceApi().sessionCounters();
    receipt.gpuHealth = gpuHealthFrom(receipt.logs, receipt.sessionAfter);
    must(!receipt.gpuHealth.contaminated, 'GPU device loss/replacement contaminates sample');
    must(receipt.errors.length === 0, 'Page errors or hidden-tab interval occurred');
    must(document.visibilityState === 'visible' && document.hasFocus(), 'Tab lost foreground status');
    must(!receipt.interference.focus.some(event => event.type === 'blur' && event.at >= receipt.uploadStart), 'Tab blurred after upload');
    must(Object.keys(receipt.interference.trustedInputCountsAfterUpload).length === 0, 'Trusted input interfered after upload');
    status.stage = 'hashing-outside-timer';
    receipt.payload = await payloadIdentity();
    must(receipt.payload.models.every(model => model.loadPath === 'wasm' && model.cacheState !== 'hit'), 'Model reports non-WASM/cache-hit route');
    const finalState = await request('/__6940/state');
    must(finalState.epoch === receipt.epoch && finalState.side === receipt.side, 'Served root changed during sample');
    receipt.ok = true;
  } catch (error) {
    receipt.error = { name: error.name, message: error.message, stack: error.stack };
    status.error = receipt.error;
  } finally {
    try {
      receipt.fullTrace ??= structuredClone(trace());
      receipt.sessionAfter ??= traceApi()?.sessionCounters?.() ?? null;
      receipt.gpuHealth ??= gpuHealthFrom(receipt.logs, receipt.sessionAfter);
      receipt.renderStats = globalThis.__ifc_lite_render_stats__?.() ?? null;
      receipt.environment.visibilityAtFinish = document.visibilityState;
      receipt.environment.hasFocusAtFinish = document.hasFocus();
      receipt.finished = new Date().toISOString();
      status.stage = 'persisting'; status.ok = receipt.ok;
      globalThis.__IFC_6940_RECEIPT__ = receipt;
      must(began, 'No durable sample intent; inspect global receipt for admission failure');
      await request(`/__6940/receipt/${options.id}`, receipt);
      status.persistence = 'saved';
    } catch (error) {
      status.persistence = 'failed'; status.persistenceError = String(error);
      globalThis.__IFC_6940_RECEIPT__ = receipt;
    } finally {
      for (const [level, original] of Object.entries(originals)) console[level] = original;
      removeEventListener('error', onError); removeEventListener('unhandledrejection', onRejection);
      document.removeEventListener('visibilitychange', onVisibility);
      removeEventListener('focus', onFocus); removeEventListener('blur', onFocus);
      for (const event of inputEvents) removeEventListener(event, onInput, { capture: true });
      observer?.disconnect();
      status.stage = 'done';
    }
  }
}
