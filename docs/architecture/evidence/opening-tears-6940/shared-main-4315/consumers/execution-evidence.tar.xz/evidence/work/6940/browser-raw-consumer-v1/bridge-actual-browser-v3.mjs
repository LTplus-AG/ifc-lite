// Evidence-only CLI; no browser execution and no acceptance-policy changes.
// node bridge-actual-browser.mjs --v3-base ACTUAL --v3-branch ACTUAL \
//   --v4-base ACTUAL --v4-branch ACTUAL --base-head SHA40 --branch-head SHA40 --out NEW_REPORT.json
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const hashBytes = bytes => createHash('sha256').update(bytes).digest('hex');
const json = value => JSON.stringify(value);
const objectHash = value => hashBytes(Buffer.from(json(value), 'utf8'));
const compare = (a, b) => json(a) < json(b) ? -1 : json(a) > json(b) ? 1 : 0;
const must = (condition, message) => { if (!condition) throw new Error(message); };
const hex = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const expectedCollectors = {
  v3: '470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17',
  v4: '55ab6c672e695c7a7db28101d945165465b9f49a54a84f1b85f4ade9a713105a',
};
const versions = { v3: 'ifc6940-complete-cpu-geometry-merkle-v3', v4: 'ifc6940-complete-cpu-geometry-merkle-v4' };
function bag(rows) {
  const result = new Map();
  for (const row of rows) {
    const key = json(row);
    const old = result.get(key);
    if (old) old.count++;
    else result.set(key, { value: row, count: 1 });
  }
  return result;
}
const entries = map => [...map.values()].sort((a, b) => compare(a.value, b.value));
function difference(before, after) {
  const left = bag(before); const right = bag(after);
  for (const [key, a] of left) {
    const b = right.get(key); const common = Math.min(a.count, b?.count ?? 0);
    a.count -= common; if (b) b.count -= common;
  }
  return { removed: entries(left).filter(row => row.count), added: entries(right).filter(row => row.count) };
}
const sameBag = (a, b) => { const d = difference(a, b); return !d.removed.length && !d.added.length; };
function validateRow(row, label) {
  must(row && typeof row === 'object' && !Array.isArray(row), `${label}: invalid mesh row`);
  for (const key of ['expressId', 'geometryItemId', 'geometryClass', 'vertices', 'triangles', 'sha256'])
    must(Object.hasOwn(row, key), `${label}: missing mesh row ${key}`);
  must(Number.isSafeInteger(row.expressId) && Number.isSafeInteger(row.vertices) && row.vertices > 0
    && Number.isSafeInteger(row.triangles) && row.triangles > 0 && hex(row.sha256), `${label}: invalid mesh counts/id/hash`);
}
function globalDetailMap(model, geometry, label) {
  must(Array.isArray(model.geometryResultFieldDetails), `${label}: missing all non-mesh field witnesses`);
  const expected = new Map(geometry.geometryResultFields.filter(row => row.field !== 'meshes').map(row => [row.field, row.sha256]));
  const actual = new Map(); let last;
  for (const item of model.geometryResultFieldDetails) {
    must(item && Object.keys(item).sort().join(',') === 'field,value' && typeof item.field === 'string',
      `${label}: invalid global field detail`);
    must(expected.has(item.field) && !actual.has(item.field) && (last === undefined || last < item.field),
      `${label}: unexpected/duplicate/unsorted global detail ${item.field}`);
    must(objectHash(item.value) === expected.get(item.field), `${label}: detail hash differs for ${item.field}`);
    actual.set(item.field, item.value); last = item.field;
  }
  must(actual.size === expected.size, `${label}: incomplete global field witnesses`);
  return actual;
}
function readReceipt(path, version, side, report) {
  const bytes = readFileSync(path);
  report.inputs.push({ path, bytes: bytes.length, sha256: hashBytes(bytes) });
  const receipt = JSON.parse(bytes.toString('utf8'));
  must(receipt.ok === true && receipt.side === side, `${version}/${side}: unsuccessful or wrong-side receipt`);
  const trace = receipt.trace;
  must(trace?.attrs?.loadPath === 'wasm', `${version}/${side}: actual trace must report WASM`);
  const pools = trace.spans?.filter(span => span.name === 'geometry.pool');
  must(pools?.length === 1 && pools[0].attrs?.workerCount === 4, `${version}/${side}: actual pool must have four workers`);
  must(receipt.gpuHealth?.contaminated === false && Array.isArray(receipt.gpuHealth.reasons)
    && receipt.gpuHealth.reasons.length === 0, `${version}/${side}: GPU health is missing/contaminated`);
  must(receipt.functionalOnly === true && receipt.noTimingQualification === true,
    `${version}/${side}: explicit untimed functional receipt required`);
  must(Array.isArray(receipt.errors) && receipt.errors.length === 0, `${version}/${side}: page errors`);
  must(receipt.payload?.schema === (version === 'v3' ? 3 : 4), `${version}/${side}: payload schema mismatch`);
  must(receipt.collectorSha256 === expectedCollectors[version], `${version}/${side}: collector source identity mismatch`);
  must(receipt.payload.models?.length === 1, `${version}/${side}: exactly one model required`);
  const model = receipt.payload.models[0]; const geometry = model.geometry;
  must(model.loadPath === 'wasm' && model.cacheState !== 'hit', `${version}/${side}: unsupported load/cache route`);
  must(geometry?.schema === versions[version], `${version}/${side}: geometry schema mismatch`);
  must(Array.isArray(geometry.flatMeshMerkleRows) && Array.isArray(geometry.geometryResultFields)
    && Array.isArray(geometry.normalizedInstanceMerkleRows), `${version}/${side}: missing complete geometry rows`);
  must(geometry.flatMeshMerkleRows.length === model.meshCount, `${version}/${side}: mesh count mismatch`);
  for (const row of geometry.flatMeshMerkleRows) validateRow(row, `${version}/${side}`);
  const names = new Set();
  for (const row of geometry.geometryResultFields) {
    must(typeof row.field === 'string' && hex(row.sha256) && !names.has(row.field), `${version}/${side}: invalid/duplicate result-field hash`);
    names.add(row.field);
  }
  const ownMeshFields = geometry.geometryResultFields.filter(row => row.field === 'meshes');
  must(ownMeshFields.length === 1 && ownMeshFields[0].sha256 === objectHash({
    type: 'SortedMeshMerkleRows', rows: geometry.flatMeshMerkleRows,
  }), `${version}/${side}: own meshes result-field hash does not verify`);
  must(model.flatVertices === geometry.flatMeshMerkleRows.reduce((sum, row) => sum + row.vertices, 0)
    && model.flatTriangles === geometry.flatMeshMerkleRows.reduce((sum, row) => sum + row.triangles, 0),
  `${version}/${side}: flat count totals do not verify`);
  must(hex(model.completeGeometryPayloadSha256) && objectHash(geometry) === model.completeGeometryPayloadSha256,
    `${version}/${side}: own complete geometry root does not verify`);
  must(hex(receipt.fixtureIdentity?.sha256) && Number.isSafeInteger(receipt.fixtureIdentity.bytes),
    `${version}/${side}: missing fixture identity`);
  const manifest = receipt.server?.manifest;
  must(manifest && /^[a-f0-9]{40}$/.test(manifest.head) && /^[a-f0-9]{40}$/.test(manifest.tree)
    && hex(manifest.packageWasm?.sha256) && hex(manifest.distManifestSha256)
    && hex(manifest.trackedDiffSha256), `${version}/${side}: incomplete source/runtime manifest`);
  must(manifest.head === args.get(`--${side}-head`), `${version}/${side}: source differs from explicit expected head`);
  must(manifest.trackedDiffSha256 === hashBytes(Buffer.alloc(0)), `${version}/${side}: source has tracked changes`);
  must(manifest.side === side && receipt.server.side === side, `${version}/${side}: manifest/server side mismatch`);
  must(typeof receipt.server.epoch === 'string' && receipt.server.epoch.length > 0
    && receipt.servingStateAtReceipt?.side === receipt.server.side
    && receipt.servingStateAtReceipt?.epoch === receipt.server.epoch,
  `${version}/${side}: final serving state differs from beginning side/epoch`);
  const identity = {
    head: manifest.head, tree: manifest.tree, trackedDiffSha256: manifest.trackedDiffSha256,
    packageWasm: { sha256: manifest.packageWasm.sha256, bytes: manifest.packageWasm.bytes },
    distManifestSha256: manifest.distManifestSha256,
  };
  report.identities.push({ version, side, receiptId: receipt.id, fixture: receipt.fixtureIdentity,
    sourceRuntime: identity, collectorSha256: receipt.collectorSha256,
    serverManifestSha256: objectHash(manifest), servingStateSha256: objectHash(receipt.servingStateAtReceipt ?? null),
    serverEpoch: receipt.server.epoch, serverSide: receipt.server.side, finalServingState: receipt.servingStateAtReceipt,
    actualTraceLoadPath: trace.attrs.loadPath, actualWorkerCount: pools[0].attrs.workerCount, gpuHealth: receipt.gpuHealth,
    rawInstanceGraphSha256: model.rawInstanceGraphSha256,
    normalizedCompleteGeometrySha256: model.completeGeometryPayloadSha256,
    modelReceiptMetadata: Object.fromEntries(Object.entries(model).filter(([key]) =>
      !['geometry', 'completeGeometryPayloadSha256'].includes(key))) });
  const globalDetails = version === 'v4' ? globalDetailMap(model, geometry, `${version}/${side}`) : null;
  if (globalDetails) report.globalWitnesses.push({ side, fieldNames: [...globalDetails.keys()],
    everyDetailHashVerified: true, witnessSHA256: objectHash(model.geometryResultFieldDetails) });
  return { receipt, model, geometry, identity, globalDetails };
}
function fieldMap(row) {
  must(Array.isArray(row.fields), 'v4 mesh lacks expanded fields');
  const map = new Map(); let last;
  for (const item of row.fields) {
    must(item && Object.keys(item).sort().join(',') === 'field,sha256'
      && typeof item.field === 'string' && hex(item.sha256), 'Invalid v4 field-hash row');
    must(!map.has(item.field) && (last === undefined || last < item.field), 'Duplicate/unsorted v4 field name');
    map.set(item.field, item.sha256); last = item.field;
  }
  must(map.size > 0 && ['positions', 'normals', 'indices'].every(key => map.has(key)), 'Missing required v4 geometry fields');
  return map;
}
function bridge(v3, v4, side, report) {
  must(json(v3.identity) === json(v4.identity), `${side}: source/runtime differs between untimed witnesses`);
  must(v3.receipt.fixtureIdentity.sha256 === v4.receipt.fixtureIdentity.sha256
    && v3.receipt.fixtureIdentity.bytes === v4.receipt.fixtureIdentity.bytes, `${side}: fixture differs`);
  const reconstructed = structuredClone(v4.geometry); const expanded = new Map();
  for (const row of reconstructed.flatMeshMerkleRows) {
    const fields = fieldMap(row); delete row.fields;
    const key = json(row); const previous = expanded.get(key);
    must(!previous || json([...previous]) === json([...fields]), `${side}: equal whole-mesh row has inconsistent expanded field hashes`);
    expanded.set(key, fields);
  }
  reconstructed.flatMeshMerkleRows.sort(compare);
  must(sameBag(reconstructed.flatMeshMerkleRows, v3.geometry.flatMeshMerkleRows), `${side}: v3/v4 mesh rows/counts/IDs/hashes differ`);
  const meshFields = reconstructed.geometryResultFields.filter(row => row.field === 'meshes');
  must(meshFields.length === 1, `${side}: expected exactly one meshes result field`);
  meshFields[0].sha256 = objectHash({ type: 'SortedMeshMerkleRows', rows: reconstructed.flatMeshMerkleRows });
  reconstructed.schema = versions.v3;
  const root = objectHash(reconstructed);
  must(root === v3.model.completeGeometryPayloadSha256, `${side}: reconstructed v3 complete root differs`);
  must(json(reconstructed) === json(v3.geometry), `${side}: reconstructed geometry content differs despite root match`);
  report.bridges.push({ side, ok: true, actualV3Root: v3.model.completeGeometryPayloadSha256,
    reconstructedV3Root: root, actualV4Root: v4.model.completeGeometryPayloadSha256,
    flatMeshes: reconstructed.flatMeshMerkleRows.length,
    distinctMeshContents: expanded.size,
    normalizedInstances: reconstructed.normalizedInstanceMerkleRows.length,
    rawAddressingGraphEqual: v3.model.rawInstanceGraphSha256 === v4.model.rawInstanceGraphSha256,
    normalization: 'Only flat-row fields removed; meshes result-field hash recomputed; exact v3 schema restored. Every other geometry field retained.' });
  return expanded;
}
function groupRows(rows) {
  const groups = new Map();
  for (const row of rows) {
    const identity = [row.expressId, row.geometryItemId, row.geometryClass]; const key = json(identity);
    if (!groups.has(key)) groups.set(key, { identity, rows: [] });
    groups.get(key).rows.push(row);
  }
  return groups;
}
function fieldDelta(removed, added, expandedBefore, expandedAfter) {
  const names = new Set(); const lookup = (row, expanded) => {
    const fields = expanded.get(json(row)); must(fields, 'Actual changed v3 row lacks matching v4 field witness');
    for (const name of fields.keys()) names.add(name);
    return fields;
  };
  const left = removed.map(row => ({ ...row, fields: lookup(row.value, expandedBefore) }));
  const right = added.map(row => ({ ...row, fields: lookup(row.value, expandedAfter) }));
  const deltas = [];
  for (const field of [...names].sort()) {
    const values = rows => rows.flatMap(row => Array.from({ length: row.count }, () =>
      row.fields.has(field) ? { present: true, sha256: row.fields.get(field) } : { present: false }));
    const delta = difference(values(left), values(right));
    if (delta.removed.length || delta.added.length) deltas.push({ field, ...delta });
  }
  const compact = rows => rows.map(row => ({ mesh: row.value, count: row.count,
    fieldHashes: [...row.fields].map(([field, sha256]) => ({ field, sha256 })) }));
  return { fieldDeltas: deltas, before: compact(left), after: compact(right) };
}
function crossArm(base, branch, expandedBase, expandedBranch, report, globalBase, globalBranch) {
  must(base.receipt.fixtureIdentity.sha256 === branch.receipt.fixtureIdentity.sha256
    && base.receipt.fixtureIdentity.bytes === branch.receipt.fixtureIdentity.bytes, 'Cross-arm fixture mismatch');
  const a = groupRows(base.geometry.flatMeshMerkleRows); const b = groupRows(branch.geometry.flatMeshMerkleRows);
  let unchanged = 0;
  for (const key of [...new Set([...a.keys(), ...b.keys()])].sort()) {
    const before = a.get(key)?.rows ?? []; const after = b.get(key)?.rows ?? [];
    const delta = difference(before, after);
    unchanged += before.length - delta.removed.reduce((sum, row) => sum + row.count, 0);
    if (!delta.removed.length && !delta.added.length) continue;
    const pairing = delta.removed.length === 1 && delta.added.length === 1
      && delta.removed[0].count === delta.added[0].count ? 'Unique-content pair (multiplicity retained)'
      : 'Unpaired content multisets; no positional matching';
    const fields = fieldDelta(delta.removed, delta.added, expandedBase, expandedBranch);
    const ambiguous = delta.removed.length > 0 && delta.added.length > 0
      && !(delta.removed.length === 1 && delta.added.length === 1 && delta.removed[0].count === delta.added[0].count);
    report.flatMeshChanges.push({ identity: (a.get(key) ?? b.get(key)).identity,
      beforeMeshes: before.length, afterMeshes: after.length, pairing, ambiguous, ...fields });
    if (ambiguous) report.holds.push({ type: 'Ambiguous flat-mesh correspondence', identity: (a.get(key) ?? b.get(key)).identity });
    if (!fields.fieldDeltas.length) report.holds.push({ type: 'Changed whole-mesh row without differing expanded field hashes', identity: key });
  }
  report.unchangedFlatMeshes = unchanged;
  const resultA = base.geometry.geometryResultFields.filter(row => row.field !== 'meshes');
  const resultB = branch.geometry.geometryResultFields.filter(row => row.field !== 'meshes');
  report.nonMeshGeometryResultDelta = difference(resultA, resultB);
  const leafBase = new Map(resultA.map(row => [row.field, row.sha256]));
  const leafBranch = new Map(resultB.map(row => [row.field, row.sha256]));
  report.nonMeshGlobalChanges = [];
  for (const field of [...new Set([...globalBase.keys(), ...globalBranch.keys()])].sort()) {
    const before = globalBase.has(field) ? { present: true, sha256: leafBase.get(field), value: globalBase.get(field) } : { present: false };
    const after = globalBranch.has(field) ? { present: true, sha256: leafBranch.get(field), value: globalBranch.get(field) } : { present: false };
    if (json(before) !== json(after)) {
      report.nonMeshGlobalChanges.push({ field, before, after, hashBoundToActualV3PerArm: true,
        semanticReview: 'HOLD until explicitly accounted; no count/scalar/name-based allowance' });
      report.holds.push({ type: 'Changed non-mesh global field requires semantic review', field, detailsExpanded: true });
    }
  }
  report.normalizedInstanceDelta = difference(base.geometry.normalizedInstanceMerkleRows, branch.geometry.normalizedInstanceMerkleRows);
  const other = geometry => Object.fromEntries(Object.entries(geometry).filter(([key]) =>
    !['flatMeshMerkleRows', 'geometryResultFields', 'normalizedInstanceMerkleRows'].includes(key)));
  report.otherGeometryContent = { before: other(base.geometry), after: other(branch.geometry) };
  if ((report.nonMeshGeometryResultDelta.removed.length || report.nonMeshGeometryResultDelta.added.length)
    && report.nonMeshGlobalChanges.length === 0)
    report.holds.push({ type: 'Unaccounted global result-field record drift' });
  if (report.normalizedInstanceDelta.removed.length || report.normalizedInstanceDelta.added.length)
    report.holds.push({ type: 'Unexpanded normalized instance geometry/provenance drift' });
  if (json(report.otherGeometryContent.before) !== json(report.otherGeometryContent.after))
    report.holds.push({ type: 'Other geometry content drift' });
  report.strictNormalizedGeometryIdentityEqual = base.model.completeGeometryPayloadSha256 === branch.model.completeGeometryPayloadSha256;
  report.strictIdentityVerdict = report.strictNormalizedGeometryIdentityEqual ? 'PASS' : 'FAIL';
  report.rawInstanceAddressingGraphEqual = base.model.rawInstanceGraphSha256 === branch.model.rawInstanceGraphSha256;
  report.flatCounts = { before: { meshes: base.model.meshCount, vertices: base.model.flatVertices, triangles: base.model.flatTriangles },
    after: { meshes: branch.model.meshCount, vertices: branch.model.flatVertices, triangles: branch.model.flatTriangles } };
}
const args = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i]; const value = process.argv[i + 1];
  must(['--v3-base', '--v3-branch', '--v4-base', '--v4-branch', '--base-head', '--branch-head', '--out'].includes(key)
    && value && !args.has(key), 'Use four explicit actual-receipt paths and a unique --out JSON path');
  if (key === '--base-head' || key === '--branch-head') {
    must(/^[a-f0-9]{40}$/.test(value), 'Expected heads must be immutable 40-character SHAs');
    args.set(key, value);
  } else args.set(key, resolve(value));
}
must(args.size === 7 && !existsSync(args.get('--out')), 'Four paths, two explicit heads and new output required');
const report = { schema: 'ifc6940-browser-field-witness-bridge-v2', at: new Date().toISOString(),
  checker: { path: fileURLToPath(import.meta.url), sha256: hashBytes(readFileSync(fileURLToPath(import.meta.url))) },
  inputs: [], identities: [], bridges: [], globalWitnesses: [], flatMeshChanges: [], holds: [], ok: false,
  functionalReceiptChecksPassed: false, bridgeValidated: false, deltaCoverageComplete: false,
  qualification: false, okMeaning: 'Source/functional checks, bridge validity, delta coverage and semantic-review holds are separate. Every changed global/instance field stays HOLD; strict cross-arm identity FAIL remains FAIL.',
  expectedHeads: { base: args.get('--base-head'), branch: args.get('--branch-head') },
  requestedInputs: Object.fromEntries([...args].filter(([key]) => key.startsWith('--v'))), limits: [
    'This checks actual saved CPU payload identities and exhaustive field-hash differences; it performs no browser work or performance qualification.',
    'No expected-ID filter. Duplicate rows retained; ambiguous correspondences are content multisets, never positional pairs.',
    'Typed field hashes retain the existing checked structural encoding and exact owned bytes, not raw-coordinate export or physical correctness.',
    'Source and server identities are fenced per arm; raw instance addressing may vary with arrival and is reported separately.',
    'Unexpected instance/global-field drift or ambiguous correspondence remains an explicit review hold.',
    'Strict cross-arm identity failure is retained even when semantic changes are later accepted. Original v3 timing wrapper remains unchanged.',
  ] };
let exitCode = 1;
try {
  const base3 = readReceipt(args.get('--v3-base'), 'v3', 'base', report);
  const branch3 = readReceipt(args.get('--v3-branch'), 'v3', 'branch', report);
  const base4 = readReceipt(args.get('--v4-base'), 'v4', 'base', report);
  const branch4 = readReceipt(args.get('--v4-branch'), 'v4', 'branch', report);
  report.functionalReceiptChecksPassed = true;
  const expandedBase = bridge(base3, base4, 'base', report);
  const expandedBranch = bridge(branch3, branch4, 'branch', report);
  report.bridgeValidated = true;
  crossArm(base3, branch3, expandedBase, expandedBranch, report, base4.globalDetails, branch4.globalDetails);
  report.deltaCoverageComplete = !report.holds.some(row => row.type !== 'Changed non-mesh global field requires semantic review');
  report.semanticReviewRequired = !report.strictNormalizedGeometryIdentityEqual || report.holds.length > 0;
  report.ok = report.holds.length === 0; exitCode = report.ok ? 0 : 2;
} catch (error) {
  report.error = { name: error.name, message: error.message, stack: error.stack };
} finally {
  writeFileSync(args.get('--out'), json(report) + '\n', { flag: 'wx' });
}
console.log(json({ ok: report.ok, bridges: report.bridges.length, changedGroups: report.flatMeshChanges.length,
  holds: report.holds.length, strictIdentityEqual: report.strictNormalizedGeometryIdentityEqual,
  output: args.get('--out') }));
process.exitCode = exitCode;
