//! Isolated #6940 evidence adapter; install temporarily as a processing example.
//! Usage: matched_native_payload <fixture.ifc> <prepared-wire.json> <new-output.json>
//! No private style/material/texture walks: use canonical public resolvers.
//! The fallback colour is supplied from observed directly-styled geometry IDs
//! in the WASM receipt; preparation rejects ambiguous/missing item styles.
use ifc_lite_core::{ColumnarEntityIndex, EntityDecoder, EntityScanner};
use ifc_lite_geometry::{build_texture_index, GeometryRouter, MaterialLayerIndex};
use ifc_lite_processing::element::{
    produce_element_meshes, ElementJobKind, ElementMeshJob, MeshProductionContext,
    MeshProductionOptions,
};
use ifc_lite_processing::prepass::{
    flat_material_colors, flat_styles_rgba8, flat_voids, material_colors_from_flat,
    resolve_prepass, PrepassSpans, ResolveOptions,
};
use ifc_lite_processing::style::GeometryStyleInfo;
use rustc_hash::FxHashMap;
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use std::sync::Arc;

// Evidence compiles the actual FFI leaf, including its matrix operation order
// and signed-zero behavior; no algebraic reimplementation of the boundary.
#[path = "../../wasm-bindings/src/zero_copy/frame_swap.rs"]
mod ffi_frame_swap;

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Wire {
    source_receipt_sha256: String,
    fixture_sha256: String,
    jobs: Vec<u32>,
    unit_scale: f64,
    plane_angle_to_radians: f64,
    rtc_offset: [f64; 3],
    needs_shift: bool,
    style_ids: Vec<u32>,
    style_colors: Vec<u8>,
    material_element_ids: Vec<u32>,
    material_color_counts: Vec<u32>,
    material_colors: Vec<u8>,
    void_keys: Vec<u32>,
    void_counts: Vec<u32>,
    void_values: Vec<u32>,
    calls: Vec<Call>,
}
#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct Call {
    host: u32,
    context: String,
    job: [u32; 3],
    selected_openings: Vec<u32>,
    fallback_rgba8: [u8; 4],
    fallback_style_ids: Vec<u32>,
}
fn rotate_f32(values: &mut [f32]) {
    for p in values.chunks_exact_mut(3) {
        let y = p[1];
        p[1] = p[2];
        p[2] = -y;
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(), 4, "fixture prepared-wire new-output");
    let output = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&args[3])?;
    let bytes = std::fs::read(&args[1])?;
    let wire_bytes = std::fs::read(&args[2])?;
    let wire: Wire = serde_json::from_slice(&wire_bytes)?;
    assert_eq!(format!("{:x}", Sha256::digest(&bytes)), wire.fixture_sha256);
    let index = Arc::new(ColumnarEntityIndex::from_scan(&bytes));
    let mut decoder = EntityDecoder::with_arc_columnar_index(&bytes, index.clone());
    decoder.seed_unit_scales(wire.unit_scale, wire.plane_angle_to_radians);
    let mut spans = PrepassSpans::default();
    let mut scanner = EntityScanner::new(&bytes);
    while let Some((id, name, start, end)) = scanner.next_entity() {
        spans.stash(name, id, start, end);
    }
    let resolved = resolve_prepass(&spans, &mut decoder, ResolveOptions::default());
    assert_eq!(
        flat_styles_rgba8(&resolved, &mut decoder),
        (wire.style_ids.clone(), wire.style_colors.clone()),
        "canonical style wires must agree"
    );
    assert_eq!(
        flat_material_colors(&resolved.element_material_colors),
        (
            wire.material_element_ids.clone(),
            wire.material_color_counts.clone(),
            wire.material_colors.clone()
        ),
        "canonical material wires must agree"
    );
    assert_eq!(
        flat_voids(&resolved.void_index),
        (
            wire.void_keys.clone(),
            wire.void_counts.clone(),
            wire.void_values.clone()
        ),
        "canonical opening wires must agree"
    );
    let colors: FxHashMap<_, _> = wire
        .style_ids
        .iter()
        .copied()
        .zip(
            wire.style_colors
                .chunks_exact(4)
                .map(|c| std::array::from_fn(|k| f32::from(c[k]) / 255.0)),
        )
        .collect();
    assert_eq!(wire.style_colors.len(), wire.style_ids.len() * 4);
    let styles: FxHashMap<_, _> = colors
        .iter()
        .map(|(&id, &c)| (id, GeometryStyleInfo::from_color(c)))
        .collect();
    let materials = material_colors_from_flat(
        &wire.material_element_ids,
        &wire.material_color_counts,
        &wire.material_colors,
    );
    let textures = build_texture_index(&bytes, &mut decoder);
    let layers = Arc::new(MaterialLayerIndex::from_spans(
        &spans.rel_associates_material,
        &mut decoder,
    ));
    let item_cache = GeometryRouter::new_dedup_cache();
    let mapped_cache = GeometryRouter::new_mapped_item_cache();
    let mut calls = Vec::new();
    for call in &wire.calls {
        assert!(
            wire.jobs.chunks_exact(3).any(|j| j == call.job),
            "exact prepass job required"
        );
        assert_eq!(call.job[0], call.host);
        let fallback = call.fallback_rgba8.map(|v| f32::from(v) / 255.0);
        assert!(!call.fallback_style_ids.is_empty());
        for id in &call.fallback_style_ids {
            assert_eq!(
                colors.get(id),
                Some(&fallback),
                "fallback must be an actual direct-item wire colour"
            );
        }
        let mut decoder = EntityDecoder::with_arc_columnar_index(&bytes, index.clone());
        decoder.seed_unit_scales(wire.unit_scale, wire.plane_angle_to_radians);
        let entity =
            decoder.decode_and_cache(call.host, call.job[1] as usize, call.job[2] as usize)?;
        assert!(!entity
            .ifc_type
            .is_subtype_of(ifc_lite_core::IfcType::IfcTypeProduct));
        let ifc_type = ifc_lite_core::ifc_type_from_record(
            entity.ifc_type.clone(),
            &bytes[call.job[1] as usize..call.job[2] as usize],
        );
        let mut router = GeometryRouter::with_scale_and_local_frame(wire.unit_scale, true);
        router.enable_content_dedup_shared(item_cache.clone());
        router.enable_shared_mapped_item_cache(mapped_cache.clone());
        router.set_material_layer_index(layers.clone());
        if wire.needs_shift {
            router.set_rtc_offset((wire.rtc_offset[0], wire.rtc_offset[1], wire.rtc_offset[2]));
        }
        let voids = if call.selected_openings.is_empty() {
            FxHashMap::default()
        } else {
            [(call.host, call.selected_openings.clone())]
                .into_iter()
                .collect()
        };
        let ctx = MeshProductionContext {
            void_index: &voids,
            geometry_style_index: &styles,
            indexed_colour_full: &resolved.indexed_colour_full,
            element_material_colors: &materials,
            texture_index: &textures,
            site_local_rotation: None,
        };
        let job = ElementMeshJob {
            id: call.host,
            ifc_type,
            entity: entity.as_ref(),
            kind: ElementJobKind::Product,
            element_color: Some(fallback),
            metadata: None,
        };
        let produced = produce_element_meshes(
            &job,
            &ctx,
            &MeshProductionOptions::default(),
            &mut decoder,
            &router,
        );
        assert!(!produced.meshes.is_empty());
        assert!(produced.instance_occurrences.is_empty(), "flat batch must not use unbaked instance occurrences");
        let meshes: Vec<_> = produced.meshes.into_iter().map(|mut m| {
            // Match actual MeshDataJs::from_mesh_data: source repetition metadata
            // is deliberately dropped by the flat boundary; positions are final.
            // The separate unbaked occurrence channel was rejected above.
            rotate_f32(&mut m.positions);
            rotate_f32(&mut m.normals);
            let origin = [m.origin[0], m.origin[2], -m.origin[1]];
            let local_bounds = m.local_bounds.map(|b| ffi_frame_swap::swap_zup_to_yup_aabb(b).map(f32::to_bits));
            let local_to_world = m.local_to_world.map(|m| {
                ffi_frame_swap::swap_zup_to_yup_mat4(&m).map(|v| format!("{:016x}", v.to_bits()))
            });
            json!({"expressId":m.express_id,"geometryItemId":m.geometry_item_id,"materialId":m.material_id,"geometryClass":m.geometry_class,"ifcType":m.ifc_type,
                "positionsBits":m.positions.iter().map(|v| v.to_bits()).collect::<Vec<_>>(),"normalsBits":m.normals.iter().map(|v| v.to_bits()).collect::<Vec<_>>(),"indices":m.indices,
                "originBits":origin.map(|v|format!("{:016x}",v.to_bits())),"colorBits":m.color.map(f32::to_bits),"localBoundsBits":local_bounds,"localToWorldBits":local_to_world})
        }).collect();
        eprintln!("{}/{}: {} meshes", call.host, call.context, meshes.len());
        calls.push(json!({"host":call.host,"context":call.context,"job":call.job,"selectedOpenings":call.selected_openings,"meshes":meshes}));
    }
    let result = json!({"schema":1,"purpose":"matched canonical producer native geometric payload; no timing verdict",
        "sourceReceiptSha256":wire.source_receipt_sha256,"preparedWireSha256":format!("{:x}",Sha256::digest(&wire_bytes)),"fixtureSha256":wire.fixture_sha256,
        "context":"actual prepass wires; local frame true; same RTC; no site rotation; direct-item fallback supplied and checked against actual wire; flat MeshCollection boundary; source repetition metadata dropped as actual FFI; no unbaked occurrence channel",
        "notCompared":["texture bytes","shadingColor","metallic","roughness"],"calls":calls});
    serde_json::to_writer_pretty(output, &result)?;
    Ok(())
}
