#!/usr/bin/env python3
"""Evidence-only configured consumer native12 runner. Preparation does not execute this script.
Installs one owned processing example, runs serial cargo with two build jobs,
and removes that example in finally. Never overwrites an evidence directory.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['checkout', 'head', 'fixture', 'prepared', 'adapter', 'output-dir']:
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--timeout-seconds', type=int, default=900)
    a = parser.parse_args()
    assert a.timeout_seconds > 0
    root = Path(a.checkout).resolve()
    fixture, prepared, adapter = map(lambda p: Path(p).resolve(), [a.fixture, a.prepared, a.adapter])
    output = Path(a.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False)
    payload = output / 'native-payload.json'
    log_path = output / 'run.log'
    name = 'issue_6940_consumer_native_evidence_' + uuid.uuid4().hex[:16]
    example = root / 'rust/processing/examples' / (name + '.rs')
    binary = root / 'target/debug/examples' / name
    env = os.environ | {
        'PATH': '/home/louistrue/.cargo/bin:' + os.environ['PATH'],
        'CARGO_TARGET_DIR': str(root / 'target'),
        'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
        'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
        'IFC_LITE_REQUIRE_FIXTURES': '1', 'RUST_TEST_THREADS': '2',
    }
    command = ['cargo', 'run', '--locked', '-p', 'ifc-lite-processing', '--example', name,
               '--', str(fixture), str(prepared), str(payload)]
    result = {'schema': 1, 'head': a.head, 'checkout': str(root), 'command': command,
              'runnerSha256': sha(__file__), 'nativeBinaryPath': str(binary),
              'temporaryExamplePath': str(example), 'exitCode': None,
              'scope': 'Matched configured canonical flat native12 payload; no GPU/instancing/performance acceptance.',
              'inheritedBuildSelectors': {k: env[k] for k in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTUP_TOOLCHAIN', 'CARGO_BUILD_TARGET', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER'] if k in env},
              'environment': {k: env[k] for k in ['CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
                  'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'IFC_LITE_REQUIRE_FIXTURES', 'RUST_TEST_THREADS']}}
    owned = False
    before = None
    process = None
    started = time.monotonic()

    def git(*args):
        return subprocess.check_output(['git', *args], cwd=root).decode().strip()

    def source_state():
        tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
        rust = {p: sha(root / p) for p in tracked if p.startswith('rust/') and p.endswith('.rs')}
        build_inputs = {p: sha(root / p) for p in tracked if p and (
            p in {'Cargo.toml', 'Cargo.lock', 'rust-toolchain', 'rust-toolchain.toml'}
            or p.startswith('.cargo/') or (p.startswith('rust/') and p.endswith('Cargo.toml')))}
        return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'trackedDiffSha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--'], cwd=root)).hexdigest(),
                'sourceSha256': rust, 'buildInputsSha256': build_inputs}

    def interrupt(signum, _frame):
        raise KeyboardInterrupt(f'Interrupted by signal {signum}')

    previous_handlers = {s: signal.signal(s, interrupt) for s in [signal.SIGINT, signal.SIGTERM]}
    try:
        assert len(a.head) == 40 and git('rev-parse', 'HEAD') == a.head
        assert hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--'], cwd=root)).hexdigest() == os.environ['IFC_6940_DIAGNOSTIC_DIFF_SHA'], 'Diagnostic patch differs from reviewed installed bytes'
        assert not git('ls-files', '--others', '--exclude-standard', '--', 'rust/'), 'checkout has untracked Rust inputs'
        assert not example.exists() and not binary.exists(), 'unique example identity unexpectedly exists'
        wire = json.loads(prepared.read_bytes())
        assert wire['fixtureSha256'] == sha(fixture)
        assert wire['validationFence']['head'] == a.head
        assert Path(wire['validationFence']['checkout']).resolve() == root
        before = source_state()
        assert before['sourceSha256']
        result.update(sourceSha256=before['sourceSha256'], buildInputsSha256=before['buildInputsSha256'],
                      adapterSha256=sha(adapter), fixtureSha256=sha(fixture),
                      preparedWireSha256=sha(prepared), sourceReceiptSha256=wire['sourceReceiptSha256'])
        write_json(output / 'source-before.json', before)
        for tool in ['rustc', 'cargo']:
            (output / (tool + '-version.txt')).write_bytes(subprocess.check_output([tool, '-Vv'], cwd=root, env=env))
        result['toolchainReceiptSha256'] = {tool: sha(output / (tool + '-version.txt')) for tool in ['rustc', 'cargo']}
        adapter_bytes = adapter.read_bytes()
        (output / 'adapter.rs').write_bytes(adapter_bytes)
        with example.open('xb') as temporary:
            temporary.write(adapter_bytes)
        owned = True
        print(json.dumps({'starting': command, 'output': str(output)}), flush=True)
        with log_path.open('x') as log:
            process = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT,
                                       start_new_session=True)
            try:
                result['exitCode'] = process.wait(timeout=a.timeout_seconds)
            finally:
                if process.poll() is None:
                    # This session is created above and owns only this cargo run.
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
        assert result['exitCode'] == 0, 'native cargo run failed; inspect retained run.log'
        assert payload.is_file() and binary.is_file()
        result.update(nativePayloadSha256=sha(payload), nativeBinarySha256=sha(binary))
        assert sha(prepared) == result['preparedWireSha256'], 'prepared input changed during run'
        assert sha(fixture) == result['fixtureSha256'], 'fixture changed during run'
        assert sha(adapter) == result['adapterSha256'], 'adapter changed during run'
        native = json.loads(payload.read_bytes())
        assert native['preparedWireSha256'] == result['preparedWireSha256']
        assert native['fixtureSha256'] == result['fixtureSha256']
        assert native['sourceReceiptSha256'] == result['sourceReceiptSha256']
        expected = {(h, c) for h in wire['expectedHosts'] for c in wire['expectedContexts']}
        assert len(wire['expectedHosts']) == 6 and wire['expectedContexts'] == ['none', 'all']
        assert len(wire['calls']) == len(expected) == 12
        assert {(c['host'], c['context']) for c in wire['calls']} == expected
        assert len(native['calls']) == len(expected) and {(c['host'], c['context']) for c in native['calls']} == expected
        result['allExpectedContextsPresent'] = True
        result['expectedHosts'] = wire['expectedHosts']
        result['expectedContexts'] = wire['expectedContexts']
    except BaseException as error:
        result['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if owned and example.exists():
            if sha(example) == result.get('adapterSha256'):
                example.unlink()
            else:
                result['cleanupError'] = 'Owned example changed unexpectedly; preserving its bytes/path for review'
        result['temporaryExampleRemoved'] = not example.exists()
        try:
            after = source_state()
            write_json(output / 'source-after.json', after)
            result['sourceUnchanged'] = before is not None and before == after
            result['untrackedRustAfter'] = git('ls-files', '--others', '--exclude-standard', '--', 'rust/')
        except BaseException as error:
            result['sourceUnchanged'] = False
            result['sourceCheckError'] = str(error)
        if log_path.exists():
            result['logSha256'] = sha(log_path)
        result['seconds'] = time.monotonic() - started
        result['success'] = (result['exitCode'] == 0 and result.get('allExpectedContextsPresent', False)
                             and result['sourceUnchanged'] and result['temporaryExampleRemoved']
                             and not result.get('untrackedRustAfter') and 'error' not in result
                             and 'cleanupError' not in result)
        write_json(output / 'result.json', result)
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)
    print(json.dumps({'success': result['success'], 'receipt': str(output / 'result.json')}), flush=True)
    raise SystemExit(0 if result['success'] else 1)


if __name__ == '__main__':
    main()
