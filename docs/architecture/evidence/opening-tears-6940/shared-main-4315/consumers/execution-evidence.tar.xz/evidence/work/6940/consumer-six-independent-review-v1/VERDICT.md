# Independent six-host review

I approve the bounded semantic classification of the **actual d034 → 1cb ISSUE129 consumer result**. I found no concrete numerical or provenance blocker in the reviewed mechanism/evidence. This does not approve a byte-identity exception by host ID, final refreshed source, or performance.

The independent check rehashed all declared inputs of the three causal/physical receipts, read both complete 396-row stage streams, and recomputed all 192 changed facet vertex occurrences using exact rational grid rounding. Each becomes its own original source-grid point; all other facet mesh fields are unchanged. The unchanged pre-facet streams and existing dual-domain incidence receipts identify an intended source-preservation operation, rather than a volume-based choice. The downstream outputs remain genuinely different; the three existing open hosts are not called closed.

For 299638, the actual reconciliation trace and raw input binding identify six changed occurrences/two corners in one of 348 invocations. The authored parent placement and duplicate corner relationship explain the move independently of proximity. I additionally checked the original STEP extrusion axis, zero solid position, exact height 5.90000000000126, and opening top/bottom: they coincide with the host endpoints. This closes a minor omission in the earlier corner checker, which copied opening Z into its comparison.

The finite-face checker accounts for all 24 actual triangles per arm, each uniquely assigned with positive outward orientation to one of six finite oracle faces. Both complete projected domains satisfy the reported existing-grid envelope. Reported overlap is zero within floating arithmetic (largest residual 4.45e-16 m²); this is not an exact multiplicity theorem. The method bounds complete convex faces, not just sampled nearest points. Its f64/GEOS limitation remains explicit. Mixed oracle-volume and projected-area changes are preserved, including worsened faces; no monotonic improvement is claimed.

The full browser witness retains all 1,402 rows and nonmesh result fields. Only 244479 changes counts, explaining the actual +20 vertices/+26 triangles. Complete scalar/material/frame correspondence and native/Node/browser bindings are prerequisites retained in the reviewed receipts, not inferred from matching IDs. Strict cross-arm identity remains **FAIL**.

## Transfer to refreshed source

The old measured source must remain named d034/1cb. The actual d034→56a5 integration changes no Rust files, but does change parser/scanner behavior and frontend benchmark/worker-related sources. The later closed-operand kernel admission is also a numerical change. Neither is covered by this historical execution.

Before transferring this classification, bind clean actual refreshed base and branch to the same selected main, rebuilt WASM, served dist, fixture, worker/GPU context and prepared wire. Compare the complete new consumer payload (all rows, duplicates, instance graph and nonmesh fields) against its corresponding authenticated old arm. Exact payload equality allows reuse of this shape interpretation; any additional delta needs its own causal review. Rebinding only these six IDs or equal total counts is insufficient. Fresh Mini27/native parity and browser9 remain separate obligations, as do all required CI and the untouched timing/admission/noise policy.

`review.json` records the independent checks, hashes, and exact changed-path list; `review.py` is the bounded read-only reproducer. No production source, browser, mesher or historical receipt was changed.
