"""Light independent audit of retained actual evidence; no meshing or browser run."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal
import hashlib,json,struct,base64,re,subprocess
ROOT=Path(__file__).resolve().parents[3]; W=ROOT/'work/6940'; OUT=Path(__file__).with_name('review.json')
assert not OUT.exists()
def read(p):return json.loads((W/p).read_bytes())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
receipts=['consumer-stage-localization-v1/facet-source-grid-restoration.json','consumer-stage-localization-v1/299638-authored-corner-v2.json','consumer-stage-localization-v1/299638-complete-boundary-v1.json']
verified={}
for p in receipts:
 x=read(p)
 for v in x['inputs']:
  if v['path'] not in verified:verified[v['path']]=sha(v['path'])
  assert verified[v['path']]==v['sha256'],v['path']
facet=read(receipts[0]); stages={s:read(f'consumer-stage-{s}-actual-v1/stages.json')for s in ['base','branch']}
assert len(stages['base'])==len(stages['branch'])==396
# Integer/Fraction implementation independent of the producer's floating snap.
def snap(b):
 f=struct.unpack('<f',struct.pack('<I',b))[0];q=Fraction.from_float(f)*65536
 sign=-1 if b>>31 else 1;q=abs(q);n=q.numerator//q.denominator
 if 2*(q.numerator%n.__class__(q.denominator))>=q.denominator:n+=1
 return struct.unpack('<I',struct.pack('<f',sign*n/65536))[0]
summary=[]
for r in facet['rows']:
 i=r['stageOrdinal'];a=stages['base'][i];b=stages['branch'][i];s=stages['base'][i-1]
 assert s==stages['branch'][i-1] and s['stage']=='facet.before' and a['stage']==b['stage']=='facet.after'
 assert {k:v for k,v in a.items()if k!='positionsBits'}=={k:v for k,v in b.items()if k!='positionsBits'}
 actual=[]
 for j in range(0,len(a['positionsBits']),3):
  if a['positionsBits'][j:j+3]!=b['positionsBits'][j:j+3]:
   assert b['positionsBits'][j:j+3]==[snap(x)for x in s['positionsBits'][j:j+3]]
   actual.append(j//3)
 assert actual==[c['vertex']for c in r['changes']]
 summary.append({'host':r['host'],'context':r['context'],'changedOccurrences':len(actual),'uniqueSourcePoints':r['uniqueChangedSourcePositions']})
assert sum(r['changedOccurrences']for r in summary)==192
assert sum(r['uniqueSourcePoints']for r in summary)==39
# Close the original authored checker omission: opening top/bottom must be
# host extrusion endpoints, not Z coordinates copied into the assertion.
author=read('consumer-299638-authoring-oracle-085-v1/299638-authored.json')
ent={x['id']:x['originalStep']['text']for x in author['reachableEntities']}
for x in author['reachableEntities']:
 r=x['originalStep'];raw=base64.b64decode(r['base64']);assert raw.decode()==r['text'] and hashlib.sha256(raw).hexdigest()==r['sha256']
def point(i):return [Decimal(v)for v in re.search(r'\(\((.*?)\)\)',ent[i]).group(1).split(',')]
height=Decimal(re.search(r'#19,([^)]*)\)',ent[299630]).group(1))
assert ent[299629]=='#299629= IFCAXIS2PLACEMENT3D(#6,$,$);'
assert point(6)==[0,0,0] and ent[19]=='#19= IFCDIRECTION((0.,0.,1.));'
translation=point(299699)
assert point(299644)[2]+translation[2]==height
assert point(299657)[2]+translation[2]==0
boundary=read(receipts[2]);faces=[]
for arm in boundary['arms']:
 assignments=arm['assignments'];assert sorted(x['triangle']for x in assignments)==list(range(24))
 assert all(x['maxPlaneDistance']<x['runnerUpDistance'] and x['outwardDot']>0 for x in assignments)
 assert sum(x['nativeTriangles']for x in arm['faces'])==24
 assert arm['completeFiniteFaceExistingGridEnvelope']
 faces.append({'side':arm['side'],'all24AssignedOnce':True,'allAssignmentsUnambiguousAndOutward':True,'sixFiniteDomainsAccounted':len(arm['faces'])==6,'maxNormalDistance':max(x['maxAbsolutePlaneDistance']for x in arm['faces']),'maxAbsoluteReportedOverlapArea':max(abs(x['projectedOverlapArea'])for x in arm['faces'])})
rec=read('consumer-reconcile-branch-actual-v1/reconciliation-analysis-v1.json');changed=[r for r in rec['rows']if r['changed']]
assert len(rec['rows'])==348 and len(changed)==1 and changed[0]['rowOrdinal']==346 and changed[0]['host']==299638
bridge=read('browser-raw-consumer-v1/actual-v3-v4-bridge-v1.json')
assert bridge['deltaCoverageComplete'] and bridge['strictIdentityVerdict']=='FAIL'
# Preserve source binding rather than relabeling old measurements.
repo='/tmp/ifc-6940-cap-818b'; old='d03448ac4b0a64722446288d0e2bfd798cfda947'; main='56a5f58c325997c4c7ec460456a9e150437718cd'
paths=subprocess.check_output(['git','-C',repo,'diff','--name-only',old,main],text=True).splitlines();assert not any(p.startswith('rust/')for p in paths)
result={'schema':1,'checkerSHA256':sha(__file__),'inputHashesVerified':verified,'facetActualRawIndependentFractionCheck':summary,'authoredHostHeightEqualsOpeningTop':str(height),'authoredOpeningBottomEqualsHostBottom':True,'completeFiniteBoundaryReview':faces,'reconciliationObservedInvocations':348,'soleChangedInvocation':346,'strictCrossArmIdentity':'FAIL retained','historicalBoundedSemanticDecision':'APPROVE for actual d034-to-1cb six-host result, with reviewed limits; not final-source qualification','mainTransfer':{'oldMain':old,'selectedMain':main,'changedTrackedPaths':paths,'rustChanged':False,'parserChanged':any(p.startswith('packages/parser/')for p in paths),'requireFreshFullSceneSourceBoundComparison':True},'limits':['Full six-face boundary envelope uses floating GEOS/f64 and existing grid, not exact 3D equality or exact layer/material bijection.','Five facet changes certify restored own source-grid coordinates; they do not prove every later cut surface equals authored IFC or monotonically improves distance/volume.','Recorded remaining open meshes are not certified closed.','Historical early HOLD receipts remain preserved; later explicit reconciliation and finite-boundary receipts supply their missing evidence.','No timing, browser execution, new meshing, CI qualification or source refresh is performed by this audit.']}
OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'output':str(OUT),'sha256':sha(OUT),'facetOccurrences':192,'height':str(height),'boundedHistoricalApproval':True}))
