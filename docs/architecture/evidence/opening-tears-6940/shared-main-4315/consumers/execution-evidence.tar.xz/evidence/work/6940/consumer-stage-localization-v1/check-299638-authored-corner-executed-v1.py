"""Exact authored duplicate-corner arithmetic + actual recorded host/cutter placement.
No meshing, fitted alignment, new acceptance tolerance, or geometry approval.
"""
from pathlib import Path
from decimal import Decimal as D,getcontext
import json,re,hashlib,struct,base64,math
getcontext().prec=70
ROOT=Path(__file__).resolve().parents[3];P=ROOT/'work/6940/consumer-299638-authoring-oracle-085-v1';OUT=Path(__file__).with_name('299638-authored-corner-v1.json');assert not OUT.exists()
author=json.loads((P/'299638-authored.json').read_bytes());entities={e['id']:e['originalStep']for e in author['reachableEntities']}
def tuple_values(id):
 t=entities[id]['text'];return [D(x)for x in re.search(r'\(\(([^()]*)\)\)',t).group(1).split(',')]
def scalar_values(id):return entities[id]['text']
assert '#299618,'in entities[299702]['text'] and '#299699' in entities[299701]['text']
assert tuple_values(6)==[D(0)]*3 and tuple_values(19)==[D(0),D(0),D(1)] and tuple_values(25)==[D(-1),D(0)]
center=tuple_values(299625);dims=[D(x)for x in scalar_values(299628).rstrip(';').rstrip(')').split(',')[-2:]]
host_xy=[center[0]+dims[0]/2,center[1]+dims[1]/2];translation=tuple_values(299699);opening=[tuple_values(id)for id in [299644,299657]]
sourceCorners=[]
for op in opening:
 point=[op[k]+translation[k]for k in range(3)];host=[*host_xy,op[2]];sourceCorners.append({'openingLocalPoint':[str(x)for x in op],'openingPointInSharedHostFrame':[str(x)for x in point],'hostProfileCorner':[str(x)for x in host],'exactDecimalCoordinateDelta':[str(point[k]-host[k])for k in range(3)]})
assert max(abs(D(x))for p in sourceCorners for x in p['exactDecimalCoordinateDelta'])==D('5e-16')
analysis_path=ROOT/'work/6940/consumer-reconcile-branch-actual-v1/reconciliation-analysis-v1.json';analysis=json.loads(analysis_path.read_bytes());changed=[r for r in analysis['rows']if r['changed']];assert len(changed)==1 and changed[0]['host']==299638 and changed[0]['rowOrdinal']==346
stages_path=analysis_path.with_name('stages.json');stages=json.loads(stages_path.read_bytes());record=changed[0]
parts={k:[s for s in stages if s['stage']==k][record['rowOrdinal']]for k in ['reconcile.host','reconcile.cutter.before','reconcile.cutter.after']}
for stage,key in [('reconcile.host','hostStageSHA256'),('reconcile.cutter.before','beforeStageSHA256'),('reconcile.cutter.after','afterStageSHA256')]:
 actual={k:v for k,v in parts[stage].items()if k not in ['callHost','callContext']};assert hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest()==record[key]
node_path=ROOT/'work/6940/canonical-consumer-deltas-v1/branch-actual-v2.json';node=json.loads(node_path.read_bytes());rtc=struct.unpack('<ddd',base64.b64decode(node['prepass']['rtcOffset']['base64']));assert node['prepass']['needsShift']
origin=[struct.unpack('<d',struct.pack('<Q',int(x,16)))[0]for x in parts['reconcile.host']['originBits']]
reference=json.loads((P/'299638-source.json').read_bytes());vertices=[reference['vertices'][i:i+3]for i in range(0,len(reference['vertices']),3)]
f32=lambda b:struct.unpack('<f',struct.pack('<I',b))[0]
actual=[]
for c in record['changes']:
 before=[(f32(c['sourceBits'][k])+origin[k])+rtc[k]for k in range(3)];after=[(f32(c['candidateBits'][k])+origin[k])+rtc[k]for k in range(3)];nearest=min(range(len(vertices)),key=lambda i:sum((vertices[i][k]-after[k])**2for k in range(3)))
 actual.append(c|{'sourceWorld':before,'candidateWorld':after,'nearestAuthoredSourceVertex':vertices[nearest],'candidateDistanceToAuthoredSourceCorner':math.dist(after,vertices[nearest]),'sourceDistanceToSameAuthoredCorner':math.dist(before,vertices[nearest])})
result={'checkerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in [P/'299638-authored.json',P/'299638-source.json',analysis_path,stages_path,node_path]],'sharedPlacement':'Opening299703 has placement299702 parent HOST299618; host solid placement299629 is identity, rectangle299627 uses symmetric sign-reversed axes. Compare authored positions in shared host frame before their COMMON placement, not a fitted bbox.','unitScaleToMetres':author['unitScaleToMetres'],'authoredCorners':sourceCorners,'actualChanges':actual,'sourceEntities':{str(i):entities[i]for i in [6,19,25,299625,299627,299628,299629,299630,299644,299657,299699,299701,299702]},'interpretation':'The literal existing host targets represent the same authored top/bottom corner duplicated in opening299703. One-grid divergence was introduced by placement/storage arithmetic. Proximity alone is not the causal justification. Distances to oracle corners are retained honestly; no monotonic whole-surface or volume claim.','physicalChangeApproval':False}
OUT.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({'exactCornerDeltas':[x['exactDecimalCoordinateDelta']for x in sourceCorners],'actualWorldCornerQueries':[{'vertex':r['vertex'],'candidateDistance':r['candidateDistanceToAuthoredSourceCorner'],'sourceDistance':r['sourceDistanceToSameAuthoredCorner']}for r in actual]}))
