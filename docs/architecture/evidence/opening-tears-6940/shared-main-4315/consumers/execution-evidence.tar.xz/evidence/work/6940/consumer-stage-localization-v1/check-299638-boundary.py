"""Actual finite six-face oracle coverage at the existing kernel-grid scale.
No fitted alignment, nearest-point sampling, tolerance update, meshing or approval.
"""
from pathlib import Path
import json,hashlib,base64,struct,math
from decimal import Decimal
import numpy as np
import shapely
from shapely.geometry import Polygon,MultiPoint
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).with_name('299638-complete-boundary-v1.json');assert not OUT.exists()
assert np.__version__=='2.0.2' and shapely.__version__=='2.0.7'
paths={s:ROOT/f'work/6940/consumer-native12-{s}-actual-v1/native-payload.json'for s in ['base','branch']}
oracle_path=ROOT/'work/6940/consumer-299638-authoring-oracle-085-v1/299638-cut.json';author_path=oracle_path.with_name('299638-authored.json');node_path=ROOT/'work/6940/canonical-consumer-deltas-v1/base-actual-v2.json'
oracle=json.loads(oracle_path.read_bytes());author=json.loads(author_path.read_bytes());node=json.loads(node_path.read_bytes());rtc=np.frombuffer(base64.b64decode(node['prepass']['rtcOffset']['base64']),dtype='<f8');assert node['prepass']['needsShift']
ref=np.array(oracle['vertices']).reshape(-1,3);ref_idx=np.array(oracle['faces']).reshape(-1,3);zs=sorted(set(ref[:,2]));xy=sorted(set(map(tuple,ref[:,:2])));assert len(zs)==2 and len(xy)==4 and len(ref)==8
# Original world coordinates and exact observed reference topology determine
# the finite authored quad; no bbox rotation/translation is inferred.
anchor=np.array(xy[0]);cap=MultiPoint([np.array(p)-anchor for p in xy]).convex_hull;assert isinstance(cap,Polygon)and len(cap.exterior.coords)==5
corners=list(cap.exterior.coords)[:-1]
# Shapely hull can be clockwise; make the authored perimeter CCW explicitly.
if sum(corners[i][0]*corners[(i+1)%4][1]-corners[(i+1)%4][0]*corners[i][1]for i in range(4))<0:corners.reverse()
faces=[{'name':'bottom','normal':np.array([0.,0.,-1.]),'anchor':np.array([*anchor,zs[0]]),'u':np.array([1.,0.,0.]),'v':np.array([0.,1.,0.]),'domain':cap},{'name':'top','normal':np.array([0.,0.,1.]),'anchor':np.array([*anchor,zs[1]]),'u':np.array([1.,0.,0.]),'v':np.array([0.,1.,0.]),'domain':cap}]
for i in range(4):
 a=np.array(corners[i])+anchor;b=np.array(corners[(i+1)%4])+anchor;e=b-a;length=float(np.linalg.norm(e));u=np.array([e[0]/length,e[1]/length,0.]);v=np.array([0.,0.,1.]);faces.append({'name':f'wall-{i}','normal':np.cross(u,v),'anchor':np.array([*a,zs[0]]),'u':u,'v':v,'domain':Polygon([(0,0),(length,0),(length,zs[1]-zs[0]),(0,zs[1]-zs[0])])})
G=1/65536
result={'schema':1,'checkerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in [*paths.values(),oracle_path,author_path,node_path]],'frame':'world IFC Z-up = inverse actual FFI Y-up for stored positions and origin, then (stored+origin)+actual prepass RTC. localToWorld remains baked-source metadata, never applied twice.','gridMetres':G,'scope':'Complete projected finite domains of every actual triangle, not sampled nearest-point distance; actual deviations and existing-grid envelope reported separately from semantic approval.','oracle':{'vertices':len(ref),'triangles':len(ref_idx),'metrics':oracle['metrics']},'arms':[],'physicalChangeApproval':False}
# Confirm every oracle triangle belongs exactly to its observed cap or one
# authored vertical perimeter edge; no non-prismatic face silently ignored.
referenceAssignments=[]
for tri in ref_idx:
 t=ref[tri];candidates=[]
 if len(set(t[:,2]))==1:candidates=[0 if t[0,2]==zs[0] else 1]
 else:
  unique=set(map(tuple,t[:,:2]));assert len(unique)==2
  for i in range(4):
   edge={tuple(np.array(corners[i])+anchor),tuple(np.array(corners[(i+1)%4])+anchor)}
   if unique==edge:candidates.append(i+2)
 assert len(candidates)==1;referenceAssignments.append(candidates[0])
assert set(referenceAssignments)==set(range(6))
for side,p in paths.items():
 payload=json.loads(p.read_bytes());call=next(c for c in payload['calls']if c['host']==299638 and c['context']=='all');assert len(call['meshes'])==1;m=call['meshes'][0]
 pos=np.array(m['positionsBits'],dtype='<u4').view('<f4').astype(np.float64).reshape(-1,3);origin=np.array([struct.unpack('<d',struct.pack('<Q',int(b,16)))[0]for b in m['originBits']]);pos=pos[:,[0,2,1]]*np.array([1.,-1.,1.]);origin=origin[[0,2,1]]*np.array([1.,-1.,1.]);world=(pos+origin)+rtc;idx=np.array(m['indices']).reshape(-1,3);assert np.all(np.isfinite(world))and len(idx)==24
 groups=[[]for _ in faces];distances=[[]for _ in faces];windings=[[]for _ in faces];assignments=[]
 for ti,ids in enumerate(idx):
  t=world[ids];errors=[float(np.max(np.abs((t-f['anchor'])@f['normal'])))for f in faces];order=sorted(range(6),key=lambda i:(errors[i],i));face=order[0];f=faces[face];q=np.column_stack(((t-f['anchor'])@f['u'],(t-f['anchor'])@f['v']));poly=Polygon(q);assert poly.is_valid and poly.area>0,'Do not drop degenerate or invalid projection';groups[face].append(poly);distances[face].extend(((t-f['anchor'])@f['normal']).tolist());w=float(np.cross(t[1]-t[0],t[2]-t[0])@f['normal']);windings[face].append(w);assignments.append({'triangle':ti,'face':f['name'],'maxPlaneDistance':errors[face],'runnerUpDistance':errors[order[1]],'outwardDot':w})
 rows=[]
 for i,f in enumerate(faces):
  assert groups[i],'No missing authored face may be ignored';union=unary_union(groups[i]);domain=f['domain'];native_in_ref=domain.buffer(G).covers(union);ref_in_native=union.buffer(G).covers(domain)
  rows.append({'name':f['name'],'nativeTriangles':len(groups[i]),'maxAbsolutePlaneDistance':max(abs(x)for x in distances[i]),'allNativeVerticesWithinExistingGridOfPlane':max(abs(x)for x in distances[i])<=G,'allTrianglesOutward':all(x>0 for x in windings[i]),'referenceArea':domain.area,'projectedUnionArea':union.area,'sumProjectedTriangleArea':sum(x.area for x in groups[i]),'projectedOverlapArea':sum(x.area for x in groups[i])-union.area,'missingProjectedArea':domain.difference(union).area,'extraProjectedArea':union.difference(domain).area,'symmetricDifferenceProjectedArea':domain.symmetric_difference(union).area,'referenceInsideNativeProjectedGridBuffer':ref_in_native,'nativeInsideReferenceProjectedGridBuffer':native_in_ref,'domainWkt':domain.wkt,'nativeUnionWkt':union.wkt})
 result['arms'].append({'side':side,'vertices':len(world),'triangles':len(idx),'allActualTrianglesAssigned':len(assignments),'faces':rows,'assignments':assignments,'completeFiniteFaceExistingGridEnvelope':all(r['allNativeVerticesWithinExistingGridOfPlane']and r['referenceInsideNativeProjectedGridBuffer']and r['nativeInsideReferenceProjectedGridBuffer']and r['allTrianglesOutward']for r in rows)})
result['interpretation']='For each face, every actual triangle lies in a normal one-grid slab and BOTH complete projected finite sets lie in the other one-grid buffer. This establishes a facewise sqrt(2)*grid 3D envelope (not exact surface identity). It cannot by itself approve displacement; exact authored-duplicate-corner reconciliation is a separate causal requirement. No thresholds are changed.'
OUT.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps([{'side':a['side'],'completeFiniteFaceExistingGridEnvelope':a['completeFiniteFaceExistingGridEnvelope'],'faces':[{k:v for k,v in f.items()if k not in ['domainWkt','nativeUnionWkt']}for f in a['faces']]}for a in result['arms']]))
