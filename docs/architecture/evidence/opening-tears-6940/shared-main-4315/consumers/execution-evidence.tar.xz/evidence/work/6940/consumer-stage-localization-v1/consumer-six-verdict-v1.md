# Actual ISSUE129 consumer delta verdict — d034 → 1cb

The six observed changes are consistent with two intended source-preservation repairs. I recommend bounded semantic classification after independent review of the linked receipts. This is not a strict byte-identity pass, a universal authored-surface guarantee, or a performance qualification. New finite-V2 runtime output must be measured and rebound separately.

All 1,402 actual browser mesh rows and all non-mesh geometry-result fields were retained. The actual V3↔V4 bridge exhaustively identifies exactly 9094, 12381, 149280, 244479, 295370 and 299638. Their ALL mesh bytes, frame/scalar/material fields and multiplicity match canonical Node WASM; all 24 configured NONE/ALL native calls match Node exactly. The original producer at the actual viewer hash tolerance supplies exactly the observed hash/AABB/volume values, preserving closure flags and absent volumes.

For 9094, 12381, 149280, 244479 and 295370, every recorded stage is identical until facet.after changes positions only. Every pre-facet operand is closed and noncollapsed in both actual incidence domains. Every one of the 192 changed position occurrences (39 distinct source positions counted separately per stage) becomes exactly its own pre-facet input coordinate snapped to the existing kernel grid. Indices, normals, origins and frame metadata do not change at that operation. This establishes the intended source-grid restoration invariant; it does not assert exact equality of later cut surfaces. The complete reconciliation trace reports no additional host/cutter reconciliation changes for these five hosts.

For 299638, the first difference is before the sole consolidation call. The actual lower-PR analytic opening reconciliation is the only changed invocation among 348 observed invocations: six occurrences representing two points are copied exactly onto existing host coordinates, each within one existing grid step per axis. The original depth vector is [0,1,0]. Its second, oblique opening is unchanged. This is observed function output, not attribution from mesh counts.

The authored STEP graph independently explains why those points coincide: opening299703's faceted-BREP top/bottom corner, translated through its placement parented directly to host299618, equals the host rectangle corner to exporter decimal residuals of 5e-16/2.78e-17 metres before their common placement. Actual target points are 15.8/96.7nm from pinned IfcOpenShell source corners; their previous cutter copies were 1.013/1.832µm away. The reason for the move is this authored duplicate-corner identity, not proximity alone.

The pinned source and cut oracle for 299638 are each closed, noncollapsed 12-triangle surfaces. Both native ALL outputs are closed/noncollapsed 24-triangle surfaces. The full finite-face check assigns every actual triangle to all six authored faces, verifies outward orientation and complete projected-domain coverage in both directions within the existing grid scale, and records every face's residual/extra/missing projected area. It uses explicit inverse FFI Y-up, recorded origin and actual RTC; no bbox alignment or second localToWorld application. This is a measured facewise quantization envelope using f64/GEOS operations, not exact surface identity or a new acceptance ceiling.

The oracle metrics are mixed and remain recorded: the candidate's whole volume is slightly farther from the oracle, and one wall's projected-domain discrepancy worsens while other faces improve. No monotone oracle-distance or volume claim is made. The independent source relationship and complete finite-boundary coverage justify the bounded classification.

Only 244479 changes mesh totals (+20 vertices/+26 triangles), accounting exactly for both changed global counters in the complete 1,402-row result. No counter is excluded from the report. Existing open-cut counts on 9094/12381/295370 are retained, not called repaired or closed.

Evidence:

- `consumer-stage-localization-v1/localization.json`
- `consumer-stage-localization-v1/facet-source-grid-restoration.json`
- `consumer-stage-base-actual-v1/facet-input-domains.json`
- `consumer-reconcile-branch-actual-v1/reconciliation-analysis-v1.json`
- `consumer-stage-localization-v1/299638-authored-corner-v2.json`
- `consumer-stage-localization-v1/299638-complete-boundary-v1.json`
- `consumer-fingerprint-probe-v1/actual-browser-binding-v1.json`
- `browser-raw-consumer-v1/actual-v3-v4-bridge-v1.json`

Original strict cross-arm identity remains FAIL. Final-source browser qualification, all planned timing attempts, unchanged admission/noise checks, and required CI remain separate.
