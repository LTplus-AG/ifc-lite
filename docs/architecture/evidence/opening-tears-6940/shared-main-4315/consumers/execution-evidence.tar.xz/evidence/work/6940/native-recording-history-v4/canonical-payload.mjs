// Offline structural/root audit of ORIGINAL 470f canonical complete CPU payload.
// No runtime/browser imports, no schema4/raw diagnostic fallback, no perf verdict.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
const must=(v,m)=>{if(!v)throw Error(m);};
const hash=v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const hex=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
const count=v=>Number.isSafeInteger(v)&&v>=0;
const exactKeys=(o,keys)=>o&&typeof o==='object'&&!Array.isArray(o)&&JSON.stringify(Object.keys(o).sort())===JSON.stringify([...keys].sort());
const sorted=rows=>rows.every((row,i)=>!i||JSON.stringify(rows[i-1])<=JSON.stringify(row));
export function checkPayload(p){
 must(p?.schema===3&&Array.isArray(p.models)&&p.models.length===1,'Exactly one actual canonical schema3 model required');
 must(typeof p.scope==='string'&&p.scope.length&&typeof p.normalization==='string'&&p.normalization.length&&Array.isArray(p.limitations),'Complete canonical capture scope absent');
 const reports=[];
 for(const m of p.models){
  must(m.loadPath==='wasm'&&typeof m.cacheState==='string'&&m.cacheState!=='hit','Actual uncached WASM model required');
  for(const k of ['meshCount','flatVertices','flatTriangles','instanceEntities','instanceTemplates','instanceOccurrences'])must(count(m[k]),'Invalid canonical count '+k);
  must(m.meshCount>0,'Retained complete flat CPU payload required');
  const g=m.geometry;
  must(exactKeys(g,['schema','geometryResultFields','flatMeshMerkleRows','normalizedInstanceMerkleRows'])&&g.schema==='ifc6940-complete-cpu-geometry-merkle-v3','Complete canonical geometry shape differs');
  const fields=g.geometryResultFields,meshes=g.flatMeshMerkleRows,instances=g.normalizedInstanceMerkleRows;
  must(Array.isArray(fields)&&Array.isArray(meshes)&&Array.isArray(instances),'Canonical field/mesh/instance rows absent');
  const names=fields.map(f=>{must(exactKeys(f,['field','sha256'])&&typeof f.field==='string'&&f.field.length&&hex(f.sha256),'Invalid own geometryResult field');return f.field;});
  must(new Set(names).size===names.length&&names.every((v,i)=>!i||names[i-1]<v),'Duplicate/unsorted own geometryResult field names');
  for(const k of ['coordinateInfo','meshes','totalTriangles','totalVertices'])must(names.includes(k),'Missing known canonical own field '+k);
  must(meshes.length===m.meshCount&&sorted(meshes),'Mesh multiplicity/count/arrival canonicalization differs');
  let vertices=0,triangles=0;
  for(const r of meshes){
   must(exactKeys(r,['expressId','geometryItemId','geometryClass','vertices','triangles','sha256'])&&Number.isSafeInteger(r.expressId)&&[r.geometryItemId,r.geometryClass].every(v=>v===null||Number.isSafeInteger(v))&&count(r.vertices)&&r.vertices>0&&count(r.triangles)&&r.triangles>0&&hex(r.sha256),'Invalid complete flat mesh row');
   vertices+=r.vertices;triangles+=r.triangles;
  }
  must(Number.isSafeInteger(vertices)&&Number.isSafeInteger(triangles)&&vertices===m.flatVertices&&triangles===m.flatTriangles,'Complete flat counts differ from all mesh rows');
  must(fields.find(f=>f.field==='meshes').sha256===hash({type:'SortedMeshMerkleRows',rows:meshes}),'Actual meshes own-field root differs');
  must(instances.length===m.instanceOccurrences&&sorted(instances),'Instance occurrence count/canonicalization differs');
  for(const r of instances)must(exactKeys(r,['entityId','sha256'])&&Number.isSafeInteger(r.entityId)&&hex(r.sha256),'Invalid normalized complete instance row');
  must(new Set(instances.map(r=>r.entityId)).size===m.instanceEntities,'Instance entity multiplicity differs');
  const raw=m.rawInstanceGraph;
  must(exactKeys(raw,['templateSlots','instanceEntities','instanceOccurrences','addressingRetainedInSha256'])&&count(raw.templateSlots)&&raw.templateSlots>=m.instanceTemplates&&raw.instanceEntities===m.instanceEntities&&raw.instanceOccurrences===m.instanceOccurrences&&raw.addressingRetainedInSha256===true&&hex(m.rawInstanceGraphSha256),'Actual raw instance-addressing coverage absent');
  must(hex(m.completeGeometryPayloadSha256)&&hash(g)===m.completeGeometryPayloadSha256,'Complete mesh/global/normalized-instance root differs');
  reports.push({meshCount:meshes.length,flatVertices:vertices,flatTriangles:triangles,instanceEntities:m.instanceEntities,instanceTemplates:m.instanceTemplates,instanceOccurrences:instances.length,ownGeometryResultFields:names,completeGeometryPayloadSha256:m.completeGeometryPayloadSha256,rawInstanceGraphSha256:m.rawInstanceGraphSha256});
 }
 return{schema:1,ok:true,scope:'Source-pinned canonical schema3 complete retained CPU Merkle structure/root consistency; no raw-array recovery or new physical/perf approval',models:reports};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(fs.realpathSync(process.argv[1])).href){let receipt=JSON.parse(fs.readFileSync(process.argv[2]));for(const k of (process.argv[3]??'').split('/').slice(1))receipt=receipt[k.replaceAll('~1','/').replaceAll('~0','~')];process.stdout.write(JSON.stringify(checkPayload(receipt.payload)));}
