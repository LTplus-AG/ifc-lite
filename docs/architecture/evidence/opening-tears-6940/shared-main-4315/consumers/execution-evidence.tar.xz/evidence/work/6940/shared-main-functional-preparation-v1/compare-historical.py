"""Exact complete CPU geometry transfer; never geometry or timing acceptance alone."""
import argparse,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
for name in ['old','new','old-head','new-head','output']:p.add_argument('--'+name,required=True)
a=p.parse_args();output=Path(a.output);assert not output.exists()
def load(path,head):
 b=Path(path).read_bytes();d=json.loads(b)
 assert d['ok'] is True and d['functionalOnly'] is True and d['noTimingQualification'] is True
 assert d['server']['manifest']['head']==head and not d['server']['pending']
 assert d['servingStateAtReceipt']=={'side':d['side'],'epoch':d['server']['epoch']}
 assert d['collectorSha256']=='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17'
 assert not d['errors'] and not d['gpuHealth']['contaminated']
 e=d['environment'];assert e['secureContext'] is True and e['crossOriginIsolated'] is True
 assert e['visibility']=='visible' and e['hasFocus'] is True
 assert e['viewport']=={'width':1280,'height':800,'dpr':1.5}
 g=d['gpuHealth'];assert g['devicesCreated']==1 and not g['reasons']
 assert all(g[k]==0 for k in ['deviceLost','instanceErrors','deviceReplacements','uncapturedErrors'])
 assert d['trace']['attrs']['loadPath']=='wasm' and not any(s['name']=='cache.storeReady'for s in d['trace']['spans'])
 assert next(s for s in d['trace']['spans']if s['name']=='geometry.pool')['attrs']['workerCount']==4
 assert d['payload']['schema']==3 and len(d['payload']['models'])==1
 m=d['payload']['models'][0];assert m['loadPath']=='wasm' and m['cacheState']!='hit'
 assert m['geometry']['schema']=='ifc6940-complete-cpu-geometry-merkle-v3'
 assert m['meshCount']==len(m['geometry']['flatMeshMerkleRows'])
 assert m['instanceOccurrences']==len(m['geometry']['normalizedInstanceMerkleRows'])
 return d,m,hashlib.sha256(b).hexdigest()
old,om,oh=load(a.old,a.old_head);new,nm,nh=load(a.new,a.new_head)
assert old['side']==new['side']
assert old['fixtureIdentity']==new['fixtureIdentity']
fields=['meshCount','flatVertices','flatTriangles','instanceEntities','instanceTemplates','instanceOccurrences','geometry','completeGeometryPayloadSha256','specialSlabs']
comparison={k:om[k]==nm[k]for k in fields}
result={'schema':1,'checkerSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'old':{'path':str(Path(a.old).resolve()),'sha256':oh,'head':a.old_head},
 'new':{'path':str(Path(a.new).resolve()),'sha256':nh,'head':a.new_head},
 'completePerArmGeometryFields':comparison,'ok':all(comparison.values()),
 'rawInstanceAddressGraphEqual':om['rawInstanceGraphSha256']==nm['rawInstanceGraphSha256'],
 'limits':['Complete normalized CPU geometry transfer only; exact referenced instance contents retained, transient addresses compared separately.','Source-bound actual executions keep their original commits. No GPU pixel/buffer identity, cross-arm identity, geometry correctness or performance approval is inferred.']}
with output.open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'ok':result['ok'],'output':str(output)}))
raise SystemExit(0 if result['ok'] else 2)
