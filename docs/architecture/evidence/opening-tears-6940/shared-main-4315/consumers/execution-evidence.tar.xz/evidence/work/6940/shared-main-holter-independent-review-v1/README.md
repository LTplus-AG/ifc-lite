# Fresh Holter: independent complete CPU comparison

**PASS normalized canonical CPU geometry identity** for actual main56a5 versus integrated4315. This is a functional result, not timing or V5 recording feasibility.

`review-v2.json` and `review-v2.mjs` retain the reproducible offline review. Every source/build/fixture/input hash is bound. Both current checkouts are clean at their recorded commit/tree; all951 served files per arm, each package WASM, and authentic177,465,622-byte Holter fixture were rehashed. Actual fresh/cold receipts, visible focused1280×800/DPR1.5, four real workers, uncached WASM and healthy GPU were checked.

The entire normalized geometry object is identical:60,001 flat mesh rows,50,631 instance occurrences representing49,999 entities/1,092 templates, all seven actual geometry-result own fields, and every row multiplicity/hash. Flat totals are1,761,017 vertices/877,450 triangles. Both complete roots independently recompute to `16520384047e95e5268f742f8bff4422764322532577bf42c236183de5e10cbd`. There are no changed normalized mesh, instance or global-field rows requiring semantic disposition.

The sole model-field difference is `rawInstanceGraphSha256`: base `e1c08c793a91bcd926df3e7960a117770b1e61f4b35568f062a1f15d639e5cf4`, branch `4ac58a16e4c427168354660d9b00b63e99e3efe005e52e6acc0c15e08b956cb4`. Raw transient addressing is NOT byte-identical. Original470f separately normalizes arrival/template addresses while retaining template geometry, full occurrence records, canonical anchors/translations and provenance. That complete normalized object is identical. No GPU-buffer/pixel identity, authored-shape oracle or native-Holter equality follows.

The first reviewer script assumed `servingStateAtReceipt.manifest.head`; authentic receipt schema contains only side/epoch there. Its TypeError and source remain in `review.json`/`review.mjs`. V2 checks that real side/epoch and the actual full `server.manifest`, source checkout and build receipt. No observation or acceptance threshold was changed.

No browser, heavy job or video decoder was run by this review. Actual recorded lifecycle/cadence/media feasibility and performance remain pending.
