// Offline review of authentic saved Holter receipts; no browser/geometry execution.
import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {execFileSync} from 'node:child_process';import {isDeepStrictEqual as equal} from 'node:util';import {checkPayload} from '../native-recording-history-v4/canonical-payload.mjs';
const root=process.cwd(),here=path.resolve('work/6940/shared-main-holter-independent-review-v1');
const must=(v,m)=>{if(!v)throw Error(m);},sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p));
const ref=p=>({path:path.resolve(p),sha256:sha(fs.readFileSync(p)),bytes:fs.statSync(p).size});
async function fileHash(p){const h=crypto.createHash('sha256');for await(const b of fs.createReadStream(p))h.update(b);return h.digest('hex');}
const git=(cwd,...args)=>execFileSync('git',args,{cwd}).toString().trim();
const expected={base:'56a5f58c325997c4c7ec460456a9e150437718cd',branch:'431571bdb96a20a73b19907c2c3ec05dc7733f43'};
const result={schema:1,at:new Date().toISOString(),scope:'Independent saved full canonical CPU payload, source/build and actual cold/worker/GPU audit. No browser, native mesh generation, video decode or timing qualification.',ok:false,inputs:[],arms:[],performanceQualified:false,recordedFeasibilityQualified:false};
const receipts=[];const fixtureHashes=new Map();
try{
 for(const p of ['work/6940/browser-ab-cohort.mjs','work/6940/native-recording-history-v4/canonical-payload.mjs',path.join(here,'review-v2.mjs')])result.inputs.push(ref(p));
 must(result.inputs[0].sha256==='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17','Original collector drift');
 for(const side of ['base','branch']){
  const id=`functional-holter-${side}-shared56a5-v1`,file=`work/6940/shared-main-browser-v1/receipts/${id}.result.json`,d=read(file);result.inputs.push(ref(file));receipts.push(d);
  must(d.id===id&&d.side===side&&d.ok===true&&d.functionalOnly===true&&d.noTimingQualification===true&&equal(d.errors,[]),'Actual functional result failed');
  must(d.collectorSha256===result.inputs[0].sha256,'Collector identity');const structure=checkPayload(d.payload),m=d.server.manifest;
  must(m.head===expected[side]&&d.server.side===side&&d.servingStateAtReceipt.side===side&&d.servingStateAtReceipt.epoch===d.server.epoch,'Actual source selection');
  must(git(m.checkout,'rev-parse','HEAD')===m.head&&git(m.checkout,'rev-parse','HEAD^{tree}')===m.tree,'Current source differs');
  must(sha(execFileSync('git',['diff','HEAD','--'],{cwd:m.checkout}))===m.trackedDiffSha256&&m.trackedDiffSha256===sha(Buffer.alloc(0)),'Tracked source drift');
  const bp=`work/6940/${side==='base'?'browser-build-main-56a5-v1':'browser-build-integrated-4315-v1'}/result.json`,build=read(bp);result.inputs.push(ref(bp));
  must(build.head===m.head&&build.tree===m.tree&&build.exitCode===0&&build.trackedSourceUnchanged===true&&build.rustSourceUnchanged===true&&build.wasmNewerThanRustSources===true&&build.singleServedIfcGeometryWasmExactlyMatchesPackage===true,'Build fence');
  must(sha(Buffer.from(JSON.stringify(m.files)))===m.distManifestSha256,'Manifest self hash');
  const cmp=a=>[...a].sort((a,b)=>a.path.localeCompare(b.path));
  must(equal(cmp(build.artifacts.filter(x=>x.path.startsWith('apps/viewer/dist/')).map(x=>({...x,path:x.path.slice('apps/viewer/dist/'.length)}))),cmp(m.files)),'Build served inventory differs');
  for(const f of m.files){const p=path.join(m.dist,f.path);must(fs.statSync(p).size===f.bytes&&await fileHash(p)===f.sha256,'Served artifact changed '+f.path);}
  const pkg=m.packageWasm;must(fs.statSync(pkg.path).size===pkg.bytes&&await fileHash(pkg.path)===pkg.sha256,'Package WASM changed');
  const fixture=d.server.fixtures.holter;must(equal(d.fixtureIdentity,{name:fixture.name,bytes:fixture.bytes,sha256:fixture.sha256}),'Fixture identity mismatch');
  if(!fixtureHashes.has(fixture.path))fixtureHashes.set(fixture.path,await fileHash(fixture.path));must(fs.statSync(fixture.path).size===fixture.bytes&&fixtureHashes.get(fixture.path)===fixture.sha256,'Actual fixture changed');
  const cf=`work/6940/shared-main-browser-v1/flows/${id}/open-cold.json`,coldEnvelope=read(cf),cold=coldEnvelope.cold.reply.structuredContent.value;result.inputs.push(ref(cf));
  must(cold.verified===true&&cold.beforeAppBoot===true&&cold.head===m.head&&cold.side===side&&cold.epoch===d.server.epoch&&cold.remainingServiceWorkers===0&&equal(cold.remainingCaches,[])&&equal(cold.remainingDB,[])&&cold.localStorageLength===0&&cold.sessionStorageLength===0,'Actual cold storage fence');
  const e=d.environment;must(e.visibility==='visible'&&e.hasFocus===true&&e.secureContext===true&&e.crossOriginIsolated===true&&equal(e.viewport,{width:1280,height:800,dpr:1.5}),'Actual environment differs');
  must(d.trace.attrs.loadPath==='wasm'&&equal(d.trace.spans.filter(s=>s.name==='geometry.pool').map(s=>s.attrs.workerCount),[4])&&!d.trace.spans.some(s=>s.name==='cache.storeReady'),'Actual worker/cache path');
  const g=d.gpuHealth;must(g.contaminated===false&&equal(g.reasons,[])&&g.devicesCreated===1&&['deviceLost','instanceErrors','deviceReplacements','uncapturedErrors'].every(k=>g[k]===0),'GPU health');
  result.arms.push({side,head:m.head,tree:m.tree,tabId:coldEnvelope.open.structuredContent.tabId,packageWasm:pkg,servedArtifactsRehashed:m.files.length,fixture,structure,gpuHealth:g,environment:e});
 }
 const a=receipts[0].payload.models[0],b=receipts[1].payload.models[0];
 const diffRows=(xs,ys)=>{const count=rows=>{const m=new Map();for(const x of rows){const k=JSON.stringify(x);m.set(k,(m.get(k)??0)+1);}return m;},x=count(xs),y=count(ys),removed=[],added=[];for(const[k,n]of x)if(n>(y.get(k)??0))removed.push({row:JSON.parse(k),multiplicity:n-(y.get(k)??0)});for(const[k,n]of y)if(n>(x.get(k)??0))added.push({row:JSON.parse(k),multiplicity:n-(x.get(k)??0)});return{removed,added};};
 const meshDiff=diffRows(a.geometry.flatMeshMerkleRows,b.geometry.flatMeshMerkleRows),instanceDiff=diffRows(a.geometry.normalizedInstanceMerkleRows,b.geometry.normalizedInstanceMerkleRows),fieldDiff=diffRows(a.geometry.geometryResultFields,b.geometry.geometryResultFields);
 result.crossArm={normalizedEntireGeometryExactlyEqual:equal(a.geometry,b.geometry),wholeNormalizedPayloadExactlyEqual:equal(receipts[0].payload,receipts[1].payload),completeGeometryRoot:a.completeGeometryPayloadSha256,baseRoot:sha(Buffer.from(JSON.stringify(a.geometry))),branchRoot:sha(Buffer.from(JSON.stringify(b.geometry))),flatMeshRowsCompared:a.geometry.flatMeshMerkleRows.length,instanceOccurrencesCompared:a.geometry.normalizedInstanceMerkleRows.length,ownFieldsCompared:a.geometry.geometryResultFields,meshDiff,instanceDiff,fieldDiff,rawAddressSummaryEqual:equal(a.rawInstanceGraph,b.rawInstanceGraph),rawAddressHashes:{base:a.rawInstanceGraphSha256,branch:b.rawInstanceGraphSha256},rawAddressHashEqual:a.rawInstanceGraphSha256===b.rawInstanceGraphSha256};
 must(result.crossArm.normalizedEntireGeometryExactlyEqual&&[meshDiff,instanceDiff,fieldDiff].every(d=>!d.removed.length&&!d.added.length),'Unclassified actual normalized geometry delta');
 must(result.crossArm.baseRoot===result.crossArm.branchRoot&&result.crossArm.baseRoot===a.completeGeometryPayloadSha256&&result.crossArm.baseRoot===b.completeGeometryPayloadSha256,'Recomputed root mismatch');
 result.crossArm.modelFieldDifferences=Object.keys(a).filter(k=>!equal(a[k],b[k]));must(equal(result.crossArm.modelFieldDifferences,['rawInstanceGraphSha256']),'Unexpected model metadata delta');
 for(const x of result.inputs)must(sha(fs.readFileSync(x.path))===x.sha256,'Input changed during review');
 result.ok=true;result.verdict='PASS complete canonical normalized CPU geometry identity across actual current-source Holter arms; raw transient addressing hash differs and is not claimed identical';
 result.limits=['All mesh/instance/global leaves and multiplicities are compared, not only counts or selected IDs. Source-pinned collector captures raw bytes, but compact Merkle leaves cannot reconstruct them independently.','Raw instance addressing graph hashes differ; normalized template geometry/occurrence records/canonical anchors/translations/provenance are identical. No exact raw-address, GPU-buffer or pixel identity claim.','Actual functional loads only. Recorded V5 lifecycle/cadence/media admission and thirty-sample timing remain unqualified.','No full authored-shape oracle or native-Holter pipeline equivalence inferred from cross-arm browser identity.'];
}catch(e){result.error={name:e.name,message:e.message,stack:e.stack};}
fs.writeFileSync(path.join(here,'review-v2.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({ok:result.ok,error:result.error?.message,crossArm:result.crossArm&&{normalized:result.crossArm.normalizedEntireGeometryExactlyEqual,rawAddress:result.crossArm.rawAddressHashEqual,rows:result.crossArm.flatMeshRowsCompared,instances:result.crossArm.instanceOccurrencesCompared}}));if(!result.ok)process.exitCode=1;
