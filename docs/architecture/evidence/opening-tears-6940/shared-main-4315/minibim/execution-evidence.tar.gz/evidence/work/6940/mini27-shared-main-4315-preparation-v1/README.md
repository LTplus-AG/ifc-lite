This is preparation, not an executed 27-context result. The original executed canonical-wasm.mjs and v3 checkers are unchanged. The new Node harness preserves the actual nine hosts, none/selected-one/all wires, canonical producer call, 26 getters, incidence arithmetic and deterministic mesh/collection/API/cache cleanup. It adds scalar -0/nonfinite tags, explicit external fixture and source-built runtime configuration, complete source/pkg/input completion fences, fixed 27-call completion and create-new output.

The two checkout paths have different roles:

- `--checkout` on prepare/compare/shape is the source-built WASM runtime checkout. The Node receipt, pkg identities, complete tracked-source maps and actual build receipt belong to this checkout.
- `--execution-checkout` is a separate native-only checkout at exactly the same HEAD and tree. Prepared wire `validationFence.checkout` points here so the native runner cannot install its temporary example into the frozen runtime tree; `wasmSourceCheckout` points back to the runtime checkout. Full source/build-input maps, prepared wire, exact adapter, produced executable and payload hashes bind actual native execution back to the same numerical source. The native runner `--checkout` is this execution checkout.

The native adapter is byte-identical to previously executed8fbee185..., using the public shared producer and actual FFI frame-swap leaf. The native runner is also unchanged. Wire fallback colors are derived only from observed directly styled geometry item IDs in this authentic Node receipt; missing/ambiguous styles decline. The native producer independently recomputes/asserts canonical wires. No private color walk, bbox-derived alignment or extra localToWorld application is introduced.

The matched-payload numerical comparisons and all shape allowances are unchanged. Only input/provenance wrappers now require the fresh complete receipt and the explicit native/runtime checkout split. Parity covers the original flat-mesh typed geometry/IDs/color/bounds/transform contract; it does not silently expand to full texture/finish/instancing or browser-consumer parity. All26fields are captured by Node, but fields outside the established native adapter contract remain outside native parity.

After root reviews this preparation and grants the heavy slot:

1. Configure a NEW input JSON from the actual successful build receipt, explicit fixture and matching native checkout:
   `python configure.py --build-receipt BUILD_RESULT --native-checkout NATIVE_ROOT --fixture ABSOLUTE_IFC --output NEW_CONFIG`
2. Node canonical receipt:
   `node canonical-wasm-closed.mjs WASM_ROOT NEW_WASM_RECEIPT NEW_CONFIG`
3. Prepare input wire, read-only:
   `python matched-payload.py prepare --checkout WASM_ROOT --execution-checkout NATIVE_ROOT --head HEAD --fixture ABSOLUTE_IFC --wasm NEW_WASM_RECEIPT --output NEW_WIRE`
4. Run the one owned native example, jobs2, creating a NEW evidence directory:
   `python run-native-payload.py --checkout NATIVE_ROOT --head HEAD --fixture ABSOLUTE_IFC --prepared NEW_WIRE --adapter adapter.rs --output-dir NEW_NATIVE_DIR`
5. Compare and shape-check using the exact executable path from `NEW_NATIVE_DIR/result.json`, the actual completed native payload/run and prepared input. Both commands receive `--checkout WASM_ROOT --execution-checkout NATIVE_ROOT` plus `--head`, `--fixture`, `--wasm`, `--native`, `--native-run`, `--native-adapter`, `--native-binary`, `--prepared` and a NEW `--output`. The shape checker also receives the saved comparison (`--comparison`). Every failure is retained; no previously executed receipt is overwritten.

All precondition failures must retain launcher intent/stdout/stderr even when they occur before API initialization. Successful capture additionally requires complete before/after source, package files, fixture, harness/config and build-receipt identity, all27 contexts, and deterministic handles/cache cleanup. Runtime hashes are taken from actual files plus the successful source-build receipt, never inferred solely from source equality. No geometry, build, browser or performance has been executed by preparation. The old830f config is historical preparation; shared-main4315 uses a separate new config after its build finishes.

The configurator additionally requires each current JS/WASM/DTS path, byte size and SHA256 to match exactly one corresponding artifact in the pinned successful build receipt. A successful receipt for different or subsequently replaced package bytes cannot create an execution configuration. The superseded unexecuted configurator is archived separately.
