"""Read-only configure any explicit source-built Mini27 runtime/native-checkout pair.
No builds, geometry or old-config overwrites. Review this file before execution.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess
p=argparse.ArgumentParser()
for n in ['build-receipt','native-checkout','fixture','output']:p.add_argument('--'+n,required=True)
a=p.parse_args();out=Path(a.output).resolve();assert not out.exists();base=Path(__file__).resolve().parent;buildpath=Path(a.build_receipt).resolve();build=json.loads(buildpath.read_text());root=Path(build['cwd']).resolve();native=Path(a.native_checkout).resolve();fixture=Path(a.fixture).resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert build['exitCode']==0 and build['trackedSourceUnchanged'] and build['rustSourceUnchanged'] and build['wasmNewerThanRustSources'] and build['singleServedIfcGeometryWasmExactlyMatchesPackage']
for checkout in [root,native]:
 def git(*v):return subprocess.check_output(['git','-C',str(checkout),*v]).decode().strip()
 assert git('rev-parse','HEAD')==build['head'] and git('rev-parse','HEAD^{tree}')==build['tree'];assert not git('diff','HEAD','--') and not git('ls-files','--others','--exclude-standard','--','rust/')
# Bind current package bytes to the artifacts produced by this exact successful build.
# Missing or duplicate paths decline; an unrelated successful receipt cannot bless later files.
runtime_files={'javascript':'packages/wasm/pkg/ifc-lite.js','wasm':'packages/wasm/pkg/ifc-lite_bg.wasm','declarations':'packages/wasm/pkg/ifc-lite.d.ts'}
runtime_hashes={}
for key,relative in runtime_files.items():
 matches=[entry for entry in build['artifacts'] if entry['path']==relative]
 assert len(matches)==1,('missing or ambiguous successful-build artifact',relative)
 artifact=matches[0];actual=root/relative
 assert actual.stat().st_size==artifact['bytes'] and sha(actual)==artifact['sha256'],('current runtime differs from successful-build artifact',relative)
 runtime_hashes[key]=artifact['sha256']
config={'purpose':'Explicit frozen Mini27 execution inputs; preparing config does not execute geometry','wasmCheckout':str(root),'nativeExecutionCheckout':str(native),'expectedHead':build['head'],'expectedTree':build['tree'],'expectedHarnessSHA256':sha(base/'canonical-wasm-closed.mjs'),'fixturePath':str(fixture),'fixtureBytes':fixture.stat().st_size,'fixtureSHA256':sha(fixture),'buildReceiptPath':str(buildpath),'buildReceiptSHA256':sha(buildpath),'runtimeSHA256':runtime_hashes,'hosts':[135923,137627,139545,141434,143323,145212,151760,154626,150890],'contexts':['none','one','all']}
assert config['fixtureSHA256']=='7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b' and config['fixtureBytes']==7459201
with out.open('x')as f:json.dump(config,f,indent=2);f.write('\n')
print(str(out))
