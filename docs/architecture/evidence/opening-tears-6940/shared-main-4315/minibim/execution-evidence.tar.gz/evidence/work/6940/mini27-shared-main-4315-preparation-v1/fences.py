"""Evidence-only source/input fences; no build or geometry production."""
import hashlib, json, subprocess
from pathlib import Path

FIXTURE_SHA = '7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b'
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def args(parser, native=False):
    for name in ['checkout','execution-checkout','head','fixture','wasm','output']:
        parser.add_argument('--'+name, required=True)
    if native:
        for name in ['native','native-run','native-adapter','native-binary','prepared']:
            parser.add_argument('--'+name, required=True)
def common(a):
    root=Path(a.checkout).resolve()
    def git(*v): return subprocess.check_output(['git',*v],cwd=root).decode().strip()
    assert not Path(a.output).exists(), 'output already exists'
    assert git('rev-parse','HEAD') == a.head and len(a.head)==40
    assert not git('diff','HEAD','--'), 'immutable checkout must have no tracked changes'
    assert not git('ls-files','--others','--exclude-standard','--','rust/'), 'remove temporary/untracked Rust before checking'
    receipt=load(a.wasm)
    assert receipt['source']['head']==a.head
    assert receipt['source']['tree']==git('rev-parse','HEAD^{tree}')
    assert receipt['source']['trackedDiffSha256']==hashlib.sha256(b'').hexdigest()
    assert Path(receipt['root']).resolve()==root
    assert receipt.get('ok') is True and receipt.get('completion',{}).get('ok') is True
    assert not receipt.get('error') and not receipt.get('completionError')
    assert receipt['completion']['expectedCalls']==receipt['completion']['actualCalls']==len(receipt['calls'])==27
    for key in ['source','runtime','packageFiles','fixture','harness','configuration','buildReceipt']:
        assert receipt['completion'][key]==receipt[key], (key,'completion fence mismatch')
    execution=Path(a.execution_checkout).resolve()
    def execution_git(*v): return subprocess.check_output(['git',*v],cwd=execution).decode().strip()
    assert execution_git('rev-parse','HEAD')==a.head
    assert execution_git('rev-parse','HEAD^{tree}')==receipt['source']['tree']
    assert not execution_git('diff','HEAD','--')
    assert not execution_git('ls-files','--others','--exclude-standard','--','rust/')
    configuration=load(receipt['configuration']['path'])
    assert sha(receipt['configuration']['path'])==receipt['configuration']['sha256']
    assert configuration['expectedHead']==a.head and configuration['expectedTree']==receipt['source']['tree']
    assert Path(configuration['wasmCheckout']).resolve()==root
    assert Path(configuration['nativeExecutionCheckout']).resolve()==execution
    assert configuration['expectedHarnessSHA256']==receipt['harness']['sha256']
    assert sha(configuration['buildReceiptPath'])==configuration['buildReceiptSHA256']==receipt['buildReceipt']['sha256']
    build=load(configuration['buildReceiptPath'])
    assert build['head']==a.head and build['tree']==receipt['source']['tree'] and build['exitCode']==0
    assert build['trackedSourceUnchanged'] and build['rustSourceUnchanged'] and build['wasmNewerThanRustSources'] and build['singleServedIfcGeometryWasmExactlyMatchesPackage']
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=root).decode().split('\0')
    actual_sources={p:sha(root/p) for p in tracked if p}
    assert actual_sources==receipt['source']['trackedFilesSha256']
    for path,identity in receipt['packageFiles'].items():
        assert sha(path)==identity['sha256'] and Path(path).stat().st_size==identity['bytes']
    assert receipt['cleanup']=={'prepassCacheCleared':True,'apiFreed':True}
    assert sha(a.fixture)==receipt['fixture']['sha256']==FIXTURE_SHA
    paths={'javascript':'ifc-lite.js','wasm':'ifc-lite_bg.wasm','declarations':'ifc-lite.d.ts'}
    for key,name in paths.items():
        artifact=root/'packages/wasm/pkg'/name; recorded=receipt['runtime'][key]
        assert Path(recorded['path']).resolve()==artifact.resolve()
        assert sha(artifact)==recorded['sha256'] and artifact.stat().st_size==recorded['bytes']
    assert sha(receipt['harness']['path'])==receipt['harness']['sha256']
    return {'checkout':str(root),'nativeExecutionCheckout':str(execution),'head':a.head,'tree':receipt['source']['tree'],
            'wasmReceiptSha256':sha(a.wasm),'fixtureSha256':sha(a.fixture),
            'runtimeSha256':{k:receipt['runtime'][k]['sha256'] for k in paths},
            'limitation':'Runtime-byte/current-source fences do not independently prove build causality; retain the successful source-built WASM command and before/after source receipt separately.'}
def native(a):
    result=common(a); root=Path(a.checkout).resolve(); execution=Path(a.execution_checkout).resolve(); run=load(a.native_run); payload=load(a.native); wire=load(a.prepared)
    assert Path(run['checkout']).resolve()==execution
    assert Path(wire['validationFence']['checkout']).resolve()==execution
    assert Path(wire['validationFence']['wasmSourceCheckout']).resolve()==root
    assert run['head']==a.head and run['exitCode']==0
    assert run['success'] is True and run['all27ContextsPresent'] is True, 'native runner did not complete all contexts'
    assert 'error' not in run and 'cleanupError' not in run and not run['untrackedRustAfter'], 'native completion checks failed'
    assert run['sourceUnchanged'] is True and run['temporaryExampleRemoved'] is True
    assert run['adapterSha256']==sha(a.native_adapter)
    assert run['nativeBinarySha256']==sha(a.native_binary)
    assert Path(run['nativeBinaryPath']).resolve()==Path(a.native_binary).resolve()
    assert run['nativePayloadSha256']==sha(a.native), 'native output changed since run completion'
    assert run['preparedWireSha256']==sha(a.prepared), 'prepared input changed since run completion'
    tracked=subprocess.check_output(['git','ls-files','-z','rust/'],cwd=root).decode().split('\0')
    required={p:sha(root/p) for p in tracked if p.endswith('.rs')}
    assert all(sha(execution/p)==h for p,h in required.items())
    assert all(sha(execution/p)==h for p,h in run['buildInputsSha256'].items())
    assert required and all(run['sourceSha256'].get(p)==h for p,h in required.items()), 'native run source map is incomplete or differs'
    assert payload['preparedWireSha256']==sha(a.prepared)
    assert payload['sourceReceiptSha256']==wire['sourceReceiptSha256']==sha(a.wasm)
    assert payload['fixtureSha256']==wire['fixtureSha256']==sha(a.fixture)
    command=run['command']; assert '--' in command
    invocation=command[:command.index('--')]
    assert Path(invocation[0]).name=='cargo' and invocation[1]=='run'
    assert invocation[invocation.index('-p')+1]=='ifc-lite-processing'
    example=invocation[invocation.index('--example')+1]
    assert Path(a.native_binary).name==example, 'recorded executable does not match cargo example target'
    values=command[command.index('--')+1:]
    assert [Path(p).resolve() for p in values]==[Path(p).resolve() for p in [a.fixture,a.prepared,a.native]], 'native command inputs/output differ'
    result.update(nativeReceiptSha256=sha(a.native),nativeRunSha256=sha(a.native_run),nativeAdapterSha256=sha(a.native_adapter),nativeBinarySha256=sha(a.native_binary),preparedWireSha256=sha(a.prepared))
    return result
