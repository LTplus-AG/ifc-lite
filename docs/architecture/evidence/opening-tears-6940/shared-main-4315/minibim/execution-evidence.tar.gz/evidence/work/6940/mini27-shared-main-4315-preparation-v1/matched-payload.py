#!/usr/bin/env python3
"""Evidence-only #6940 prepare/compare. Never overwrites an existing receipt.
Use prepare/compare --help for explicit immutable checkout, source and input paths.
No tolerance: compare actual f32/u32/f64 byte payloads in emitted mesh order.
"""
import argparse, base64, hashlib, json, math, struct, sys
import fences
FENCE = None
from pathlib import Path

HOSTS = {135923,137627,139545,141434,143323,145212,151760,154626,150890}

def sha(data): return hashlib.sha256(data).hexdigest()
def load(path): return json.loads(Path(path).read_bytes())
def dump(path, value, *, native_wire=False):
    value['validationFence'] = FENCE if not native_wire else FENCE | {'checkout':FENCE['nativeExecutionCheckout'],'wasmSourceCheckout':FENCE['checkout']}
    value['checkerSha256'] = sha(Path(__file__).read_bytes())
    value['fencesSha256'] = fences.sha(Path(fences.__file__))
    with Path(path).open('x') as f: json.dump(value, f, indent=2, allow_nan=False); f.write('\n')
def raw(value):
    data = base64.b64decode(value['base64'], validate=True)
    assert len(data) == value['byteLength']
    assert sha(data) == value['sha256']
    return data

def unpack(value, code):
    data = raw(value)
    assert len(data) == struct.calcsize('<'+code)*value['length']
    return list(struct.unpack('<'+code*value['length'], data))

def optional(value):
    return None if value is None or value == {'undefined': True} else value

def bits(value, kind):
    value = optional(value)
    if value is None: return None
    if kind == 32: return unpack(value, 'I')
    return [f'{i:016x}' for i in unpack(value, 'Q')]

def prepare(source, output):
    receipt = load(source); pre = receipt['prepass']
    assert 'error' not in receipt
    assert receipt['fixture']['sha256'] == '7d3ae097a2f1ca5e63f7698d12215cb58427cdb6a932e75e6bf1ca222bcf873b'
    assert len(receipt['calls']) == 27, 'nine hosts times three contexts required'
    fields = {'jobs':'I','rtcOffset':'d','styleIds':'I','styleColors':'B',
              'materialElementIds':'I','materialColorCounts':'I','materialColors':'B',
              'voidKeys':'I','voidCounts':'I','voidValues':'I'}
    out = {key: unpack(pre[key], code) for key,code in fields.items()}
    for key in ['unitScale','planeAngleToRadians','needsShift']: out[key] = pre[key]
    assert len(out['jobs']) % 3 == 0
    assert len(out['voidKeys']) == len(out['voidCounts']) == len(set(out['voidKeys']))
    assert sum(out['voidCounts']) == len(out['voidValues'])
    voids = {}; offset = 0
    for host, count in zip(out['voidKeys'], out['voidCounts']):
        voids[host] = out['voidValues'][offset:offset+count]; offset += count
    colors = {id:out['styleColors'][4*i:4*i+4] for i,id in enumerate(out['styleIds'])}
    contexts = {}; fallback_by_host = {}; calls = []
    for call in receipt['calls']:
        host=call['host']; context=call['context']
        assert host in HOSTS and context in {'none','one','all'}
        assert voids.get(host), 'actual host opening wires required'
        selected = [] if context == 'none' else voids[host] if context == 'all' else [135934 if host == 135923 else voids[host][0]]
        assert call['selectedOpenings'] == selected
        assert call['actualAllOpenings'] == voids[host]
        assert all(id in voids[host] for id in selected)
        assert [out['jobs'][i:i+3] for i in range(0,len(out['jobs']),3) if out['jobs'][i] == host] == [call['job']]
        assert context not in contexts.setdefault(host,set());contexts[host].add(context)
        assert call['meshes']
        style_ids = sorted({m['geometryItemId'] for m in call['meshes']})
        assert all(id in colors for id in style_ids), 'direct-item wire style required'
        rgba = colors[style_ids[0]]
        assert all(colors[id] == rgba for id in style_ids), 'ambiguous element fallback'
        assert fallback_by_host.setdefault(host,rgba) == rgba
        calls.append({key:call[key] for key in ['host','context','job','selectedOpenings']} |
                     {'fallbackRgba8':rgba,'fallbackStyleIds':style_ids})
    assert contexts.keys()==HOSTS and all(v=={'none','one','all'} for v in contexts.values())
    out.update(sourceReceiptSha256=sha(Path(source).read_bytes()),fixtureSha256=receipt['fixture']['sha256'],calls=calls,
               assumptions=['Fallback colour is taken only from directly styled geometry item IDs observed in this exact WASM receipt; all submeshes/contexts for a host must agree.',
                            'Native producer recomputes canonical prepass and asserts style/material/void wires; complete payload comparison is separate from this input preparation.'])
    dump(output,out,native_wire=True);print(output)

def validate_mesh(mesh):
    p, n, indices = mesh['positionsBits'], mesh['normalsBits'], mesh['indices']
    assert p and len(p) % 3 == 0 and len(n) == len(p)
    assert indices and len(indices) % 3 == 0
    assert all(type(i) is int and 0 <= i < len(p)//3 for i in indices)
    for key, size in [('originBits',3), ('colorBits',4), ('localBoundsBits',6), ('localToWorldBits',16)]:
        values = mesh[key]
        if values is None:
            assert key in {'localBoundsBits','localToWorldBits'}
            continue
        assert len(values) == size
    for key in ['positionsBits','normalsBits','colorBits','localBoundsBits']:
        for value in mesh[key] or []:
            assert type(value) is int and 0 <= value < 2**32
            assert math.isfinite(struct.unpack('<f',struct.pack('<I',value))[0])
    for key in ['originBits','localToWorldBits']:
        for value in mesh[key] or []:
            assert isinstance(value,str) and len(value)==16
            assert math.isfinite(struct.unpack('<d',struct.pack('<Q',int(value,16)))[0])

def comparable(mesh):
    result = {key:optional(mesh.get(key)) for key in ['expressId','geometryItemId','materialId','geometryClass','ifcType']} | {
        'positionsBits':bits(mesh['positions'],32),'normalsBits':bits(mesh['normals'],32),
        'indices':unpack(mesh['indices'],'I'),'originBits':bits(mesh['origin'],64),
        'colorBits':bits(mesh['color'],32),'localBoundsBits':bits(mesh.get('localBounds'),32),
        'localToWorldBits':bits(mesh.get('localToWorld'),64)}
    validate_mesh(result)
    return result

def compare(source, native, output):
    wasm=load(source); rust=load(native)
    assert rust['sourceReceiptSha256']==sha(Path(source).read_bytes()), 'unmatched source receipt'
    assert rust['fixtureSha256']==wasm['fixture']['sha256']
    expected={(c['host'],c['context']):c for c in wasm['calls']}
    observed={(c['host'],c['context']):c for c in rust['calls']}
    assert len(expected)==len(wasm['calls']) and len(observed)==len(rust['calls'])
    assert expected.keys()==observed.keys()
    assert expected.keys()=={(host,context) for host in HOSTS for context in ['none','one','all']}
    records=[];equal=True
    for key,w in expected.items():
        n=observed[key];assert w['job']==n['job'] and w['selectedOpenings']==n['selectedOpenings']
        a=[comparable(m) for m in w['meshes']];b=n['meshes'];diff=[]
        for mesh in b: validate_mesh(mesh)
        if len(a)!=len(b):diff.append({'field':'meshMultiplicity','wasm':len(a),'native':len(b)})
        for i,(x,y) in enumerate(zip(a,b)):
            for field,value in x.items():
                other=y[field]
                if value!=other:
                    record={'mesh':i,'field':field}
                    if isinstance(value,list) and isinstance(other,list):
                        record.update(wasmLength=len(value),nativeLength=len(other),
                                      differentEntries=sum(v!=o for v,o in zip(value,other)),
                                      firstDifferences=[{'index':j,'wasm':v,'native':o} for j,(v,o) in enumerate(zip(value,other)) if v!=o][:8])
                    else:record.update(wasm=value,native=other)
                    diff.append(record)
        equal &= not diff
        records.append({'host':key[0],'context':key[1],'equal':not diff,'differences':diff})
    dump(output,{'schema':1,'exactPayloadEqual':equal,'calls':records,
                 'wasmReceiptSha256':sha(Path(source).read_bytes()),'nativeReceiptSha256':sha(Path(native).read_bytes()),
                 'comparison':'Exact positions/normals/index/origin/color/localbounds/localtransform bits and IDs, with emitted mesh order and multiplicity retained.',
                 'scope':'Functional flat-mesh parity only, no texture/finish/instancing/performance claim.'})
    print(json.dumps({'equal':equal,'contexts':len(records),'output':output}))
    if not equal:raise SystemExit(1)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='mode',required=True)
    fences.args(sub.add_parser('prepare'))
    fences.args(sub.add_parser('compare'),native=True)
    a=parser.parse_args()
    FENCE=fences.common(a) if a.mode=='prepare' else fences.native(a)
    if a.mode=='prepare': prepare(a.wasm,a.output)
    else: compare(a.wasm,a.native,a.output)
