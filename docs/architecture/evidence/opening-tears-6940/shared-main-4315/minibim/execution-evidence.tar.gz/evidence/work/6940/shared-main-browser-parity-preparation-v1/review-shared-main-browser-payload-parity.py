#!/usr/bin/env python3
"""Evidence-only parameterized successor to review-final-payload-bridges.py.
Read saved actual receipts only; no browser, meshing, or performance execution.
"""
import argparse, base64, collections, hashlib, importlib.util, json, math, struct, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent.parent
CHECKERS=HERE/'mini27-shared-main-4315-preparation-v1'
sys.path.insert(0,str(CHECKERS))
import fences
spec=importlib.util.spec_from_file_location('matched_payload',CHECKERS/'matched-payload.py')
matched=importlib.util.module_from_spec(spec);spec.loader.exec_module(matched)
sha=fences.sha
load=fences.load
HOSTS=matched.HOSTS

def origin_bits(values):
    assert len(values)==3 and all(type(v) in [int,float] and math.isfinite(v) and v!=0 for v in values), 'JSON-only origins must be finite/nonzero; zero needs raw f64-bit proof'
    return tuple(struct.unpack('<3Q',struct.pack('<3d',*values)))

def same_fields(value, expected, label):
    assert set(value)==set(expected), (label,'unknown/missing own fields',sorted(set(value)^set(expected)))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    fences.args(parser,native=True)
    for name in ['browser','comparison','shape','build']:
        parser.add_argument('--'+name,required=True)
    a=parser.parse_args();fence=fences.native(a)
    w,n,b,comparison,shape,build=map(load,[a.wasm,a.native,a.browser,a.comparison,a.shape,a.build])
    assert comparison['validationFence']==shape['validationFence']==fence
    assert comparison['exactPayloadEqual'] and len(comparison['calls'])==27
    assert comparison['wasmReceiptSha256']==sha(a.wasm) and comparison['nativeReceiptSha256']==sha(a.native)
    assert shape['all27FiniteValidClosedNoncollapsed'] and shape['all18RetainedShapeComparisonsPass'] and shape['all27Outward']
    assert shape['inputReceipts'][str(Path(a.wasm))]==sha(a.wasm)
    assert shape['inputReceipts'][str(Path(a.native))]==sha(a.native)
    assert shape['inputReceipts'][str(Path(a.comparison))]==sha(a.comparison)
    assert shape['scriptSha256']==sha(CHECKERS/'check-payload-shape.py')
    assert shape['fencesSha256']==sha(CHECKERS/'fences.py')
    assert comparison['checkerSha256']==sha(CHECKERS/'matched-payload.py')
    assert comparison['fencesSha256']==shape['fencesSha256']
    for name,value in shape['rustOracleSourceSha256'].items():assert sha(Path(a.checkout)/name)==value
    assert len(shape['rows'])==27 and len(shape['comparisons'])==18
    assert {(r['host'],r['context'])for r in shape['rows']}=={(h,c)for h in HOSTS for c in ['none','one','all']}
    assert {(r['host'],r['context'])for r in shape['comparisons']}=={(h,c)for h in HOSTS for c in ['one','all']}
    assert all(r['passed']for r in shape['comparisons'])
    expected_native={'positionsBits','normalsBits','indices','originBits','colorBits','localBoundsBits','localToWorldBits','expressId','geometryItemId','materialId','geometryClass','ifcType'}
    assert len(w['calls'])==len(n['calls'])==27
    native_calls=[]
    for wc,nc in zip(w['calls'],n['calls']):
        for key in ['host','context','selectedOpenings','job']:assert wc[key]==nc[key]
        assert len(wc['meshes'])==len(nc['meshes'])
        for wm,nm in zip(wc['meshes'],nc['meshes']):
            same_fields(nm,expected_native,'native mesh')
            assert matched.comparable(wm)==nm
        native_calls.append({'host':wc['host'],'context':wc['context'],'meshes':len(wc['meshes'])})
    assert Path(build['cwd']).resolve()==Path(a.checkout).resolve()
    assert w['buildReceipt']['sha256']==sha(a.build) and Path(w['buildReceipt']['path']).resolve()==Path(a.build).resolve()
    assert Path(fence['nativeExecutionCheckout']).resolve()==Path(a.execution_checkout).resolve()
    assert build['head']==a.head and build['tree']==fence['tree'] and build['exitCode']==0
    assert all(build[k]is True for k in ['trackedSourceUnchanged','rustSourceUnchanged','wasmNewerThanRustSources','singleServedIfcGeometryWasmExactlyMatchesPackage'])
    assert sha(Path(a.build).parent/'build.log')==build['logSha256']
    artifacts={row['path']:row for row in build['artifacts']}
    assert len(artifacts)==len(build['artifacts']),'Duplicate build artifact paths'
    geometry_wasm=[row for row in build['artifacts']if row['path'].startswith('apps/viewer/dist/assets/ifc-lite_bg-')and row['path'].endswith('.wasm')]
    assert len(geometry_wasm)==1
    for row in [artifacts['packages/wasm/pkg/ifc-lite.js'],artifacts['packages/wasm/pkg/ifc-lite_bg.wasm'],artifacts['packages/wasm/pkg/ifc-lite.d.ts'],geometry_wasm[0]]:
        p=Path(a.checkout)/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
    for key,relative in [('javascript','packages/wasm/pkg/ifc-lite.js'),('wasm','packages/wasm/pkg/ifc-lite_bg.wasm'),('declarations','packages/wasm/pkg/ifc-lite.d.ts')]:
        assert artifacts[relative]['sha256']==w['runtime'][key]['sha256'] and artifacts[relative]['bytes']==w['runtime'][key]['bytes']
    assert geometry_wasm[0]['sha256']==w['runtime']['wasm']['sha256']
    assert b['ok']is True and b['functionalOnly']is True and b['noTimingQualification']is True
    assert b['errors']==[] and b['side']=='branch'
    assert b['collectorSha256']==sha(HERE/'browser-ab-cohort.mjs')
    assert b['fixtureIdentity']['sha256']==fence['fixtureSha256']
    assert b['fixtureIdentity']['bytes']==w['fixture']['bytes']
    manifest=b['server']['manifest'];assert manifest['head']==a.head and manifest['tree']==fence['tree']
    assert manifest['trackedDiffSha256']==w['source']['trackedDiffSha256']
    assert manifest['packageWasm']['sha256']==w['runtime']['wasm']['sha256']
    assert manifest['packageWasm']['bytes']==w['runtime']['wasm']['bytes']
    assert b['servingStateAtReceipt']['epoch']==b['server']['epoch']
    assert b['servingStateAtReceipt']['side']==b['server']['side']=='branch'
    assert b['environment']['secureContext']and b['environment']['crossOriginIsolated']
    assert b['environment']['visibility']=='visible' and b['environment']['hasFocus']
    pools=[s for s in b['trace']['spans']if s['name']=='geometry.pool']
    assert len(pools)==1 and pools[0]['attrs']['workerCount']==4
    gpu=b['gpuHealth'];assert not gpu['contaminated'] and not gpu['reasons']
    assert gpu['devicesCreated']==1 and all(gpu[k]==0 for k in ['deviceLost','instanceErrors','deviceReplacements','uncapturedErrors'])
    assert b['payload']['schema']==3 and len(b['payload']['models'])==1
    model=b['payload']['models'][0];assert model['loadPath']=='wasm'and model['cacheState']!='hit'
    geometry=model['geometry'];same_fields(geometry,{'schema','geometryResultFields','flatMeshMerkleRows','normalizedInstanceMerkleRows'},'geometry')
    assert geometry['schema']=='ifc6940-complete-cpu-geometry-merkle-v3'
    roots=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import {createHash} from 'node:crypto';let s='';for await(const c of process.stdin)s+=c;const g=JSON.parse(s);const h=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');console.log(JSON.stringify({root:h(g),meshes:h({type:'SortedMeshMerkleRows',rows:g.flatMeshMerkleRows})}));"],input=json.dumps(geometry).encode()))
    assert roots['root']==model['completeGeometryPayloadSha256']
    names=[r['field']for r in geometry['geometryResultFields']];assert len(names)==len(set(names))
    assert next(r['sha256']for r in geometry['geometryResultFields']if r['field']=='meshes')==roots['meshes']
    assert len(geometry['flatMeshMerkleRows'])==model['meshCount']
    assert len(geometry['normalizedInstanceMerkleRows'])==model['instanceOccurrences']
    all_calls={c['host']:c for c in w['calls']if c['context']=='all'}
    special=model['specialSlabs'];assert len(special)==9 and {s['expressId']for s in special}==HOSTS
    browser_fields={'expressId','geometryItemId','geometryClass','positions','normals','indices','origin','vertices','triangles'}
    rows=[]
    for slab in special:
        same_fields(slab,{'expressId','meshes'},'special slab')
        expected=[];observed=[]
        for mesh in all_calls[slab['expressId']]['meshes']:
            expected.append((mesh['expressId'],mesh['geometryItemId'],mesh['geometryClass'],mesh['positions']['sha256'],mesh['normals']['sha256'],mesh['indices']['sha256'],tuple(matched.unpack(mesh['origin'],'Q')),mesh['vertexCount'],mesh['triangleCount']))
        for mesh in slab['meshes']:
            same_fields(mesh,browser_fields,'browser slab mesh')
            observed.append((mesh['expressId'],mesh['geometryItemId'],mesh['geometryClass'],mesh['positions'],mesh['normals'],mesh['indices'],origin_bits(mesh['origin']),mesh['vertices'],mesh['triangles']))
        assert collections.Counter(expected)==collections.Counter(observed),(slab['expressId'],'typed bytes/metadata/multiplicity differ')
        rows.append({'host':slab['expressId'],'meshCount':len(expected),'allOpeningPayloadExact':True,'allSpecialRowOwnFieldsCompared':True,'nonzeroFiniteOriginBitsExact':True})
    paths=[a.wasm,a.native,a.native_run,a.native_adapter,a.native_binary,a.prepared,a.browser,a.comparison,a.shape,a.build]
    report={'schema':1,'source':a.head,'all27NativeNodeContextsExact':True,'all9ActualViewerHostsExact':True,'actualSavedShapeBridgeVerified':True,
        'inputSHA256':{str(p):sha(p)for p in paths},'validationFence':fence,'scriptSHA256':sha(__file__),
        'nativeCalls':native_calls,'viewerHosts':rows,'currentWasmSHA256':w['runtime']['wasm']['sha256'],
        'completeCPUScene':{'schema':geometry['schema'],'merkleRootVerified':True,'root':roots['root'],'geometryResultFieldNames':names,
            'flatMeshes':model['meshCount'],'instanceTemplates':model['instanceTemplates'],'instanceEntities':model['instanceEntities'],'instanceOccurrences':model['instanceOccurrences'],'rawInstanceGraphSha256':model['rawInstanceGraphSha256']},
        'scope':'Every own field in browser special-slab proof rows is compared; exact typed flat geometry/origins and emitted native order/multiplicity are retained. Complete resident CPU scene separately self-hashed by the original collector.',
        'limits':['No browser operation or performance sample executed by this checker.','Nine target slabs only; full-model native/style/texture/finish identity and GPU pixel/buffer equality are not established.','Full-scene Merkle verification checks receipt consistency, not an independent raw instance reconstruction.','JSON-only viewer origins must all be finite/nonzero; future signed-zero origins require raw-bit receipts.','Native parity remains the explicit flat FFI contract; extra WASM finish/texture fields are captured but not compared to native.','This does not waive existing corpus/golden/identity/performance/CI holds.']}
    with Path(a.output).open('x')as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'output':a.output,'source':a.head,'nativeNodeCalls':27,'viewerHosts':9,'wasm':w['runtime']['wasm']['sha256']}))

if __name__=='__main__':main()

