"""Offline packet-byte integrity only; no execution, geometry or performance claim."""
import hashlib,json,sys,tarfile
from pathlib import Path
p=Path(sys.argv[1]);m=json.loads((p/'manifest.json').read_text());a=p/m['archive']['path'];h=lambda b:hashlib.sha256(b).hexdigest()
assert a.stat().st_size==m['archive']['bytes'] and h(a.read_bytes())==m['archive']['sha256']
with tarfile.open(a,'r:*')as t:
 rows=[e for e in m['files']if e['storage']=='archive']
 assert len(rows)==m['archive']['members'] and sorted(t.getnames())==sorted(e['path']for e in rows)
 for e in m['files']:
  b=t.extractfile(e['path']).read()if e['storage']=='archive'else(p/e['path']).read_bytes()
  assert len(b)==e['bytes']and h(b)==e['sha256'],e['path']
print(json.dumps({'allSelectedBytesVerified':True,'archiveMembers':len(rows),'geometryExecution':False}))
