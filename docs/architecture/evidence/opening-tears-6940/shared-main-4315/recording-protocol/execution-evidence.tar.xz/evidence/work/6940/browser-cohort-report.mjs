// Evidence-only finite-cohort verifier. It never launches a browser or retries.
// node work/6940/browser-cohort-report.mjs plan.json receipts-directory output-directory
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
const [planPath, receiptsDir, output] = process.argv.slice(2);
if (!planPath || !receiptsDir || !output) throw new Error('plan, receipt directory and unique output directory required');
fs.mkdirSync(output, { recursive: false });
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const plan = JSON.parse(fs.readFileSync(planPath));
const summary = { schema: 1, started: new Date().toISOString(), qualified: false,
  scope: 'Finite T3 fresh-tab control cohort; shared Electron browsermainprocess explicitly outside fresh-process claim',
  plan: { path: planPath, sha256: digest(fs.readFileSync(planPath)) }, rows: [], missing: [], errors: [], geometryIdentity: {}, positiveRealMoves: [] };
const rows = [];
for (const sample of plan.samples) {
  const file = path.join(receiptsDir, `${sample.id}.result.json`);
  const begin = path.join(receiptsDir, `${sample.id}.begin.json`);
  if (!fs.existsSync(file)) {
    summary.missing.push({ ...sample, beginExists: fs.existsSync(begin) });
    continue;
  }
  const bytes = fs.readFileSync(file), receipt = JSON.parse(bytes);
  const failures = [];
  const require = (test, message) => { if (!test) failures.push(message); };
  require(receipt.id === sample.id && receipt.side === sample.side && receipt.fixture === sample.fixture && receipt.pair === sample.pair,
    'Receipt identity/order differs from finite plan');
  require(receipt.ok === true, `Sample failed: ${JSON.stringify(receipt.error)}`);
  require(receipt.payload?.schema === 3, 'Complete payload Merkle schema3 missing');
  require(receipt.collectorSha256 === plan.collector.sha256, 'Collector source differs from frozen finite plan');
  require(receipt.server?.manifest?.head === sample.expectedSource, 'Frozen source mismatch');
  require(receipt.server?.manifest?.distManifestSha256 === plan.manifests[sample.side].distManifestSha256, 'Frozen build manifest mismatch');
  require(receipt.environment?.geomWorkersActual === 4 && receipt.environment?.uploadMode === 'timed', 'Expected actual4workers and timeduploads');
  require(receipt.environment?.visibilityAtReady === 'visible' && receipt.environment?.hasFocusAtReady === true, 'Foreground readiness absent');
  require(receipt.environment?.viewport?.innerWidth === 1280 && receipt.environment?.viewport?.innerHeight === 800,
    'Actual viewport mismatch');
  require(receipt.externalAdmission?.quiet === true && receipt.externalAdmission?.policy?.version === 'native-host-v12-departure-observation',
    'No accepted canonical host observation at upload');
  require(receipt.coldStorageAdmission?.verified === true, 'Cold origin storage/DB clearance before appboot not attached');
  require(receipt.gpuHealth && !receipt.gpuHealth.contaminated, 'GPU health missing/contaminated');
  require(receipt.readinessTrace?.attrs?.loadPath === 'wasm', 'Not a genuine WASM path');
  require(!receipt.readinessTrace?.spans?.some(span => span.name === 'cache.storeReady' || span.attrs?.uploadMode === 'count'),
    'Cachehit/countupload workload present');
  require(receipt.payload?.models?.length === 1, 'Exactly one complete model payload required');
  const model = receipt.payload?.models?.[0];
  require(model?.loadPath === 'wasm' && model?.cacheState !== 'hit', 'Model path/cachehit mismatch');
  require(typeof model?.completeGeometryPayloadSha256 === 'string', 'Full geometry Merkle hash missing');
  const logs = (receipt.logs ?? []).join('\n');
  // Same count-only parsing used by ViewerBenchmarkPage.parseMetrics; timing
  // values come exclusively from its imported canonical trace metrics helper.
  const stream = logs.match(/\[useIfc\] Geometry streaming complete: (\d+) batches, (\d+) meshes/);
  const summaryLog = logs.match(/\[(?:ifc-lite|useIfc)\].*?\(([\d.]+)MB\)\s*→\s*([\d,]+)\s*meshes/);
  const totalMeshes = stream ? Number(stream[2]) : summaryLog ? Number(summaryLog[2].replace(/,/g, '')) : null;
  require(Number.isInteger(totalMeshes) && totalMeshes > 0, 'Canonical meshcount diagnostic missing');
  const row = { side: sample.side, fixture: sample.fixture, round: sample.pair, ok: failures.length === 0,
    ...receipt.metrics, metadataRenderReadyMs: receipt.metadataRenderReadyMs, totalMeshes, gpuHealth: receipt.gpuHealth,
    error: failures.length ? failures.join('; ') : undefined,
    completeGeometryPayloadSha256: model?.completeGeometryPayloadSha256, devicePixelRatio: receipt.environment?.viewport?.devicePixelRatio,
    receipt: { path: file, sha256: digest(bytes) } };
  rows.push(row); summary.rows.push(row);
}
fs.writeFileSync(path.join(output, 'runs.jsonl'), rows.map(row => JSON.stringify(row)).join('\n') + '\n', { flag: 'wx' });
try {
  if (plan.samples.length !== 30 || rows.length !== 30 || summary.missing.length) throw new Error('Finite30sample cohort incomplete; no missing attempt may be dropped');
  if (rows.some(row => !row.ok)) throw new Error('One or more samples failed validation; no survivor-only qualification');
  const ratioSet = new Set(rows.map(row => row.devicePixelRatio));
  if (ratioSet.size !== 1 || !Number.isFinite(rows[0].devicePixelRatio)) throw new Error('Device pixel ratio differs or missing');
  for (const fixture of ['fzk', 'issue129', 'holter']) {
    const cohort = rows.filter(row => row.fixture === fixture);
    const values = [...new Set(cohort.map(row => row.completeGeometryPayloadSha256))];
    summary.geometryIdentity[fixture] = { values, stableAcrossBothArmsAndAllFiveRounds: cohort.length === 10 && values.length === 1 };
    if (!summary.geometryIdentity[fixture].stableAcrossBothArmsAndAllFiveRounds) throw new Error(`Complete geometry payload changed: ${fixture}`);
  }
} catch (error) { summary.errors.push(error.message); }
// Invoke the actual canonical reporter even for retained incomplete/failure
// cohorts; this does not let its process exit code waive statistical gates.
const reportPath = path.join(output, 'canonical-report.json');
const result = spawnSync(process.execPath, ['scripts/perf/browser-ab-report.mjs', path.join(output, 'runs.jsonl'), '--base', 'base', '--branch', 'branch', '--json', reportPath], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 });
fs.writeFileSync(path.join(output, 'canonical-report.stdout'), result.stdout ?? '', { flag: 'wx' });
fs.writeFileSync(path.join(output, 'canonical-report.stderr'), result.stderr ?? '', { flag: 'wx' });
summary.reporterExitCode = result.status;
if (fs.existsSync(reportPath)) {
  const report = JSON.parse(fs.readFileSync(reportPath));
  summary.canonicalVerdict = report.verdict;
  for (const fixture of report.fixtures) for (const metric of fixture.metrics) {
    if (metric.real && metric.deltaPct > 0) summary.positiveRealMoves.push({ fixture: fixture.fixture, ...metric });
  }
  for (const key of ['noSuccessfulSamples', 'fingerprintDrift', 'tooNoisy', 'insufficientPairedSamples', 'incomparableFixture']) {
    if (report.verdict[key] !== false) summary.errors.push(`Canonical reporter refusal: ${key}`);
  }
  if (report.failures !== 0 || result.status !== 0) summary.errors.push('Canonical reporter recorded failures');
} else summary.errors.push('Canonical reporter produced no verdict');
if (summary.positiveRealMoves.length) summary.errors.push('Positive metric move beyond canonical noise/3%/5ms floor');
summary.qualified = summary.errors.length === 0;
summary.finished = new Date().toISOString();
fs.writeFileSync(path.join(output, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ qualified: summary.qualified, rows: rows.length, missing: summary.missing.length, errors: summary.errors }, null, 2));
process.exitCode = summary.qualified ? 0 : 1;
