// Evidence-only adapter; invoking this performs actual unchanged native-host-v12 observations.
import { readHostAdmission } from '../../../scripts/perf/frame-gpu-host.ts';
import { writeFileSync, existsSync } from 'node:fs';
const output = process.argv[2];
if (!output || existsSync(output)) throw new Error('New unique output file required');
try {
  const observation = await readHostAdmission();
  writeFileSync(output, JSON.stringify(observation, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify(observation));
} catch (error) {
  writeFileSync(output, JSON.stringify({ failed: true, capturedAt: new Date().toISOString(),
    error: error instanceof Error ? { name: error.name, message: error.message, stack: error.stack } : String(error),
    quiet: false, scope: 'Observation failed; no admission or benchmark launch' }, null, 2) + '\n', { flag: 'wx' });
  throw error;
}
