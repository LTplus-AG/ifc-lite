from pathlib import Path
import subprocess,json,datetime,time,hashlib
root=Path.cwd();case=Path(__file__).resolve().parent.parent;out=Path(__file__).resolve().parent
assembler=root/'work/6940/native-recording-case-assembler-v5/case.mjs';auditor=root/'work/6940/native-recording-history-v6/validate-first-frame-class.py';finalizer=root/'work/6940/native-recording-first-frame-class-review-v1/finalize.mjs';intent=json.loads((case/'intent.json').read_text());records=[]
def ref(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
inputs={str(p):ref(p)['sha256'] for p in [assembler,auditor,finalizer,case/'intent.json',case/'native-history/history.json',*[Path(v['path'])for v in intent['sources'].values()]]}
def run(label,command):
 command=[str(v)for v in command]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();(out/(label+'.command.json')).open('x').write(json.dumps(command,indent=2)+'\n')
 with (out/(label+'.stdout')).open('xb')as stdout,(out/(label+'.stderr')).open('xb')as stderr:r=subprocess.run([str(v)for v in command],stdout=stdout,stderr=stderr)
 rec={'label':label,'command':[str(v)for v in command],'startUtc':start,'endUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-t,'exitCode':r.returncode,'stdout':ref(out/(label+'.stdout')),'stderr':ref(out/(label+'.stderr'))};records.append(rec);(out/(label+'.result.json')).open('x').write(json.dumps(rec,indent=2)+'\n');print(label,r.returncode,flush=True);assert r.returncode==0,label
ok=False
try:
 run('01-artifacts',['node',assembler,'artifacts','--case',str(case)])
 artifact=json.loads((case/'artifact-inputs.json').read_text());video=Path(artifact['video']['path']);inputs[str(video)]=artifact['video']['sha256']
 run('02-media',['/tmp/ifc-6940-oracle-818b/bin/python',intent['sources']['mediaInspector']['path'],video,case/'media-inspection'])
 run('03-anchor-manifest',['node',assembler,'anchor-manifest','--case',case,'--inspection',case/'media-inspection/media-inspection.json'])
 run('04-detect',['/tmp/ifc-6940-oracle-818b/bin/python',intent['sources']['anchorDetector']['path'],case/'anchor-inputs.json',case/'anchor-detection'])
 receipt=root/'work/6940/shared-main-browser-v1/receipts'/(intent['id']+'.result.json');inputs[str(receipt)]=ref(receipt)['sha256']
 run('05-assemble',['node',assembler,'assemble','--case',case,'--receipt',receipt,'--inspection',case/'media-inspection/media-inspection.json','--detection',case/'anchor-detection/result.json','--ordinal-base','32'])
 run('06-class-review',['python3',auditor,case/'validation-input.json',case/'validation-first-frame-class-review-v1.json'])
 v=json.loads((case/'validation-first-frame-class-review-v1.json').read_text());assert v['ok']is True and v['statusKind']=='timed'and v['actualNativeCalls']==9
 run('07-finalize',['node',finalizer,case,case/'validation-first-frame-class-review-v1.json']);ok=True
finally:
 unchanged=all(ref(Path(p))['sha256']==h for p,h in inputs.items());result={'schema':1,'ok':ok,'scope':'Actual row0 recording offline processing only; failedrow1 and28unlaunched preserved. No single-row performance qualification.','inputsBeforeSHA256':inputs,'inputsUnchanged':unchanged,'commands':records,'performanceQualified':False};(out/'result.json').open('x').write(json.dumps(result,indent=2)+'\n');assert unchanged,'Input changed'
