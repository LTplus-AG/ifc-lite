(async () => {
  if (location.origin !== 'https://louistrue-pc.tail476f78.ts.net:8448' || location.pathname !== '/__6940/modules/preflight.html') throw Error('Own unloaded evidence preflight origin required');
  if (globalThis.__ifc_lite_viewer_store__) throw Error('App already booted');
  const state = await fetch('/__6940/state', { cache: 'no-store' }).then(r => r.json());
  if (state.pending.length) throw Error('Pending sample must be preserved');
  const serviceWorkers = await navigator.serviceWorker.getRegistrations();
  for (const worker of serviceWorkers) if (!await worker.unregister()) throw Error('Service worker unregister failed');
  const clearedCaches = await caches.keys();
  for (const name of clearedCaches) if (!await caches.delete(name)) throw Error('Cache delete failed');
  const clearedDB = (await indexedDB.databases()).map(db => db.name);
  if (clearedDB.some(name => typeof name !== 'string')) throw Error('Unnamed database cannot be verified');
  for (const name of clearedDB) await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(Error('Database delete timed out: ' + name)), 15000);
    const request = indexedDB.deleteDatabase(name);
    request.onsuccess = () => { clearTimeout(timer); resolve(); };
    request.onerror = () => { clearTimeout(timer); reject(request.error); };
    request.onblocked = () => { clearTimeout(timer); reject(Error('Database deletion blocked: ' + name)); };
  });
  localStorage.clear(); sessionStorage.clear();
  const remainingCaches = await caches.keys(), remainingDB = await indexedDB.databases();
  const remainingServiceWorkers = (await navigator.serviceWorker.getRegistrations()).length;
  if (remainingCaches.length || remainingDB.length || remainingServiceWorkers || localStorage.length || sessionStorage.length) throw Error('Cold origin clearance incomplete');
  return { verified: true, at: new Date().toISOString(), beforeAppBoot: true, side: state.side, head: state.manifest.head, epoch: state.epoch,
    clearedCaches, clearedDB, serviceWorkers: serviceWorkers.length, remainingCaches, remainingDB, remainingServiceWorkers,
    localStorageLength: localStorage.length, sessionStorageLength: sessionStorage.length };
})()
