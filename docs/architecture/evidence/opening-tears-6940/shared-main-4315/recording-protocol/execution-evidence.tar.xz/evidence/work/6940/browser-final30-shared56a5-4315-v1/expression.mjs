// Print a T3 evaluate expression using authentic previously saved input receipts. Never evaluates it.
import { readFileSync } from 'node:fs';
const directory = new URL('./', import.meta.url);
const plan = JSON.parse(readFileSync(new URL('plan.json', directory)));
const [mode, indexText, ...files] = process.argv.slice(2);
const index = Number(indexText), row = plan.samples[index];
if (!Number.isInteger(index) || !row) throw Error('Explicit planned index0..29 required');
const read = path => { const j = JSON.parse(readFileSync(path)); return j.value ?? j; };
const mod = "await import('/__6940/cohort.mjs')";
if (mode === 'prepare') {
  if (files.length !== 3) throw Error('prepare INDEX actual-cold.json actual-preview-status.json actual-lifecycle.json');
  const [cold, previewStatus, lifecycle] = files.map(read);
  if (!cold.verified || cold.beforeAppBoot !== true || cold.side !== row.side || cold.head !== row.expectedSource) throw Error('Actual matching cold preboot receipt required');
  const options = { id: row.id, side: row.side, fixture: row.fixture, pair: row.pair, timeoutMs: 600000,
    waitForAdmission: true, collectorSha256: plan.collector.sha256, coldStorageAdmission: cold, previewStatus, lifecycle };
  console.log(`(async()=>{const s=await fetch('/__6940/state',{cache:'no-store'}).then(r=>r.json());if(s.side!==${JSON.stringify(row.side)}||s.manifest.head!==${JSON.stringify(row.expectedSource)}||s.manifest.distManifestSha256!==${JSON.stringify(plan.manifests[row.side].distManifestSha256)}||s.epoch!==${JSON.stringify(cold.epoch)})throw Error('Plan/source/cold epoch fence');return (${mod}).startSample(${JSON.stringify(options)});})()`);
} else if (mode === 'release') {
  if (files.length !== 1) throw Error('release INDEX actual-new-host-observation.json');
  const admission = read(files[0]);
  // Original collector enforces policy, actual observations, freshness and foreground; do not reimplement or weaken it.
  console.log(`(async()=>(${mod}).releasePreparedSample(${JSON.stringify({id:row.id, admission})}))()`);
} else if (mode === 'cancel') {
  if (files.length !== 1 || !files[0].trim()) throw Error('cancel INDEX explicit-reason');
  console.log(`(async()=>(${mod}).cancelPreparedSample(${JSON.stringify({id:row.id,reason:files[0]})}))()`);
} else throw Error('prepare|release|cancel required');
