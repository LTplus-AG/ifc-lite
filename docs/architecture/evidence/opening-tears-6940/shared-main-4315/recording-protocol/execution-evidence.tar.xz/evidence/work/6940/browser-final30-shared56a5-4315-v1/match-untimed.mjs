// Supplemental identity linkage only; never changes original strict/canonical timing verdicts.
// node match-untimed.mjs actual-witness-map.json actual-timed-receipts new-report.json
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const [mapFile, receipts, output] = process.argv.slice(2);
if (!mapFile || !receipts || !output || fs.existsSync(output)) throw Error('Actual witness map, timed receipt directory, new output required');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const objectHash = value => hash(JSON.stringify(value));
const planPath = new URL('plan.json', import.meta.url), plan = JSON.parse(fs.readFileSync(planPath));
const report = { schema:1, at:new Date().toISOString(), checkerSHA256:hash(fs.readFileSync(new URL(import.meta.url))), planSHA256:hash(fs.readFileSync(planPath)), witnessMapSHA256:hash(fs.readFileSync(mapFile)), rows:[], witnesses:[], errors:[], ok:false,
  scope:'Complete per-arm timed-to-authentic-untimed v3 normalized CPU geometry linkage only; no semantic/physical/performance qualification or strict cross-arm waiver.' };
try {
  const map = JSON.parse(fs.readFileSync(mapFile)), expected = new Map();
  for (const fixture of ['fzk','issue129','holter']) for (const side of ['base','branch']) {
    const file = map.v3?.[fixture]?.[side]; if (typeof file !== 'string') throw Error('Missing authentic witness path: '+fixture+'/'+side);
    const bytes = fs.readFileSync(file), receipt = JSON.parse(bytes), model = receipt.payload?.models?.[0];
    if (!receipt.ok || receipt.functionalOnly !== true || receipt.noTimingQualification !== true || receipt.side !== side || receipt.collectorSha256 !== plan.collector.sha256 || receipt.payload?.schema !== 3 || receipt.payload.models.length !== 1 || receipt.errors?.length !== 0) throw Error('Invalid actual v3 witness: '+file);
    if (receipt.server?.manifest?.head !== plan.manifests[side].head || receipt.server.manifest.distManifestSha256 !== plan.manifests[side].distManifestSha256 || receipt.fixtureIdentity?.sha256 !== plan.samples.find(r=>r.fixture===fixture).fixtureIdentity.sha256) throw Error('Witness source/build/fixture mismatch: '+file);
    if (model?.completeGeometryPayloadSha256 !== objectHash(model.geometry)) throw Error('Witness root self-check failed: '+file);
    expected.set(fixture+'/'+side,{model,receipt,file,sha256:hash(bytes)});
    report.witnesses.push({fixture,side,path:file,sha256:hash(bytes),root:model.completeGeometryPayloadSha256});
  }
  for (const row of plan.samples) {
    const file = path.join(receipts,row.id+'.result.json');
    try {
      const bytes=fs.readFileSync(file), receipt=JSON.parse(bytes), model=receipt.payload?.models?.[0], witness=expected.get(row.fixture+'/'+row.side);
      if (receipt.id!==row.id || receipt.side!==row.side || receipt.fixture!==row.fixture || receipt.pair!==row.pair || !receipt.ok || receipt.payload?.schema!==3 || receipt.payload.models.length!==1 || receipt.collectorSha256!==plan.collector.sha256) throw Error('Sample failed/identity differs');
      if (receipt.server?.manifest?.head!==row.expectedSource || receipt.server.manifest.distManifestSha256!==plan.manifests[row.side].distManifestSha256 || receipt.fixtureIdentity?.sha256!==row.fixtureIdentity.sha256) throw Error('Sample source/build/fixture differs');
      if (model?.completeGeometryPayloadSha256!==objectHash(model.geometry) || model.completeGeometryPayloadSha256!==witness.model.completeGeometryPayloadSha256 || JSON.stringify(model.geometry)!==JSON.stringify(witness.model.geometry)) throw Error('Complete within-arm geometry content/root differs');
      report.rows.push({id:row.id,ok:true,path:file,sha256:hash(bytes),root:model.completeGeometryPayloadSha256,witnessSHA256:witness.sha256});
    } catch(error) { report.rows.push({id:row.id,ok:false,path:file,error:error.message});report.errors.push(row.id+': '+error.message); }
  }
  report.ok=plan.samples.length===30 && report.rows.length===30 && report.errors.length===0;
} catch(error) { report.errors.push(error.message); }
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({ok:report.ok,rows:report.rows.length,errors:report.errors}));process.exitCode=report.ok?0:1;
