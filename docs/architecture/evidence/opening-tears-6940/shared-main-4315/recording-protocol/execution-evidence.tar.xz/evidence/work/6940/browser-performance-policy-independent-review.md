# Independent browser performance policy adjudication

The repository's AGENTS policy explicitly permits declared legitimate geometry-output changes. An unchanged canonical end-to-end timing report, accompanied by an explicit source-qualified semantic output classification, can therefore support a timing verdict for the corrected behavior. It cannot turn the stricter evidence-only cross-arm payload-identity gate into PASS.

Keep `browser-cohort-report.mjs`, its full-identity refusal and the complete original summary unchanged. Never rewrite hashes, mesh counts, samples or statistical thresholds. Do not describe the aggregate evidence-only report as qualified when its own `qualified` field is false. State separate dimensions: strict cross-arm identity, semantic output classification, and measured timing qualification. Freeze that interpretation before examining cohort timings.

For a timing qualification, all thirty planned attempts must be retained; each arm must have stable complete payloads across all five rounds per fixture; actual source/build/options/job sets and the real four-worker timed consumer must match. Actual browser per-element/field changes must be exhaustively matched to independently reviewed intended corrections. Native facet/guard evidence alone cannot qualify an extra browser field or a different source. The collector's broader material, texture, instance and provenance coverage must remain explicit. Any unclassified change or within-arm nondeterminism blocks qualification.

The unchanged canonical reporter supplies the timing statistics. All cold-storage, host, GPU, foreground, readiness, unique matched-round, complete-coverage, noise and positive-regression conditions remain enforced separately. Process exit0 alone is insufficient because the canonical JSON includes additional refusal flags. Noisy or incomplete results remain unqualified; changed output does not excuse a failure in those dimensions.

Suggested measured language:

> Strict cross-arm geometry identity: FAIL, with [actual hashes/count changes]. Complete source-qualified differences are the reviewed geometry corrections [receipt]. With stable per-arm outputs and all30planned cold worker-pool loads retained, the unchanged canonical reporter found [actual verdict and deltas]. This measures the load cost of corrected output; it does not establish byte identity or a pure algorithm speedup.

Until those observations exist: performance unqualified. Do not claim “all gates PASS.” No script, acceptance threshold, source or gate is changed by this review.
