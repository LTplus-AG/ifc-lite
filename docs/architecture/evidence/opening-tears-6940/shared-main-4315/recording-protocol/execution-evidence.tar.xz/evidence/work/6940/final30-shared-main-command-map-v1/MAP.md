This directory is an offline command/input MAP and pending template. It is **not a selected cohort, frozen plan, recording-mode selection, successful feasibility or launch authority**. There is deliberately no `plan.json`, new sample ID, chosen receipt directory or executed browser/host/recording command. The old D and retired d034/1cb plans remain untouched. Candidate owns V7 helper edits; this map never edits those files.

`original-D-order-reference.json` retains the original 30 indices, fixture/pair/arm order and seeds694100/694101/694102. Replaying the existing `node scripts/perf/ab-order.mjs 5 SEED` for all three seeds exactly reproduces that order. This reproduces the old choice; it does not make a new one. `inputs-template.json` binds the already selected actual built56a5/4315 pair and all six genuine ordinary untimed canonical470f witnesses. Ordinary Holter PASS is explicitly **not recorded feasibility**.

Before selecting any new plan, BOTH actual source-matched recorded Holter cases must pass the reviewed V7 integration: native history, full original video decode, optical anchors, PRE/POST cadence, actual post-fixture host admission while recording, focus/viewport/GPU/readiness and complete canonical output. Their exported summaries must equal the actual underlying successful validations, share the exact configured recording mode, retain all original source/input hashes, and complete in the same boot before any timed history initialization. V7 capture freeze198195... and the separately reviewed first-frame auditor639713.../freeze454d8e... are now actual source references. Base recorded feasibility has actually passed; branch remains pending. No future observation is invented here. Gzip transport must reconstruct the complete actual host object without field loss or freshness waiver.

After those conditions hold, root can review/select a NEW cohort using this exact field map:

| New plan field | Actual source / mapping |
| --- | --- |
| `samples[0..29]` | Copy only index/fixture/pair/side/seed from original-D-order-reference; choose unique NEW IDs at selection, set expectedSource to existing selected arm head, fixtureIdentity from the actual matching catalog. Retain every attempt; no row replacement. |
| `sourceExecutionHeads`, `actualBuildReceipts` | Existing56a5/4315 arms/build refs in inputs-template. Do not relabel later source/data/doc heads as executed runtimes. |
| `manifests`, `helpers`, `serverInventoryReference` | FULL actual current timing-server startup inventory, exact source/tree/pkg/dist/collector/helpers. The existing815 inventory is a reference, not a fabricated future startup. Root alone owns any server/control action; pending uploads must be empty. |
| `collector`, `reportWrapper`, `reporter` | Original470f3f /3fa1e9 /40ef0f bytes and actual paths; hashes verified in inputs-template. No alternate timed collector. |
| `hostObserver`, `hostWindowsObserver` | Original frame-gpu-host.ts28fbde and frame-gpu-session.ts6eaa81. CPU≤10%, Linux≥41943040KiB, zero classified active graphs, freshness and rawGPU fields unchanged. |
| `recordingPolicy` | Protocol ifc6940-native-recording-matched-v1; exact actual common configuredMode and BOTH successful exported feasibility refs; frozen V7 source refs below. |
| `recordingPolicy.checkerSha256`, `anchorJoinSha256`, `policySha256` | Actual unchanged policy-v5 join.mjs, anchors.mjs, README.md; map hashes are existing observations, no final-plan freeze claimed. |
| `recordingPolicy.nativeHistoryValidator/Recorder/Emitter/DynamicHelper`, `canonicalPayloadValidator`, `releaseGenerator`, `functionalPrepareGenerator`, `markerGenerator`, `anchorDetector` | Exact reviewed V7 freeze mappings: history-v6 capture sources plus actual validate-first-frame.py639713... reviewer, release-v2, prepare-latch-v1, media-anchor-v3. Do not use obsolete latch-v1 release or assembler-v4 selector merely because a historical command refers to them. |
| six ordinary timed-output witnesses | witness-map-reference.json paths plus exact source/fixture/root bindings. FZK and Holter roots equal cross-arm; ISSUE129 roots differ intentionally and need the independent actual browser-field semantic/transfer closure. Native five-host evidence alone cannot replace this. |
| receipt/output directories | NEW create-exclusive directories only after selection. Keep all old refusals, failed native requests/cases, retired plans and failed source cohorts. |

The concrete assemble-plan.py is SOURCE ONLY and awaits root review; syntax was checked without invoking it. It creates a plan only when both actual exported feasibility refs and all source/runtime/input closures validate. No plan or sample IDs have been selected. The existing retired-plan expression/match helpers load adjacent `plan.json`: **do not execute them from their old directory**. After selecting the new plan, copy their byte-identical generic sources into the NEW selected directory and provide only that new adjacent plan. Observe-host's relative source import assumes the same work/6940/one-directory depth.

The root-only later command templates are:

```text
# Only AFTER both actual V7 recorded Holter validations succeed:
python3 REVIEWED_V7_HISTORY/export-feasibility.py ACTUAL_VALIDATED_BASE.json NEW_BASE_SUMMARY.json
python3 REVIEWED_V7_HISTORY/export-feasibility.py ACTUAL_VALIDATED_BRANCH.json NEW_BRANCH_SUMMARY.json
# Review/select NEW plan from exact field map above; no such selection occurs now.

# For every fixed index0..29 in order, after genuine fresh/cold focused tab setup:
# FIRST prepare the matching timed case with REVIEWED_V7_ASSEMBLER (assembler-v5),
# actual tab/state/epoch/server/build/fixture/mode refs, --status-kind timed --pair PAIR.
# The actual state saved for assembler preparation MUST have pending.length===0.
# Offline case preparation does not initialize native history or call startSample.
node NEW_SELECTED_COHORT/expression.mjs prepare INDEX ACTUAL_COLD.json ACTUAL_PREVIEW.json ACTUAL_LIFECYCLE.json
# Root then executes that exact original timed prepare expression OUTSIDE native history,
# BEFORE history initialization/recording-start; await genuine prepared-awaiting-host-admission.
# startSample posts /begin and creates serverpending ID before fetching/hashing the fixture.
# Do not run assembler prepare against the post-/begin pending state, or change source/epoch now.
# Save the actual prepare result/stage, THEN initialize the already prepared case's native history.
# There is no additional tenth native call inside the fixed nine-call timed history.
# Root performs actual recording-start; fixed4s; PRE show/remove; PRE cadence;
# Fixture fetch/hash preparation is ALREADY complete before history initialization/recording-start.
# There is NO second prepare invocation after PRE cadence. Original470f stays paused for release.
# Obtain fresh complete actual host observation with recorder still active:
pnpm exec tsx NEW_SELECTED_COHORT/observe-host.mts NEW_CASE/actual-host.json
# Use V7's actual dynamic-release command and original native wrapper, preserving full host bytes.
# Never run the old direct expression.mjs release path outside the recorded native history.
# No interaction/browser polling during measured load; only durable server-receipt filesystem polling.
# Actual POST cadence/show/remove; recording-stop; seal actual nativehistory.
node REVIEWED_V7_ASSEMBLER artifacts --case NEW_CASE
# Run the exact printed full-video inspector; then:
node REVIEWED_V7_ASSEMBLER anchor-manifest --case NEW_CASE --inspection ACTUAL_INSPECTION.json
# Run the exact printed anchor detector; then:
node REVIEWED_V7_ASSEMBLER assemble --case NEW_CASE --receipt ACTUAL_DURABLE_SAMPLE.json --inspection ACTUAL_INSPECTION.json --detection ACTUAL_DETECTION.json --ordinal-base PREVIOUS_LAST_ORDINAL
# Run the actual frozen V7 history-v6 validator against this case; preserve every failure.
node REVIEWED_V7_ASSEMBLER finalize --case NEW_CASE --validation ACTUAL_VALIDATION.json

# After preserving ALL30 attempts, original strict report MUST run even for expected identity FAIL:
node work/6940/browser-cohort-report.mjs NEW_PLAN.json ACTUAL_RECEIPTS NEW_STRICT_OUTPUT
# Retain its actual nonzero exit/refusal. Do not stop diagnostic reporting merely because it is false.
node NEW_SELECTED_COHORT/match-untimed.mjs ACTUAL_WITNESS_MAP.json ACTUAL_RECEIPTS NEW_OUTPUT_LINKAGE.json
node work/6940/native-recording-matched-policy-v5/join.mjs NEW_PLAN.json ACTUAL_SIDECARS NEW_STRICT_OUTPUT/summary.json NEW_RECORDING_ADMISSION.json
```

Strict cross-arm complete-output identity FAIL stays FAIL. Separately evaluate unchanged canonical parse/geometry/readiness/total deltas, five unique matched rounds per fixture, spread/noise,3%/5ms floor and positive-regression gates, complete within-arm output stability, independent intended-output classification and supplemental recording admission. Generic all-gates-PASS and pure algorithm-speedup claims remain prohibited. A recording summary does not qualify timing by itself.

Each case uses distinct actual tab/artifact/nonce and global native-journal ordinal continuation. A failed or missing timed row blocks the whole finite cohort: stop/retain safely, no survivor subset or replacement ID. Owner-managed extension is independently live-verified through19:45:34.963381UTC; it is not future host admission and does not authorize work after the owner resumes. Do not compress/drop tests or thresholds to fit the remaining window. No new plan/operation is selected by this MAP.

Root source-review corrections (before any selection/execution): timed preparation is completed once before history initialization/recording-start; fresh host observation is after actual PRE cadence, while recording is active. Functional feasibility alone retains its separate in-history functional-prepare step. Pending V7 includes history-v6 for minimal marked compressed-reply decoding; do not reuse history-v5 export/validator merely because old examples named it. Actual observed hashes are recorded in source-reference.json; source references alone do not replace required independent review or actual branch feasibility.

Verified original collector/server ordering: collector470f runSample posts `/__6940/begin/ID` before fixture fetch/hash; server immediately adds ID to pending. Assembler-v5 inherits the existing pending.length===0 source-state guard. Therefore the timed sequence is case preparation at genuine pending0 → one original timed startSample prepare outside native history → genuine prepared stage → native-history initialization → recording-start →4s/PRE markers/cadence → fresh host observation/release. No guard or collector change is required.

Candidate V7 source reference is now observed byte-exact in candidate-v7-source-reference.json: freeze198195286b66f6f3427569622170c5006f8c765e28c5923677ee866a8b6ccbfc and every frozen source file matched. This records existing source bytes only. The source-only status update below supersedes the original pending placeholders; no plan or mode is selected.

Current source-only readiness (19:17UTC): original V7 capture freeze198195286b66f6f3427569622170c5006f8c765e28c5923677ee866a8b6ccbfc remains unchanged. The actual reviewer is native-recording-history-v6/validate-first-frame.py6397136450b2bb763a87aa4d6c50c7841d545633f98946cf50a64c0da95e1018, frozen in native-recording-first-frame-review-v1/freeze.json454d8e64b264a43806b8b7d6777680a5409c67f40ea07a9267963c0a70cf614e. It preserves the original first-frame-validator failure and records audited exact-old-binding compatibility. Base functional-feasibility-first-frame-reviewed.json is an actual successful ten-call export; branch feasibility is still pending. Future plan nativeHistoryValidator MUST reference actual6397 reviewer, while immutable captured case intent retains originalbb215 binding through its explicit audit.

Prospective identical predispatch wait policy is operator-idle-wait-policy-v1.json68c6dec9ed3398a9d9044b98eaa723b6dea745def9fab59a790cf578250cb247, awaiting independent source approval. It retains every observation, first qualifying result only, at most8serial invocations/60seconds with original thresholds, no repoll after quiet/release, and180-second owner/case reserve. Historical base first-observation feasibility is not relabelled an execution of this new operator policy.

Concrete later selection command (DO NOT execute until branch actual PASS and root approves source/idle policy):

```text
python3 work/6940/final30-shared-main-command-map-v1/assemble-plan.py \
  --base-feasibility work/6940/holter-v7-base-case1/functional-feasibility-first-frame-reviewed.json \
  --branch-feasibility ACTUAL_SUCCESSFUL_BRANCH_EXPORTED_FEASIBILITY.json \
  --inventory work/6940/shared-main-browser-v1/receipts/server-815-1792085949429.json \
  --cohort ROOT_CHOSEN_NEW_COHORT --output-directory work/6940/ROOT_CHOSEN_NEW_DIRECTORY \
  --reviewed-idle-policy work/6940/operator-idle-wait-policy-v1.json \
  --reviewed-idle-policy-sha256 68c6dec9ed3398a9d9044b98eaa723b6dea745def9fab59a790cf578250cb247 \
  --source-approval ACTUAL_ROOT_REVIEW_RECEIPT.json
```

Offline finalization for timed cases must use NEW native-recording-timed-finalizer-v1/finalize.mjs (candidate source5474d369..., freeze86688eb4..., independent review pending), not the functional-only first-frame selector. All30 native histories/videos/durable receipts can be sealed/preserved first, with no competing decode during timed runs. Full-video inspection, optical detection, case assembly and exact6397 history validation/finalization may then run serially in original order after the window; global logical journal ordinals are assigned in that original order. Both functional feasibility validations must already have completed before EVERY timed history initialization. Every later failure still blocks the entire cohort; no early performance verdict or substitute recording.

19:23UTC source-only correction: the unchanged current server writes actual sample receipts into `work/6940/shared-main-browser-v1/receipts`; a future plan must name that existing actual directory, NOT a new empty cohort/receipts path. Only new cohort metadata/report directories and IDs are created at selection; the assembler rejects collisions with ANY retained artifact for a new sample ID. No server restart, copying, or relabelled persistence is required. A newly discovered marker-callback first-frame clock comparison is under minimal class-wide auditor review; source6397 and its first-frame-only freeze are historical. Do not execute the staged assembler or select a plan until candidate's NEW auditor freeze and both newly successful post-run base/branch reviews/exports replace those pins. Original captures and failures remain unchanged.
