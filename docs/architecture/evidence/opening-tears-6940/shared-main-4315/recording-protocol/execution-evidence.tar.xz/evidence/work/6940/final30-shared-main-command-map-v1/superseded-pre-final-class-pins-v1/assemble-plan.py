"""SOURCE ONLY until root approves and BOTH actual recorded feasibility exports exist.
Creates a new finite30 plan; never calls browser, host, recording, or meshing tools.
"""
import argparse
import copy
import datetime
import hashlib
import json
import re
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
W = ROOT / 'work/6940'
VALIDATOR = '6397136450b2bb763a87aa4d6c50c7841d545633f98946cf50a64c0da95e1018'
V7 = '198195286b66f6f3427569622170c5006f8c765e28c5923677ee866a8b6ccbfc'

def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):
    return json.loads(Path(p).read_text())

def ref(p):
    p = Path(p).resolve()
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}

def verify(r, parse_json=True):
    p = Path(r['path'])
    assert p.is_absolute() and digest(p) == r['sha256'], 'Changed reference: ' + str(p)
    if 'bytes' in r:
        assert p.stat().st_size == r['bytes']
    return read(p) if parse_json else None

def frozen(p, expected):
    assert digest(p) == expected, 'Freeze changed: ' + str(p)
    f = read(p)
    for filename, expected_sha in f['files'].items():
        assert digest(filename) == expected_sha, 'Frozen helper changed: ' + filename
    return f

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    for key in ('base-feasibility', 'branch-feasibility', 'inventory', 'cohort', 'output-directory', 'reviewed-idle-policy', 'reviewed-idle-policy-sha256', 'source-approval'):
        ap.add_argument('--' + key, required=True)
    a = ap.parse_args()
    assert re.fullmatch(r'[a-z0-9][a-z0-9-]{2,80}', a.cohort)
    out = Path(a.output_directory).resolve()
    assert out.parent == W and not out.exists(), 'New one-level work/6940 directory required'
    template = read(HERE / 'inputs-template.json')
    observed = read(HERE / 'source-reference.json')
    frozen(W / 'native-recording-final-helper-freeze-v7.json', V7)
    frozen(W / 'native-recording-first-frame-review-v1/freeze.json', '454d8e64b264a43806b8b7d6777680a5409c67f40ea07a9267963c0a70cf614e')
    auditor = ref(W / 'native-recording-history-v6/validate-first-frame.py')
    assert auditor['sha256'] == VALIDATOR
    assert digest(a.reviewed_idle_policy) == a.reviewed_idle_policy_sha256
    idle = ref(a.reviewed_idle_policy)
    assert idle['sha256'] == '68c6dec9ed3398a9d9044b98eaa723b6dea745def9fab59a790cf578250cb247'
    for r in (read(a.reviewed_idle_policy)['observer'], read(a.reviewed_idle_policy)['observerImplementation'], read(a.reviewed_idle_policy)['ownerReceipt']):
        verify(r, parse_json=False)
    approval = ref(a.source_approval)  # Root supplies the actual reviewed-source decision; no invented approval.
    original_path = W / 'browser-final30-d034-1cb4-v1/plan.json'
    original = read(original_path)
    order = read(HERE / 'original-D-order-reference.json')
    verify(order['source'])
    slots = order['slotsWithoutSampleIdsOrExecutionState']
    assert len(slots) == 30
    assert [{k: s[k] for k in ('index', 'fixture', 'pair', 'side', 'seed')} for s in original['samples']] == slots
    for source in template['originalUnchangedSources'].values():
        verify(source, parse_json=False)
    inventory = read(a.inventory)
    for side, arm in template['existingRuntimeArms'].items():
        m = inventory['manifests'][side]
        assert (m['head'], m['tree'], m['checkout'], m['distManifestSha256']) == (arm['existingSelectedRuntimeHead'], arm['tree'], arm['runtimeCheckout'], arm['existingDistManifestSHA256'])
        assert m['packageWasm'] == arm['runtimeWasm']
        assert m['trackedDiffSha256'] == hashlib.sha256(b'').hexdigest()
        verify(arm['successfulBuildReceipt'])
        assert digest(m['packageWasm']['path']) == m['packageWasm']['sha256']
        assert subprocess.check_output(['git', '-C', m['checkout'], 'rev-parse', 'HEAD'], text=True).strip() == m['head']
        assert subprocess.check_output(['git', '-C', m['checkout'], 'rev-parse', 'HEAD^{tree}'], text=True).strip() == m['tree']
        assert subprocess.check_output(['git', '-C', m['checkout'], 'diff', 'HEAD', '--']) == b''
        for entry in m['files']:
            disk = Path(m['dist']) / entry['path']
            assert disk.stat().st_size == entry['bytes'] and digest(disk) == entry['sha256']
    for fixture, sides in template['actualOrdinaryUntimedWitnesses'].items():
        for side, witness in sides.items():
            actual = verify(witness['receipt'])
            assert actual['ok'] is True and actual['functionalOnly'] is True and actual['noTimingQualification'] is True
            assert actual['server']['manifest']['head'] == inventory['manifests'][side]['head']
            assert actual['payload']['models'][0]['completeGeometryPayloadSha256'] == witness['completeCPUroot']
    assert {k: inventory['fixtures'][k] for k in template['fixtureCatalog']} == template['fixtureCatalog']  # Server also exposes Mini; the timed charter selects exactly these three fixtures.
    for h in inventory['helpers']:
        assert digest(h['path']) == h['sha256']
    helper_fields = {'nativeHistoryRecorder': ('native-recording-history-v6/journal.py', 'recorderSHA256'), 'nativeHistoryEmitter': ('native-recording-history-v6/emit-invocation.mjs', 'emitterSHA256'), 'nativeHistoryDynamicHelper': ('native-recording-history-v6/dynamic.py', 'dynamicHelperSHA256'), 'canonicalPayloadValidator': ('native-recording-history-v6/canonical-payload.mjs', 'canonicalPayloadValidatorSHA256'), 'releaseGenerator': ('native-recording-functional-latch-v2/release.mjs', 'releaseGeneratorSHA256'), 'functionalPrepareGenerator': ('native-recording-functional-latch-v1/prepare-expression.mjs', 'functionalPrepareGeneratorSHA256')}
    helpers = {k: ref(W / p) for k, (p, _) in helper_fields.items()}
    now = time.monotonic_ns()
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    feasible = {}
    mode = None
    for side, filename in [('base', a.base_feasibility), ('branch', a.branch_feasibility)]:
        f = read(filename)
        assert f['schema'] == 1 and f['statusKind'] == 'functional' and f['protocol'] == 'ifc6940-native-recording-matched-v1'
        assert f['side'] == side and f['fixture'] == 'holter' and f['sourceHead'] == inventory['manifests'][side]['head']
        assert all(f[k] is True for k in ('functionalOnly', 'complete', 'artifactValidated', 'recordingContinuousThroughSettling', 'noTimingQualification'))
        v = verify(f['validationReport'])
        assert all(v[k] is True for k in ('ok', 'lifecycleCoverageVerified', 'actualCompleteNativeHistoryReviewed'))
        assert v['performanceQualified'] is False and v['recordingInterrupted'] is False and v['actualNativeCalls'] == 10 and v['statusKind'] == 'functional'
        assert v['validatorSHA256'] == VALIDATOR
        assert {k: value for k, value in f.items() if k != 'validationReport'} == v['functionalFeasibility']
        assert v['actualInputs'] and v['actualInputs'][v['nativeHistory']['path']] == v['nativeHistory']['sha256']
        for p, sha in v['actualInputs'].items():
            assert Path(p).is_absolute() and digest(p) == sha
        for key, (_, field) in helper_fields.items():
            assert v[field] == helpers[key]['sha256']
        complete, sealed = f['validationCompletedClock'], f['nativeHistorySealedClock']
        assert complete == v['validationCompletedClock'] and sealed == v['nativeHistorySealedClock']
        assert complete['clockDomain'] == sealed['clockDomain'] and complete['clockDomain']['bootId'] == boot
        assert 0 < int(sealed['monotonicNs']) <= int(complete['monotonicNs']) < now
        if mode is None:
            mode = f['recordingMode']
        assert f['recordingMode'] == mode
        feasible[side] = ref(filename)
    p = copy.deepcopy(original)
    p.update(preparedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), state='prepared-unlaunched', sourceExecutionHeads={s: m['head'] for s, m in inventory['manifests'].items()}, serverInventoryReference=ref(a.inventory), manifests=inventory['manifests'], helpers=inventory['helpers'], actualBuildReceipts=[ref(x['successfulBuildReceipt']['path']) for x in template['existingRuntimeArms'].values()], receiptDirectory=str(W / 'shared-main-browser-v1/receipts'), outputDirectory=str(out / 'strict-report'))
    p['scope'] = 'Finite30 original seeded order; five matched rounds per three fixtures; actual selected56a5/4315 runtimes. Fresh tabs, not fresh browser-main processes.'
    p['serverRequirement'] = 'Actual original470f canonicalURL/current56a5/4315 inventory pinned; per-case source/epoch/pending/cold/fullhost checks remain mandatory.'
    prior_retirement = p.pop('retirementReceipt', None)
    if prior_retirement is not None:
        p['priorPlanHistory'].append({**prior_retirement, 'disposition': 'Historical oldD retirement only; does not retire this new selected cohort.'})
    p['samples'] = [{**s, 'id': 'perf6940-' + s['fixture'] + '-r' + str(s['pair']) + '-' + s['side'] + '-' + a.cohort, 'status': 'planned', 'expectedSource': p['sourceExecutionHeads'][s['side']], 'fixtureIdentity': template['fixtureCatalog'][s['fixture']]} for s in slots]
    p['recordingPolicy'] = dict(protocol='ifc6940-native-recording-matched-v1', configuredMode=mode, feasibility=feasible, checkerSha256=template['originalUnchangedSources']['recordedJoin']['sha256'], anchorJoinSha256=template['originalUnchangedSources']['anchorJoin']['sha256'], policySha256=template['originalUnchangedSources']['recordedPolicy']['sha256'], nativeHistoryValidator=auditor, markerGenerator=ref(W / 'native-recording-media-anchor-v3/marker-expression.mjs'), anchorDetector=ref(W / 'native-recording-media-anchor-v3/detect.py'), **helpers)
    p['sourceSelectionInputs'] = dict(assembler=ref(__file__), originalPlan=ref(original_path), template=ref(HERE / 'inputs-template.json'), sourceReference=ref(HERE / 'source-reference.json'), sourceApproval=approval, reviewedPredispatchIdlePolicy=idle, observedBootId=boot, selectedMonotonicNs=str(now), noBrowserOrHostCalls=True)
    p['prerequisites'] = dict(p['prerequisites'], allSixActualUntimedV3Controls='Actual six source-matched ordinary controls retained in witness-map.json; recorded feasibility separately pinned above.', freshV3TimingServer='Actual pinned current inventory; live source/epoch/pending/cold/host checks remain mandatory per case.', issue129UntimedV4PairAndExhaustiveSemanticReview='Actual complete per-arm transfer and bounded six-consumer physical reviews retained; strict cross-arm identity FAIL remains.', coordinatedOwnHeavyHold='Required before every actual load; not granted by plan selection.')
    p['priorPlanHistory'].append({**ref(original_path), 'disposition': 'Retired unlaunched on shared-main refresh; retained unchanged.'})
    assert len({s['id'] for s in p['samples']}) == 30
    assert Path(p['receiptDirectory']).is_dir(), 'Actual existing server receipt directory required'
    for sample in p['samples']:
        assert not list(Path(p['receiptDirectory']).glob(sample['id'] + '*')), 'Sample ID collides with retained server evidence'
    out.mkdir()
    (out / 'plan.json').write_text(json.dumps(p, indent=2) + '\n')
    for name in ('expression.mjs', 'match-untimed.mjs', 'observe-host.mts', 'cold-storage-expression.js'):
        (out / name).write_bytes((original_path.parent / name).read_bytes())
    (out / 'witness-map.json').write_bytes((HERE / 'witness-map-reference.json').read_bytes())
    print(json.dumps({'plan': ref(out / 'plan.json'), 'state': 'prepared-unlaunched', 'samples': 30, 'noBrowserOrHostCalls': True}))

if __name__ == '__main__':
    main()
