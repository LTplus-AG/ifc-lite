This directory is an offline command/input MAP and pending template. It is **not a selected cohort, frozen plan, recording-mode selection, successful feasibility or launch authority**. There is deliberately no `plan.json`, new sample ID, chosen receipt directory or executed browser/host/recording command. The old D and retired d034/1cb plans remain untouched. Candidate owns V7 helper edits; this map never edits those files.

`original-D-order-reference.json` retains the original 30 indices, fixture/pair/arm order and seeds694100/694101/694102. Replaying the existing `node scripts/perf/ab-order.mjs 5 SEED` for all three seeds exactly reproduces that order. This reproduces the old choice; it does not make a new one. `inputs-template.json` binds the already selected actual built56a5/4315 pair and all six genuine ordinary untimed canonical470f witnesses. Ordinary Holter PASS is explicitly **not recorded feasibility**.

Before selecting any new plan, BOTH actual source-matched recorded Holter cases must pass the reviewed V7 integration: native history, full original video decode, optical anchors, PRE/POST cadence, actual post-fixture host admission while recording, focus/viewport/GPU/readiness and complete canonical output. Their exported summaries must equal the actual underlying successful validations, share the exact configured recording mode, retain all original source/input hashes, and complete in the same boot before any timed history initialization. V7 freeze, assembler-v5 and release-v2 refs remain PENDING until candidate freezes/reviews them; no future hash or observation is invented here. Gzip transport must reconstruct the complete actual host object without field loss or freshness waiver.

After those conditions hold, root can review/select a NEW cohort using this exact field map:

| New plan field | Actual source / mapping |
| --- | --- |
| `samples[0..29]` | Copy only index/fixture/pair/side/seed from original-D-order-reference; choose unique NEW IDs at selection, set expectedSource to existing selected arm head, fixtureIdentity from the actual matching catalog. Retain every attempt; no row replacement. |
| `sourceExecutionHeads`, `actualBuildReceipts` | Existing56a5/4315 arms/build refs in inputs-template. Do not relabel later source/data/doc heads as executed runtimes. |
| `manifests`, `helpers`, `serverInventoryReference` | FULL actual current timing-server startup inventory, exact source/tree/pkg/dist/collector/helpers. The existing815 inventory is a reference, not a fabricated future startup. Root alone owns any server/control action; pending uploads must be empty. |
| `collector`, `reportWrapper`, `reporter` | Original470f3f /3fa1e9 /40ef0f bytes and actual paths; hashes verified in inputs-template. No alternate timed collector. |
| `hostObserver`, `hostWindowsObserver` | Original frame-gpu-host.ts28fbde and frame-gpu-session.ts6eaa81. CPU≤10%, Linux≥41943040KiB, zero classified active graphs, freshness and rawGPU fields unchanged. |
| `recordingPolicy` | Protocol ifc6940-native-recording-matched-v1; exact actual common configuredMode and BOTH successful exported feasibility refs; frozen V7 source refs below. |
| `recordingPolicy.checkerSha256`, `anchorJoinSha256`, `policySha256` | Actual unchanged policy-v5 join.mjs, anchors.mjs, README.md; map hashes are existing observations, no final-plan freeze claimed. |
| `recordingPolicy.nativeHistoryValidator/Recorder/Emitter/DynamicHelper`, `canonicalPayloadValidator`, `releaseGenerator`, `functionalPrepareGenerator`, `markerGenerator`, `anchorDetector` | Exact reviewed V7 freeze mappings: history-v5, release-v2, prepare-latch-v1, media-anchor-v3. Do not use obsolete latch-v1 release or assembler-v4 selector merely because a historical command refers to them. |
| six ordinary timed-output witnesses | witness-map-reference.json paths plus exact source/fixture/root bindings. FZK and Holter roots equal cross-arm; ISSUE129 roots differ intentionally and need the independent actual browser-field semantic/transfer closure. Native five-host evidence alone cannot replace this. |
| receipt/output directories | NEW create-exclusive directories only after selection. Keep all old refusals, failed native requests/cases, retired plans and failed source cohorts. |

The future plan assembly/generator must be separately reviewed against this map after the real input refs exist. No unimplemented command is represented here as an executable plan generator. The existing retired-plan expression/match helpers load adjacent `plan.json`: **do not execute them from their old directory**. After selecting the new plan, copy their byte-identical generic sources into the NEW selected directory and provide only that new adjacent plan. Observe-host's relative source import assumes the same work/6940/one-directory depth.

The root-only later command templates are:

```text
# Only AFTER both actual V7 recorded Holter validations succeed:
python3 work/6940/native-recording-history-v5/export-feasibility.py ACTUAL_VALIDATED_BASE.json NEW_BASE_SUMMARY.json
python3 work/6940/native-recording-history-v5/export-feasibility.py ACTUAL_VALIDATED_BRANCH.json NEW_BRANCH_SUMMARY.json
# Review/select NEW plan from exact field map above; no such selection occurs now.

# For every fixed index0..29 in order, after genuine fresh/cold focused tab setup:
node NEW_SELECTED_COHORT/expression.mjs prepare INDEX ACTUAL_COLD.json ACTUAL_PREVIEW.json ACTUAL_LIFECYCLE.json
# Save that exact printed prepare expression as the declared timed prepare request.
# Prepare the matching timed case with REVIEWED_V7_ASSEMBLER (candidate's assembler-v5),
# actual tab/state/epoch/server/build/fixture/mode refs, --status-kind timed --pair PAIR.
# Root performs actual recording-start; fixed4s; PRE show/remove; PRE cadence;
# THEN the timed prepare request performs fetch/hash outside timer under original470f.
# Obtain fresh complete actual host observation with recorder still active:
pnpm exec tsx NEW_SELECTED_COHORT/observe-host.mts NEW_CASE/actual-host.json
# Use V7's actual dynamic-release command and original native wrapper, preserving full host bytes.
# Never run the old direct expression.mjs release path outside the recorded native history.
# No interaction/browser polling during measured load; only durable server-receipt filesystem polling.
# Actual POST cadence/show/remove; recording-stop; seal actual nativehistory.
node REVIEWED_V7_ASSEMBLER artifacts --case NEW_CASE
# Run the exact printed full-video inspector; then:
node REVIEWED_V7_ASSEMBLER anchor-manifest --case NEW_CASE --inspection ACTUAL_INSPECTION.json
# Run the exact printed anchor detector; then:
node REVIEWED_V7_ASSEMBLER assemble --case NEW_CASE --receipt ACTUAL_DURABLE_SAMPLE.json --inspection ACTUAL_INSPECTION.json --detection ACTUAL_DETECTION.json --ordinal-base PREVIOUS_LAST_ORDINAL
# Run printed frozen history-v5 validator against this case; preserve every failure.
node REVIEWED_V7_ASSEMBLER finalize --case NEW_CASE --validation ACTUAL_VALIDATION.json

# After preserving ALL30 attempts, original strict report MUST run even for expected identity FAIL:
node work/6940/browser-cohort-report.mjs NEW_PLAN.json ACTUAL_RECEIPTS NEW_STRICT_OUTPUT
# Retain its actual nonzero exit/refusal. Do not stop diagnostic reporting merely because it is false.
node NEW_SELECTED_COHORT/match-untimed.mjs ACTUAL_WITNESS_MAP.json ACTUAL_RECEIPTS NEW_OUTPUT_LINKAGE.json
node work/6940/native-recording-matched-policy-v5/join.mjs NEW_PLAN.json ACTUAL_SIDECARS NEW_STRICT_OUTPUT/summary.json NEW_RECORDING_ADMISSION.json
```

Strict cross-arm complete-output identity FAIL stays FAIL. Separately evaluate unchanged canonical parse/geometry/readiness/total deltas, five unique matched rounds per fixture, spread/noise,3%/5ms floor and positive-regression gates, complete within-arm output stability, independent intended-output classification and supplemental recording admission. Generic all-gates-PASS and pure algorithm-speedup claims remain prohibited. A recording summary does not qualify timing by itself.

Each case uses distinct actual tab/artifact/nonce and global native-journal ordinal continuation. A failed or missing timed row blocks the whole finite cohort: stop/retain safely, no survivor subset or replacement ID. Owner window expires19:15:34.963381UTC; it is not future host admission and does not authorize work after the owner resumes. Do not compress/drop tests or thresholds to fit the remaining window. No new plan/operation is selected by this MAP.
