"""Read existing evidence and prepare a MAP, never select a plan or run a browser."""
from pathlib import Path
import json,hashlib,subprocess,datetime
root=Path('work/6940');out=root/'final30-shared-main-command-map-v1'
def ref(p):return {'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def write(name,d):
 with (out/name).open('x')as f:json.dump(d,f,indent=2);f.write('\n')
dpath=root/'browser-cohort-plan-20261015d.json';old=json.loads(dpath.read_text())
serverpath=root/'shared-main-browser-v1/receipts/server-815-1792085949429.json';server=json.loads(serverpath.read_text())
slots=[{k:s[k]for k in ['index','fixture','pair','side','seed']}for s in old['samples']]
assert len(slots)==30 and len({(s['fixture'],s['pair'],s['side'])for s in slots})==30
checks=[]
for fixture in ['fzk','issue129','holter']:
 rows=[s for s in slots if s['fixture']==fixture];seeds={s['seed']for s in rows};assert len(seeds)==1
 seed=seeds.pop();command=['node','scripts/perf/ab-order.mjs','5',str(seed)]
 r=subprocess.run(command,capture_output=True,text=True,check=True)
 expected=[tuple(x.split())for x in r.stdout.strip().splitlines()]
 actual=[tuple(s['side']for s in rows if s['pair']==i)for i in range(1,6)]
 assert expected==actual
 checks.append({'fixture':fixture,'seed':seed,'command':command,'actualGeneratedOrder':expected,'matchesRetiredD':True})
write('original-D-order-reference.json',{'state':'REFERENCE_ONLY_NOT_A_SELECTED_COHORT','source':ref(dpath),'slotsWithoutSampleIdsOrExecutionState':slots,'originalSeedReplays':checks})
arms={};witnesses={}
for side in ['base','branch']:
 m=server['manifests'][side]
 bpath=root/('browser-build-main-56a5-v1/result.json'if side=='base'else'browser-build-integrated-4315-v1/result.json')
 b=json.loads(bpath.read_text());assert b['head']==m['head']and b['tree']==m['tree']and b['exitCode']==0
 arms[side]={'existingSelectedRuntimeHead':m['head'],'tree':m['tree'],'runtimeCheckout':m['checkout'],'existingDistManifestSHA256':m['distManifestSha256'],'runtimeWasm':m['packageWasm'],'successfulBuildReceipt':ref(bpath)}
 for fixture in ['fzk','issue129','holter']:
  p=root/f'shared-main-browser-v1/receipts/functional-{fixture}-{side}-shared56a5-v1.result.json'
  r=json.loads(p.read_text());assert r['ok']is True and r['functionalOnly']is True and r['noTimingQualification']is True
  assert r['server']['manifest']['head']==m['head']and r['collectorSha256']=='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17'
  assert r['fixtureIdentity']['sha256']==server['fixtures'][fixture]['sha256']
  witnesses.setdefault(fixture,{})[side]={'receipt':ref(p),'completeCPUroot':r['payload']['models'][0]['completeGeometryPayloadSha256'],'recordedFeasibilityClaimed':False}
source_paths={
 'collector':root/'browser-ab-cohort.mjs','reportWrapper':root/'browser-cohort-report.mjs',
 'reporter':Path('scripts/perf/browser-ab-report.mjs'),'hostObserver':Path('scripts/perf/frame-gpu-host.ts'),
 'hostWindowsObserver':Path('scripts/perf/frame-gpu-session.ts'),
 'correctedOutputPolicy':root/'final-browser-perf-output-policy-v1.json',
 'recordedJoin':root/'native-recording-matched-policy-v5/join.mjs',
 'recordedPolicy':root/'native-recording-matched-policy-v5/README.md',
 'anchorJoin':root/'native-recording-matched-policy-v5/anchors.mjs'}
refs={k:ref(p)for k,p in source_paths.items()}
assert refs['collector']['sha256']=='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17'
assert refs['reportWrapper']['sha256']=='3fa1e9b34f260cdf9a856dc3921b5da271a84fe9907faf99b851b6629957db26'
assert refs['reporter']['sha256']=='40ef0f8f677c9361ee671e86db0131834197e8d57328985693d3d4acba109e1d'
pending={
 'actualBothHolterFunctionalFeasibility':{'base':None,'branch':None},
 'actualUnderlyingSuccessfulValidation':{'base':None,'branch':None},
 'actualCommonConfiguredRecordingMode':None,'reviewedFinalHelperFreezeV7':None,
 'reviewedAssemblerV5':None,'actualFreshTimingServerInventory':None,
 'newCohortId':None,'newPlanPath':None,'newReceiptsDirectory':None,
 'independentSemanticReviewAndCurrentSourceTransferClosure':None}
template={
 'state':'COMMAND_MAP_AND_PENDING_INPUT_TEMPLATE_ONLY','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'notASelectedOrFrozenPlan':True,'noBrowserHostRecordingOrPerformanceExecuted':True,
 'existingRuntimeArms':arms,'existingServerInventoryReference':ref(serverpath),
 'actualOrdinaryUntimedWitnesses':witnesses,'originalUnchangedSources':refs,
 'fixtureCatalog':{k:server['fixtures'][k]for k in ['fzk','issue129','holter']},
 'pendingRequiredBeforeAnyNewPlanSelection':pending,
 'expectedPendingHelperLocationsNotVerifiedOrSelected':{
  'helperFreeze':str((root/'native-recording-final-helper-freeze-v7.json').resolve()),
  'assembler':str((root/'native-recording-case-assembler-v5/case.mjs').resolve()),
  'releaseGenerator':str((root/'native-recording-functional-latch-v2/release.mjs').resolve())}}
write('inputs-template.json',template)
write('witness-map-reference.json',{'state':'ACTUAL_ORDINARY_WITNESS_PATH_REFERENCE_ONLY_NOT_RECORDED_FEASIBILITY','v3':{f:{side:row['receipt']['path']for side,row in sides.items()}for f,sides in witnesses.items()}})
write('preparation-checks.json',{'originalSeedReplayAllThreePass':True,'slots':30,'matchedFixturePairArms':30,'newPlanCreated':False,'sampleIdsChosen':False,'finalV7FeasibilityOrModeInvented':False,'originalSourceHashes':refs})
print(str(out.resolve()))
