(async function probe(a) {
  const state = await fetch('/__6940/state', { cache: 'no-store' }).then(response => { if (!response.ok) throw Error('State fetch failed'); return response.json(); });
  if (state.side !== a.side || state.epoch !== a.epoch || state.manifest?.head !== a.head) throw Error('Actual source/epoch mismatch');
  const status=()=>{const s=a.statusKind==='timed'?globalThis.__IFC_6940_SAMPLE__:globalThis.__IFC_6940_FUNCTIONAL_STATUS__;return s?{...s}:null;};
  const functional=()=>{const r=globalThis.__IFC_6940_FUNCTIONAL_RECEIPT__;return r?{id:r.id,ok:r.ok,functionalOnly:r.functionalOnly,noTimingQualification:r.noTimingQualification,source:{head:r.server?.manifest?.head,side:r.server?.side,epoch:r.server?.epoch}}:null;};
  function allowed(){const s=status(),f=functional();if(a.statusKind==='functional'){if(globalThis.__IFC_6940_SAMPLE__)throw Error('Functional probe alongside timed sample');if(a.phase==='pre'&&(s||f))throw Error('Functional PRE requires unloaded context');if(a.phase==='post'&&(s?.stage!=='done'||s.persistence!=='saved'||f?.id!==a.id||f.ok!==true||f.functionalOnly!==true||f.noTimingQualification!==true||f.source.head!==a.head||f.source.side!==a.side||f.source.epoch!==a.epoch))throw Error('Actual functional completion missing');}else{if(a.phase==='pre'&&s&&(s.id!==a.id||s.stage!=='prepared-awaiting-host-admission'))throw Error('Preflight after release');if(a.phase==='post'&&(s?.id!==a.id||s.stage!=='done'||s.persistence!=='saved'))throw Error('Postflight before durable completion');}}
  allowed();
  const result = { protocol: 'ifc6940-native-recording-matched-v1', phase: a.phase, statusKind: a.statusKind, id: a.id, tabId: a.tabId,
    tabIdentityProvidedByCaller: true, href: location.href, source: { side: state.side, head: state.manifest.head, epoch: state.epoch },
    viewport: { innerWidth, innerHeight, devicePixelRatio }, collector: status(), functionalReceiptBefore:a.statusKind==='functional'?functional():null, timeOrigin: performance.timeOrigin,
    startNow: performance.now(), samples: [], finished: false, timeout: false };
  await new Promise(resolve => {
    let handle;
    const timeout = setTimeout(() => { result.timeout = true; cancelAnimationFrame(handle); resolve(); }, 3000);
    function frame(timestamp) {
      result.samples.push({ timestamp, visibility: document.visibilityState, hasFocus: document.hasFocus() });
      if (result.samples.length === 60) { result.finished = true; clearTimeout(timeout); resolve(); }
      else handle = requestAnimationFrame(frame);
    }
    handle = requestAnimationFrame(frame);
  });
  allowed();
  result.functionalReceiptAfter=a.statusKind==='functional'?functional():null;
  result.finishNow = performance.now();
  result.collectorAfter = status();
  return result;
})({"phase":"pre","statusKind":"functional","id":"functional-holter-base-recorded-shared56a5-v7-case1","tabId":"tab_12","head":"56a5f58c325997c4c7ec460456a9e150437718cd","side":"base","epoch":"a6d952e1-cec4-4b63-b4b6-e1d267c21cec"})