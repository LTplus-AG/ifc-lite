(async function marker(a) {
  const state = await fetch('/__6940/state',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Source fetch');return r.json();});
  if(state.side!==a.side || state.epoch!==a.epoch || state.manifest?.head!==a.head)throw Error('Source/epoch differs');
  const status=()=>{const s=a.statusKind==='timed'?globalThis.__IFC_6940_SAMPLE__:globalThis.__IFC_6940_FUNCTIONAL_STATUS__;return s?{...s}:null;};
  const functional=()=>{const r=globalThis.__IFC_6940_FUNCTIONAL_RECEIPT__;return r?{id:r.id,ok:r.ok,functionalOnly:r.functionalOnly,noTimingQualification:r.noTimingQualification,source:{head:r.server?.manifest?.head,side:r.server?.side,epoch:r.server?.epoch}}:null;};
  function allowed(){const s=status(),f=functional();if(a.statusKind==='functional'){if(globalThis.__IFC_6940_SAMPLE__)throw Error('Functional protocol cannot run alongside a timed sample');if(a.phase==='pre'&&(s||f))throw Error('Functional PRE requires fresh unloaded context');if(a.phase==='post'&&(s?.stage!=='done'||s.persistence!=='saved'||f?.id!==a.id||f.ok!==true||f.functionalOnly!==true||f.noTimingQualification!==true||f.source.head!==a.head||f.source.side!==a.side||f.source.epoch!==a.epoch))throw Error('Actual functional completion missing');}else{if(a.phase==='pre'&&s&&(s.id!==a.id||s.stage!=='prepared-awaiting-host-admission'))throw Error('PRE after release');if(a.phase==='post'&&(s?.id!==a.id||s.stage!=='done'||s.persistence!=='saved'))throw Error('POST before durable completion');}}
  allowed();if(document.visibilityState!=='visible'||!document.hasFocus())throw Error('Not genuinely visible/focused');
  const elementId='__ifc6940_media_anchor_v1__';let el=document.getElementById(elementId);
  const result={...a,tabIdentityProvidedByCaller:true,href:location.href,timeOrigin:performance.timeOrigin,startNow:performance.now(),viewport:{innerWidth,innerHeight,devicePixelRatio},collectorBefore:status(),functionalReceiptBefore:a.statusKind==='functional'?functional():null,source:{head:state.manifest.head,side:state.side,epoch:state.epoch},frames:[],finished:false};
  if(a.action==='show'){
    if(el)throw Error('Marker already present');
    el=document.createElement('div');el.id=elementId;el.dataset.token=a.token;
    Object.assign(el.style,{position:'fixed',left:'24px',top:'24px',width:'160px',height:'160px',zIndex:'2147483647',pointerEvents:'none',display:'grid',gridTemplateColumns:'repeat(20,8px)',gridTemplateRows:'repeat(20,8px)',padding:'0',margin:'0',border:'0',opacity:'1',transform:'none',filter:'none',mixBlendMode:'normal',isolation:'isolate',boxSizing:'content-box'});
    const bits=[...a.token].flatMap(h=>[3,2,1,0].map(k=>(parseInt(h,16)>>k)&1));
    for(let y=0;y<20;y++)for(let x=0;x<20;x++){
      let bit;if(x<2||y<2||x>=18||y>=18)bit=(x*3+y*5+Math.floor(x/2))%2;else{const j=(y-2)*16+x-2;bit=bits[j%128]^(j>=128?1:0);}
      const c=document.createElement('div');Object.assign(c.style,{width:'8px',height:'8px',margin:'0',padding:'0',border:'0',background:bit?'rgb(255,255,255)':'rgb(0,0,0)'});el.append(c);
    }
    document.documentElement.append(el);
    const r=el.getBoundingClientRect();result.rect={x:r.x,y:r.y,width:r.width,height:r.height};
  }else{if(!el||el.dataset.token!==a.token)throw Error('Wrong/missing owned marker');const r=el.getBoundingClientRect();result.rect={x:r.x,y:r.y,width:r.width,height:r.height};el.remove();}
  // Passive callbacks only, strictly outside collector measurement/admission.
  await new Promise((resolve,reject)=>{let h;const timeout=setTimeout(()=>{cancelAnimationFrame(h);reject(Error('Paint callback deadline'));},3000);const count=a.action==='show'?60:3;function frame(t){try{allowed();if(document.visibilityState!=='visible'||!document.hasFocus())throw Error('Visibility/focus lost');result.frames.push(t);if(result.frames.length===count){clearTimeout(timeout);resolve();}else h=requestAnimationFrame(frame);}catch(e){clearTimeout(timeout);reject(e);}}h=requestAnimationFrame(frame);});
  result.finishNow=performance.now();result.collectorAfter=status();result.functionalReceiptAfter=a.statusKind==='functional'?functional():null;result.markerPresent=document.getElementById(elementId)?.dataset.token===a.token;result.finished=true;
  if(result.markerPresent!==(a.action==='show'))throw Error('Marker lifecycle differs');
  return result;
})({"protocol":"ifc6940-media-anchor-v1","statusKind":"functional","phase":"pre","id":"functional-holter-branch-recorded-shared56a5-v7-case4","tabId":"tab_13","head":"431571bdb96a20a73b19907c2c3ec05dc7733f43","side":"branch","epoch":"8cf5fa13-655f-40d8-90d1-faaf30001b54","nonce":"7c595b2e53a15772054a1060f29380b5","action":"show","token":"023c97635443d8a3fc4cc65500dedec8","generatorSha256":"16fa14ea277649aeb448a4693981c636e963d485d5c6b9d9bf7bafecc075ed0c"})