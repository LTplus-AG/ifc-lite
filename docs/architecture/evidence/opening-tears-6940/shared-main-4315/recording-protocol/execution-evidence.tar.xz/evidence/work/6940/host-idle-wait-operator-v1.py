# Root operator orchestration only: unchanged canonical observer; no browser/timing calls.
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
case=Path(sys.argv[1]).resolve()
def read(p): return json.loads(p.read_text())
def ref(p): return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def clock(): return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicNs':str(time.monotonic_ns()),'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}
def write(p,o): p.open('x').write(json.dumps(o,indent=2)+'\n')
b=read(case/'case-policy-binding.json');p=Path(b['policy']['path']);assert ref(p)==b['policy'];policy=read(p)
for k in ['observer','observerImplementation','ownerReceipt']:
 r=policy[k];assert ref(Path(r['path']))==r
assert ref(case/'intent.json')==b['intent']
d=case/'host-observations';d.mkdir();start=time.monotonic_ns();records=[];deadline=datetime.datetime.fromisoformat(b['caseDeadlineUtc'].replace('Z','+00:00'));reason='maxSerialInvocations exhausted'
for ordinal in range(1,policy['limits']['maxSerialInvocations']+1):
 elapsed=(time.monotonic_ns()-start)/1e6
 if elapsed>=policy['limits']['maxElapsedMonotonicMs']: reason='monotonic budget exhausted';break
 if (deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds()<policy['limits']['deadlineReserveSeconds']: reason='owner deadline reserve exhausted';break
 output=d/f'{ordinal:02}.observation.json';command=['pnpm','exec','tsx',policy['observer']['path'],str(output)];before=clock();r=subprocess.run(command,capture_output=True);after=clock();stdout=d/f'{ordinal:02}.stdout';stderr=d/f'{ordinal:02}.stderr';stdout.open('xb').write(r.stdout);stderr.open('xb').write(r.stderr)
 record={'ordinal':ordinal,'command':command,'observer':policy['observer'],'observerImplementation':policy['observerImplementation'],'start':before,'end':after,'exitStatus':r.returncode,'stdout':ref(stdout),'stderr':ref(stderr),'observation':ref(output) if output.exists() else None};write(d/f'{ordinal:02}.record.json',record);records.append(ref(d/f'{ordinal:02}.record.json'))
 if r.returncode!=0 or not output.exists(): reason='observer error';break
 if (time.monotonic_ns()-start)/1e6>policy['limits']['maxElapsedMonotonicMs']: reason='observer ended beyond monotonic budget';break
 observation=read(output)
 if observation.get('failed'): reason='observer reported error';break
 if observation.get('quiet') is True:
  selected=case/'actual-host.json';selected.open('xb').write(output.read_bytes());write(case/'host-selection.json',{'ok':True,'policy':b['policy'],'caseBinding':ref(case/'case-policy-binding.json'),'records':records,'firstQuietOrdinal':ordinal,'selectedObservation':ref(output),'actualHost':ref(selected),'clock':clock()});print(json.dumps({'ok':True,'firstQuietOrdinal':ordinal, 'host':ref(selected)}));sys.exit(0)
write(case/'host-selection.json',{'ok':False,'reason':reason,'policy':b['policy'],'caseBinding':ref(case/'case-policy-binding.json'),'records':records,'clock':clock()});print(json.dumps({'ok':False,'reason':reason,'observations':len(records)}));sys.exit(2)
