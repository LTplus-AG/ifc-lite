# Offline case assembler — unlaunched preparation

This helper writes genuine-case preparation files and derives later sidecar references from actual saved native history. It never contacts T3, a browser, the evidence server, host observers, recording tools or performance probes. Its only child processes are the already reviewed print-only marker/cadence source generators. No passing history, observation, video or performance row is fabricated. All original 28 frozen files remain untouched.

Root is the sole native T3 operator. Use a NEW directory and unique id/tab/optical nonce for each of the two source-matched Holter feasibility cases and, only after both are validated, each of the finite30 planned timed cases. Native errors, abandoned preparations and failed samples remain preserved; do not regenerate a successful replacement under the same id or drop the planned row.

## Prepare from actual inputs

Before preparing a case, root obtains the actual fresh tab, cold storage, focused visible Home and viewport through the existing protocol. Save the actual `/__6940/state` body (or preserve its original JSON envelope and supply `--state-pointer`), current server startup inventory, exact-head successful build receipt, exact fixture, canonical served collector source and existing actual video inspection identifying the intended native-default recording mode. The helper performs no such observations itself. The prior video inspection selects a mode, not functional feasibility. The new artifact must independently match that mode.

Run from the repository root, substituting actual paths and values. `--epoch` is JSON: a UUID epoch is passed as `'"ACTUAL-UUID"'`, preserving its string type. None of the placeholders below are observation data.

```sh
node work/6940/native-recording-case-assembler-v5/case.mjs prepare \
  --out /ABS/NEW_CASE --sample-id UNIQUE_REAL_CASE_ID --tabId ACTUAL_TAB \
  --side base --head IMMUTABLE_40_SHA --epoch '"ACTUAL-UUID"' \
  --status-kind functional --fixture-name holter --fixture /ABS/ACTUAL_HOLTER.ifc \
  --state /ABS/ACTUAL_STATE.json --server-receipt /ABS/ACTUAL_SERVER_INVENTORY.json \
  --build-receipt /ABS/ACTUAL_BUILD_RESULT.json --collector /ABS/ACTUAL_SERVED_COLLECTOR.mjs \
  --recording-inspection /ABS/PRIOR_ACTUAL_MEDIA_INSPECTION.json \
  --functional-expression /ABS/ACTUAL_IDENTITY_MATCHED_FUNCTIONAL_EXPRESSION.js
```

For timed cases use `--status-kind timed --pair 1` through5 and the actual frozen plan's fixture/name/id/arm; omit `--functional-expression`. The original timed prepare/fixture fetch-and-hash happens before native history initialization. This helper does not create or launch that original prepare request, modify the original timed collector, admit a new source, create a timed plan or relax any gate. Root must match each prepared timed case to its already frozen plan row and source/fixture identity. Use `--state-pointer /reply/structuredContent/value` only when that is the genuine saved observation's exact pointer; no implicit envelope guesses are made.

Preparation verifies the revised helper freeze; empty tracked source diff; exact side/head/epoch/tree; successful unchanged-source build; the complete build-vs-server dist inventory and its self-hash; actual package WASM; canonical `/__6940/cohort.mjs` hash; fixture SHA/bytes; no pending upload; and the genuine prior inspected recording mode. It retains hashes of every original input plus itself. A mismatch stops preparation. A partly written directory is preserved as failed preparation, never reused. The original identity-matched functional expression is source-pinned and transformed through the reviewed two-phase builder; actual runtime source/id/fixture checks still apply.

Outputs include `intent.json`, every ordinary expression/request, random cryptographic128-bit optical nonce, `case-manifest.json` and `operator-commands.json`. Intent has both exact native-history fields and existing strict-sidecar aliases. Every expression file is trim-safe and equals its request's expression bytes. Functional preparation preserves the original complete loader body while pausing before File dispatch.

## Actual operator sequence (commands are not automatically executed)

`operator-commands.json` prints shell commands only. Run its journal initialization command after cold/fresh/focus preparation; execute each generated native wrapper exactly once through root's actual tool channel. The emitter command only prints a `functions.exec` body: save its complete output and invoke that unchanged body. Do not execute the native tool directly beside the wrapper, edit embedded args, or silently trim expression args.

1. Actual recording-start through wrapper. After its successful completion, wait the fixed4s before PRE-show.
2. Actual PRE-show, PRE-remove and PRE-cadence, each through its wrapper.
3. Functional ONLY: actual `functional-prepare` wrapper awaits the genuine fetched/hashed preparation receipt. Its page loader is now paused. Timed preparation already finished before history initialization.
4. Root executes the unchanged canonical host observer outside the browser and writes its actual result at the predeclared `actual-host.json` path. It must be a new quiet observation after functional preparation (or timed PRE-cadence), never a copied older admission.
5. Run the printed release generator command. It reads that actual host file and creates only the declared new `load-release.js` and `.request.json`. Unknown future host bytes were not prehashed or invented in the intent. Run the release emitter and execute its exact printed wrapper. Existing timed collector or genuine functional latch checks actual admission; functional dispatch checks it again after release, immediately before assigning the normal File input.
6. Await actual durable server receipt by inspecting the owned receipt file outside the browser. No extra native polling call inside this lifecycle. Preserve failure receipts rather than proceed as success.
7. Actual POST-cadence, POST-show, POST-remove, then recording-stop through wrappers. Keep the native recording active throughout load, settling and durable persistence.
8. Seal the complete actual native history using the printed command. Exactly nine timed or ten functional native calls are accepted. Extra/cancelled/retried/error/pending operations remain in history and prevent qualification. A real functional cancellation is a failure-only escape, not an accepted alternate history.

The pre-start intent pins every ordinary request path/hash, and declares the dynamic release's future host/expression/request paths plus exact generator. The recorder compares the actually embedded request with saved bytes before tool invocation. The offline validator later reconstructs the dynamic request from the frozen generator and actual host bytes. This avoids both a self-hash cycle and borrowing stale host admission.

## Assemble only authentic post-save evidence

After actual stop/seal, the following offline modes derive exact RFC6901 references from the real saved history. They do not create tool reply values or claim that a case passed.

```sh
node work/6940/native-recording-case-assembler-v5/case.mjs artifacts --case /ABS/CASE
```

This writes actual video/PRE/POST refs and prints the existing complete-video inspector command. Root may then run that offline inspector against the original transferred stop path. No renamed/substitute artifact is accepted. Complete media inspection/optical decoding happens after native recording, outside all measurement windows; preserve raw outputs and failures.

```sh
node work/6940/native-recording-case-assembler-v5/case.mjs anchor-manifest \
  --case /ABS/CASE --inspection /ABS/CASE/media-inspection/media-inspection.json
```

This writes exact video/inspection/original PRE+POST-show refs and prints the already reviewed full-frame detector command. Run that command only against actual artifacts; it preserves raw decode/PTS/stderr receipts. Then assemble from actual result paths:

```sh
node work/6940/native-recording-case-assembler-v5/case.mjs assemble \
  --case /ABS/CASE --receipt /ABS/ACTUAL_DURABLE_LOAD.result.json \
  --inspection /ABS/CASE/media-inspection/media-inspection.json \
  --detection /ABS/CASE/anchor-detection/result.json --ordinal-base 0
```

Check the real inspector/detector output filenames printed by those tools; pass their actual paths. The assembler never assumes successful content from names. Use the preceding case's returned `lastOrdinal` as the next case's `--ordinal-base`, so all32 logical histories retain global order. These ordinals are ordering labels over real native replies, not invented observation clocks. Actual clocks remain in the raw native journal. A single post-cadence reply's authentic `/collector` field supplies both settling-complete and durable witnesses; no extra page polling or synthetic status is added. Raw native reply envelopes and pointers are retained.

Assembly creates a NEW logical journal, prevalidation sidecar and validation input, and prints the exact frozen validator command. The logical journal's `complete` means its references cover the actual sealed sequence; it is not a validation/performance verdict. The validator remains authoritative for errors, source/fixture/host freshness, lifecycle, mode, media, optical tokens and all unchanged gates. Run it and preserve nonzero exit/failed result without replacement.

```sh
node work/6940/native-recording-case-assembler-v5/case.mjs finalize \
  --case /ABS/CASE --validation /ABS/CASE/validation-result.json
```

Only a successful actual frozen validator with matching case/input closure can produce the new final `ID.recording.json` containing its lifecycleCoverage ref. The immutable prevalidation sidecar is not rewritten. Functional mode prints the reviewed `export-feasibility.py` command; root runs it against the actual successful result. Both source-matched exported Holter summaries, exact configured mode and same-boot validation-before-cohort order are required before timed initialization. Final timed sidecars join the unchanged original strict report and supplemental source-frozen checker; this assembler never creates a performance verdict.

## Limits

No assembler-generated files have been exercised against an actual recording case yet. Syntax/source review only is insufficient to qualify runtime feasibility. The root-owned wrapper journal excludes unknown out-of-band user/platform/recorder activity; optical endpoints do not prove uninterrupted recorder internals or continuous30Hz during loading. Existing cross-arm geometry identity failure and semantic-review policy remain separate from recording admission and performance. No thresholds, timing collector, source heads, numerical expectations or failed observations are changed here.

## Root-found canonical schema correction

The previous unexecuted helper set incorrectly demanded diagnostic schema4 and geometryResultFieldDetails. Actual original canonical470f, agreed for BOTH functional feasibility and timed cases, produces schema3 with geometryResultFields, flatMeshMerkleRows and normalizedInstanceMerkleRows. Root identified this before any actual case. The previous source/freeze/review remains preserved as superseded for this mismatch, never relabelled as runtime proof. Raw V4 diagnostic collectors are not fallback workload options.

This version source-pins canonicalCollector SHA470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17 and the new canonicalPayloadValidator. The offline JS checker requires exactly one uncached WASM model, the known complete geometry schema/own fields, unique sorted own-field names and exact hash shapes, all flat row counts/multiplicity/sorting, mesh own-field root, normalized instance/entity counts/sorting, raw-addressing coverage and full geometry root. Every additional own geometryResult field remains retained and hash-covered; no expected-ID filter or instance omission is introduced. The producer's source-pinned full traversal/failure contract remains essential: compact Merkle leaves cannot independently recover raw typed bytes. No new physical-geometry or performance approval follows from structural consistency.

Intent.sources and recordingPolicy must add canonicalPayloadValidator (exact path/SHA) while retaining all existing source bindings. Intent.sources also freezes actual canonicalCollector bytes. Both actual source-matched full-Holter sessions, mode/cadence/host/focus/GPU/readiness/output checks and original timed collector/thresholds remain unchanged and pending.

Current reviewed-helper input is `native-recording-final-helper-freeze-v7.json`, SHA `198195286b66f6f3427569622170c5006f8c765e28c5923677ee866a8b6ccbfc`. Both functional and timed `--collector` MUST be actual canonical470f; source preparation rejects the raw schema4 diagnostic variant before any expensive Holter case.

## Actual optional fields and scalable request transport

Astra replayed authentic zero-instance ISSUE129 receipts and found the earlier unconditional instancing-metadata requirement invalid. GeometryResult in packages/geometry/src/types.ts explicitly makes instancedGeometryHashes/Aabbs/Volumes optional (including when hashing is off). The unconditional known set is coordinateInfo, meshes, totalTriangles and totalVertices. Every additional actual own field, including optional instancing metadata when present, remains uniquely named, sorted, fully captured and root-covered. All flat/instance counts and actual source-pinned collector checks remain. There is no zero-instance or raw-schema fallback.

Root also measured the complete actual host audit above Linux's approximately128KiB single-argument limit. The old request embedding would fail before native invocation. The new emitter prints only source/request refs plus a bounded wrapper. It reads the complete declared request through4096-codepoint chunks (at most4 independent reads in flight), reconstructs and freezes the exact actual request object, durably stages the SAME raw text in ordered4096-codepoint chunks, then asks journal BEGIN to verify the full raw SHA, exact original bytes, all chunk refs, source hash and type-sensitive object equality BEFORE calling the native tool. Actual request capacity is8MiB/2048chunks; cumulative staged bytes are bounded as each chunk is written. Missing, reordered, duplicated, oversized or mismatched chunks fail, and orphan/incomplete transports prevent sealing. No host/GPU field is dropped.

The request's durable transport ref is retained in its actual journal request and independently rehashed/reconstructed by validation. Printed wrappers and final wrapper output contain small refs/summary only; complete original native replies remain in their existing bounded durable raw reply protocol. Full host freshness is still checked at actual collector release/functional dispatch, AFTER this transport work; transport duration is never subtracted or waived. An authentic-host offline transport-only replay is not a browser invocation or passing recording history.

The actual dispatch serialization is retained separately from the exact reconstructed original source bytes. Journal and offline validator compare the parsed actual JS serialization with the saved source using bool-sensitive equality; lossy large-integer conversion is rejected before native invocation. The same frozen JS object that supplied that serialization is passed to the actual tool. Native wrapper output contains refs only; its complete actual reply is durable. Offline proof at native-recording-request-transport-offline-v2 preserves authentic175809B source, zero native calls, and rejected precision/type/order/missing/duplicate mutations. It is deliberately not a passing recording history.

## Minimal offline-import correction

History-v5 fixes only Node-e argument layout for importing the existing generators; other implementation files are byte-identical copies and policy-v5 remains unchanged. Freeze-v6 binds it. Prior prepared holter-v5-branch-case1 is immutable/unlaunched with its failed prelaunch receipt preserved. Prepare a NEW case directory/id with current actual tab/source/state/epoch; do not initialize or alter the old case. Actual refused-host offline reconstruction controls are not a quiet admission or recording qualification.

## Actual T3 transport limits

Assembler5 selects history6 and functional-latch-v2/release.mjs for BOTH the intent source and printed release CLI command. Prepare latch remains originalv1, policy remainsv5. Fullhostgzip input and fullfunctionalvaluegzip reply avoid actual64ktransport rejection while preserving allhost/GPU fields. No additional native call, route, collector change or threshold. Preserve failed V6case2 and create a NEW case after approval; response-codec failure may occur afterdispatch and must be treated as a real failed case.
