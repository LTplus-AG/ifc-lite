// Offline evidence preparation/assembly only. Never invokes native/browser/host/recording tools.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {prepare as prepareFunctional} from '../native-recording-functional-latch-v1/prepare-expression.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),parent=path.dirname(here);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const must=(b,m)=>{if(!b)throw Error(m);};
const raw=p=>fs.readFileSync(p),read=p=>JSON.parse(raw(p));
const ref=(p,pointer)=>({...{path:path.resolve(p),sha256:sha(raw(p))},...(pointer?{pointer}:{})});
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const text=(p,v)=>fs.writeFileSync(p,v,{flag:'wx'});
const quote=s=>"'"+String(s).replaceAll("'","'\\''")+"'";
const command=(...a)=>a.map(quote).join(' ');
function pointer(d,p=''){for(const k of p.split('/').slice(1))d=d[k.replaceAll('~1','/').replaceAll('~0','~')];return d;}
function load(r){must(path.isAbsolute(r.path)&&sha(raw(r.path))===r.sha256,'Changed input '+r.path);return pointer(read(r.path),r.pointer);}
function args(){const [mode,...a]=process.argv.slice(2),o={};for(let i=0;i<a.length;i+=2){must(a[i]?.startsWith('--')&&a[i+1]!==undefined,'Expected --key VALUE');must(!(a[i].slice(2)in o),'Duplicate option');o[a[i].slice(2)]=a[i+1];}return{mode,o};}
function required(o,keys){for(const k of keys)must(typeof o[k]==='string'&&o[k].length,'Missing --'+k);}
function generate(file,a){const r=spawnSync('node',[file,...a],{encoding:'utf8'});must(r.status===0,r.stderr);must(r.stdout===r.stdout.trim(),'Generated native expression has surrounding whitespace');return r.stdout;}
function frozen(){const p=path.join(parent,'native-recording-final-helper-freeze-v7.json'),f=read(p);must(sha(raw(p))==='198195286b66f6f3427569622170c5006f8c765e28c5923677ee866a8b6ccbfc','Reviewed helper freeze differs');for(const[p,h]of Object.entries(f.files))must(sha(raw(p))===h,'Frozen helper changed '+p);return ref(p);}
function ownSources(){return{assembler:ref(fileURLToPath(import.meta.url)),helperFreeze:frozen()};}
function verifyCase(dir){const m=read(path.join(dir,'case-manifest.json'));for(const r of Object.values(m.inputs))loadBytes(r);for(const r of Object.values(m.generated))loadBytes(r);frozen();return m;}
function loadBytes(r){must(path.isAbsolute(r.path)&&sha(raw(r.path))===r.sha256,'Changed bytes '+r.path);return raw(r.path);}
function prepare(o){
 required(o,['out','sample-id','tabId','side','head','epoch','state','server-receipt','build-receipt','fixture-name','fixture','collector','recording-inspection','status-kind']);
 must(['base','branch'].includes(o.side)&&/^[a-f0-9]{40}$/.test(o.head),'Explicit immutable source required');
 must(['functional','timed'].includes(o['status-kind'])&&['fzk','issue129','holter'].includes(o['fixture-name']),'Explicit case mode/fixture required');
 must(/^[A-Za-z0-9_.-]+$/.test(o['sample-id'])&&o.tabId.length,'Unique safe sample id and actual tab required');
 const mode=o['status-kind'];if(mode==='functional')must(o['fixture-name']==='holter'&&o['functional-expression'],'Genuine Holter functional expression required');
 if(mode==='timed')must(/^[1-5]$/.test(o.pair??''),'Actual frozen plan pair1..5 required');
 const epoch=JSON.parse(o.epoch),state=pointer(read(o.state),o['state-pointer']),build=read(o['build-receipt']),inspection=read(o['recording-inspection']);
 must(state.side===o.side&&state.epoch===epoch&&state.manifest?.side===o.side&&state.manifest.head===o.head,'Actual state/source/epoch differs');
 must(state.manifest.trackedDiffSha256===sha(Buffer.alloc(0))&&state.pending?.length===0,'Served source dirty or pending upload');
 const server=read(o['server-receipt']);must(JSON.stringify(server.manifests?.[o.side])===JSON.stringify(state.manifest),'Actual server inventory/source differs from observed state');
 must(sha(raw(o.collector))==='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17','Both functional and timed require original canonical470f collector');
 const servedCollector=server.helpers?.find(h=>h.url==='/__6940/cohort.mjs');must(servedCollector?.sha256===sha(raw(o.collector)),'Canonical served collector differs');
 must(build.head===o.head&&build.exitCode===0&&build.trackedSourceUnchanged===true&&build.rustSourceUnchanged===true&&build.wasmNewerThanRustSources===true&&build.singleServedIfcGeometryWasmExactlyMatchesPackage===true,'Actual successful exact-head build receipt required');
 must(build.tree===state.manifest.tree,'Build/source tree differs');
 const distArtifacts=build.artifacts.filter(a=>a.path.startsWith('apps/viewer/dist/')).map(a=>({path:a.path.slice('apps/viewer/dist/'.length),bytes:a.bytes,sha256:a.sha256})).sort((a,b)=>a.path.localeCompare(b.path));
 const stateFiles=[...state.manifest.files].sort((a,b)=>a.path.localeCompare(b.path));
 must(JSON.stringify(distArtifacts)===JSON.stringify(stateFiles),'Build and actual served complete dist inventories differ');
 must(sha(Buffer.from(JSON.stringify(state.manifest.files)))===state.manifest.distManifestSha256,'Actual dist inventory self hash differs');
 const wasm=build.artifacts.find(a=>a.path==='packages/wasm/pkg/ifc-lite_bg.wasm');
 must(wasm?.sha256===state.manifest.packageWasm.sha256&&wasm.bytes===state.manifest.packageWasm.bytes&&sha(raw(state.manifest.packageWasm.path))===wasm.sha256,'Build/served runtime WASM differs');
 must(inspection.complete===true&&inspection.configuredMode?.nativeTool==='preview_recording_start'&&inspection.configuredMode.captureMode==='native-default','Actual prior media mode observation required');
 const inputPaths={state:o.state,serverReceipt:o['server-receipt'],buildReceipt:o['build-receipt'],fixture:o.fixture,collector:o.collector,recordingInspection:o['recording-inspection'],...ownSources()};
 if(mode==='functional')inputPaths.functionalBaseExpression=o['functional-expression'];
 const inputs=Object.fromEntries(Object.entries(inputPaths).map(([k,p])=>[k,typeof p==='string'?ref(p):p]));
 const dir=path.resolve(o.out);must(!fs.existsSync(dir),'NEW case directory required');fs.mkdirSync(dir);
 const hp=n=>path.join(parent,'native-recording-history-v6',n),lp=n=>path.join(parent,'native-recording-functional-latch-v1',n),mp=path.join(parent,'native-recording-media-anchor-v3/marker-expression.mjs'),cp=path.join(parent,'native-recording-matched-policy-v5/probe-expression.mjs');
 const sources=Object.fromEntries(Object.entries({nativeHistoryValidator:hp('validate.py'),nativeHistoryRecorder:hp('journal.py'),nativeHistoryEmitter:hp('emit-invocation.mjs'),nativeHistoryDynamicHelper:hp('dynamic.py'),canonicalPayloadValidator:hp('canonical-payload.mjs'),canonicalCollector:o.collector,releaseGenerator:path.join(parent,'native-recording-functional-latch-v2/release.mjs'),markerGenerator:mp,cadenceGenerator:cp,anchorDetector:path.join(parent,'native-recording-media-anchor-v3/detect.py'),mediaInspector:path.join(parent,'native-recording-matched-policy-v1/inspect-video.py')}).map(([k,p])=>[k,ref(p)]));
 if(mode==='functional'){sources.functionalPrepareGenerator=ref(lp('prepare-expression.mjs'));sources.functionalBaseExpression=ref(o['functional-expression']);}
 const fixture=raw(o.fixture);must(state.fixtures?.[o['fixture-name']]?.sha256===sha(fixture)&&state.fixtures[o['fixture-name']].bytes===fixture.length,'Actual served fixture identity differs');
 const nonce=crypto.randomBytes(16).toString('hex'),intentPath=path.join(dir,'intent.json');
 const intent={schema:1,protocol:'ifc6940-native-recording-matched-v1',exclusiveRootOwnedBrowserControl:true,statusKind:mode,sampleId:o['sample-id'],id:o['sample-id'],tabId:o.tabId,head:o.head,expectedSource:o.head,side:o.side,epoch,fixture:o['fixture-name'],fixtureSHA256:sha(fixture),fixtureSha256:sha(fixture),fixtureBytes:fixture.length,pair:mode==='timed'?Number(o.pair):null,distManifestSHA256:state.manifest.distManifestSha256,collectorSHA256:inputs.collector.sha256,recordingMode:inspection.configuredMode,markerGeneratorSHA256:sources.markerGenerator.sha256,anchorDetectorSHA256:sources.anchorDetector.sha256,sources,caseInputs:inputs,dynamicRelease:{intentPath,generator:sources.releaseGenerator,hostObservationPath:path.join(dir,'actual-host.json'),expressionPath:path.join(dir,'load-release.js'),requestPath:path.join(dir,'load-release.request.json')},expectedCalls:[]};
 const generated={},requests=[];
 function request(purpose,tool,expression){const file=path.join(dir,purpose+'.request.json'),r={purpose,tool,args:{tabId:o.tabId}};if(expression!==undefined){const p=path.join(dir,purpose+'.js');must(expression===expression.trim(),'Whitespace in expression');text(p,expression);r.expressionSource=ref(p);Object.assign(r.args,{expression,awaitPromise:true,returnByValue:true});generated[purpose+'Expression']=ref(p);}write(file,r);requests.push({purpose,request:ref(file)});generated[purpose+'Request']=ref(file);}
 request('recording-start','mcp__t3_code__preview_recording_start');
 for(const phase of ['pre','post']){
  if(phase==='post'){
   if(mode==='functional'){const identity={id:intent.sampleId,head:intent.head,side:intent.side,epoch,fixtureSHA256:intent.fixtureSHA256,fixtureBytes:intent.fixtureBytes,prepareGeneratorSHA256:sources.functionalPrepareGenerator.sha256,baseExpressionSHA256:sources.functionalBaseExpression.sha256};request('functional-prepare','mcp__t3_code__preview_evaluate',prepareFunctional(raw(o['functional-expression']).toString('utf8'),identity));}
   requests.push({purpose:'load-release',dynamicRelease:true});
  }
  if(phase==='pre'){
   for(const action of ['show','remove'])request(phase+'-marker-'+action,'mcp__t3_code__preview_evaluate',generate(mp,[action,phase,mode,intent.sampleId,intent.tabId,intent.head,intent.side,JSON.stringify(epoch),nonce]));
   request('pre-cadence','mcp__t3_code__preview_evaluate',generate(cp,['pre',mode,intent.sampleId,intent.tabId,intent.head,intent.side,JSON.stringify(epoch)]));
  }else{
   request('post-cadence','mcp__t3_code__preview_evaluate',generate(cp,['post',mode,intent.sampleId,intent.tabId,intent.head,intent.side,JSON.stringify(epoch)]));
   for(const action of ['show','remove'])request(phase+'-marker-'+action,'mcp__t3_code__preview_evaluate',generate(mp,[action,phase,mode,intent.sampleId,intent.tabId,intent.head,intent.side,JSON.stringify(epoch),nonce]));
  }
 }
 request('recording-stop','mcp__t3_code__preview_recording_stop');intent.expectedCalls=requests;write(intentPath,intent);generated.intent=ref(intentPath);
 const commands=[{step:'initialize only after cold/fresh/focus preparation',command:command('python3',hp('journal.py'),'init',path.join(dir,'native-history'),intentPath)}];
 for(const r of requests){if(r.dynamicRelease)commands.push({step:'AFTER actual host file exists, generate exact actual dynamic request',command:command('node',sources.releaseGenerator.path,intentPath,intent.dynamicRelease.hostObservationPath,intent.dynamicRelease.expressionPath,intent.dynamicRelease.requestPath)});
  commands.push({step:'PRINT ONLY wrapper; root executes printed body exactly ONCE: '+r.purpose,command:command('node',hp('emit-invocation.mjs'),path.join(dir,'native-history'),r.request?.path??intent.dynamicRelease.requestPath)});
 }
 commands.push({step:'seal after actual stop and complete paired replies',command:command('python3',hp('journal.py'),'seal',path.join(dir,'native-history'))});write(path.join(dir,'operator-commands.json'),commands);generated.commands=ref(path.join(dir,'operator-commands.json'));
 for(const r of Object.values(inputs))loadBytes(r);frozen();
 write(path.join(dir,'case-manifest.json'),{schema:1,preparationOnly:true,noNativeToolsInvoked:true,noObservationsCreated:true,inputs,generated,opticalNonce:nonce,sources,ordinalBaseNotSelected:true});
 console.log(JSON.stringify({directory:dir,intent:ref(intentPath),calls:requests.length,preparationOnly:true}));
}
function historyCalls(file){const h=read(file),events=h.events;must(h.completeWrapperInvocationPairs===true&&events.length%2===0,'Actual sealed paired history required');const intent=load(h.intent),expected=intent.expectedCalls.map(c=>c.purpose),actual=events.filter((_,i)=>i%2===0).map(e=>load(e.file).invocation.purpose);must(JSON.stringify(expected)===JSON.stringify(actual),'Extra/missing/retried native call; preserve failure and HOLD');const calls={};for(let i=0;i<events.length;i+=2){const r=load(events[i].file),c=load(events[i+1].file);must(events[i].kind==='request'&&events[i+1].kind==='completion'&&c.request.sha256===events[i].file.sha256,'Actual request/completion mismatch');const p=r.invocation.purpose;must(!calls[p],'Duplicate actual native call');const rr={...c.rawReply,pointer:r.invocation.tool.endsWith('preview_evaluate')?'/reply/structuredContent/value':'/reply/structuredContent'};const wrapper=load(c.rawReply);must(wrapper.outcome==='reply'&&wrapper.reply.isError!==true,'Actual failed tool retained; case cannot assemble as success');calls[p]={ref:rr,value:load(rr),request:r};}return{h,calls};}
function artifacts(o){required(o,['case']);const dir=path.resolve(o.case);verifyCase(dir);const{calls}=historyCalls(path.join(dir,'native-history/history.json'));const video=calls['recording-stop'].value;must(video.tabId===read(path.join(dir,'intent.json')).tabId&&fs.statSync(video.path).size===video.sizeBytes,'Actual transferred stop artifact differs');const out=path.join(dir,'artifact-inputs.json');write(out,{nativeHistory:ref(path.join(dir,'native-history/history.json')),video:ref(video.path),pre:calls['pre-marker-show'].ref,post:calls['post-marker-show'].ref});console.log(JSON.stringify({artifactInputs:ref(out),actualVideoPath:video.path,inspectionCommand:command('python3',path.join(parent,'native-recording-matched-policy-v1/inspect-video.py'),video.path,path.join(dir,'media-inspection'))}));}
function anchorManifest(o){required(o,['case','inspection']);const dir=path.resolve(o.case);verifyCase(dir);const a=read(path.join(dir,'artifact-inputs.json'));loadBytes(a.video);write(path.join(dir,'anchor-inputs.json'),{video:a.video,inspection:ref(o.inspection),pre:a.pre,post:a.post});console.log(JSON.stringify({command:command('python3',path.join(parent,'native-recording-media-anchor-v3/detect.py'),path.join(dir,'anchor-inputs.json'),path.join(dir,'anchor-detection'))}));}
function assemble(o){
 required(o,['case','receipt','inspection','detection','ordinal-base']);must(/^\d+$/.test(o['ordinal-base']),'Explicit global ordinal base required');const dir=path.resolve(o.case);verifyCase(dir);const intentPath=path.join(dir,'intent.json'),intent=read(intentPath),historyFile=path.join(dir,'native-history/history.json'),{h,calls}=historyCalls(historyFile);must(JSON.stringify(load(h.intent))===JSON.stringify(intent),'Sealed actual intent differs');
 const receipt=read(o.receipt);must(receipt.id===intent.sampleId,'Actual durable load receipt id differs');const host=ref(intent.dynamicRelease.hostObservationPath);must(JSON.stringify(load(host))===JSON.stringify(receipt.externalAdmission),'Actual durable receipt host differs');const stop=calls['recording-stop'].value,video=ref(stop.path),inspection=ref(o.inspection),detection=ref(o.detection),anchor=ref(path.join(dir,'anchor-inputs.json'));const manifest=load(anchor);must(JSON.stringify(manifest.video)===JSON.stringify(video)&&JSON.stringify(manifest.inspection)===JSON.stringify(inspection),'Actual inspected video inputs differ');
 const refs={start:calls['recording-start'].ref,stop:calls['recording-stop'].ref,preCadence:calls['pre-cadence'].ref,postCadence:calls['post-cadence'].ref};
 const markers=Object.fromEntries([['preShow','pre-marker-show'],['preRemove','pre-marker-remove'],['postShow','post-marker-show'],['postRemove','post-marker-remove']].map(([k,p])=>[k,calls[p].ref]));
 const durable={...refs.postCadence,pointer:refs.postCadence.pointer+'/collector'};load(durable);let ordinal=Number(o['ordinal-base']);must(Number.isSafeInteger(ordinal)&&ordinal>=0,'Ordinal base not safe');const events=[];
 function event(kind,r,extra={}){events.push({kind,ordinal:++ordinal,tabId:intent.tabId,receipt:r,receiptSha256:r.sha256,...extra});}
 event('intent',ref(intentPath));for(const p of ['recording-start','pre-marker-show','pre-marker-remove','pre-cadence'])event(p,calls[p].ref);if(intent.statusKind==='functional')event('functional-prepare',calls['functional-prepare'].ref);event('host-observation',host);event('upload-release',calls['load-release'].ref,{sampleId:intent.sampleId});event('settling-complete',durable);event('collector-durable',durable);for(const p of ['post-cadence','post-marker-show','post-marker-remove','recording-stop'])event(p,calls[p].ref);event('artifact-validated',inspection);event('anchors-validated',detection);
 const journalPath=path.join(dir,'logical-journal.json');write(journalPath,{schema:1,complete:true,scope:'Derived references to complete actual root-owned history; no native calls added or omitted. Logical ordinals are ordering labels, not observed clocks.',nativeHistory:ref(historyFile),recordingToolCalls:[{tool:'preview_recording_start',tabId:intent.tabId,result:refs.start},{tool:'preview_recording_stop',tabId:intent.tabId,result:refs.stop}],events});
 const sidecar={schema:1,protocol:intent.protocol,id:intent.sampleId,side:intent.side,fixture:intent.fixture,pair:intent.pair,tabId:intent.tabId,intent:ref(intentPath),...refs,markers,hostObservation:host,journal:ref(journalPath),video,videoInspection:inspection,anchorInputManifest:anchor,anchorDetection:detection,...(intent.statusKind==='timed'?{timedReceipt:ref(o.receipt)}:{})};
 const sidecarPath=path.join(dir,'prevalidation.recording.json');write(sidecarPath,sidecar);const validationInput=path.join(dir,'validation-input.json');write(validationInput,{nativeHistory:ref(historyFile),sidecar:ref(sidecarPath),...(intent.statusKind==='functional'?{functionalReceipt:ref(o.receipt)}:{})});
 console.log(JSON.stringify({prevalidationSidecar:ref(sidecarPath),lastOrdinal:ordinal,validationCommand:command('python3',path.join(parent,'native-recording-history-v6/validate.py'),validationInput,path.join(dir,'validation-result.json')),qualification:'NOT VALIDATED: run actual frozen validator; failures remain failures'}));
}
function finalize(o){required(o,['case','validation']);const dir=path.resolve(o.case);verifyCase(dir);const v=read(o.validation),pre=read(path.join(dir,'prevalidation.recording.json'));must(v.ok===true&&v.lifecycleCoverageVerified===true&&v.validatorSHA256===sha(raw(path.join(parent,'native-recording-history-v6/validate.py'))),'Successful actual frozen validator required');must(v.actualInputs?.[path.join(dir,'prevalidation.recording.json')]===ref(path.join(dir,'prevalidation.recording.json')).sha256&&v.inputPath===path.join(dir,'validation-input.json'),'Validation belongs to different case/sidecar');for(const[p,h]of Object.entries(v.actualInputs))must(sha(raw(p))===h,'Actual validated input drifted');write(path.join(dir,pre.id+'.recording.json'),{...pre,lifecycleCoverage:ref(o.validation)});console.log(JSON.stringify({finalSidecar:ref(path.join(dir,pre.id+'.recording.json')),performanceQualified:false,...(v.statusKind==='functional'?{exportCommand:command('python3',path.join(parent,'native-recording-history-v6/export-feasibility.py'),o.validation,path.join(dir,'functional-feasibility.json'))}:{})}));}
const{mode,o}=args();if(mode==='prepare')prepare(o);else if(mode==='artifacts')artifacts(o);else if(mode==='anchor-manifest')anchorManifest(o);else if(mode==='assemble')assemble(o);else if(mode==='finalize')finalize(o);else throw Error('Use prepare|artifacts|anchor-manifest|assemble|finalize with explicit --key VALUE options');
