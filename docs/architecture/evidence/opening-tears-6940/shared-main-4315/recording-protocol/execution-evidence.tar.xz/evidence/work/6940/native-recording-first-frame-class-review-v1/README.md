# Full first-frame clock review

Actual source-pinned browser frame timestamps can precede callback registration. This separate reviewer extends the prior first-cadence correction to first marker callbacks only: finite/nonnegative and finish bounds remain; later callbacks retain registration bounds and all marker strict ordering, cadence59 intervals, lifecycle and optical evidence checks remain unchanged. No30Hz marker interval or arbitrary lookback is invented. There is no independent ancient-first-marker rejection: authentic callback provenance, later samples, optical matching and lifecycle evidence remain essential.

Both actual basecase1 and branchcase5 complete ten-call recordings pass this new post-run reviewer. All old captures, intents and failed reviews remain unchanged. The exact original recorded validator bb215... is explicitly audited while the new actual reviewer hash is reported. No capture rerun or timing qualification follows from these functional checks.

From repository root:

```sh
node work/6940/native-recording-first-frame-class-review-v1/finalize.mjs ABS_CASE ABS_NEW_SUCCESS_REVIEW
```

The common selector accepts functional10 or timed9, preserves every original source/input fence, writes an exclusive NEW frame-class sidecar, and prints functional export only in functional mode. Future timed plans must pin actual reviewer e8a9da...; complete cohort and unchanged performance gates remain mandatory.
