# Explicit post-run first-frame review — old capture immutable

Actual baseV7 recording completed its ten native calls, media/optical decode and source/output gates. The original offline validator failed only because the first POST rAF frame timestamp104343.89 preceded callback registration startNow104351.45 by7.56ms. Frame timestamps denote the rendering frame, not callback-registration time. All59 intervals, focus/visibility, duration and remaining checks pass. Original failed result/raw envelopes/intent remain untouched.

NEW SAMEfolder `native-recording-history-v6/validate-first-frame.py` changes only the first cadence sample lower bound: all timestamps remain finite/nonnegative/<=finish; samples1..59 retain >=startNow; all59 original ±3% intervals and the3s deadline remain. The first timestamp cannot be arbitrarily ancient because the unchanged first interval and second-sample start bound constrain it. Marker checks are unchanged; actual base marker first timestamps already satisfy their old bounds.

The new reviewer records its OWN actual source SHA6397136450b2bb763a87aa4d6c50c7841d545633f98946cf50a64c0da95e1018. It accepts normal exact self binding OR EXACTLY ONE explicitly recorded old binding: the absolute `native-recording-history-v6/validate.py` path under this workspace, SHA bb215bb1a54f8dce26caefab33fa3e44de10cda179cf2f1470443e87f8422af6. Every other source/input pin is unchanged. It emits validatorBindingAudit with both refs. No __file__ spoof, rewritten intent, oldhash on new code or compatibility with other old versions.

Actual base revalidation produced `holter-v7-base-case1/validation-first-frame-review-v1.json` PASS with10 actual native calls; it is a NEW post-run decision, never an overwrite of original failure. Seven explicit counterfactual cadence negatives are rejected. No native/browser call or geometry rerun was needed. Full decoded functional release remains preserved and all original host/media/optical checks apply.

After independent source approval, root can review the branch's identical-source capture with:

python3 work/6940/native-recording-history-v6/validate-first-frame.py ABS_BRANCH_CASE/validation-input.json ABS_BRANCH_CASE/NEW_validation-first-frame-review.json

The new finalize.mjs selects only this exact auditor+oldbinding, rehashes the old V7freeze and all original case/generated/actual reviewed inputs, and writes a NEW suffixed sidecar. It never runs native tools or the validator. Invoke from repository root:

node work/6940/native-recording-first-frame-review-v1/finalize.mjs ABS_CASE ABS_SUCCESSFUL_NEW_REVIEW

Its printed existing `native-recording-history-v6/export-feasibility.py` command exports the actual new review. That generic exporter needs no change. Do not use old assembler5 finalize (it correctly expects the old validator SHA). Do not rewrite old case source declarations or original sidecar; the new sidecar points to the actual post-run review.

Future finite30 policy/source map must pin the ACTUAL NEW reviewer ref, not the old validator hash. Captures may retain their exact original V7 declared binding: every post-run review explicitly audits that compatibility. Source-matched base+branch feasibility and same-host monotonic completion order remain required before timed initialization. Existing policy5 can consume the actual new-source result with the correctly pinned reviewer; no policy, mode, cadence interval, source workload or performance gate is changed.

This source/offline decision does not qualify performance. Original failures remain failures; the new, explicitly corrected review is separately named. Root solely operates native tools and source/plan selection.
