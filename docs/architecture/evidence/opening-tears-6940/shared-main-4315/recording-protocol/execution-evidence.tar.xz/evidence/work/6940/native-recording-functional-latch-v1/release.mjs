// Source-pinned dynamic request builder. Importing/generating never executes browser code.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
async function release(a, admission) {
  const state=await fetch('/__6940/state',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Source fetch failed');return r.json();});
  if(state.side!==a.side||state.epoch!==a.epoch||state.manifest?.head!==a.head)throw Error('Release source differs');
  if(a.statusKind==='timed')return (await import('/__6940/cohort.mjs')).releasePreparedSample({id:a.id,admission});
  const pending=globalThis.__IFC_6940_FUNCTIONAL_PREPARED__;
  if(!pending||pending.id!==a.id||pending.preparation.source.head!==a.head||pending.preparation.source.side!==a.side||pending.preparation.source.epoch!==a.epoch||pending.preparation.fixtureIdentity.sha256!==a.fixtureSHA256||pending.preparation.fixtureIdentity.bytes!==a.fixtureBytes)throw Error('Actual functional preparation differs');
  return pending.release(admission);
}
export function expression(identity, admission) {
  if(!['timed','functional'].includes(identity.statusKind))throw Error('Explicit status kind required');
  return `(${release.toString()})(${JSON.stringify(identity)},${JSON.stringify(admission)})`;
}
export function build(intent, hostPath, expressionPath) {
  if(!path.isAbsolute(hostPath)||!path.isAbsolute(expressionPath)||hostPath!==intent.dynamicRelease.hostObservationPath)throw Error('Actual host path differs from preintent');
  const source=fs.readFileSync(fileURLToPath(import.meta.url));
  if(intent.dynamicRelease.generator.path!==fileURLToPath(import.meta.url)||intent.dynamicRelease.generator.sha256!==hash(source))throw Error('Release generator not frozen');
  const raw=fs.readFileSync(hostPath),admission=JSON.parse(raw);
  const identity={statusKind:intent.statusKind,id:intent.sampleId,head:intent.head,side:intent.side,epoch:intent.epoch,fixtureSHA256:intent.fixtureSHA256,fixtureBytes:intent.fixtureBytes};
  const code=expression(identity,admission);if(code!==code.trim())throw Error('Native expression must have no surrounding whitespace');
  return {purpose:'load-release',tool:'mcp__t3_code__preview_evaluate',args:{tabId:intent.tabId,expression:code,awaitPromise:true,returnByValue:true},expressionSource:{path:expressionPath,sha256:hash(Buffer.from(code))},dynamicHostObservation:{path:hostPath,sha256:hash(raw)},dynamicReleaseGenerator:intent.dynamicRelease.generator};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [intentPath,hostPath,expressionPath,requestPath]=process.argv.slice(2);
  if(!intentPath||!requestPath||fs.existsSync(expressionPath)||fs.existsSync(requestPath))throw Error('Explicit intent/host and NEW expression/request required');
  const request=build(JSON.parse(fs.readFileSync(intentPath)),hostPath,expressionPath);
  fs.writeFileSync(expressionPath,request.args.expression,{flag:'wx'});
  fs.writeFileSync(requestPath,JSON.stringify(request,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({requestPath,requestSHA256:hash(fs.readFileSync(requestPath)),expressionPath,expressionSHA256:request.expressionSource.sha256}));
}
