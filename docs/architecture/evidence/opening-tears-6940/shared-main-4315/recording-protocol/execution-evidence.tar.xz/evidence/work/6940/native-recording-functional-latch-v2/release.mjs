// Source-pinned dynamic request builder. Importing/generating never executes browser code.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {gzipSync} from 'node:zlib';
import { fileURLToPath } from 'node:url';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
async function decodeHost(transport) {
  if(!Number.isSafeInteger(transport.bytes)||transport.bytes<1||transport.bytes>8*1024*1024)throw Error('Full host transport capacity invalid');
  const compressed=Uint8Array.from(atob(transport.gzipBase64),c=>c.charCodeAt(0));
  const reader=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
  const chunks=[];let size=0;
  while(true){const row=await reader.read();if(row.done)break;size+=row.value.byteLength;if(size>transport.bytes){await reader.cancel('Declared full host size exceeded');throw Error('Full host decompression capacity exceeded');}chunks.push(row.value);}
  if(size!==transport.bytes)throw Error('Full host decompressed length differs');
  const raw=new Uint8Array(size);let offset=0;for(const chunk of chunks){raw.set(chunk,offset);offset+=chunk.byteLength;}
  const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(n=>n.toString(16).padStart(2,'0')).join('');
  if(digest!==transport.sha256)throw Error('Full ORIGINAL host bytes SHA differs');
  return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));
}
async function encodeReply(value) {
  const raw=new TextEncoder().encode(JSON.stringify(value));
  if(raw.byteLength>8*1024*1024)throw Error('Full reply transport8MiB capacity exceeded after actual dispatch');
  const compressed=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());
  let binary='';for(let offset=0;offset<compressed.length;offset+=16384)binary+=String.fromCharCode(...compressed.subarray(offset,offset+16384));
  const envelope={protocol:'ifc6940-functional-release-gzip-v1',bytes:raw.byteLength,sha256:[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(n=>n.toString(16).padStart(2,'0')).join(''),gzipBase64:btoa(binary)};
  if(JSON.stringify(envelope).length>64000)throw Error('Full reply T3 capacity exceeded after actual dispatch; preserve failed case');
  return envelope;
}
async function release(a, transport) {
  const admission=await decodeHost(transport);
  const state=await fetch('/__6940/state',{cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Source fetch failed');return r.json();});
  if(state.side!==a.side||state.epoch!==a.epoch||state.manifest?.head!==a.head)throw Error('Release source differs');
  if(a.statusKind==='timed')return (await import('/__6940/cohort.mjs')).releasePreparedSample({id:a.id,admission});
  const pending=globalThis.__IFC_6940_FUNCTIONAL_PREPARED__;
  if(!pending||pending.id!==a.id||pending.preparation.source.head!==a.head||pending.preparation.source.side!==a.side||pending.preparation.source.epoch!==a.epoch||pending.preparation.fixtureIdentity.sha256!==a.fixtureSHA256||pending.preparation.fixtureIdentity.bytes!==a.fixtureBytes)throw Error('Actual functional preparation differs');
  return encodeReply(pending.release(admission));
}
export function expression(identity, raw) {
  if(!['timed','functional'].includes(identity.statusKind))throw Error('Explicit status kind required');
  if(!(raw instanceof Uint8Array)||raw.byteLength<1||raw.byteLength>8*1024*1024)throw Error('Complete original host bytes required within8MiB transport capacity');
  const transport={bytes:raw.byteLength,sha256:hash(raw),gzipBase64:gzipSync(raw,{level:9}).toString('base64')};
  const code=`(async()=>{${decodeHost.toString()};${encodeReply.toString()};return (${release.toString()})(${JSON.stringify(identity)},${JSON.stringify(transport)});})()`;
  if(code.length>64000)throw Error('T3 expression64000 UTF-16-unit capacity exceeded; full host preserved, no fallback');
  return code;
}
export function build(intent, hostPath, expressionPath) {
  if(!path.isAbsolute(hostPath)||!path.isAbsolute(expressionPath)||hostPath!==intent.dynamicRelease.hostObservationPath)throw Error('Actual host path differs from preintent');
  const source=fs.readFileSync(fileURLToPath(import.meta.url));
  if(intent.dynamicRelease.generator.path!==fileURLToPath(import.meta.url)||intent.dynamicRelease.generator.sha256!==hash(source))throw Error('Release generator not frozen');
  const raw=fs.readFileSync(hostPath);JSON.parse(raw);
  const identity={statusKind:intent.statusKind,id:intent.sampleId,head:intent.head,side:intent.side,epoch:intent.epoch,fixtureSHA256:intent.fixtureSHA256,fixtureBytes:intent.fixtureBytes};
  const code=expression(identity,raw);if(code!==code.trim())throw Error('Native expression must have no surrounding whitespace');
  return {purpose:'load-release',tool:'mcp__t3_code__preview_evaluate',args:{tabId:intent.tabId,expression:code,awaitPromise:true,returnByValue:true},expressionSource:{path:expressionPath,sha256:hash(Buffer.from(code))},dynamicHostObservation:{path:hostPath,sha256:hash(raw)},dynamicReleaseGenerator:intent.dynamicRelease.generator};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const [intentPath,hostPath,expressionPath,requestPath]=process.argv.slice(2);
  if(!intentPath||!requestPath||fs.existsSync(expressionPath)||fs.existsSync(requestPath))throw Error('Explicit intent/host and NEW expression/request required');
  const request=build(JSON.parse(fs.readFileSync(intentPath)),hostPath,expressionPath);
  fs.writeFileSync(expressionPath,request.args.expression,{flag:'wx'});
  fs.writeFileSync(requestPath,JSON.stringify(request,null,2)+'\n',{flag:'wx'});
  console.log(JSON.stringify({requestPath,requestSHA256:hash(fs.readFileSync(requestPath)),expressionPath,expressionSHA256:request.expressionSource.sha256}));
}
