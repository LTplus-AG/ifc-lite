# Actual root-owned native history — UNLAUNCHED preparation

These helpers record actual T3 tool requests/replies and validate the narrow exclusively coordinated root-owned lifecycle. They never launch a browser from Python/Node. The print-only emitter creates a `functions.exec` body which root may later execute; only that explicitly executed body calls the named actual native tool. No passing history, video, sample or feasibility result was manufactured. Syntax checks are the only execution so far.

Scope: root is the exclusive owner of browser actions during the recorded sequence; other agents do not use the browser. This records every root-owned invocation in that sequence, including errors and incomplete requests. It cannot attest to unknown user/platform/out-of-band actions or recorder defects. Keep that explicit limit in every verdict. All timing/performance/output gates remain unchanged.

## Pre-create a finite actual run

Finish fresh-tab/focus/viewport preparation before initializing this recording history. Create an intent with `exclusiveRootOwnedBrowserControl:true`, `sampleId`, `tabId`, `statusKind:timed|functional`, exact `head`, `side`, `epoch`, fixture name/SHA/bytes, `distManifestSHA256`, `collectorSHA256`, actual `recordingMode`, `markerGeneratorSHA256`, `anchorDetectorSHA256`, and `sources` path/SHA refs for markerGenerator, cadenceGenerator, anchorDetector, mediaInspector. Root's immutable pre-start sample intent can carry the existing strict sidecar aliases as well; do not derive a new source identity from the recording.

Timed mode has nine actual calls; functional feasibility has ten. Bind each ordinary request file path/SHA in `intent.expectedCalls`, in order:

1. recording-start (`mcp__t3_code__preview_recording_start`)
2. pre-marker-show (evaluate)
3. pre-marker-remove (evaluate)
4. pre-cadence (evaluate)
5. functional-prepare (functional ONLY: genuine fixture-fetch/hash preparation; timed fixture preparation finishes before initialization)
6. load-release (evaluate: source-pinned dynamic request using the actual later host observation)
7. post-cadence (evaluate, only after actual durable server receipt)
8. post-marker-show (evaluate)
9. post-marker-remove (evaluate)
10. recording-stop (`mcp__t3_code__preview_recording_stop`)

Each request is `{purpose,tool,args}` with the real explicit tabId. Evaluate additionally binds `expressionSource:{path,sha256}`, and `args.expression` must equal that source file's complete UTF-8 contents, with `awaitPromise:true,returnByValue:true`. Marker/probe expressions come from the reviewed media-anchor-v3 and matched-policy-v3 generators and include explicit statusKind. Functional loading uses the original functional body with the reviewed separate prepare/release latch; no fake sample-global alias. No page polling occurs between load-release and durable completion: inspect the server receipt file outside the browser. Additional native calls, failures, retries or pending requests remain recorded and cause validation to HOLD.

`python3 journal.py init NEW_SESSION INTENT.json` creates the append-only session. For each call, `node emit-invocation.mjs ABS_SESSION ABS_REQUEST.json` prints the exact `functions.exec` body. Save that printed source, then root can invoke it. The wrapper durably records the request **before** calling `tools[actualName](actualArgs)`, records the entire returned MCP envelope without synthesizing structured values, and preserves exceptions separately. Large replies are transported in bounded Unicode-safe chunks through shell-quoted storage calls; raw reconstructed JSON is retained. The wrapper returns saved-file refs plus the actual reply. Tool `isError:true` is still recorded and later rejected. No call overlaps another; flock, monotonically ordered clocks/ordinals, exclusive file creation, fsync and chained index hashes protect the owned history from accidental overwrite/concurrent drift. Limits128 calls/8MiB reply fail explicitly.

After the actual stop completes, `python3 journal.py seal ABS_SESSION` creates immutable `history.json`. Every request has its reply/completion pair; orphan requests cannot seal. The recorder rejects further writes after seal. Preserve failed directories and start no replacement timing sample. Initialization pins recorder/emitter source; each command checks it. The authoritative envelope is `reply.structuredContent` for start/stop and `reply.structuredContent.value` for evaluate, matching the authentic native MCP example; text content is preserved but never reparsed as a substitute.

## Offline joins

Build a sidecar using actual refs from recorded reply files, with pointers `/reply/structuredContent` or `/reply/structuredContent/value`. Include the existing v2 fields `start`, `stop`, `markers`, `preCadence`, `postCadence`, `video`, `videoInspection`, `anchorInputManifest`, `anchorDetection`, `journal`, plus `hostObservation`. Use actual full-video inspector/detector outputs, never inferred booleans. The actual host observation must follow successful PRE removal/pre-cadence, occur while recording is active, satisfy original CPU≤10%/memory/active-graph rules, and be≤30s old at release. Fixed4s initialization occurs after the successful native start reply, before PRE-show; matching optical anchors remain mandatory regardless of this delay.

The existing v2 journal's logical source-observation events may reference exact nested fields of the actual post-cadence reply for settling/durable proof (`collector` is captured before its passive callback probe). This is one real native call, not invented additional calls. Functional status intentionally has no id: its associated actual functional receipt must supply the matching id/source/ok/functionalOnly/noTimingQualification. Never rewrite those tool values to fit the timing schema.

Input to `python3 validate.py INPUT.json NEW_RESULT.json` has `nativeHistory`, prevalidation `sidecar`, and, for functional mode, `functionalReceipt` refs. It checks the chained raw history, all predeclared requests/expressions, every native envelope/tab/pointer, failures, source identities, marker/removal/page clocks, cadence completion, host admission, actual complete media and matched optical frame indices/PTS. It binds actual configured recording mode and same-boot monotonic seal/validation clocks. Both source-matched feasibility validations must finish before the first timed history initializes. Complete ROOT-OWNED history is the scoped continuity proof. Media endpoints do not prove continuous30Hz during loading.

Functional validation additionally requires Holter as the actual fixture, authentic normal-load receipt/source/build/fixture/collector identity, visible focused secure isolated viewport, uncached WASM path, four actual workers, healthy GPU counters and complete schema4 payload receipts. It preserves the full payload binding; it does not claim new mesh correctness or cross-arm byte equality from the recording. Those remain the original complete-output witnesses/semantic review. `export-feasibility.py SUCCESSFUL_RESULT.json NEW_SUMMARY.json` produces the separately hashed summary consumed by the strict30 join.

To avoid self-hash cycles, first freeze the journal and a sidecar snapshot **without** lifecycleCoverage. Run validation, then create a NEW final sidecar adding the successful result ref as lifecycleCoverage. Do not rewrite the prevalidation sidecar. The lifecycle result hashes the journal and artifacts, never its own final sidecar. Feasibility summaries similarly reference the completed validator result, not themselves.

## Admission still pending

No helper has run against an actual recording session yet. Root/independent source review and genuine both-arm full Holter recording feasibility must precede any timed plan. Existing v1/v2 helper sources and previous failed recording diagnostics are preserved. No source heads, thirty-row plan, performance threshold, video codec setting or output-data expectation is selected by this preparation.

## V2 actual-request and frozen-source binding

The emitted invocation passes its exact embedded request to journal.begin. Begin compares it with type-aware recursive JSON equality (booleans are distinct from numbers) with the predeclared request file before writing the actual invocation or calling any native tool. Edited embedded arguments therefore fail before execution. Never edit printed native wrapper source; regenerate from a new explicitly reviewed request instead.

The intent sources must additionally pin nativeHistoryValidator, nativeHistoryRecorder and nativeHistoryEmitter (absolute path/SHA256), matching the V3 plan. The validator verifies these exact helper paths and hashes and emits the actual initialized recorder/emitter hashes. V3 feasibility and timed joins bind those source versions and recheck all original actual-input hashes. V1 remains immutable. No browser or fabricated history has been executed by this preparation.

For the fixed nine-call timed sequence, complete the original collector prepare/fixture fetch-and-hash before initializing this native history; do not add a tenth browser call between PRE and release. Host observation still follows fixture preparation, successful PRE removal and pre-cadence, and the unchanged original release enforces freshness. Functional PRE has no loader/global alias. Its fifth call is genuine preparation; actual dispatch follows the separate sixth release call and a new actual host observation.

## Dynamic actual host binding (both modes)

The pre-start intent declares `dynamicRelease:{intentPath,generator:{path,sha256},hostObservationPath,expressionPath,requestPath}`. All paths are absolute and unique; `intentPath` is the original immutable intent. The future host path is declared before recording, but its unknown future bytes are never fabricated or prehashed. `expectedCalls` contains `{purpose:"load-release",dynamicRelease:true}` for that call; every other call has its predeclared request ref.

Freeze `sources` refs for nativeHistoryValidator, nativeHistoryRecorder, nativeHistoryEmitter, nativeHistoryDynamicHelper, releaseGenerator, markerGenerator, cadenceGenerator, anchorDetector and mediaInspector. Functional mode also freezes functionalPrepareGenerator and functionalBaseExpression. The reviewed generators are `../native-recording-functional-latch-v1/{prepare-expression,release}.mjs`; dynamic.py reconstructs exact expression/request bytes offline from these pinned sources and the actual host file.

Functional order is PRE-show/remove/cadence, actual functional-prepare, actual host observation, dynamically generated release, actual dispatch, durable completion, POST-cadence/show/remove, stop. Thus PRE genuinely sees an unloaded page. Preparation fetches/hashes the fixture and returns its actual prepared receipt while the original loader pauses. Host observation occurs after that native call completes. Release checks actual source/fixture and host policy; the original loader checks it again immediately before assigning the normal File input. The functional receipt retains the exact host object, dispatch epoch milliseconds and same-page monotonic preparation/release/upload clocks. Timed preparation remains outside recording and the original timed collector/release checks remain unchanged.

Generate the functional prepare expression with `node prepare-expression.mjs ABS_ORIGINAL_FUNCTIONAL_EXPRESSION ABS_INTENT NEW_EXPRESSION`. After actual host observation, generate release with `node release.mjs ABS_INTENT ABS_ACTUAL_HOST NEW_EXPRESSION NEW_REQUEST`. Make all ordinary request files before initialization; make only this declared dynamic request afterward. Record it through the same emitter/journal wrapper. A failed or abandoned prepared functional load may be cancelled through its real owned cancel method; that extra call and failure are retained and cannot qualify the normal sequence.

Every generated browser expression has no leading/trailing whitespace, including the saved file bytes. Marker/probe generators write without an appended newline. The prepare builder explicitly normalizes its saved output with trim; offline reconstruction uses the identical builder. Journal BEGIN and validation reject surrounding whitespace, preventing T3 protocol rejection or a silent source-vs-argument trim mismatch.
