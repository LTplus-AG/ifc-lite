// PRINT a functions.exec body. This generator invokes no native/browser tool.
// node emit-invocation.mjs ABS_SESSION ABS_REQUEST.json
import fs from 'node:fs';import crypto from 'node:crypto';import path from 'node:path';import {fileURLToPath} from 'node:url';
const [session,file]=process.argv.slice(2);if(!path.isAbsolute(session??'')||!path.isAbsolute(file??''))throw Error('Absolute session/request required');
const bytes=fs.readFileSync(file),request=JSON.parse(bytes),requestSHA=crypto.createHash('sha256').update(bytes).digest('hex');
if(!/^mcp__t3_code__preview_[a-z_]+$/.test(request.tool)||!request.args?.tabId)throw Error('Explicit T3 preview tool/tab required');
const config={session,file,request,requestSHA,journal:path.join(path.dirname(fileURLToPath(import.meta.url)),'journal.py')};
async function invoke(c){
 const quote=s=>"'"+String(s).replaceAll("'","'\\''")+"'";
 async function record(args){const r=await tools.exec_command({cmd:['python3',c.journal,...args].map(quote).join(' '),login:false,max_output_tokens:2000});if(r.exit_code!==0)throw Error('Native journal write failed: '+r.output);return r.output.trim()?JSON.parse(r.output):null;}
 const begun=await record(['begin',c.session,c.file,c.requestSHA,JSON.stringify(c.request)]);let outcome,result,error;
 try{result=await tools[c.request.tool](c.request.args);outcome={outcome:'reply',reply:result};}
 catch(e){error=e;outcome={outcome:'throw',transportError:{name:e?.name??'Error',message:String(e?.message??e)}};}
 // Preserve the entire actual result envelope, including isError replies. No value synthesis.
 const codepoints=Array.from(JSON.stringify(outcome));
 for(let offset=0,index=0;offset<codepoints.length;offset+=16000,index++)await record(['chunk',c.session,String(begun.ordinal),String(index),JSON.stringify(codepoints.slice(offset,offset+16000).join(''))]);
 const saved=await record(['finish',c.session,String(begun.ordinal)]);text({nativeJournal:saved,actualReply:result??null,transportError:outcome.transportError??null});
 if(error)throw error;
}
console.log(`await (${invoke.toString()})(${JSON.stringify(config)});`);
