"""Export the actual successful functional validator result without self-hash cycles."""
from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();d=json.loads(p.read_text())
assert d['ok'] is True and d['statusKind']=='functional' and d['lifecycleCoverageVerified'] is True
f=d['functionalFeasibility'];assert f['functionalOnly'] is True and f['noTimingQualification'] is True
f=dict(f,validationReport={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with out.open('x')as handle:json.dump(f,handle,indent=2);handle.write('\n')
