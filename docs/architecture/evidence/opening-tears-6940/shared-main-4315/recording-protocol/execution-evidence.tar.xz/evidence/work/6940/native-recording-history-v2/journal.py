"""Append-only owned native invocation recorder. Never invokes a browser itself."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,re,sys,time
MAX_CALLS=128;MAX_REPLY=8*1024*1024
sha=lambda b:hashlib.sha256(b).hexdigest()
def same_json(a,b):
 if isinstance(a,bool) or isinstance(b,bool):return type(a)is type(b) and a==b
 if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(same_json(a[k],b[k])for k in a)
 if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(same_json(x,y)for x,y in zip(a,b))
 if type(a)is not type(b) and not(isinstance(a,(int,float))and isinstance(b,(int,float))):return False
 return a==b
def raw(p):return p.read_bytes()
def read(p):return json.loads(raw(p))
def stamp():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicNs':str(time.monotonic_ns()),'clockDomain':{'platform':sys.platform,'hostname':os.uname().nodename,'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}}
def create(p,d):
 with p.open('xb') as f:f.write(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode());f.flush();os.fsync(f.fileno())
def ref(p):return {'path':str(p.resolve()),'sha256':sha(raw(p))}
cmd=sys.argv[1];directory=Path(sys.argv[2]).resolve()
if cmd=='init':
 intent=Path(sys.argv[3]).resolve();d=read(intent);assert d['exclusiveRootOwnedBrowserControl'] is True and d['statusKind'] in ['timed','functional'];assert d['sampleId'] and d['tabId'] and re.fullmatch('[0-9a-f]{40}',d['head']);directory.mkdir();create(directory/'intent.json',d);create(directory/'initialization.json',{'intentSource':ref(intent),'clock':stamp(),'recorderSHA256':sha(raw(Path(__file__))),'emitterSHA256':sha(raw(Path(__file__).with_name('emit-invocation.mjs'))),'scope':'Complete exclusively coordinated ROOT-OWNED wrapper invocations only; unknown out-of-band/platform events excluded.'});(directory/'index.jsonl').touch(exist_ok=False);print(json.dumps({'directory':str(directory)}));raise SystemExit()
with (directory/'lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);assert not (directory/'history.json').exists(),'Session already sealed'
 initial=read(directory/'initialization.json');assert sha(raw(Path(__file__)))==initial['recorderSHA256'] and sha(raw(Path(__file__).with_name('emit-invocation.mjs')))==initial['emitterSHA256'],'Recorder source changed'
 rows=[json.loads(s)for s in (directory/'index.jsonl').read_text().splitlines()];previous=None
 for entry in rows:
  assert entry['previousEntrySHA256']==previous;previous=sha(json.dumps(entry,separators=(',',':')).encode());assert ref(Path(entry['file']['path']))==entry['file']
 def append(kind,p,ordinal):
  d={'kind':kind,'ordinal':ordinal,'file':ref(p),'previousEntrySHA256':previous}
  with (directory/'index.jsonl').open('ab') as f:f.write(json.dumps(d,separators=(',',':')).encode()+b'\n');f.flush();os.fsync(f.fileno())
 if cmd=='begin':
  assert not rows or rows[-1]['kind']=='completion','Prior invocation incomplete'
  ordinal=len(rows)//2+1;assert ordinal<=MAX_CALLS;source=Path(sys.argv[3]).resolve();assert sha(raw(source))==sys.argv[4];request=read(source)
  actual_invocation=json.loads(sys.argv[5]);assert same_json(actual_invocation,request),'Embedded actual invocation differs from predeclared recorded request'
  assert re.fullmatch('mcp__t3_code__preview_[a-z_]+',request['tool']);assert request['args']['tabId']==read(directory/'intent.json')['tabId'];assert isinstance(request['purpose'],str)
  if request['tool'].endswith('preview_evaluate'):
   e=request['expressionSource'];p=Path(e['path']);assert p.is_absolute() and sha(raw(p))==e['sha256'] and p.read_text()==request['args']['expression'];assert isinstance(request['args']['expression'],str) and request['args']['expression']==request['args']['expression'].strip(),'Native expression has surrounding whitespace';assert request['args'].get('returnByValue') is True and request['args'].get('awaitPromise') is True
  p=directory/f'{ordinal:04d}.request.json';create(p,{'ordinal':ordinal,'clockBefore':stamp(),'invocation':request,'requestSource':ref(source)});append('request',p,ordinal);print(json.dumps({'ordinal':ordinal,'request':ref(p)}))
 elif cmd=='chunk':
  ordinal=int(sys.argv[3]);index=int(sys.argv[4]);assert rows[-1]['kind']=='request' and rows[-1]['ordinal']==ordinal
  parts=list(directory.glob(f'{ordinal:04d}.chunk-*.json'));assert index==len(parts) and index<512
  chunk=json.loads(sys.argv[5]);assert isinstance(chunk,str) and len(chunk)<=16384;create(directory/f'{ordinal:04d}.chunk-{index:04d}.json',chunk)
 elif cmd=='finish':
  ordinal=int(sys.argv[3]);assert rows[-1]['kind']=='request' and rows[-1]['ordinal']==ordinal
  parts=sorted(directory.glob(f'{ordinal:04d}.chunk-*.json'));assert parts;blob=''.join(read(p)for p in parts).encode();assert len(blob)<=MAX_REPLY
  d=json.loads(blob);assert d['outcome'] in ['reply','throw'];reply=directory/f'{ordinal:04d}.reply.json'
  with reply.open('xb')as f:f.write(blob);f.flush();os.fsync(f.fileno())
  p=directory/f'{ordinal:04d}.completion.json';create(p,{'ordinal':ordinal,'clockAfter':stamp(),'request':rows[-1]['file'],'rawReply':ref(reply),'chunks':[ref(x)for x in parts],'outcome':d['outcome']});append('completion',p,ordinal);print(json.dumps({'ordinal':ordinal,'reply':ref(reply),'completion':ref(p)}))
 elif cmd=='seal':
  assert rows and rows[-1]['kind']=='completion' and len(rows)%2==0
  h={'schema':1,'intent':ref(directory/'intent.json'),'initialization':ref(directory/'initialization.json'),'index':ref(directory/'index.jsonl'),'events':rows,'sealed':stamp(),'completeWrapperInvocationPairs':True,'scope':'ROOT-OWNED recorded calls under explicit exclusive coordination; not unknown user/platform/recorder events.'};create(directory/'history.json',h);print(json.dumps(ref(directory/'history.json')))
 else:raise ValueError(cmd)
