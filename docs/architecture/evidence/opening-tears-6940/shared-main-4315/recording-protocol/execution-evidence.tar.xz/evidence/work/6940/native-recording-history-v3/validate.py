"""Validate REAL recorded native envelopes and joined media. No native execution.
Usage: python3 validate.py INPUT.json NEW_RESULT.json
Input refs: nativeHistory, sidecar, functionalReceipt (functional mode only).
"""
from pathlib import Path
from fractions import Fraction
import datetime,hashlib,json,math,sys,time,os,subprocess
import dynamic
sha=lambda b:hashlib.sha256(b).hexdigest()
def canonical(d):return json.dumps(d,ensure_ascii=False,separators=(',',':')).encode()
def ref(p,pointer=None):
 r={'path':str(p.resolve()),'sha256':sha(p.read_bytes())}
 if pointer:r['pointer']=pointer
 return r
seen={}
def load(r):
 p=Path(r['path']);assert p.is_absolute();b=p.read_bytes();assert sha(b)==r['sha256'],str(p);seen[str(p)]=r['sha256'];d=json.loads(b)
 for part in r.get('pointer','').split('/')[1:]:d=d[part.replace('~1','/').replace('~0','~')]
 return d
def utc(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()
def epoch_ms(s):
 d=datetime.datetime.fromisoformat(s.replace('Z','+00:00'))-datetime.datetime(1970,1,1,tzinfo=datetime.timezone.utc)
 return(d.days*86400+d.seconds)*1000+d.microseconds//1000
def finite(x):return type(x) in [int,float] and math.isfinite(x)
def cadence(a,mode,phase,intent):
 assert a['protocol']=='ifc6940-native-recording-matched-v1' and a['statusKind']==mode and a['phase']==phase and a['id']==intent['sampleId'] and a['tabId']==intent['tabId']
 assert a['source']=={'head':intent['head'],'side':intent['side'],'epoch':intent['epoch']}
 assert a['viewport']['innerWidth']==1280 and a['viewport']['innerHeight']==800 and finite(a['viewport']['devicePixelRatio']) and a['viewport']['devicePixelRatio']>0
 assert a['finished'] is True and a['timeout'] is False and len(a['samples'])==60
 assert finite(a['startNow']) and finite(a['finishNow']) and 0<=a['finishNow']-a['startNow']<=3000
 for i,s in enumerate(a['samples']):
  assert finite(s['timestamp']) and a['startNow']<=s['timestamp']<=a['finishNow'] and s['visibility']=='visible' and s['hasFocus'] is True
  if i:assert abs((s['timestamp']-a['samples'][i-1]['timestamp'])-1000/30)<=1000/30*.03
src=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]).resolve();assert not output.exists();result={'schema':1,'ok':False,'lifecycleCoverageVerified':False,'performanceQualified':False,'validatorSHA256':sha(Path(__file__).read_bytes()),'inputSHA256':sha(src.read_bytes()),'inputPath':str(src),'scope':'Complete ROOT-OWNED wrapper invocation history under explicit exclusive browser coordination; excludes unknown out-of-band user/platform/recorder activity.'}
try:
 args=json.loads(src.read_text());history=load(args['nativeHistory']);intent=load(history['intent']);initial=load(history['initialization']);sidecar=load(args['sidecar']);mode=intent['statusKind'];assert load(initial['intentSource'])==intent and intent['dynamicRelease']['intentPath']==initial['intentSource']['path'];assert mode in ['timed','functional'] and intent['exclusiveRootOwnedBrowserControl'] is True
 for source in intent['sources'].values():
  q=Path(source['path']);assert q.is_absolute() and sha(q.read_bytes())==source['sha256'];seen[str(q)]=source['sha256']
 assert intent['sources']['markerGenerator']['sha256']==intent['markerGeneratorSHA256'] and intent['sources']['anchorDetector']['sha256']==intent['anchorDetectorSHA256']
 assert initial['recorderSHA256']==sha(Path(__file__).with_name('journal.py').read_bytes()) and initial['emitterSHA256']==sha(Path(__file__).with_name('emit-invocation.mjs').read_bytes())
 for key,sourcefile in [('nativeHistoryValidator',Path(__file__)),('nativeHistoryRecorder',Path(__file__).with_name('journal.py')),('nativeHistoryEmitter',Path(__file__).with_name('emit-invocation.mjs')),('nativeHistoryDynamicHelper',Path(__file__).with_name('dynamic.py')),('canonicalPayloadValidator',Path(__file__).with_name('canonical-payload.mjs'))]:
  source=intent['sources'][key];assert Path(source['path']).resolve()==sourcefile.resolve() and source['sha256']==sha(sourcefile.read_bytes()),'Native history source intent differs from actual reviewed helper'
 assert intent['collectorSHA256']==intent['sources']['canonicalCollector']['sha256']=='470f3febe606b7f4d9677e486a4dc5d6b98d851a1fd98d7bb8b02a425159dc17'
 result['canonicalPayloadValidatorSHA256']=intent['sources']['canonicalPayloadValidator']['sha256']
 result['recorderSHA256']=initial['recorderSHA256'];result['emitterSHA256']=initial['emitterSHA256']
 indexpath=Path(history['index']['path']);assert sha(indexpath.read_bytes())==history['index']['sha256'];seen[str(indexpath)]=history['index']['sha256'];events=[json.loads(x)for x in indexpath.read_text().splitlines()];assert events==history['events'] and len(events)%2==0 and len(events)<=256
 previous=None;calls=[];domain=initial['clock']['clockDomain'];last=int(initial['clock']['monotonicNs'])
 for i in range(0,len(events),2):
  request_event,completion_event=events[i:i+2]
  for event in [request_event,completion_event]:
   assert event['previousEntrySHA256']==previous;previous=sha(json.dumps(event,separators=(',',':')).encode())
  assert request_event['kind']=='request' and completion_event['kind']=='completion' and request_event['ordinal']==completion_event['ordinal']==i//2+1
  request=load(request_event['file']);completion=load(completion_event['file']);assert request['ordinal']==completion['ordinal']==request_event['ordinal'];assert completion['request']==request_event['file'];actual=load(completion['rawReply']);assert actual['outcome']=='reply' and actual['reply'].get('isError',False) is False and completion['outcome']=='reply'
  chunks=''.join(load(x)for x in completion['chunks']).encode();assert sha(chunks)==completion['rawReply']['sha256']
  assert request['clockBefore']['clockDomain']==completion['clockAfter']['clockDomain']==domain;assert last<=int(request['clockBefore']['monotonicNs'])<=int(completion['clockAfter']['monotonicNs']);last=int(completion['clockAfter']['monotonicNs'])
  invocation=request['invocation'];assert invocation==load(request['requestSource']);assert invocation['args']['tabId']==intent['tabId']
  if invocation['tool']=='mcp__t3_code__preview_evaluate':
   e=invocation['expressionSource'];p=Path(e['path']);assert sha(p.read_bytes())==e['sha256'] and p.read_text()==invocation['args']['expression'] and p.read_text()==p.read_text().strip();seen[str(p)]=e['sha256'];pointer='/reply/structuredContent/value'
  else:pointer='/reply/structuredContent'
  value=load(dict(completion['rawReply'],pointer=pointer));calls.append({'request':request,'completion':completion,'value':value,'ref':dict(completion['rawReply'],pointer=pointer),'purpose':invocation['purpose'],'tool':invocation['tool']})
 assert history['sealed']['clockDomain']==domain and int(history['sealed']['monotonicNs'])>=last and history['completeWrapperInvocationPairs'] is True
 purposes=['recording-start','pre-marker-show','pre-marker-remove','pre-cadence']+(['functional-prepare']if mode=='functional'else[])+['load-release','post-cadence','post-marker-show','post-marker-remove','recording-stop']
 assert [c['purpose']for c in calls]==purposes,'Extra/missing/retried native call; cohort must HOLD'
 assert len(intent['expectedCalls'])==len(calls)
 for c,e in zip(calls,intent['expectedCalls']):
  assert e['purpose']==c['purpose']
  if c['purpose']=='load-release':
   assert e=={'purpose':'load-release','dynamicRelease':True} and c['request']['requestSource']['path']==intent['dynamicRelease']['requestPath']
   assert load(c['request']['requestSource'])==c['request']['invocation'];dynamic_host=dynamic.release_request(intent,c['request']['invocation']);load(dynamic_host)
  else:assert e['request']==c['request']['requestSource'],'Call not fixed by pre-start intent'
 for i,c in enumerate(calls):assert c['tool']==('mcp__t3_code__preview_recording_start' if i==0 else 'mcp__t3_code__preview_recording_stop' if i==len(calls)-1 else 'mcp__t3_code__preview_evaluate')
 by={c['purpose']:c for c in calls};values={k:c['value']for k,c in by.items()};start,stop=values['recording-start'],values['recording-stop'];assert start['recording'] is True and start['tabId']==stop['tabId']==intent['tabId'] and start['startedAt'] and stop['mimeType'].startswith('video/')
 assert (int(by['pre-marker-show']['request']['clockBefore']['monotonicNs'])-int(by['recording-start']['completion']['clockAfter']['monotonicNs']))>=4_000_000_000,'Fixed initial4s warmup missing'
 bindings={'start':'recording-start','stop':'recording-stop','preCadence':'pre-cadence','postCadence':'post-cadence'}
 for k,purpose in bindings.items():assert sidecar[k]==by[purpose]['ref']
 for k,purpose in [('preShow','pre-marker-show'),('preRemove','pre-marker-remove'),('postShow','post-marker-show'),('postRemove','post-marker-remove')]:assert sidecar['markers'][k]==by[purpose]['ref']
 pre,post=values['pre-cadence'],values['post-cadence'];cadence(pre,mode,'pre',intent);cadence(post,mode,'post',intent)
 markerkeys=['pre-marker-show','pre-marker-remove','post-marker-show','post-marker-remove'];nonce=set()
 for key in markerkeys:
  a=values[key];phase=key.split('-')[0];action=key.split('-')[-1];assert a['protocol']=='ifc6940-media-anchor-v1' and a['statusKind']==mode and a['phase']==phase and a['action']==action and a['id']==intent['sampleId'] and a['tabId']==intent['tabId']
  assert a['source']==pre['source'] and a['head']==intent['head'] and a['side']==intent['side'] and a['epoch']==intent['epoch'] and a['generatorSha256']==intent['markerGeneratorSHA256'];nonce.add(a['nonce'])
  identity={k:a[k]for k in ['protocol','statusKind','phase','id','tabId','head','side','epoch','nonce']};assert sha(canonical(identity))[:32]==a['token']
  assert a['rect']=={'x':24,'y':24,'width':160,'height':160}
  assert a['finished'] is True and a['markerPresent']==(action=='show') and len(a['frames'])==(60 if action=='show'else 3)
  assert a['timeOrigin']==pre['timeOrigin']==post['timeOrigin'] and a['viewport']==pre['viewport']==post['viewport']
  assert all(finite(t) and a['startNow']<=t<=a['finishNow'] for t in a['frames']) and all(b>a for a,b in zip(a['frames'],a['frames'][1:]))
  if phase=='post':assert a['collectorBefore']['stage']==a['collectorAfter']['stage']=='done' and a['collectorBefore']['persistence']==a['collectorAfter']['persistence']=='saved'
 assert len(nonce)==1
 if mode=='functional':
  for key in ['pre-cadence','pre-marker-show','pre-marker-remove']:
   a=values[key];assert a.get('collector',a.get('collectorBefore')) is None and a.get('collectorAfter') is None and a['functionalReceiptBefore'] is None and a['functionalReceiptAfter'] is None
 assert values['pre-marker-show']['finishNow']<values['pre-marker-remove']['startNow']<values['pre-marker-remove']['finishNow']<pre['startNow']
 assert post['finishNow']<values['post-marker-show']['startNow']<values['post-marker-show']['finishNow']<values['post-marker-remove']['startNow']
 assert values['pre-marker-show']['token']==values['pre-marker-remove']['token'] and values['post-marker-show']['token']==values['post-marker-remove']['token']
 assert dynamic_host==sidecar['hostObservation'];host=load(sidecar['hostObservation']);assert host['quiet'] is True and host['policy']=={'version':'native-host-v12-departure-observation','minimumLinuxKiB':41943040,'maximumWindowsCpuPercent':10}
 assert host['linux']['MemAvailableKiB']>=41943040 and not host['linux']['activeGraphs'] and len(host['windows'])==3 and all(finite(w['totalProcessorPercent']) and 0<=w['totalProcessorPercent']<=10 for w in host['windows'])
 host_predecessor='functional-prepare'if mode=='functional'else'pre-cadence'
 hosttime=utc(host['capturedAt']);assert utc(by[host_predecessor]['completion']['clockAfter']['utc'])<=hosttime<=utc(by['load-release']['request']['clockBefore']['utc']) and utc(by['load-release']['request']['clockBefore']['utc'])-hosttime<=30
 media=load(sidecar['videoInspection']);det=load(sidecar['anchorDetection']);dm=load(sidecar['anchorInputManifest']);video=Path(sidecar['video']['path']);assert sha(video.read_bytes())==sidecar['video']['sha256']==media['videoSha256']==det['videoSHA256'];seen[str(video)]=sidecar['video']['sha256'];assert str(video)==stop['path'] and video.stat().st_size==stop['sizeBytes']<=50*1024*1024
 assert media['scriptSHA256']==intent['sources']['mediaInspector']['sha256'] and media['configuredMode']==intent['recordingMode']
 assert str(video) in media['decodeCommand'] and str(video) in media['probeCommand'] and str(video) in det['command']
 assert det['inputs']['ffprobeOutput']==media['ffprobeOutput']
 assert media['complete'] is True and media['videoUnchanged'] is True and media['decodeExitCode']==0 and Path(media['decoderStderr']['path']).read_bytes()==b'';load(media['ffprobeOutput']);assert sha(Path(media['decoderStderr']['path']).read_bytes())==media['decoderStderr']['sha256']
 assert det['ok'] is True and det['inputsUnchanged'] is True and not det.get('error') and det['decodeExitCode']==0 and sha(Path(det['decoderStderr']['path']).read_bytes())==det['decoderStderr']['sha256'] and Path(det['decoderStderr']['path']).stat().st_size==0
 assert det['detectorSHA256']==intent['anchorDetectorSHA256'] and det['manifestSHA256']==sidecar['anchorInputManifest']['sha256']
 for k,r in [('video',sidecar['video']),('inspection',sidecar['videoInspection']),('pre',sidecar['markers']['preShow']),('post',sidecar['markers']['postShow'])]:assert dm[k]==det['inputs'][k]==r
 q=load(media['ffprobeOutput']);frames=[f for f in q['frames']if f['media_type']=='video'];streams=[s for s in q['streams']if s['codec_type']=='video'];assert len(streams)==1;tb=Fraction(streams[0]['time_base']);pts=[int(f['best_effort_timestamp'])*tb for f in frames];assert all(b>a for a,b in zip(pts,pts[1:])) and len(frames)==det['decodedFrames']==media['videoFrameCount']
 for match,key in zip(det['matches'],['pre-marker-show','post-marker-show']):
  assert match['token']==values[key]['token'] and match['phase']==values[key]['phase'];idx=match['frames'];assert len(idx)>=3 and any(a+1==b and b+1==c for a,b,c in zip(idx,idx[1:],idx[2:]));assert all(0<=i<len(frames) for i in idx) and all(b>a for a,b in zip(idx,idx[1:]));assert [Fraction(p)for p in match['pts']]==[pts[i]for i in idx]
 assert len(det['matches'])==2 and det['matches'][0]['frames'][-1]<det['matches'][1]['frames'][0]
 if mode=='functional':
  f=load(args['functionalReceipt']);assert f['id']==intent['sampleId'] and f['ok'] is True and f['functionalOnly'] is True and f['noTimingQualification'] is True and f['errors']==[] and intent['fixture']=='holter'
  assert f['server']['side']==intent['side'] and f['server']['epoch']==intent['epoch'] and f['server']['manifest']['head']==intent['head'] and f['server']['manifest']['distManifestSha256']==intent['distManifestSHA256']
  assert f['fixtureIdentity']['sha256']==intent['fixtureSHA256'] and f['fixtureIdentity']['bytes']==intent['fixtureBytes'] and f['collectorSha256']==intent['collectorSHA256']
  preparation=values['functional-prepare'];generation=dynamic.prepare_expression(intent,by['functional-prepare']['request']['invocation'])
  assert preparation['protocol']=='ifc6940-functional-prepared-v1' and preparation['prepared'] is True and preparation['id']==intent['sampleId'] and preparation['source']==pre['source'] and preparation['generation']==generation
  assert preparation['fixtureIdentity']['sha256']==intent['fixtureSHA256'] and preparation['fixtureIdentity']['bytes']==intent['fixtureBytes'] and preparation['collectorSha256']==intent['collectorSHA256']
  assert f['functionalPreparation']==preparation and f['externalAdmission']==host and f['timeOrigin']==pre['timeOrigin']==preparation['timeOrigin']
  release=values['load-release'];assert release['released'] is True and release['id']==intent['sampleId'] and release['externalAdmission']==host and release['source']==pre['source'] and release['timeOrigin']==pre['timeOrigin']
  assert finite(preparation['preparedNow']) and pre['finishNow']<preparation['preparedNow']<=release['releaseNow']<=f['uploadStart']<post['startNow']
  assert type(f['dispatchAtEpochMs'])is int and f['dispatchAtEpochMs']==epoch_ms(f['dispatchAt'])
  age=f['dispatchAtEpochMs']-epoch_ms(host['capturedAt']);assert 0<=age<=30000 and age==f['externalAdmissionAgeAtDispatchMs']
  result['functionalPrepareGeneratorSHA256']=generation['generatorSHA256']
  env=f['environment'];assert env['secureContext'] is True and env['crossOriginIsolated'] is True and env['visibility']=='visible' and env['hasFocus'] is True and env['viewport']=={'width':1280,'height':800,'dpr':pre['viewport']['devicePixelRatio']}
  assert f['trace']['attrs']['loadPath']=='wasm';spans=f['trace']['spans'];assert not any(s['name']=='cache.storeReady'for s in spans);assert [s['attrs']['workerCount']for s in spans if s['name']=='geometry.pool']==[4]
  g=f['gpuHealth'];assert g['contaminated'] is False and not g['reasons'] and g['devicesCreated']==1 and all(g[k]==0 for k in ['deviceLost','instanceErrors','deviceReplacements','uncapturedErrors'])
  checker=Path(__file__).with_name('canonical-payload.mjs');payload_check=json.loads(subprocess.check_output(['node',str(checker),args['functionalReceipt']['path'],args['functionalReceipt'].get('pointer','')]));assert payload_check['ok'] is True;result['canonicalPayloadCheck']=payload_check
  for key in ['post-cadence','post-marker-show','post-marker-remove']:
   for field in ['functionalReceiptBefore','functionalReceiptAfter']:
    a=values[key][field];assert a['id']==f['id'] and a['ok'] is True and a['functionalOnly'] is True and a['noTimingQualification'] is True and a['source']==pre['source']
  result['functionalFeasibility']={'schema':1,'statusKind':'functional','protocol':'ifc6940-native-recording-matched-v1','functionalOnly':True,'fixture':'holter','side':intent['side'],'sourceHead':intent['head'],'complete':True,'artifactValidated':True,'recordingContinuousThroughSettling':True,'noTimingQualification':True,'actualFunctionalReceipt':args['functionalReceipt'],'payloadSHA256':sha(canonical(f['payload'])),'recordingMode':intent['recordingMode'],'nativeHistorySealedClock':history['sealed']}
 else:
  timed=load(sidecar['timedReceipt']);assert timed['id']==intent['sampleId'] and timed['ok'] is True and pre['finishNow']<timed['uploadStart'] and post['startNow']>=timed['observedReady'];assert values['load-release']['released'] is True
  for key in ['post-cadence','post-marker-show','post-marker-remove']:
   a=values[key].get('collector',values[key].get('collectorBefore'));assert a['id']==intent['sampleId'] and a['stage']=='done' and a['persistence']=='saved'
 journal=load(sidecar['journal']);assert journal['complete'] is True
 kinds=['intent','recording-start','pre-marker-show','pre-marker-remove','pre-cadence']+(['functional-prepare']if mode=='functional'else[])+['host-observation','upload-release','settling-complete','collector-durable','post-cadence','post-marker-show','post-marker-remove','recording-stop','artifact-validated','anchors-validated'];je=journal['events'];assert [e['kind']for e in je]==kinds and all(e['tabId']==intent['tabId']for e in je) and all(b['ordinal']>a['ordinal']for a,b in zip(je,je[1:]))
 jm={e['kind']:e for e in je}
 for purpose,c in by.items():
  kind='upload-release' if purpose=='load-release' else purpose
  assert jm[kind]['receiptSha256']==c['ref']['sha256']
 assert jm['host-observation']['receipt']==sidecar['hostObservation'] and jm['artifact-validated']['receiptSha256']==sidecar['videoInspection']['sha256'] and jm['anchors-validated']['receiptSha256']==sidecar['anchorDetection']['sha256']
 durable=load(jm['collector-durable']['receipt']);settled=load(jm['settling-complete']['receipt']);assert durable['stage']=='done' and durable['persistence']=='saved' and settled['stage'] in ['hashing-outside-timer','persisting','done']
 assert journal['nativeHistory']==args['nativeHistory'];assert journal['recordingToolCalls']==[{'tool':'preview_recording_start','tabId':intent['tabId'],'result':sidecar['start']},{'tool':'preview_recording_stop','tabId':intent['tabId'],'result':sidecar['stop']}]
 for path,digest in seen.items():assert sha(Path(path).read_bytes())==digest,'Input changed during verification'
 current_domain={'platform':sys.platform,'hostname':os.uname().nodename,'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()};assert current_domain==domain
 completed={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicNs':str(time.monotonic_ns()),'clockDomain':domain}
 if mode=='functional':result['functionalFeasibility']['validationCompletedClock']=completed
 result.update(validationCompletedClock=completed,nativeHistoryInitializationClock=initial['clock'],nativeHistorySealedClock=history['sealed'],releaseGeneratorSHA256=intent['sources']['releaseGenerator']['sha256'],dynamicHelperSHA256=intent['sources']['nativeHistoryDynamicHelper']['sha256'],ok=True,lifecycleCoverageVerified=True,recordingInterrupted=False,actualCompleteNativeHistoryReviewed=True,nativeHistory=args['nativeHistory'],videoSHA256=sidecar['video']['sha256'],inspectionSHA256=sidecar['videoInspection']['sha256'],anchorDetectionSHA256=sidecar['anchorDetection']['sha256'],journalSHA256=sidecar['journal']['sha256'],statusKind=mode,actualNativeCalls=len(calls),actualInputs=seen)
except BaseException as e:result['error']={'type':type(e).__name__,'message':str(e)}
with output.open('x')as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({k:result.get(k)for k in ['ok','statusKind','actualNativeCalls','error']}))
if not result['ok']:raise SystemExit(1)
