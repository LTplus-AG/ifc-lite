// PRINT a small refs-only functions.exec body. No native/browser invocation here.
// node emit-invocation.mjs ABS_SESSION ABS_REQUEST.json
import fs from 'node:fs';import crypto from 'node:crypto';import path from 'node:path';import {fileURLToPath} from 'node:url';
const [session,file]=process.argv.slice(2);if(!path.isAbsolute(session??'')||!path.isAbsolute(file??''))throw Error('Absolute session/request required');
const bytes=fs.readFileSync(file);if(bytes.length>8*1024*1024)throw Error('Explicit request8MiB capacity exceeded; preserve failure');
const request=JSON.parse(bytes),requestSHA=crypto.createHash('sha256').update(bytes).digest('hex');
if(!/^mcp__t3_code__preview_[a-z_]+$/.test(request.tool)||!request.args?.tabId)throw Error('Explicit T3 preview tool/tab required');
const config={session,file,requestSHA,journal:path.join(path.dirname(fileURLToPath(import.meta.url)),'journal.py')};
async function invoke(c){
 const quote=s=>"'"+String(s).replaceAll("'","'\\''")+"'";
 async function record(args){const r=await tools.exec_command({cmd:['python3',c.journal,...args].map(quote).join(' '),login:false,max_output_tokens:20000});if(r.exit_code!==0)throw Error('Native journal transport failed: '+r.output);return r.output.trim()?JSON.parse(r.output):null;}
 const t=await record(['transport-init',c.session,c.file,c.requestSHA]);
 if(t.bytes>8*1024*1024||t.chunkChars!==4096||t.chunks<1||t.chunks>2048||t.requestSource.sha256!==c.requestSHA)throw Error('Request transport metadata differs');
 const pieces=[];
 // Independent bounded reads, at most4 in flight; exact saved source hash checked on every read.
 for(let offset=0;offset<t.chunks;offset+=4){const indexes=Array.from({length:Math.min(4,t.chunks-offset)},(_,i)=>offset+i);const results=await Promise.all(indexes.map(i=>record(['request-slice',c.session,t.token,String(i)])));for(let i=0;i<results.length;i++){const r=results[i];if(r.index!==indexes[i]||r.requestSHA256!==c.requestSHA||typeof r.chunk!=='string')throw Error('Request slice differs');pieces.push(r.chunk);}}
 const actualText=pieces.join(''),actualRequest=JSON.parse(actualText);
 // Freeze the actual reconstructed object passed to the tool; the SAME raw text is durably staged.
 const pending=[actualRequest];while(pending.length){const value=pending.pop();if(value&&typeof value==='object'){for(const child of Object.values(value))pending.push(child);Object.freeze(value);}}
 const points=Array.from(actualText);if(points.length!==t.characters)throw Error('Actual reconstruction character count differs');
 for(let offset=0,index=0;offset<points.length;offset+=4096,index++)await record(['transport-chunk',c.session,t.token,String(index),JSON.stringify(points.slice(offset,offset+4096).join(''))]);
 const dispatchPoints=Array.from(JSON.stringify(actualRequest));
 await record(['dispatch-init',c.session,t.token,String(dispatchPoints.length),String(Math.ceil(dispatchPoints.length/4096))]);
 for(let offset=0,index=0;offset<dispatchPoints.length;offset+=4096,index++)await record(['dispatch-chunk',c.session,t.token,String(index),JSON.stringify(dispatchPoints.slice(offset,offset+4096).join(''))]);
 await record(['transport-seal',c.session,t.token]);
 // BEGIN verifies full raw SHA, all chunks, durable file, original source and type-sensitive equality of ACTUAL JS-serialized args.
 const begun=await record(['begin',c.session,t.token]);let outcome,error;
 try{const result=await tools[actualRequest.tool](actualRequest.args);outcome={outcome:'reply',reply:result};}
 catch(e){error=e;outcome={outcome:'throw',transportError:{name:e?.name??'Error',message:String(e?.message??e)}};}
 const codepoints=Array.from(JSON.stringify(outcome));
 for(let offset=0,index=0;offset<codepoints.length;offset+=16000,index++)await record(['chunk',c.session,String(begun.ordinal),String(index),JSON.stringify(codepoints.slice(offset,offset+16000).join(''))]);
 const saved=await record(['finish',c.session,String(begun.ordinal)]);
 // Full actual reply is durable in rawReply; avoid duplicating huge host objects in tool text.
 text({nativeJournal:saved,outcome:outcome.outcome,isError:outcome.reply?.isError===true,transportError:outcome.transportError??null});
 if(error)throw error;
}
console.log(`await (${invoke.toString()})(${JSON.stringify(config)});`);
