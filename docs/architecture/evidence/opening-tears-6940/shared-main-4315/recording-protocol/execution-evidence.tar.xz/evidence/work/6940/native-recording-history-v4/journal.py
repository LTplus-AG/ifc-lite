"""Append-only owned native invocation recorder. Never invokes a browser itself."""
from pathlib import Path
import datetime,fcntl,hashlib,json,os,re,sys,time
MAX_CALLS=128;MAX_REPLY=8*1024*1024;MAX_REQUEST=8*1024*1024;REQUEST_CHARS=4096
sha=lambda b:hashlib.sha256(b).hexdigest()
def same_json(a,b):
 if isinstance(a,bool) or isinstance(b,bool):return type(a)is type(b) and a==b
 if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(same_json(a[k],b[k])for k in a)
 if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(same_json(x,y)for x,y in zip(a,b))
 if type(a)is not type(b) and not(isinstance(a,(int,float))and isinstance(b,(int,float))):return False
 return a==b
def raw(p):return p.read_bytes()
def read(p):return json.loads(raw(p))
def stamp():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicNs':str(time.monotonic_ns()),'clockDomain':{'platform':sys.platform,'hostname':os.uname().nodename,'bootId':Path('/proc/sys/kernel/random/boot_id').read_text().strip()}}
def create(p,d):
 with p.open('xb') as f:f.write(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode());f.flush();os.fsync(f.fileno())
def ref(p):return {'path':str(p.resolve()),'sha256':sha(raw(p))}
cmd=sys.argv[1];directory=Path(sys.argv[2]).resolve()
if cmd=='init':
 intent=Path(sys.argv[3]).resolve();d=read(intent);assert d['exclusiveRootOwnedBrowserControl'] is True and d['statusKind'] in ['timed','functional'];assert d['sampleId'] and d['tabId'] and re.fullmatch('[0-9a-f]{40}',d['head']);directory.mkdir();create(directory/'intent.json',d);create(directory/'initialization.json',{'intentSource':ref(intent),'clock':stamp(),'recorderSHA256':sha(raw(Path(__file__))),'emitterSHA256':sha(raw(Path(__file__).with_name('emit-invocation.mjs'))),'scope':'Complete exclusively coordinated ROOT-OWNED wrapper invocations only; unknown out-of-band/platform events excluded.'});(directory/'index.jsonl').touch(exist_ok=False);print(json.dumps({'directory':str(directory)}));raise SystemExit()
with (directory/'lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);assert not (directory/'history.json').exists(),'Session already sealed'
 initial=read(directory/'initialization.json');assert sha(raw(Path(__file__)))==initial['recorderSHA256'] and sha(raw(Path(__file__).with_name('emit-invocation.mjs')))==initial['emitterSHA256'],'Recorder source changed'
 rows=[json.loads(s)for s in (directory/'index.jsonl').read_text().splitlines()];previous=None
 for entry in rows:
  assert entry['previousEntrySHA256']==previous;previous=sha(json.dumps(entry,separators=(',',':')).encode());assert ref(Path(entry['file']['path']))==entry['file']
 def append(kind,p,ordinal):
  d={'kind':kind,'ordinal':ordinal,'file':ref(p),'previousEntrySHA256':previous}
  with (directory/'index.jsonl').open('ab') as f:f.write(json.dumps(d,separators=(',',':')).encode()+b'\n');f.flush();os.fsync(f.fileno())
 def transport_dir(token):
  assert re.fullmatch('[0-9]{4}',token);p=directory/(token+'.transport');assert p.is_dir();return p
 if cmd=='transport-init':
  assert not rows or rows[-1]['kind']=='completion','Prior invocation incomplete'
  ordinal=len(rows)//2+1;assert ordinal<=MAX_CALLS;source=Path(sys.argv[3]).resolve();blob=raw(source);assert len(blob)<=MAX_REQUEST and sha(blob)==sys.argv[4];content=blob.decode();token=f'{ordinal:04d}';p=directory/(token+'.transport');p.mkdir();metadata={'ordinal':ordinal,'requestSource':ref(source),'characters':len(content),'bytes':len(blob),'chunkChars':REQUEST_CHARS,'chunks':(len(content)+REQUEST_CHARS-1)//REQUEST_CHARS};assert 0<metadata['chunks']<=MAX_REQUEST//REQUEST_CHARS;create(p/'metadata.json',metadata);print(json.dumps(dict(metadata,token=token)))
 elif cmd=='request-slice':
  p=transport_dir(sys.argv[3]);m=read(p/'metadata.json');source=Path(m['requestSource']['path']);content=raw(source);assert sha(content)==m['requestSource']['sha256'];content=content.decode();index=int(sys.argv[4]);assert 0<=index<m['chunks'];print(json.dumps({'index':index,'chunk':content[index*REQUEST_CHARS:(index+1)*REQUEST_CHARS],'requestSHA256':m['requestSource']['sha256']}))
 elif cmd=='dispatch-init':
  p=transport_dir(sys.argv[3]);m=read(p/'metadata.json');characters=int(sys.argv[4]);chunks=int(sys.argv[5]);assert 0<characters<=MAX_REQUEST and chunks==(characters+REQUEST_CHARS-1)//REQUEST_CHARS<=MAX_REQUEST//REQUEST_CHARS;create(p/'dispatch-metadata.json',{'characters':characters,'chunks':chunks,'bytes':MAX_REQUEST})
 elif cmd in ['transport-chunk','dispatch-chunk']:
  p=transport_dir(sys.argv[3]);assert not(p/'sealed.json').exists();dispatch=cmd=='dispatch-chunk';prefix='dispatch'if dispatch else'actual';m=read(p/('dispatch-metadata.json'if dispatch else'metadata.json'));index=int(sys.argv[4]);parts=sorted(p.glob(prefix+'-chunk-*.json'));assert index==len(parts) and index<m['chunks'];chunk=json.loads(sys.argv[5]);assert isinstance(chunk,str) and len(chunk)<=REQUEST_CHARS;expected=min(REQUEST_CHARS,m['characters']-index*REQUEST_CHARS);assert len(chunk)==expected;assert sum(len(read(q).encode())for q in parts)+len(chunk.encode())<=m['bytes']<=MAX_REQUEST,'Actual staged request capacity exceeded';create(p/f'{prefix}-chunk-{index:04d}.json',chunk)
 elif cmd=='transport-seal':
  p=transport_dir(sys.argv[3]);m=read(p/'metadata.json');parts=sorted(p.glob('actual-chunk-*.json'));assert len(parts)==m['chunks'];blob=''.join(read(p)for p in parts).encode();assert len(blob)==m['bytes']<=MAX_REQUEST and sha(blob)==m['requestSource']['sha256'];source=Path(m['requestSource']['path']);assert raw(source)==blob;actual=p/'actual-request.json'
  with (p/'source-reconstructed.json').open('xb')as f:f.write(blob);f.flush();os.fsync(f.fileno())
  dm=read(p/'dispatch-metadata.json');dispatch_parts=sorted(p.glob('dispatch-chunk-*.json'));assert len(dispatch_parts)==dm['chunks'];dispatch_blob=''.join(read(q)for q in dispatch_parts).encode();assert len(dispatch_blob)<=MAX_REQUEST;assert same_json(json.loads(dispatch_blob),json.loads(blob)),'Serialized ACTUAL JS dispatch differs from saved source (including numeric precision)'
  with actual.open('xb')as f:f.write(dispatch_blob);f.flush();os.fsync(f.fileno())
  create(p/'sealed.json',{'metadata':ref(p/'metadata.json'),'dispatchMetadata':ref(p/'dispatch-metadata.json'),'reconstructedSource':ref(p/'source-reconstructed.json'),'sourceChunks':[ref(q)for q in parts],'actualRequest':ref(actual),'chunks':[ref(q)for q in dispatch_parts],'requestSource':ref(source)});print(json.dumps({'transport':ref(p/'sealed.json')}))
 elif cmd=='begin':
  assert not rows or rows[-1]['kind']=='completion','Prior invocation incomplete'
  p=transport_dir(sys.argv[3]);sealed=read(p/'sealed.json');m=read(p/'metadata.json');ordinal=len(rows)//2+1;assert ordinal==m['ordinal']<=MAX_CALLS;assert ref(p/'metadata.json')==sealed['metadata'];actual_path=Path(sealed['actualRequest']['path']);assert ref(actual_path)==sealed['actualRequest'];assert len(sealed['chunks'])<=MAX_REQUEST//REQUEST_CHARS
  assert ref(p/'dispatch-metadata.json')==sealed['dispatchMetadata'];dm=read(p/'dispatch-metadata.json');assert len(sealed['chunks'])==dm['chunks'];assert len(sealed['sourceChunks'])==m['chunks']
  for part in sealed['chunks']+sealed['sourceChunks']:assert ref(Path(part['path']))==part
  assert ''.join(read(Path(part['path']))for part in sealed['chunks']).encode()==raw(actual_path)
  reconstructed=Path(sealed['reconstructedSource']['path']);assert ref(reconstructed)==sealed['reconstructedSource'];assert ''.join(read(Path(part['path']))for part in sealed['sourceChunks']).encode()==raw(reconstructed)
  source=Path(sealed['requestSource']['path']);assert ref(source)==sealed['requestSource']==m['requestSource'] and sha(raw(reconstructed))==m['requestSource']['sha256'];request=read(source);actual_invocation=read(actual_path);assert same_json(actual_invocation,request),'Actual serialized invocation differs from saved request'
  request_transport=ref(p/'sealed.json')
  assert re.fullmatch('mcp__t3_code__preview_[a-z_]+',request['tool']);assert request['args']['tabId']==read(directory/'intent.json')['tabId'];assert isinstance(request['purpose'],str)
  if request['tool'].endswith('preview_evaluate'):
   e=request['expressionSource'];p=Path(e['path']);assert p.is_absolute() and sha(raw(p))==e['sha256'] and p.read_text()==request['args']['expression'];assert isinstance(request['args']['expression'],str) and request['args']['expression']==request['args']['expression'].strip(),'Native expression has surrounding whitespace';assert request['args'].get('returnByValue') is True and request['args'].get('awaitPromise') is True
  p=directory/f'{ordinal:04d}.request.json';create(p,{'ordinal':ordinal,'clockBefore':stamp(),'invocation':request,'requestSource':ref(source),'requestTransport':request_transport});append('request',p,ordinal);print(json.dumps({'ordinal':ordinal,'request':ref(p)}))
 elif cmd=='chunk':
  ordinal=int(sys.argv[3]);index=int(sys.argv[4]);assert rows[-1]['kind']=='request' and rows[-1]['ordinal']==ordinal
  parts=list(directory.glob(f'{ordinal:04d}.chunk-*.json'));assert index==len(parts) and index<512
  chunk=json.loads(sys.argv[5]);assert isinstance(chunk,str) and len(chunk)<=16384;create(directory/f'{ordinal:04d}.chunk-{index:04d}.json',chunk)
 elif cmd=='finish':
  ordinal=int(sys.argv[3]);assert rows[-1]['kind']=='request' and rows[-1]['ordinal']==ordinal
  parts=sorted(directory.glob(f'{ordinal:04d}.chunk-*.json'));assert parts;blob=''.join(read(p)for p in parts).encode();assert len(blob)<=MAX_REPLY
  d=json.loads(blob);assert d['outcome'] in ['reply','throw'];reply=directory/f'{ordinal:04d}.reply.json'
  with reply.open('xb')as f:f.write(blob);f.flush();os.fsync(f.fileno())
  p=directory/f'{ordinal:04d}.completion.json';create(p,{'ordinal':ordinal,'clockAfter':stamp(),'request':rows[-1]['file'],'rawReply':ref(reply),'chunks':[ref(x)for x in parts],'outcome':d['outcome']});append('completion',p,ordinal);print(json.dumps({'ordinal':ordinal,'reply':ref(reply),'completion':ref(p)}))
 elif cmd=='seal':
  assert rows and rows[-1]['kind']=='completion' and len(rows)%2==0
  transports=sorted(directory.glob('*.transport'));assert len(transports)==len(rows)//2 and all((p/'sealed.json').is_file()for p in transports),'Orphan/incomplete actual request transport'
  h={'schema':1,'intent':ref(directory/'intent.json'),'initialization':ref(directory/'initialization.json'),'index':ref(directory/'index.jsonl'),'events':rows,'sealed':stamp(),'completeWrapperInvocationPairs':True,'scope':'ROOT-OWNED recorded calls under explicit exclusive coordination; not unknown user/platform/recorder events.'};create(directory/'history.json',h);print(json.dumps(ref(directory/'history.json')))
 else:raise ValueError(cmd)
