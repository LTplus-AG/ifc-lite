# Offline invocation correction — source version5

Only dynamic.py implementation differs from history-v4: both Node `-e` import harnesses insert a non-generator sentinel at argv[1] and consume generator/arguments from slice(2). Imported prepare/release generators therefore retain their intentional standalone CLI guard without accidentally executing it during offline reconstruction. All other implementation files are byte-identical copies; policy-v5, media-anchor-v3, functional-latch-v1, original470f collector, numerical/admission/lifecycle gates and request transport are unchanged.

The actual holter-v5-branch-case1 prepared intent/request and all31 prior frozen files remain unchanged. Its independent prelaunch failure is preserved; no native history, recording or browser load started for that case. Use NEW assembler-v4 case output after source approval, not edits to the prior case.

Offline controls reconstruct the ORIGINAL actual case's functional preparation byte-exactly and a generated release against the entire authentic refused host observation (explicit /observation pointer). Both old invocations fail and both corrected invocations reconstruct successfully. The host remains quiet=false: reconstruction is NOT admission, browser execution or recording feasibility. The initial offline control incorrectly looked for quiet at the audit envelope root; its KeyError and runner are preserved before the explicit-pointer correction.

See native-recording-invocation-fix-offline-v1/actual-run-v2/result.json and source.diff. The corrected helper freeze is version6; policy-v5 is reused unchanged. Concrete operator commands come from native-recording-case-assembler-v4/README.md and its prepared case, never manual modifications to printed native wrappers.
