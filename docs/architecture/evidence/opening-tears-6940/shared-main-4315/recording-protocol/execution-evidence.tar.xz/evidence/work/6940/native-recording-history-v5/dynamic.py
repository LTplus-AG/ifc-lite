"""Source-pinned reconstruction of genuine dynamic requests; no browser execution."""
from pathlib import Path
import hashlib,json,subprocess
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def release_request(intent,request):
 config=intent['dynamicRelease'];generator=config['generator'];assert generator==intent['sources']['releaseGenerator'] and Path(generator['path']).is_absolute() and H(generator['path'])==generator['sha256']
 assert request['dynamicHostObservation']['path']==config['hostObservationPath'] and request['dynamicHostObservation']['sha256']==H(config['hostObservationPath'])
 assert request['expressionSource']['path']==config['expressionPath'] and request['dynamicReleaseGenerator']==generator
 script="import{pathToFileURL}from'node:url';import fs from'node:fs';const[g,i,h,e]=process.argv.slice(2);const m=await import(pathToFileURL(g).href);process.stdout.write(JSON.stringify(m.build(JSON.parse(fs.readFileSync(i)),h,e)));"
 expected=json.loads(subprocess.check_output(['node','--input-type=module','-e',script,'ifc6940-offline-import',generator['path'],config['intentPath'],config['hostObservationPath'],config['expressionPath']]))
 assert request==expected,'Actual dynamic release differs from frozen generator and observed host data'
 return request['dynamicHostObservation']
def prepare_expression(intent,request):
 gen=intent['sources']['functionalPrepareGenerator'];base=intent['sources']['functionalBaseExpression'];assert H(gen['path'])==gen['sha256'] and H(base['path'])==base['sha256']
 identity={'id':intent['sampleId'],'head':intent['head'],'side':intent['side'],'epoch':intent['epoch'],'fixtureSHA256':intent['fixtureSHA256'],'fixtureBytes':intent['fixtureBytes'],'prepareGeneratorSHA256':gen['sha256'],'baseExpressionSHA256':base['sha256']}
 script="import{pathToFileURL}from'node:url';import fs from'node:fs';const[g,b,a]=process.argv.slice(2);const m=await import(pathToFileURL(g).href);process.stdout.write(m.prepare(fs.readFileSync(b,'utf8'),JSON.parse(a)));"
 expected=subprocess.check_output(['node','--input-type=module','-e',script,'ifc6940-offline-import',gen['path'],base['path'],json.dumps(identity,separators=(',',':'))]).decode()
 assert request['args']['expression']==expected,'Functional preparation differs from actual frozen base expression + latch generator'
 return {'generatorSHA256':gen['sha256'],'baseExpressionSHA256':base['sha256']}
