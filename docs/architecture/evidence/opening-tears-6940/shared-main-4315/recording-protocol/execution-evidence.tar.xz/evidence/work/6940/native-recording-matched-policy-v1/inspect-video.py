"""Decode and inspect the COMPLETE actual recording outside all timing windows.
This establishes media integrity only; lifecycle coverage remains a separate HOLD.
Usage: python3 inspect-video.py ACTUAL_VIDEO NEW_OUTPUT_DIRECTORY
"""
import datetime
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

video = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=False)
assert video.is_file()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):
    return {'path': str(p), 'sha256': sha(p)}
identity = {'path': str(video), 'sha256': sha(video), 'bytes': video.stat().st_size}
commands = {
    'probe': ['ffprobe', '-v', 'error', '-show_frames', '-show_streams', '-show_format', '-print_format', 'json', str(video)],
    # Match the source time base and preserve EVERY VFR frame. The null muxer's
    # default frame-rate time base otherwise rounds distinct source timestamps
    # onto duplicate output DTS values; raw ffprobe timestamps stay independent.
    'decode': ['ffmpeg', '-v', 'error', '-xerror', '-err_detect', 'explode', '-threads', '1', '-i', str(video), '-map', '0:v:0', '-fps_mode', 'passthrough', '-enc_time_base', '-1', '-f', 'null', '-'],
}
r = {'schema': 1, 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'videoPath': str(video), 'videoSha256': identity['sha256'], 'videoBytes': identity['bytes'],
     'scriptSHA256': sha(Path(__file__)), 'probeCommand': commands['probe'], 'decodeCommand': commands['decode'],
     'complete': False, 'lifecycleCoverageVerified': False, 'performanceQualification': False,
     'scope': 'Complete actual media decode and rational timestamp inspection only. Actual native/page lifecycle must be independently joined; no recording continuity inferred from a filename or average FPS.'}
start = time.monotonic()
try:
    assert 0 < identity['bytes'] <= 50 * 1024 * 1024
    for tool in ['ffmpeg', 'ffprobe']:
        (out / (tool + '-version.txt')).write_bytes(subprocess.check_output([tool, '-version']))
    for label, cmd in commands.items():
        stdout, stderr = out / (label + '.stdout'), out / (label + '.stderr')
        with stdout.open('xb') as so, stderr.open('xb') as se:
            result = subprocess.run(cmd, stdout=so, stderr=se, timeout=300)
        r[label + 'ExitCode'] = result.returncode
        assert result.returncode == 0 and stderr.stat().st_size == 0, label + ' failed; retain raw output'
    r['ffprobeOutput'] = ref(out / 'probe.stdout')
    r['decoderStderr'] = ref(out / 'decode.stderr')
    p = json.loads((out / 'probe.stdout').read_bytes())
    streams = [s for s in p['streams'] if s['codec_type'] == 'video']
    assert len(streams) == 1
    stream = streams[0]
    frames = [f for f in p['frames'] if f['media_type'] == 'video']
    assert frames and all(f['width'] == stream['width'] and f['height'] == stream['height'] for f in frames)
    timestamps = [int(f['best_effort_timestamp']) * Fraction(stream['time_base']) for f in frames]
    assert all(b > a for a, b in zip(timestamps, timestamps[1:]))
    duration = Fraction(p['format']['duration'])
    assert duration > 0 and timestamps[-1] - timestamps[0] <= duration
    r.update(durationSeconds=float(duration), videoFrameCount=len(frames),
             firstFrameTimestamp=str(timestamps[0]), lastFrameTimestamp=str(timestamps[-1]),
             monotoneFrameTimestamps=True, noDecodeErrors=True,
             configuredMode={'nativeTool': 'preview_recording_start', 'captureMode': 'native-default',
                             'width': stream['width'], 'height': stream['height'], 'codec': stream['codec_name']},
             observedTimeBase=stream['time_base'], observedAverageFrameRate=stream.get('avg_frame_rate'),
             complete=True)
except BaseException as e:
    r['error'] = {'type': type(e).__name__, 'message': str(e)}
finally:
    r['seconds'] = time.monotonic() - start
    r['videoUnchanged'] = video.stat().st_size == identity['bytes'] and sha(video) == identity['sha256']
    r['complete'] = r['complete'] and r['videoUnchanged']
    with (out / 'media-inspection.json').open('x') as f:
        json.dump(r, f, indent=2, allow_nan=False)
        f.write('\n')
print(json.dumps({k: r.get(k) for k in ['complete', 'videoUnchanged', 'videoFrameCount', 'durationSeconds', 'error']}))
raise SystemExit(0 if r['complete'] else 1)
