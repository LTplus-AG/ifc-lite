"""Offline ALL-frame optical anchors. No browser execution or performance verdict.
Usage: PYTHON detect.py INPUT-MANIFEST.json NEW-OUTPUT-DIRECTORY
Manifest refs: video, inspection, pre, post; each absolute path+SHA256, optional JSON pointer.
"""
from pathlib import Path
from fractions import Fraction
import hashlib,json,subprocess,sys,time,select,os,math
import numpy as np
src=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(ref,binary=False):
 p=Path(ref['path']);assert p.is_absolute() and sha(p)==ref['sha256'];
 if binary:return p
 d=json.loads(p.read_bytes())
 for part in ref.get('pointer','').split('/')[1:]:d=d[part.replace('~1','/').replace('~0','~')]
 return d
m=json.loads(src.read_text());initialManifestSHA256=sha(src);r={'schema':1,'protocol':'ifc6940-media-anchor-v1','ok':False,'performanceQualified':False,'manifestSHA256':sha(src),'detectorSHA256':sha(Path(__file__)),'scope':'Actual PRE and POST optical tokens in every decoded frame stream; native continuous lifecycle and original timing gates remain separate.'};started=time.monotonic()
try:
 video=load(m['video'],True);inspection=load(m['inspection']);pre=load(m['pre']);post=load(m['post'])
 assert inspection['complete'] and inspection['videoSha256']==sha(video)
 r['inputs']={k:m[k] for k in ['video','inspection','pre','post']};r['inputs']['ffprobeOutput']=inspection['ffprobeOutput'];r['inputManifestPath']=str(src)
 probe=load(inspection['ffprobeOutput']);streams=[s for s in probe['streams'] if s['codec_type']=='video'];assert len(streams)==1;s=streams[0]
 frames=[f for f in probe['frames'] if f['media_type']=='video'];pts=[Fraction(int(f['best_effort_timestamp']))*Fraction(s['time_base']) for f in frames];assert all(b>a for a,b in zip(pts,pts[1:]))
 for a,phase in [(pre,'pre'),(post,'post')]:
  assert a['protocol']==r['protocol'] and a['phase']==phase and a['action']=='show' and a['finished'] and a['markerPresent'] and len(a['frames'])==60
  assert a['source']=={'head':a['head'],'side':a['side'],'epoch':a['epoch']}
  assert all(math.isfinite(t) and a['startNow']<=t<=a['finishNow'] for t in a['frames']) and all(v>u for u,v in zip(a['frames'],a['frames'][1:]))
  identity={k:a[k] for k in ['protocol','statusKind','phase','id','tabId','head','side','epoch','nonce']}
  token=hashlib.sha256(json.dumps(identity,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()[:32];assert token==a['token']
 for k in ['statusKind','id','tabId','head','side','epoch','nonce','viewport','rect','timeOrigin']:assert pre[k]==post[k],k
 assert pre['statusKind'] in ['timed','functional']
 if pre['statusKind']=='functional':
  for a in [pre,post]:
   for f in [a['functionalReceiptBefore'],a['functionalReceiptAfter']]:
    if a['phase']=='pre':assert f is None
    else:assert f['id']==a['id'] and f['ok'] and f['functionalOnly'] and f['noTimingQualification'] and f['source']==a['source']
 else:assert post['collectorBefore']['id']==post['id']
 assert pre['token']!=post['token'] and pre['finishNow']<post['startNow'];assert post['collectorBefore']['stage']=='done' and post['collectorBefore']['persistence']=='saved'
 v=pre['viewport'];rect=pre['rect'];sx=Fraction(s['width'],v['innerWidth']);sy=Fraction(s['height'],v['innerHeight']);assert sx==sy==Fraction(v['devicePixelRatio']),'Unsupported scale/letterbox; do not guess crop'
 assert rect=={'x':24,'y':24,'width':160,'height':160}
 raw=[Fraction(rect[k])*sx for k in ['x','y','width','height']];assert all(x.denominator==1 for x in raw);x,y,w,h=map(int,raw);assert (w%20,h%20)==(0,0)
 def pattern(token):
  bits=[(int(c,16)>>k)&1 for c in token for k in [3,2,1,0]]
  return np.array([[(xx*3+yy*5+xx//2)%2 if xx<2 or yy<2 or xx>=18 or yy>=18 else bits[((yy-2)*16+xx-2)%128]^int(yy>=10) for xx in range(20)]for yy in range(20)],dtype=bool)
 patterns=[pattern(pre['token']),pattern(post['token'])];matches=[[],[]];minimum=[400,400];size=w*h*3
 cmd=['ffmpeg','-v','error','-xerror','-err_detect','explode','-threads','1','-i',str(video),'-map','0:v:0','-vf',f'crop={w}:{h}:{x}:{y}','-fps_mode','passthrough','-enc_time_base','-1','-pix_fmt','rgb24','-f','rawvideo','pipe:1'];r['command']=cmd
 (out/'ffmpeg-version.txt').write_bytes(subprocess.check_output(['ffmpeg','-version']))
 with (out/'decode.stderr').open('xb') as err:
  proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=err);index=0;deadline=time.monotonic()+300
  try:
   while True:
    data=bytearray()
    while len(data)<size:
     remaining=deadline-time.monotonic();assert remaining>0,'Decode deadline'
     ready,_,_=select.select([proc.stdout],[],[],remaining);assert ready,'Decode deadline'
     chunk=os.read(proc.stdout.fileno(),size-len(data))
     if not chunk:break
     data.extend(chunk)
    if not data:break
    assert len(data)==size and index<len(frames),'Incomplete/extra decoded frame'
    image=np.frombuffer(data,dtype=np.uint8).reshape(h,w,3);cw=w//20;ch=h//20
    cells=image.reshape(20,ch,20,cw,3).transpose(0,2,1,3,4)[:,:,ch//4:ch-ch//4,cw//4:cw-cw//4,:]
    black=np.max(cells,axis=(2,3,4))<=48;white=np.min(cells,axis=(2,3,4))>=207
    for j,p in enumerate(patterns):
     wrong=int(np.count_nonzero(~np.where(p,white,black)));minimum[j]=min(minimum[j],wrong)
     if wrong==0:matches[j].append(index)
    index+=1
   code=proc.wait(timeout=30)
  finally:
   proc.stdout.close()
   if proc.poll() is None:proc.kill();proc.wait()
 r['decodeExitCode']=code;r['decoderStderr']={'path':str((out/'decode.stderr').resolve()),'sha256':sha(out/'decode.stderr')}
 assert code==0 and (out/'decode.stderr').stat().st_size==0 and index==len(frames)
 assert sha(video)==m['video']['sha256'],'Video changed during inspection'
 r.update(decodedFrames=index,videoSHA256=sha(video),timeBase=s['time_base'],crop=[x,y,w,h],minimumWrongCells=minimum,matches=[{'phase':phase,'token':a['token'],'frames':idx,'pts':[str(pts[i])for i in idx]}for phase,a,idx in zip(['pre','post'],[pre,post],matches)])
 assert all(len(x)>=3 for x in matches),'Missing/trimmed/undecodable marker'
 assert max(matches[0])<min(matches[1]),'Overlapping/reversed markers'
 assert all(any(b==a+1 and c==b+1 for a,b,c in zip(idx,idx[1:],idx[2:]))for idx in matches),'Need three consecutive actual frames per anchor'
 assert sha(src)==initialManifestSHA256,'Manifest changed during decode'
 for ref in r['inputs'].values():assert sha(Path(ref['path']))==ref['sha256'],'Referenced input changed during decode'
 r['inputsUnchanged']=True;r['ok']=True
except BaseException as exc:r['error']=repr(exc)
finally:
 r['seconds']=time.monotonic()-started;(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
if not r['ok']:raise SystemExit(1)
