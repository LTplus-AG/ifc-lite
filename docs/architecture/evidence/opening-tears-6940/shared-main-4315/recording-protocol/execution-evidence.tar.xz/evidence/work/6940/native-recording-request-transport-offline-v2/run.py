"""OFFLINE request transport only, using authentic saved host bytes. NO native tool.
Usage: python3 run.py NEW_OUTPUT_DIRECTORY
Positive remains an incomplete/unsealable native history, not recording evidence.
"""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent;HELPER=ROOT/'native-recording-history-v4';OUT=Path(sys.argv[1]).resolve();OUT.mkdir()
HOST=ROOT/'shared-main-browser-v1/host-audit-before-feasibility/stdout.json';HOST_BYTES=HOST.read_bytes();assert len(HOST_BYTES)>128*1024
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before={str(p):H(p)for p in [Path(__file__),HOST,*HELPER.glob('*.py'),*HELPER.glob('*.mjs')]}
expression='('+HOST_BYTES.decode().strip()+')';ep=OUT/'authentic-host-expression.js';ep.write_text(expression)
base={'purpose':'OFFLINE-TRANSPORT-ONLY','tool':'mcp__t3_code__preview_evaluate','args':{'tabId':'NO-NATIVE-INVOCATION','expression':expression,'awaitPromise':True,'returnByValue':True},'expressionSource':{'path':str(ep),'sha256':H(ep)}}
calls=[];cases=[]
def run(args,success=True):
 cmd=['python3',str(HELPER/'journal.py'),*map(str,args)];r=subprocess.run(cmd,capture_output=True,text=True);i=len(calls);stdout=OUT/f'{i:03d}.stdout';stderr=OUT/f'{i:03d}.stderr';stdout.write_text(r.stdout);stderr.write_text(r.stderr)
 calls.append({'argvSHA256':[hashlib.sha256(s.encode()).hexdigest()for s in cmd],'maximumArgumentBytes':max(len(s.encode())for s in cmd),'exitCode':r.returncode,'expectedSuccess':success,'stdout':{'path':str(stdout),'sha256':H(stdout)},'stderr':{'path':str(stderr),'sha256':H(stderr)}});assert(r.returncode==0)==success,r.stderr
 return json.loads(r.stdout)if success and r.stdout.strip()else None
for name in ['authentic-host','precision-negative','boolean-negative']:
 d=OUT/name;d.mkdir();request=json.loads(json.dumps(base));
 if name=='precision-negative':request['offlinePrecisionWitness']=9007199254740993
 rp=d/'request.json';rp.write_text(json.dumps(request,ensure_ascii=False,indent=2)+'\n');intent=d/'intent.json';intent.write_text(json.dumps({'exclusiveRootOwnedBrowserControl':True,'statusKind':'functional','sampleId':'OFFLINE-ONLY-NOT-A-CASE','tabId':'NO-NATIVE-INVOCATION','head':'0'*40,'scope':'Recorder protocol only; no actual native invocation or passing history'})+'\n')
 session=d/'session';run(['init',session,intent]);t=run(['transport-init',session,rp,H(rp)]);parts=[run(['request-slice',session,t['token'],i])['chunk']for i in range(t['chunks'])];assert ''.join(parts)==rp.read_text()
 if name=='authentic-host':
  run(['transport-chunk',session,t['token'],1,json.dumps(parts[1])],False)
  run(['transport-chunk',session,t['token'],0,json.dumps(parts[0])]);run(['transport-chunk',session,t['token'],0,json.dumps(parts[0])],False);run(['transport-seal',session,t['token']],False)
  start=1
 else:start=0
 for i,p in enumerate(parts[start:],start):run(['transport-chunk',session,t['token'],i,json.dumps(p)])
 script="const fs=require('node:fs');const r=JSON.parse(fs.readFileSync(process.argv[1]));if(process.argv[2]==='boolean-negative')r.args.awaitPromise=1;process.stdout.write(JSON.stringify(r));"
 js=subprocess.run(['node','-e',script,str(rp),name],capture_output=True,text=True);assert js.returncode==0;dispatch=js.stdout;(d/'actual-JS-serialization.json').write_text(dispatch);dp=[dispatch[i:i+4096]for i in range(0,len(dispatch),4096)];run(['dispatch-init',session,t['token'],len(dispatch),len(dp)])
 for i,p in enumerate(dp):run(['dispatch-chunk',session,t['token'],i,json.dumps(p)])
 run(['transport-seal',session,t['token']],name=='authentic-host')
 if name=='authentic-host':
  run(['begin',session,t['token']]);run(['seal',session],False);transport=session/(t['token']+'.transport');assert(transport/'source-reconstructed.json').read_bytes()==rp.read_bytes();assert(transport/'actual-request.json').read_text()==dispatch
 emitter=subprocess.run(['node',str(HELPER/'emit-invocation.mjs'),str(session),str(rp)],capture_output=True,text=True);assert emitter.returncode==0;(d/'wrapper-NOT-EXECUTED.js').write_text(emitter.stdout);assert len(emitter.stdout.encode())<10000
 cases.append({'name':name,'sourceRequestBytes':rp.stat().st_size,'sourceRequestSHA256':H(rp),'wrapperBytes':len(emitter.stdout.encode()),'actualJSDispatchSHA256':H(d/'actual-JS-serialization.json'),'transportAccepted':name=='authentic-host','nativeInvocations':0,'adversarialMutation':name!='authentic-host'})
assert all(H(p)==h for p,h in before.items())
result={'schema':1,'scope':'Pure offline request protocol; authentic preserved full host input and explicitly marked negative mutations; ZERO native/browser calls, no passing recording history or feasibility/timing claim','host':{'path':str(HOST),'sha256':H(HOST),'bytes':len(HOST_BYTES)},'sourceBeforeAfter':before,'sourceUnchanged':True,'cases':cases,'calls':calls,'maximumArgumentBytes':max(c['maximumArgumentBytes']for c in calls),'nativeInvocations':0,'noPassingRecordingHistory':True};(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cases':cases,'maximumArgumentBytes':result['maximumArgumentBytes'],'nativeInvocations':0}))
