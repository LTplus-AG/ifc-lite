"""Archive authentic recorded feasibility and failed timing evidence; never run it."""
from pathlib import Path
import hashlib,json,tarfile,subprocess,re,time
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work/6940';OUT=W/'reviewable-proof-pack-recording-protocol-v3';OUT.mkdir()
selected={};external={};references=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def add(p,expected=None,reason='selected evidence'):
 p=Path(p)
 if not p.is_absolute():p=ROOT/p
 p=p.resolve()
 if not p.is_relative_to(ROOT) or p.suffix.lower() in {'.ifc','.wasm','.mp4','.webm','.exe','.dll','.so','.pyc'} or any(s in p.parts for s in ('node_modules','target','__pycache__','dist','pkg')):
  external[str(p)]={'sha256':expected,'reason':'Intentionally excluded fixture/runtime/video/tool or outside owned repository evidence; not embedded or re-executed.'};return
 if not p.is_file():external[str(p)]={'sha256':expected,'reason':'Referenced path unavailable or directory; no bytes fabricated.'};return
 b=p.read_bytes();h=sha(b)
 assert not b.startswith((b'\x7fELF',b'\x00asm')),p
 if expected is not None and h!=expected:
  external[str(p)+'#sha256='+expected]={'path':str(p),'sha256':expected,'currentSha256':h,'reason':'Historical reference no longer matches current file. Original receipt retained; current source is not substituted for historical bytes.'};return
 selected[p]={'original':str(p),'path':'evidence/'+p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':len(b),'storage':'archive'}
def tree(name):
 for p in (W/name).rglob('*'):
  if p.is_file():add(p)
for n in ['holter-v7-base-case1','holter-v7-branch-case5','browser-final30-shared56a5-4315-v1','final30-shared-main-command-map-v1','holter-v7-actual-preparation-v1','native-recording-first-frame-class-review-v1','native-recording-first-frame-class-independent-review-v1','holter-v7-base-case1-validator-trace-v1','holter-v7-branch-case5-validator-trace-v1','holter-v7-branch-case5-host-policy-independent-review-v1','native-recording-helper-independent-review-v7','shared-main-browser-v1/owner-extension-1945-readonly-v1']:
 tree(n)
for n in ['native-recording-final-helper-freeze-v7.json','native-recording-first-frame-class-marker-controls-v1.json','operator-idle-wait-policy-v1.json','host-idle-wait-operator-v1.py','root-timed-case-operator-v1.js','root-timed-case-operator-v2.js','final30-assembler-4a9b-independent-source-review-v1.json']:
 add(W/n)
for id in ['functional-holter-base-recorded-shared56a5-v7-case1','functional-holter-branch-recorded-shared56a5-v7-case5','perf6940-fzk-r1-base-shared56a5-4315-v1','perf6940-fzk-r1-branch-shared56a5-4315-v1']:
 for ext in ['begin.json','result.json']:add(W/'shared-main-browser-v1/receipts'/f'{id}.{ext}')
# The ordinary complete Holter controls are retained alongside recorded results.
for side in ('base','branch'):add(W/'shared-main-browser-v1/receipts'/f'functional-holter-{side}-shared56a5-v1.result.json')
add(ROOT/'LICENSE');add(Path(__file__))
def ref(p,h,owner):
 if isinstance(p,str)and p.startswith('/')and isinstance(h,str)and re.fullmatch('[0-9a-f]{64}',h):
  references.append({'owner':owner,'path':p,'sha256':h});add(p,h)
def visit(v,owner):
 if isinstance(v,dict):
  ref(v.get('path'),v.get('sha256'),owner)
  for k,val in v.items():
   # Includes freeze file maps and actual validated-input maps.
   ref(k,val,owner)
   visit(val,owner)
 elif isinstance(v,list):
  for x in v:visit(x,owner)
done=set(); retained_json_parse_failures=[]
while set(selected)-done:
 for p in sorted(set(selected)-done):
  done.add(p)
  if p.suffix=='.json':
   try: value=json.loads(p.read_bytes())
   except (json.JSONDecodeError,UnicodeDecodeError) as error:
    retained_json_parse_failures.append({'path':str(p),'error':str(error),'bytes':p.stat().st_size});continue
   visit(value,str(p))
# Ensure exactly every V7 and class-freeze source is present or explicitly external.
for name in ['native-recording-final-helper-freeze-v7.json','native-recording-first-frame-class-review-v1/freeze.json']:
 x=json.loads((W/name).read_text())
 for p,h in x['files'].items():assert Path(p)in selected and selected[Path(p)]['sha256']==h,(name,p)
# High-confidence token checks, not an assertion that arbitrary logs are universally secret-free.
patterns=[rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'github_pat_[A-Za-z0-9_]{40,}',rb'AKIA[0-9A-Z]{16}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'Bearer [A-Za-z0-9._~-]{32,}']
findings=[]
for p in selected:
 b=p.read_bytes()
 for pattern in patterns:
  if re.search(pattern,b):findings.append({'path':str(p),'pattern':pattern.decode()})
# The archive builder's literal regex is not a credential; private-key syntax matches only real banner text.
assert not findings,findings
rows=[selected[p]for p in sorted(selected)];a=OUT/'execution-evidence.tar.xz';cmd=['xz','--threads=1','--check=crc64','--lzma2=preset=6,dict=256MiB','--stdout'];start=time.monotonic()
with a.open('xb')as dest,(OUT/'compression.stderr').open('xb')as err:
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=dest,stderr=err)
 try:
  with tarfile.open(fileobj=proc.stdin,mode='w|',format=tarfile.USTAR_FORMAT)as tar:
   for e in rows:
    p=Path(e['original']);assert sha(p.read_bytes())==e['sha256'];t=tarfile.TarInfo(e['path']);t.size=e['bytes'];t.mode=0o644
    with p.open('rb')as src:tar.addfile(t,src)
  proc.stdin.close();assert proc.wait()==0
 finally:
  if proc.poll()is None:proc.kill();proc.wait()
byname={r['path']:r for r in rows};seen=set()
with tarfile.open(a,'r|xz')as t:
 for member in t:
  assert member.isfile()and member.name in byname and member.name not in seen and '..'not in Path(member.name).parts and not member.name.startswith('/');seen.add(member.name);e=byname[member.name];b=t.extractfile(member).read();assert len(b)==e['bytes']and sha(b)==e['sha256']
assert seen==set(byname)
for e in rows:assert sha(Path(e['original']).read_bytes())==e['sha256']
manifest={'schema':1,'scope':'STAGING ONLY: two actual untimed recorded functional feasibility cases plus failed/incomplete finite30 attempt. Performance UNQUALIFIED.','executionHeads':{'base':'56a5f58c325997c4c7ec460456a9e150437718cd','branch':'431571bdb96a20a73b19907c2c3ec05dc7733f43'},'archive':{'path':a.name,'sha256':sha(a.read_bytes()),'bytes':a.stat().st_size,'members':len(rows),'uncompressedMemberBytes':sum(r['bytes']for r in rows),'allExtractedMembersRehashed':True,'allOriginalsUnchanged':True,'deterministicConstruction':{'tar':'USTAR sorted paths, mode0644, uid/gid/mtime0, no names','compressor':cmd,'version':subprocess.check_output(['xz','--version'],text=True),'repeatCompressionPerformed':False}},'files':rows,'externalReferences':external,'retainedJsonParseFailures':retained_json_parse_failures,'structuredReferenceCount':len(references),'referenceClosureScope':'Absolute path+sha256 objects and absolute-key SHA maps recursively included or explicitly external. Bare strings, relative source inventories, arbitrary embedded strings, environment/dependency/OS closure are not automatically embedded. All34V7 files and complete final class-freeze files verified.','secretScan':{'highConfidencePatterns':[x.decode()for x in patterns],'findings':findings,'scope':'No matching credential forms. Not a universal privacy or secret-free guarantee; own native/host audit receipts retain observed process names/paths, not foreign userdata files.'},'elapsedSeconds':time.monotonic()-start,'geometryReexecuted':False,'mediaReexecuted':False,'performanceQualified':False,'published':False}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'reference-closure.json').write_text(json.dumps(references,indent=2)+'\n')
print(json.dumps({'packet':str(OUT),'archive':manifest['archive'],'externalReferences':len(external),'structuredReferences':len(references),'secretMatches':len(findings)}),flush=True)
