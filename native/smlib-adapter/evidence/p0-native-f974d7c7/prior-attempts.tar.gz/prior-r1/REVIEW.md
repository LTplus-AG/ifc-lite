# P0 native surface query correction: runtime evidence pending

Base: `01abf2b4d940ac94eaddc58794d52767cc2984e0`.
SDK pin: `c9c5979f04cea8c38213004d4f04df0dcfb40d05`.
Candidate file hashes and execution status are in `summary.json`.

The historical source331 receipt establishes successful build/link, upload
transport and worker framing, followed by an owned-boundary abort on actual
planar/curved surface counts. It contains no fixture name or observed count.
Its retained log is
`docs/architecture/evidence/geometry-platform-retained-review/curved-round3-delivery/receipts/fbacabd8-8b31-46d8-b433-19690d89c074-output.log.gz`.
The cause of that historical failure remains unconfirmed.

The pinned SDK's `SmSurface.cpp` implements `IsPlanar` using
`CalculateBoundingBox` with default expansion enabled. Its Bezier pseudo-box
branch expands by radius/20. `SmPrimitiveCreation.cpp` creates an analytic
plane for an orthogonal line/sweep pair, but a general surface of extrusion
otherwise. Thus a geometric plane can fail the original query without any
geometric defect. `scalar-plane.json` illustrates the oblique fixture's plane:
corner error is at most approximately 2.2e-16 while the default box expansion
is 0.125. These are independent scalar calculations, not SDK execution.

The candidate replaces the geometric classification query specifically for
general extrusion surfaces. It obtains every Cartesian generator control
point and its rational weight. Empty weights denote a nonrational curve;
rational weights must be positive and finite. A plane containing the entire
control hull and parallel to the extrusion direction contains the entire
rational surface. The check includes numerical sweep-normal residual over
the finite STEP extrusion interval, then checks 25 independently evaluated
surface points against that plane. All comparisons retain `1e-8`. The SDK
query and certificate deviations are logged separately. Expected plane,
curved and cylinder counts, analytic volumes/bounds, section lengths and
boundary assertions are preserved. Direct SDK regressions cover oblique
planes in both UV arrangements and rejection of a curved extrusion.

Actual-header C++17 syntax checking of `tests/sweep_region_tests.cpp` passed
with `SM_NO_DEBUG_CODE`, `SM_NO_GFX_OUTPUT_CODE`, `NDEBUG`, the adapter's
`src`/`include` directories, and the pinned SDK's SMLib/SM_API include paths.
This establishes parsing and header correspondence only.

Exactly one fresh request was submitted, for the unchanged base source:
`auto-359d868f3f7b40208e2d9ea9a80dc995`, job
`365bee07-e8ab-42ed-91e8-d7eccf9acb38`, host `pop-os`.
The unmodified request, receipt and output are copied here with SHA-256 hashes
in `summary.json`. Admission passed. The command then failed before CMake
because the environment wrapper was invoked directly and lacked execute
permission. It must be invoked with `bash`, as documented in the adapter
README. No request was retried; no foreign job, lock, SDK or source was changed.

Current-source CTest: **NOT RUN**. Current-source real SDK witness: **NOT RUN**.
Candidate build/link and new assertions: **NOT RUN**. These were not successful
tests or optional skips; execution was blocked before configuration. A final
committed-source qualification with the corrected wrapper invocation is still
required before this candidate can resolve the native qualification blocker.
No browser or product qualification follows from this work. The exact kernel
remains the permanent default; this change introduces no product selection or
substitution behavior.
