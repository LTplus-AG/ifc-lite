// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Unwrapping a representation item to the solid it ends in (ROUTER-4).
//!
//! The void probes, the host-extrusion reader and the layer slicer each walked
//! the same `IfcBooleanResult -> FirstOperand` / `IfcMappedItem ->
//! MappedRepresentation -> Items[0]` chain with a loop of their own, and the
//! four loops had drifted on exactly the points [`UnwrapPolicy`] now names:
//! which wrappers they follow, whether a multi-item map is refused or read at
//! its first item, how the mapping chain is accumulated, and how the walk is
//! bounded. Those differences are kept (this is a refactor; reconciling them
//! would change which openings take a fast path), but each is now a visible
//! field of the call instead of a property of a pasted loop.
//!
//! The walk is iterative with a visited set, so a self-referential chain ends
//! instead of recursing (AGENTS.md "Bounding walks"). `max_nodes` additionally
//! bounds a long acyclic chain for the callers that always did.

use ifc_lite_core::{DecodedEntity, EntityDecoder};
use nalgebra::Matrix4;
use rustc_hash::FxHashSet;

/// How the mapping transforms met on the way are accumulated.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum ChainSeed {
    /// Start from the identity and multiply each map in (`chain *= map`). The
    /// chain is a matrix even when no map was met.
    Identity,
    /// The first map IS the chain; later maps multiply on its right. Whether a
    /// map was met at all is [`Unwrapped::mapped`].
    FirstMap,
}

/// What an unwrapping call follows and how it is bounded.
#[derive(Clone, Copy)]
pub(crate) struct UnwrapPolicy {
    /// Follow `IfcBooleanClippingResult` / `IfcBooleanResult` to `FirstOperand`.
    pub through_booleans: bool,
    /// Follow `IfcMappedItem` into its mapped representation. A map that is not
    /// followed is returned as the leaf.
    pub through_maps: bool,
    /// A mapped representation must hold EXACTLY one item, else the whole walk
    /// gives up. When false its first item is read and the rest are dropped.
    pub single_item: bool,
    /// How the mapping transforms are accumulated.
    pub seed: ChainSeed,
    /// At most this many nodes are examined (leaf included); the walk gives up
    /// on the next. `None` bounds the walk by the visited set alone.
    pub max_nodes: Option<usize>,
}

/// The end of an unwrapping walk.
pub(crate) struct Unwrapped {
    /// The first node the policy does not follow. Its type is the caller's to
    /// check.
    pub leaf: DecodedEntity,
    /// The mapping transforms met on the way, per [`ChainSeed`]. The identity
    /// when none was met.
    pub chain: Matrix4<f64>,
    /// Whether any mapping transform contributed to `chain`.
    pub mapped: bool,
}

/// Unwrap `item` per `policy`. `None` when the chain is malformed or cyclic, a
/// mapping transform fails to compose (the caller then defers to the exact
/// kernel rather than read a frame it knows is wrong), or `max_nodes` is
/// exceeded.
pub(crate) fn unwrap_solid(
    item: DecodedEntity,
    decoder: &mut EntityDecoder,
    policy: &UnwrapPolicy,
) -> Option<Unwrapped> {
    let mut current = item;
    let mut chain = Matrix4::<f64>::identity();
    let mut mapped = false;
    let mut visited: FxHashSet<u32> = FxHashSet::default();
    let mut nodes = 0usize;
    loop {
        nodes += 1;
        if policy.max_nodes.is_some_and(|max| nodes > max) {
            return None;
        }
        let is_boolean = policy.through_booleans
            && matches!(
                current.ifc_type,
                ifc_lite_core::IfcType::IfcBooleanClippingResult
                    | ifc_lite_core::IfcType::IfcBooleanResult
            );
        let is_map = policy.through_maps && current.ifc_type == ifc_lite_core::IfcType::IfcMappedItem;
        if !is_boolean && !is_map {
            return Some(Unwrapped { leaf: current, chain, mapped });
        }
        // Only a followed wrapper can recur, so only wrappers enter the set.
        if !visited.insert(current.id) {
            return None;
        }
        if is_boolean {
            // FirstOperand (attribute 1) carries the base geometry.
            current = decoder.resolve_ref(current.get(1)?).ok()??;
            continue;
        }
        // MappingSource (attribute 0) -> RepresentationMap.MappedRepresentation
        // (attribute 1) -> Items (attribute 3).
        let source = decoder.resolve_ref(current.get(0)?).ok()??;
        let mapped_rep = decoder.resolve_ref(source.get(1)?).ok()??;
        // MappingTarget · MappingOrigin, matching the mesh path (#1985). A
        // composition that fails to parse abandons the walk instead of
        // continuing with an identity chain, which would recover geometry in the
        // wrong frame.
        if let Some(map) = crate::representation::mapped_item_local_transform(&current, &source, decoder).ok()? {
            match policy.seed {
                ChainSeed::Identity => chain *= map,
                ChainSeed::FirstMap => chain = if mapped { chain * map } else { map },
            }
            mapped = true;
        }
        let mut items = decoder.resolve_ref_list(mapped_rep.get(3)?).ok()?.into_iter();
        let first = items.next()?;
        if policy.single_item && items.next().is_some() {
            return None;
        }
        current = first;
    }
}

#[cfg(test)]
#[path = "unwrap_tests.rs"]
mod tests;
