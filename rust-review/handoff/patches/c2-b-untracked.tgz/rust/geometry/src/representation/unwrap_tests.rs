// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! `unwrap_solid` on small STEP fixtures: what each policy follows, how the
//! mapping chain is seeded, and the bounds (cycle, node cap, malformed links).

use super::*;
use ifc_lite_core::{EntityDecoder, IfcType};

/// #10: extrusion. #11: boolean over #10. #12: boolean over #11. #20: map
/// (translation 1,0,0 via the origin) over rep #22 holding the extrusion #10.
/// #21: map over rep #23 holding TWO items. #30: boolean cycle. #40: map with the identity
/// origin. #50: chain of `N` booleans.
fn model(chain: usize) -> String {
    let mut s = String::from(
        "#1=IFCCARTESIANPOINT((0.,0.,0.));#2=IFCCARTESIANPOINT((1.,0.,0.));\
         #3=IFCAXIS2PLACEMENT3D(#2,$,$);#4=IFCAXIS2PLACEMENT3D(#1,$,$);\
         #10=IFCEXTRUDEDAREASOLID($,$,$,1.);\
         #11=IFCBOOLEANCLIPPINGRESULT(.DIFFERENCE.,#10,#10);\
         #12=IFCBOOLEANCLIPPINGRESULT(.DIFFERENCE.,#11,#10);\
         #14=IFCREPRESENTATIONMAP(#3,#22);#22=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#10));\
         #20=IFCMAPPEDITEM(#14,$);\
         #15=IFCREPRESENTATIONMAP(#3,#23);#23=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#10,#11));\
         #21=IFCMAPPEDITEM(#15,$);\
         #30=IFCBOOLEANRESULT(.DIFFERENCE.,#30,#10);\
         #16=IFCREPRESENTATIONMAP(#3,#24);#24=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#12));\
         #25=IFCMAPPEDITEM(#16,$);\
         #40=IFCREPRESENTATIONMAP(#4,#26);#26=IFCSHAPEREPRESENTATION($,'Body','SweptSolid',(#10));\
         #41=IFCMAPPEDITEM(#40,$);",
    );
    // A chain of `chain` booleans: #100 -> #101 -> ... -> #10.
    for i in 0..chain {
        let next = if i + 1 == chain { 10 } else { 101 + i };
        s.push_str(&format!("#{}=IFCBOOLEANCLIPPINGRESULT(.DIFFERENCE.,#{next},#10);", 100 + i));
    }
    s
}

const BOOLEANS_AND_MAPS: UnwrapPolicy = UnwrapPolicy {
    through_booleans: true,
    through_maps: true,
    single_item: false,
    seed: ChainSeed::FirstMap,
    max_nodes: Some(32),
};

fn run(content: &str, id: u32, policy: &UnwrapPolicy) -> Option<Unwrapped> {
    let mut d = EntityDecoder::new(content);
    let item = d.decode_by_id(id).unwrap();
    unwrap_solid(item, &mut d, policy)
}

#[test]
fn follows_booleans_to_the_first_operand_and_maps_to_the_first_item() {
    let m = model(0);
    let u = run(&m, 12, &BOOLEANS_AND_MAPS).unwrap();
    assert_eq!((u.leaf.id, u.mapped), (10, false));
    // The map's origin translates by +1 in x.
    let u = run(&m, 20, &BOOLEANS_AND_MAPS).unwrap();
    assert_eq!((u.leaf.id, u.mapped), (10, true));
    assert_eq!(u.chain[(0, 3)], 1.0);
    // A map holding two items is read at its first when the policy allows it.
    assert_eq!(run(&m, 21, &BOOLEANS_AND_MAPS).unwrap().leaf.id, 10);
}

#[test]
fn a_policy_that_does_not_follow_a_wrapper_returns_it_as_the_leaf() {
    let m = model(0);
    let maps_only = UnwrapPolicy { through_booleans: false, ..BOOLEANS_AND_MAPS };
    let u = run(&m, 12, &maps_only).unwrap();
    assert_eq!((u.leaf.id, u.leaf.ifc_type), (12, IfcType::IfcBooleanClippingResult));
    let booleans_only = UnwrapPolicy { through_maps: false, ..BOOLEANS_AND_MAPS };
    assert_eq!(run(&m, 20, &booleans_only).unwrap().leaf.ifc_type, IfcType::IfcMappedItem);
}

#[test]
fn single_item_refuses_a_multi_item_map() {
    let m = model(0);
    let single = UnwrapPolicy { single_item: true, ..BOOLEANS_AND_MAPS };
    assert!(run(&m, 21, &single).is_none());
    assert_eq!(run(&m, 20, &single).unwrap().leaf.id, 10);
}

#[test]
fn the_seed_decides_the_chain_when_no_map_contributes() {
    let m = model(0);
    let first = run(&m, 41, &BOOLEANS_AND_MAPS).unwrap();
    // Origin at the placement origin: the identity contributes nothing.
    assert_eq!(first.mapped, false);
    let identity = UnwrapPolicy { seed: ChainSeed::Identity, ..BOOLEANS_AND_MAPS };
    let u = run(&m, 20, &identity).unwrap();
    assert_eq!(u.chain[(0, 3)], 1.0);
    assert!(u.mapped);
}

#[test]
fn a_boolean_cycle_ends_instead_of_looping() {
    let m = model(0);
    assert!(run(&m, 30, &BOOLEANS_AND_MAPS).is_none());
    let uncapped = UnwrapPolicy { max_nodes: None, ..BOOLEANS_AND_MAPS };
    assert!(run(&m, 30, &uncapped).is_none());
}

#[test]
fn max_nodes_counts_the_leaf_and_none_is_bounded_by_the_visited_set() {
    // 31 booleans + the extrusion = 32 nodes: the cap admits it, 33 refuses.
    assert_eq!(run(&model(31), 100, &BOOLEANS_AND_MAPS).unwrap().leaf.id, 10);
    assert!(run(&model(32), 100, &BOOLEANS_AND_MAPS).is_none());
    // Revit chains run past any cap (#960): unbounded policies still arrive.
    let uncapped = UnwrapPolicy { max_nodes: None, ..BOOLEANS_AND_MAPS };
    assert_eq!(run(&model(200), 100, &uncapped).unwrap().leaf.id, 10);
}
