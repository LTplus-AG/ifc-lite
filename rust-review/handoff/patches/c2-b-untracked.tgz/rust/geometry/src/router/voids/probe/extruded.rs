// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! The 2D-path probes: a host or opening body read as extruded solids with
//! their full profiles ([`super::super::bool2d_path`]).

use super::{GeometryRouter, EXTRUDED_WALK};
use crate::profile::Profile2D;
use crate::profiles::ProfileProcessor;
use crate::representation::unwrap_solid;
use ifc_lite_core::{DecodedEntity, EntityDecoder, IfcType};
use nalgebra::Matrix4;

/// A host or opening solid recovered as a single IfcExtrudedAreaSolid swept along
/// its profile normal (local ±Z), for the 2D opening-subtraction fast path
/// ([`super::super::bool2d_path`]). `m` maps profile-local coordinates (profile in the
/// z=0 plane, swept to `dir_sign·depth`) to NATIVE world (pre unit-scale / RTC),
/// composed as `placement · mapped-chain · solid-Position`.
pub(in crate::router::voids) struct ExtrudedSolidInfo {
    /// Full 2D profile (outer + any holes) in the solid's profile plane.
    pub profile: Profile2D,
    /// Extrusion depth (> 0).
    pub depth: f64,
    /// +1 for a +Z sweep, -1 for a -Z sweep (the only two eligible cases).
    pub dir_sign: f64,
    /// Profile-local → native-world transform.
    pub m: Matrix4<f64>,
}

impl GeometryRouter {
    /// Unwrap `item` — through `IfcMappedItem` (accumulating the mapping
    /// transform), but NOT through `IfcBooleanClippingResult`/`IfcBooleanResult`
    /// (a clipped host is ineligible for the 2D re-extrude) — to a single
    /// `IfcExtrudedAreaSolid` swept along its profile normal (local ±Z), and
    /// recover its full 2D profile + depth + composed profile-local→native-world
    /// transform. Returns `None` for any non-extrusion, clipped, obliquely-swept,
    /// or degenerate solid, so callers fall back to the exact kernel.
    pub(in crate::router::voids) fn extruded_solid_from_item(
        &self,
        item: DecodedEntity,
        placement: &Matrix4<f64>,
        decoder: &mut EntityDecoder,
    ) -> Option<ExtrudedSolidInfo> {
        // Maps only: boolean clipping or anything else is ineligible for the 2D
        // path. The mapping composition MUST parse (silently dropping it would
        // misplace the re-extruded footprint) and a map must hold EXACTLY ONE
        // item (a multi-item mapped opening would otherwise be reduced to its
        // first solid, dropping the rest from BOTH the 2D footprint and the
        // residual exact cut); any failure defers the whole opening.
        let unwrapped = unwrap_solid(item, decoder, &EXTRUDED_WALK)?;
        if unwrapped.leaf.ifc_type != IfcType::IfcExtrudedAreaSolid {
            return None;
        }
        let (solid, chain) = (unwrapped.leaf, unwrapped.chain);

        let profile_entity = decoder.resolve_ref(solid.get(0)?).ok()??;
        // The 2D path re-extrudes ONE outer ring with holes; a composite of
        // several disjoint areas (#7685) defers to the 3D path.
        let [profile] = <[_; 1]>::try_from(
            ProfileProcessor::new(self.schema.clone())
                .process_regions(&profile_entity, decoder, self.tessellation_quality())
                .ok()?,
        )
        .ok()?;
        if profile.outer.len() < 3 {
            return None;
        }
        let depth = solid.get_float(3)?;
        if !depth.is_finite() || depth <= 0.0 {
            return None;
        }
        let dir_local = {
            let e = decoder.resolve_ref(solid.get(2)?).ok()??;
            crate::transform::parse_direction(&e).ok()?
        }
        .try_normalize(1e-12)?;
        // The 2D re-extrude is only valid when the sweep is along the profile
        // normal (local ±Z). An oblique / sheared extrusion shifts the footprint
        // with depth, so the through-cut projection would be wrong — defer.
        if dir_local.x.abs() > 1e-6 || dir_local.y.abs() > 1e-6 {
            return None;
        }
        let dir_sign = if dir_local.z >= 0.0 { 1.0 } else { -1.0 };
        let solid_pos = match solid.get(1) {
            Some(a) if !a.is_null() => {
                let e = decoder.resolve_ref(a).ok()??;
                crate::transform::parse_axis2_placement_3d(&e, decoder).ok()?
            }
            _ => Matrix4::identity(),
        };
        Some(ExtrudedSolidInfo {
            profile,
            depth,
            dir_sign,
            m: placement * chain * solid_pos,
        })
    }

    /// The host element's body as a SINGLE eligible extruded solid (exactly one
    /// Body item, an `IfcExtrudedAreaSolid` after unwrapping mapped items). A
    /// multi-item body or a clipped host returns `None`.
    pub(in crate::router::voids) fn host_extruded_solid(
        &self,
        element: &DecodedEntity,
        decoder: &mut EntityDecoder,
    ) -> Option<ExtrudedSolidInfo> {
        let placement = self
            .get_placement_transform_from_element(element, decoder)
            .ok()?;
        let items = Self::body_representation_items(element, decoder)?;
        if items.len() != 1 {
            return None;
        }
        self.extruded_solid_from_item(items.into_iter().next()?, &placement, decoder)
    }

    /// Every Body item of an opening element as an eligible extruded solid (an
    /// opening may be a union of extruded prisms — Tekla multi-solid). `None` if
    /// the body is empty or ANY item is not a clean extruded solid.
    pub(in crate::router::voids) fn opening_extruded_solids(
        &self,
        element: &DecodedEntity,
        decoder: &mut EntityDecoder,
    ) -> Option<Vec<ExtrudedSolidInfo>> {
        let placement = self
            .get_placement_transform_from_element(element, decoder)
            .ok()?;
        let items = Self::body_representation_items(element, decoder)?;
        if items.is_empty() {
            return None;
        }
        let mut out = Vec::with_capacity(items.len());
        for it in items {
            out.push(self.extruded_solid_from_item(it, &placement, decoder)?);
        }
        Some(out)
    }
}
