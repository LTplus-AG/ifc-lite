// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Per-item meshes and bounds of an opening element, in the host's frame.

use super::super::geom::{extract_rotation_columns, rotate_and_normalize};
use super::GeometryRouter;
use crate::math::aabb::Aabb3;
use crate::representation::{product_shape, rep_items, Select};
use crate::{Mesh, Point3, Result, Vector3};
use ifc_lite_core::{DecodedEntity, EntityDecoder};
use nalgebra::Matrix4;

impl GeometryRouter {
    /// The element's placement (scaled, identity when it does not resolve) and
    /// the items of the representations the mesh path meshes: body only, and a
    /// MappedRepresentation skipped when direct body geometry duplicates it, so
    /// one void yields one cutter, not two (ROUTER-28, #7690). Shared by the
    /// mesh and bounds probes so the two cannot select differently.
    fn opening_body_items(
        &self,
        element: &DecodedEntity,
        decoder: &mut EntityDecoder,
    ) -> Result<Option<(Matrix4<f64>, Vec<DecodedEntity>)>> {
        let Some(shape) = product_shape(element, decoder)? else {
            return Ok(None);
        };
        // Get the same placement transform that apply_placement uses
        let mut placement_transform = self
            .get_placement_transform_from_element(element, decoder)
            .unwrap_or_else(|_| Matrix4::identity());
        self.scale_transform(&mut placement_transform);

        let mut items = Vec::new();
        for shape_rep in shape.select(element, Select::Meshed) {
            if let Ok(found) = rep_items(shape_rep, decoder) {
                items.extend(found);
            }
        }
        Ok(Some((placement_transform, items)))
    }

    /// Get per-item meshes for an opening element, transformed to world coordinates.
    /// Uses the same `transform_mesh` path as `process_element` to ensure identical
    /// coordinate handling (ObjectPlacement, unit scaling, conditional RTC offset).
    pub fn get_opening_item_meshes_world(
        &self,
        element: &DecodedEntity,
        decoder: &mut EntityDecoder,
    ) -> Result<Vec<Mesh>> {
        let Some((placement_transform, items)) = self.opening_body_items(element, decoder)? else {
            return Ok(vec![]);
        };
        let mut item_meshes = Vec::new();
        for item in items {
            // A raw national-grid cutter rebases in this opening's own
            // frame, like the host it cuts (#5698).
            // A mapped source mixing frames yields one cutter per frame (#6446).
            let item_parts = match self.process_raw_item_for_element(&item, element, decoder) {
                Ok(Some(mesh)) => Ok(vec![mesh]),
                Ok(None) => self.process_representation_item_parts(&item, decoder),
                Err(error) => Err(error),
            };
            let Ok(item_parts) = item_parts else { continue };
            for mut mesh in item_parts.into_iter().filter(|mesh| !mesh.is_empty()) {
                // Keep ordinary opening cutters in the world/RTC frame. A large
                // mapped origin, or a cutter far from the RTC origin (#6478),
                // would lose its fractional translation when the world point is
                // cast to f32; the void context folds each cutter's origin into
                // the host frame before cutting.
                let frame_cutter = self.needs_local_frame(&mesh, &placement_transform);
                self.transform_mesh_world_framed(&mut mesh, &placement_transform, frame_cutter);

                item_meshes.push(mesh);
            }
        }

        Ok(item_meshes)
    }

    /// Extrusion direction is in world coordinates, normalized
    /// Returns None for extrusion direction if it cannot be extracted (fallback to bounds-only)
    pub fn get_opening_item_bounds_with_direction(
        &self,
        element: &DecodedEntity,
        decoder: &mut EntityDecoder,
    ) -> Result<Vec<(Point3<f64>, Point3<f64>, Option<Vector3<f64>>)>> {
        // Same representation selection as `get_opening_item_meshes_world`.
        let Some((placement_transform, items)) = self.opening_body_items(element, decoder)? else {
            return Ok(vec![]);
        };
        let mut bounds_list = Vec::new();
        // Process each item separately to get individual bounds
        for item in items {
            let extrusion_direction = Self::world_extrusion_direction(&item, &placement_transform, decoder);

            // Get mesh bounds (same as original function), one entry per frame
            // part in the order `get_opening_item_meshes_world` emits them (#6446).
            let Ok(item_parts) = self.process_representation_item_parts(&item, decoder) else {
                continue;
            };
            for mesh in item_parts.into_iter().filter(|mesh| !mesh.is_empty()) {
                let (world_min, world_max) = Self::mesh_world_bounds(&mesh, &placement_transform);

                // Apply RTC offset to opening bounds so they match wall mesh coordinate system
                // Wall mesh positions have RTC subtracted during transform_mesh, so opening bounds must match
                let rtc = self.rtc_offset();
                let rtc_min = Point3::new(world_min.x - rtc.0, world_min.y - rtc.1, world_min.z - rtc.2);
                let rtc_max = Point3::new(world_max.x - rtc.0, world_max.y - rtc.1, world_max.z - rtc.2);

                bounds_list.push((rtc_min, rtc_max, extrusion_direction));
            }
        }

        Ok(bounds_list)
    }

    /// The item's extrusion direction in world coordinates, normalized, found
    /// by unwrapping its wrappers (booleans, maps) to the extrusion. A
    /// zero-length IFCDIRECTION drops only THIS item's direction (coarser
    /// bounds), not `?`-abort every sibling item's bounds.
    fn world_extrusion_direction(
        item: &DecodedEntity,
        placement_transform: &Matrix4<f64>,
        decoder: &mut EntityDecoder,
    ) -> Option<Vector3<f64>> {
        let (local_dir, position_transform) =
            Self::extract_extrusion_direction_recursive(item, decoder)?;
        let element_rot = extract_rotation_columns(placement_transform);
        if let Some(pos_transform) = position_transform {
            let pos_rot = extract_rotation_columns(&pos_transform);
            rotate_and_normalize(&pos_rot, &local_dir)
                .ok()
                .and_then(|world_dir| rotate_and_normalize(&element_rot, &world_dir).ok())
        } else {
            rotate_and_normalize(&element_rot, &local_dir).ok()
        }
    }

    /// World AABB of `mesh` under `placement_transform`. `Mesh::bounds` is
    /// local to `mesh.positions`; mapped items can carry a large f64 origin that
    /// must be folded in before the element placement, or the cutter box lands
    /// near zero.
    fn mesh_world_bounds(
        mesh: &Mesh,
        placement_transform: &Matrix4<f64>,
    ) -> (Point3<f64>, Point3<f64>) {
        let (mesh_min, mesh_max) = mesh.bounds();
        let (lo, hi) = (
            [mesh_min.x as f64, mesh_min.y as f64, mesh_min.z as f64],
            [mesh_max.x as f64, mesh_max.y as f64, mesh_max.z as f64],
        );
        // Transform the eight corner points to world coordinates and refit.
        let corners = (0..8).map(|i| {
            let p = [
                if i & 1 == 0 { lo[0] } else { hi[0] },
                if i & 2 == 0 { lo[1] } else { hi[1] },
                if i & 4 == 0 { lo[2] } else { hi[2] },
            ];
            let source = Point3::new(
                p[0] + mesh.origin[0],
                p[1] + mesh.origin[1],
                p[2] + mesh.origin[2],
            );
            let world = placement_transform.transform_point(&source);
            [world.x, world.y, world.z]
        });
        let bounds = Aabb3::from_points(corners);
        (
            Point3::new(bounds.min[0], bounds.min[1], bounds.min[2]),
            Point3::new(bounds.max[0], bounds.max[1], bounds.max[2]),
        )
    }
}
