// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! #7781 / #7887: a shallow mapped sibling used to make submesh production
//! succeed while silently omitting the depth-32 leaf the drawing extracted.
//! Exercise ordinary production, including the nonempty-submesh early return.

#[path = "../../geometry/tests/support/profile_walk_model.rs"]
mod model;

use ifc_lite_core::{EntityDecoder, MAX_MAPPED_ITEM_DEPTH};
use ifc_lite_geometry::{extract_profiles_with_diagnostics, GeometryRouter};
use ifc_lite_processing::process_geometry;

fn mixed_chain(levels: u32) -> String {
    model::chain(levels)
        .replace("(#1000)", "(#2000,#1000)")
        .replace("ENDSEC;\nEND-ISO", &format!("{}ENDSEC;\nEND-ISO", model::mapped(2000, "#140")))
}

fn check(levels: u32, expected: usize, refusals: usize) {
    let content = mixed_chain(levels);
    let (profiles, skipped) = extract_profiles_with_diagnostics(&content, 0);
    assert_eq!(profiles.len(), expected, "drawing: {skipped:?}");
    assert_eq!(skipped.len(), refusals, "drawing refusals: {skipped:?}");
    if refusals > 0 {
        assert!(skipped[0].reason.contains("maximum depth"), "{skipped:?}");
    }

    let produced = process_geometry(&content);
    let wall_meshes: Vec<_> = produced.meshes.iter().filter(|m| m.express_id == 100).collect();
    assert_eq!(wall_meshes.len(), expected, "ordinary element production disagrees with drawing");
    let triangles: usize = wall_meshes.iter().map(|m| m.indices.len() / 3).sum();
    assert_eq!(triangles, 12 * expected, "each reachable extrusion is a closed box");
    // Distinct profile dimensions identify each solid independently of the
    // number of mesh records. Native MeshData is IFC Z-up; the WASM
    // boundary applies the viewer Y-up conversion later.
    let mut heights: Vec<_> = wall_meshes.iter().map(|m| {
        let min = m.positions.chunks_exact(3).map(|p| p[2]).fold(f32::INFINITY, f32::min);
        let max = m.positions.chunks_exact(3).map(|p| p[2]).fold(f32::NEG_INFINITY, f32::max);
        max - min
    }).collect();
    heights.sort_by(f32::total_cmp);
    let expected_heights = if expected == 2 { vec![1.0, 2.5] } else { vec![2.5] };
    assert_eq!(heights, expected_heights, "both distinct solids must survive");

    // Check the router's report separately: process_geometry consumes its
    // diagnostics. Counting output alone would miss a silently truncated walk.
    let mut decoder = EntityDecoder::new(&content);
    let router = GeometryRouter::with_units(&content, &mut decoder);
    let wall = decoder.decode_by_id(100).unwrap();
    let submeshes = router.process_element_with_submeshes(&wall, &mut decoder).unwrap();
    assert_eq!(submeshes.len(), expected, "shallow sibling must not hide a deep drop");
    let drops = router.take_unsupported_items();
    assert_eq!(drops.get("IfcMappedItem").copied().unwrap_or(0), refusals as u64, "{drops:?}");
    assert_eq!(drops.len(), usize::from(refusals > 0), "{drops:?}");
}

#[test]
fn issue_7781_shallow_plus_exact_depth_chain_meshes_every_drawn_solid() {
    check(MAX_MAPPED_ITEM_DEPTH, 2, 0);
}

#[test]
fn issue_7781_shallower_chain_is_a_positive_control() {
    check(MAX_MAPPED_ITEM_DEPTH - 1, 2, 0);
}

#[test]
fn issue_7781_map_past_the_cap_is_reported_and_shallow_sibling_survives() {
    check(MAX_MAPPED_ITEM_DEPTH + 1, 1, 1);
}
