// SPDX-License-Identifier: MPL-2.0
//! D47/#7895: a canonical source set spends the model budget once, however
//! many occurrence, inherited or orphan-type projections consume its values.
use ifc_lite_core::limits::COMPLEX_PROPERTY_BUDGET_MARKER;
use ifc_lite_export::{
    build_export_model, build_export_model_with_options, export_csv, export_jsonld,
    stream_export_model, CsvMode, CsvOptions, EntityRow, JsonLdOptions, ModelOptions,
};
use ifc_lite_processing::data_model::{extract_data_model, DataModel};
use serde_json::Value;
use sha2::{Digest, Sha256};

fn vector_case(name: &str) -> Value {
    let vector: Value = serde_json::from_str(include_str!(
        "../../../packages/parser/test/fixtures/complex-property-budget-7675.json"
    )).unwrap();
    vector["cases"].as_array().unwrap().iter().find(|c| c["name"] == name).unwrap().clone()
}

fn ids(entries: &Value) -> Vec<u32> {
    entries.as_array().unwrap().iter().flat_map(|entry| {
        if let Some(id) = entry.as_u64() { return vec![id as u32]; }
        let from = entry["from"].as_u64().unwrap() as u32;
        (from..from + entry["count"].as_u64().unwrap() as u32).collect()
    }).collect()
}

fn fixture(case: &Value, extra: &str) -> String {
    let mut lines = Vec::new();
    for line in case["dataLines"].as_array().unwrap() {
        if let Some(line) = line.as_str() { lines.push(line.to_string()); continue; }
        for i in ids(&serde_json::json!([line])) {
            for template in line["repeat"].as_array().unwrap() {
                lines.push(template.as_str().unwrap().replace("{i}", &i.to_string()));
            }
        }
    }
    format!("ISO-10303-21;\nHEADER;\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n{}\n{extra}\nENDSEC;\nEND-ISO-10303-21;\n", lines.join("\n"))
}

fn assert_row(row: &EntityRow, server: &DataModel, case: &Value) {
    let pins = case["psets"].as_array().unwrap();
    assert_eq!(row.property_sets.len(), pins.len(), "#{}", row.express_id);
    for (set, pin) in row.property_sets.iter().zip(pins) {
        assert_eq!(set.name, pin["name"].as_str().unwrap());
        let canonical = server.property_sets.iter().find(|s| s.pset_name == set.name).unwrap();
        assert_eq!(set.properties.len(), canonical.properties.len());
        for (value, expected) in set.properties.iter().zip(&canonical.properties) {
            assert_eq!(value.name, expected.property_name);
            assert_eq!(value.value, expected.property_value, "#{} {}", row.express_id, set.name);
        }
    }
}

fn assert_server_pins(server: &DataModel, case: &Value) {
    for pin in case["psets"].as_array().unwrap() {
        let set = server.property_sets.iter().find(|s| s.pset_name == pin["name"].as_str().unwrap()).unwrap();
        let values: Vec<_> = set.properties.iter().map(|p| p.property_value.as_str()).collect();
        assert_eq!(values.len() as u64, pin["count"].as_u64().unwrap());
        if let Some(exact) = pin.get("values") {
            assert_eq!(serde_json::json!(values), *exact);
        } else {
            let joined = values.join("\n");
            assert_eq!(joined.len() as u64, pin["length"].as_u64().unwrap());
            assert_eq!(format!("{:x}", Sha256::digest(joined.as_bytes())), pin["sha256"].as_str().unwrap());
        }
    }
}

fn assert_csv(input: &[u8], server: &DataModel, expected_rows: usize) {
    // These vectors contain no tabs, newlines, quotes or formula prefixes.
    // A tab delimiter lets us inspect the actual public CSV without a second
    // implementation of its comma/quote escaping policy.
    let csv = export_csv(input, CsvMode::Properties, &CsvOptions {
        delimiter: "\t".into(), ..Default::default()
    });
    let mut count = 0;
    let mut positions = std::collections::HashMap::new();
    for line in csv.lines().skip(1) {
        let cells: Vec<_> = line.split('\t').collect();
        assert_eq!(cells.len(), 8);
        let set = server.property_sets.iter().find(|s| s.pset_name == cells[4]).unwrap();
        let position = positions.entry((cells[0], cells[4])).or_insert(0usize);
        let prop = &set.properties[*position];
        *position += 1;
        assert_eq!(cells[5], prop.property_name);
        assert_eq!(cells[6], prop.property_value, "CSV #{} {}", cells[0], cells[4]);
        count += 1;
    }
    assert_eq!(count, expected_rows);
}

#[test]
fn issue_7895_all_200_shared_set_occurrences_equal_the_canonical_server() {
    let case = vector_case("shared-set");
    assert_eq!(case["cuts"], 1, "the legitimate original cut is retained");
    let input = fixture(&case, "");
    let server = extract_data_model(&input);
    assert_server_pins(&server, &case);
    let expected_ids = ids(&case["entityIds"]);
    assert_eq!(expected_ids.len(), 200);
    let mut seen = Vec::new();
    let streamed_units = stream_export_model(input.as_bytes(), |row| {
        assert_row(&row, &server, &case);
        seen.push(row.express_id);
    });
    assert_eq!(seen, expected_ids);
    {
        let built = build_export_model(input.as_bytes());
        assert_eq!(built.units, streamed_units);
        assert_eq!(built.entities.len(), 200);
        for row in &built.entities { assert_row(row, &server, &case); }
        assert_eq!(built.entities.first().unwrap().property_sets, built.entities.last().unwrap().property_sets);
    }
    assert_csv(input.as_bytes(), &server, 200);
    // Filter only the output: the classified stream still resolves all 200
    // occurrences, so the last node tests the cached value AND kind metadata.
    let opts = JsonLdOptions { included: vec![100, 299], ..Default::default() };
    let doc: Value = serde_json::from_str(&export_jsonld(input.as_bytes(), &opts)).unwrap();
    let nodes = doc["@graph"].as_array().unwrap();
    assert_eq!(nodes.len(), 2);
    for node in nodes {
        let props = node["ifc:hasPropertySets"][0]["ifc:hasProperties"].as_array().unwrap();
        assert_eq!(props.len(), 1);
        assert_eq!(props[0]["@type"], "ifc:IfcComplexProperty");
        assert_eq!(props[0]["ifc:nominalValue"], server.property_sets[0].properties[0].property_value);
    }
}

#[test]
fn issue_7895_distinct_sets_still_exhaust_and_keep_last_records_still_win() {
    for name in ["unnamed-member", "duplicated-set-record", "duplicate-records-differ"] {
        let case = vector_case(name);
        let input = fixture(&case, "");
        let server = extract_data_model(&input);
        assert_server_pins(&server, &case);
        let built = build_export_model(input.as_bytes());
        assert_eq!(built.entities.len(), 1);
        assert_row(&built.entities[0], &server, &case);
        let mut count = 0;
        stream_export_model(input.as_bytes(), |row| { assert_row(&row, &server, &case); count += 1; });
        assert_eq!(count, 1);
        let n = built.entities[0].property_sets.iter().map(|s| s.properties.len()).sum();
        assert_csv(input.as_bytes(), &server, n);
        if name == "unnamed-member" {
            assert_eq!(built.entities[0].property_sets.last().unwrap().properties[0].value, COMPLEX_PROPERTY_BUDGET_MARKER);
        }
    }
}

#[test]
fn issue_7895_occurrence_inherited_and_orphan_consumers_reuse_one_decision() {
    let case = vector_case("shared-set");
    // Same source set reaches a normal occurrence first, then a different
    // type's inheritance, then an orphan type product. Geometry is not run.
    let extra = "#800=IFCWALL('extra',$,'Inherited',$,$,$,$,$,$);\n\
        #801=IFCWALLTYPE('type',$,'Type',$,$,(#30),$,$,$,.NOTDEFINED.);\n\
        #802=IFCRELDEFINESBYTYPE('typed',$,$,$,(#800),#801);\n\
        #803=IFCWALLTYPE('orphan',$,'Orphan',$,$,(#30),(#804),$,$,.NOTDEFINED.);\n\
        #804=IFCREPRESENTATIONMAP($,$);";
    let input = fixture(&case, extra);
    let server = extract_data_model(&input);
    assert_server_pins(&server, &case);
    let opts = ModelOptions::default().with_inherit_type_properties(true);
    let built = build_export_model_with_options(input.as_bytes(), &opts);
    assert_eq!(built.entities.len(), 202);
    for row in &built.entities { assert_row(row, &server, &case); }
    assert_eq!(built.entities[built.entities.len() - 2].express_id, 800);
    assert_eq!(built.entities.last().unwrap().express_id, 803);
}

#[test]
fn issue_7895_cached_and_omitted_complex_rows_preserve_positional_kind_metadata() {
    use ifc_lite_processing::data_model::property::PropertyKind;
    use ifc_lite_processing::data_model::rows::stream_export_model_with_property_kinds;
    let case = vector_case("shared-set");
    let input = fixture(&case, "#24=IFCPROPERTYSINGLEVALUE('Absent',$,$,$);\n\
        #25=IFCPROPERTYLISTVALUE('List',$,(IFCLABEL('x')),$);\n\
        #26=IFCCOMPLEXPROPERTY('',$,'Omitted',(#20));")
        .replace("'Pset_Shared',$,(#22)", "'Pset_Shared',$,(#24,#22,#26,#25)");
    let server = extract_data_model(&input);
    let canonical = &server.property_sets[0].properties[1].property_value;
    let mut count = 0;
    stream_export_model_with_property_kinds(input.as_bytes(), |row, kinds| {
        assert_eq!(kinds, &[vec![PropertyKind::Complex, PropertyKind::List]]);
        assert_eq!(row.property_sets.len(), 1);
        let props = &row.property_sets[0].properties;
        assert_eq!(props.len(), 2);
        assert_eq!(props[0].value, *canonical);
        assert_eq!((props[1].name.as_str(), props[1].value.as_str()), ("List", "x"));
        count += 1;
    });
    assert_eq!(count, 200);
    let opts = JsonLdOptions { included: vec![100, 299], ..Default::default() };
    let doc: Value = serde_json::from_str(&export_jsonld(input.as_bytes(), &opts)).unwrap();
    for node in doc["@graph"].as_array().unwrap() {
        let props = node["ifc:hasPropertySets"][0]["ifc:hasProperties"].as_array().unwrap();
        assert_eq!(props.len(), 2);
        assert_eq!(props[0]["@type"], "ifc:IfcComplexProperty");
        assert_eq!(props[0]["ifc:nominalValue"], *canonical);
        assert_eq!(props[1]["@type"], "ifc:IfcPropertyListValue");
        assert_eq!(props[1]["ifc:nominalValue"], "x");
    }
}

#[test]
fn issue_7895_set_decisions_are_local_to_the_input_and_preserve_file_units() {
    let input = b"ISO-10303-21;
HEADER;FILE_SCHEMA(('IFC4'));ENDSEC;
DATA;
#1=IFCPROJECT('project',$,'P',$,$,$,$,$,#3);
#2=IFCSIUNIT(*,.LENGTHUNIT.,.MILLI.,.METRE.);
#3=IFCUNITASSIGNMENT((#2));
#10=IFCWALL('first',$,'First',$,$,$,$,$,$);
#11=IFCWALL('last',$,'Last',$,$,$,$,$,$);
#20=IFCPROPERTYSINGLEVALUE('P',$,IFCLENGTHMEASURE(1000.),$);
#22=IFCCOMPLEXPROPERTY('Complex',$,'Usage',(#20));
#30=IFCPROPERTYSET('set',$,'Pset_Shared',$,(#22));
#40=IFCRELDEFINESBYPROPERTIES('rel',$,$,$,(#10,#11),#30);
ENDSEC;END-ISO-10303-21;";
    let first = build_export_model(input);
    assert_eq!(first.units.length_unit_scale, 0.001);
    for row in &first.entities {
        assert_eq!(row.lookup("Pset_Shared", "Complex").as_deref(), Some("P: 1000"));
    }
    let other = std::str::from_utf8(input).unwrap().replace("1000.", "2000.");
    assert_eq!(other.len(), input.len(), "input length is not an identity key");
    let second = build_export_model(other.as_bytes());
    assert_eq!(second.units, first.units);
    for row in &second.entities {
        assert_eq!(row.lookup("Pset_Shared", "Complex").as_deref(), Some("P: 2000"));
    }
    assert_eq!(build_export_model(input).entities, first.entities);
}
