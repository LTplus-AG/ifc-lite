# SPDX-License-Identifier: MPL-2.0
"""D47/#7895: public wheel consumer of the normative complex budget vectors.

The Rust public-consumer regression compares the same pins with canonical
server extraction. No geometry or alternate property decoder runs here.
"""
import hashlib
import json
from pathlib import Path

import ifclite_geom

REPO = Path(__file__).resolve().parents[3]
VECTOR = REPO / "packages/parser/test/fixtures/complex-property-budget-7675.json"
MARKER = "(truncated: nested properties over the walk budget)"


def budget_case(name):
    cases = json.loads(VECTOR.read_text())["cases"]
    return next(case for case in cases if case["name"] == name)


def fixture(case):
    lines = []
    for line in case["dataLines"]:
        if isinstance(line, str):
            lines.append(line)
        else:
            for i in range(line["from"], line["from"] + line["count"]):
                lines.extend(text.replace("{i}", str(i)) for text in line["repeat"])
    return ("ISO-10303-21;\nHEADER;\nFILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n"
            + "\n".join(lines) + "\nENDSEC;\nEND-ISO-10303-21;\n").encode()


def assert_pins(row, case):
    sets = row["property_sets"]
    assert [s["name"] for s in sets] == [s["name"] for s in case["psets"]]
    for pset, pin in zip(sets, case["psets"]):
        values = [p["value"] for p in pset["properties"]]
        assert len(values) == pin["count"]
        if "values" in pin:
            assert values == pin["values"]
        else:
            joined = "\n".join(values).encode()
            assert len(joined) == pin["length"]
            assert hashlib.sha256(joined).hexdigest() == pin["sha256"]


def test_issue_7895_all_shared_occurrences_keep_the_one_canonical_value():
    case = budget_case("shared-set")
    assert case["cuts"] == 1  # The legitimate original cut remains allowed.
    data = ifclite_geom.entity_data(fixture(case))
    rows = data["entities"]
    assert list(rows) == case["entityIds"]
    first = rows[case["entityIds"][0]]["property_sets"]
    assert_pins(rows[case["entityIds"][0]], case)
    assert len(rows) == 200
    for row in rows.values():
        assert row["property_sets"] == first


def test_issue_7895_distinct_set_exhaustion_and_keep_last_records():
    for name in ("unnamed-member", "duplicated-set-record", "duplicate-records-differ"):
        case = budget_case(name)
        data = ifclite_geom.entity_data(fixture(case))
        assert len(data["entities"]) == 1
        for row in data["entities"].values():
            assert_pins(row, case)
            if name == "unnamed-member":
                assert row["property_sets"][-1]["properties"][0]["value"] == MARKER
