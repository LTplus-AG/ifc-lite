/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import { spawnSync } from 'node:child_process';

export interface PhysicalSessionReceipt {
  currentSession: number;
  consoleSession: number;
  protocol: number;
  connectState: number;
  remoteMetric: number;
  monitors: number;
}

/** WTS protocol + physical console identity; SM_REMOTESESSION alone misses RemoteFX. */
export function isPhysicalConsole(receipt: PhysicalSessionReceipt): boolean {
  return receipt.consoleSession !== 0xffffffff
    && receipt.currentSession === receipt.consoleSession
    && receipt.protocol === 0 && receipt.connectState === 0
    && receipt.remoteMetric === 0 && receipt.monitors > 0;
}

// WTSClientProtocolType=16 (0 console, 2 RDP), WTSConnectState=8 (0 active).
// References: Microsoft WTSQuerySessionInformation / WTSGetActiveConsoleSessionId.
const SCRIPT = `
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class IfcFrameSession {
  [DllImport("kernel32.dll")] public static extern uint WTSGetActiveConsoleSessionId();
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int index);
  [DllImport("wtsapi32.dll", SetLastError=true)]
  public static extern bool WTSQuerySessionInformation(IntPtr server, int session, int field, out IntPtr data, out int bytes);
  [DllImport("wtsapi32.dll")] public static extern void WTSFreeMemory(IntPtr data);
  public static int Query(int session, int field, bool shortValue) {
    IntPtr data; int bytes;
    if (!WTSQuerySessionInformation(IntPtr.Zero, session, field, out data, out bytes))
      throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    try { return shortValue ? Marshal.ReadInt16(data) : Marshal.ReadInt32(data); }
    finally { WTSFreeMemory(data); }
  }
}
'@
$session = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
@{
  currentSession = $session
  consoleSession = [IfcFrameSession]::WTSGetActiveConsoleSessionId()
  protocol = [IfcFrameSession]::Query($session, 16, $true)
  connectState = [IfcFrameSession]::Query($session, 8, $false)
  remoteMetric = [IfcFrameSession]::GetSystemMetrics(0x1000)
  monitors = [IfcFrameSession]::GetSystemMetrics(80)
} | ConvertTo-Json -Compress
`;

/** Read-only Windows admission. No usernames, credentials or process command lines retained. */
export function readPhysicalSession(): PhysicalSessionReceipt {
  const run = spawnSync('powershell.exe', [
    '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(SCRIPT, 'utf16le').toString('base64'),
  ], { encoding: 'utf8', timeout: 15_000 });
  if (run.error || run.status !== 0) throw new Error(`physical session probe failed: ${run.error?.message ?? run.stderr}`);
  const parsed: unknown = JSON.parse(run.stdout.trim());
  if (!parsed || typeof parsed !== 'object') throw new Error('invalid physical session receipt');
  for (const field of ['currentSession', 'consoleSession', 'protocol', 'connectState', 'remoteMetric', 'monitors']) {
    const value: unknown = Reflect.get(parsed, field);
    if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) throw new Error(`invalid session field ${field}`);
  }
  return parsed as PhysicalSessionReceipt;
}
