/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import { randomBytes } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';

export interface ChromeOwner {
  version: 1;
  token: string;
  profileWsl: string;
  profileWin: string;
}
const MARKER = '.ifclite-frame-owner.json';
const run = (command: string, args: string[]): string => {
  const result = spawnSync(command, args, { encoding: 'utf8', timeout: 15_000 });
  if (result.error || result.status !== 0) throw new Error(`${command} failed: ${result.error?.message ?? result.stderr}`);
  return result.stdout.replace(/\r/g, '').trim();
};

/** The marker and optional recovery ledger exist before the Windows child is spawned. */
export function createChromeOwner(ledger?: string): ChromeOwner {
  const token = randomBytes(16).toString('hex');
  const tempWin = `${run('cmd.exe', ['/c', 'echo %LOCALAPPDATA%'])}\\Temp`;
  const profileWsl = join(run('wslpath', ['-u', tempWin]), `ifclite-frame-rig-${token}`);
  mkdirSync(profileWsl); // Never adopt an existing directory.
  try {
    const owner: ChromeOwner = { version: 1, token, profileWsl, profileWin: run('wslpath', ['-w', profileWsl]) };
    writeFileSync(join(profileWsl, MARKER), JSON.stringify(owner), { flag: 'wx' });
    if (ledger) {
      mkdirSync(ledger, { recursive: true });
      writeFileSync(join(ledger, `${token}.owner.json`), JSON.stringify(owner), { flag: 'wx' });
    }
    return owner;
  } catch (error) {
    rmSync(profileWsl, { recursive: true, force: true }); // No child has been spawned yet.
    throw error;
  }
}

/** Recovery refuses foreign/altered profiles rather than broadening its kill predicate. */
export function decodeChromeOwner(value: unknown): ChromeOwner {
  if (!value || typeof value !== 'object' || Reflect.get(value, 'version') !== 1) throw new Error('invalid Chrome owner');
  const token: unknown = Reflect.get(value, 'token');
  const profileWsl: unknown = Reflect.get(value, 'profileWsl');
  const profileWin: unknown = Reflect.get(value, 'profileWin');
  if (typeof token !== 'string' || !/^[a-f0-9]{32}$/.test(token)
    || typeof profileWsl !== 'string' || basename(profileWsl) !== `ifclite-frame-rig-${token}`
    || typeof profileWin !== 'string' || !profileWin.endsWith(`\\ifclite-frame-rig-${token}`)) {
    throw new Error('invalid Chrome ownership identity');
  }
  const marker: unknown = JSON.parse(readFileSync(join(profileWsl, MARKER), 'utf8'));
  if (!marker || typeof marker !== 'object'
    || ['version', 'token', 'profileWsl', 'profileWin'].some((field) => Reflect.get(marker, field) !== Reflect.get(value, field))) {
    throw new Error('Chrome profile ownership marker changed');
  }
  if (run('wslpath', ['-w', profileWsl]) !== profileWin) throw new Error('Chrome profile path mapping changed');
  const tempWin = `${run('cmd.exe', ['/c', 'echo %LOCALAPPDATA%'])}\\Temp`;
  if (resolve(dirname(profileWsl)) !== resolve(run('wslpath', ['-u', tempWin]))) {
    throw new Error('Chrome profile is outside the current Windows user temporary directory');
  }
  return value as ChromeOwner;
}

/** Exact Windows argv match, followed by process creation-time verification before Stop-Process. */
function stopOwnedChrome(owner: ChromeOwner): void {
  const profile = owner.profileWin.replace(/'/g, "''");
  const script = `
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class IfcFrameArgv {
  [DllImport("shell32.dll", SetLastError=true)] static extern IntPtr CommandLineToArgvW([MarshalAs(UnmanagedType.LPWStr)] string command, out int count);
  [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr data);
  public static string[] Parse(string command) {
    int count; IntPtr data = CommandLineToArgvW(command, out count);
    if (data == IntPtr.Zero) throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    try { string[] args = new string[count]; for (int i=0; i<count; i++) args[i] = Marshal.PtrToStringUni(Marshal.ReadIntPtr(data, i * IntPtr.Size)); return args; }
    finally { LocalFree(data); }
  }
}
'@
$wanted = '--user-data-dir=${profile}'
function Owned {
  @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object {
    $_.CommandLine -and ([IfcFrameArgv]::Parse($_.CommandLine) -ccontains $wanted)
  })
}
$deadline = [DateTime]::UtcNow.AddSeconds(10)
do {
  $owned = @(Owned)
  if ($owned.Count -eq 0) { exit 0 }
  foreach ($candidate in $owned) {
    if ($null -eq $candidate.CreationDate -or $candidate.CreationDate -isnot [DateTime]) {
      throw 'Missing owned Chrome process creation time'
    }
    $current = @(Get-CimInstance Win32_Process -Filter "ProcessId=$($candidate.ProcessId)")
    if ($current.Count -eq 0) { continue }
    if ($current.Count -ne 1 -or $current[0].CreationDate -ne $candidate.CreationDate -or
      -not ($current[0].CommandLine -and ([IfcFrameArgv]::Parse($current[0].CommandLine) -ccontains $wanted))) {
      throw 'Owned Chrome process identity changed before cleanup'
    }
    try { Stop-Process -Id $candidate.ProcessId -Force }
    catch {
      if (@(Get-CimInstance Win32_Process -Filter "ProcessId=$($candidate.ProcessId)").Count -ne 0) { throw }
    }
  }
  Start-Sleep -Milliseconds 250
} while ([DateTime]::UtcNow -lt $deadline)
throw 'Owned Chrome processes remained after cleanup deadline'
`;
  run('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')]);
}

export async function disposeChromeOwner(value: ChromeOwner, ledger?: string): Promise<string | null> {
  try {
    const owner = decodeChromeOwner(value);
    stopOwnedChrome(owner);
    for (let attempt = 0; attempt < 20; attempt++) {
      try { rmSync(owner.profileWsl, { recursive: true, force: true }); }
      catch (error) {
        if (attempt === 19) throw error;
        console.error(`frame-gpu-chrome: owned profile deletion retry ${attempt + 1}: ${String(error)}`);
      }
      if (!existsSync(owner.profileWsl)) {
        if (ledger) writeFileSync(join(ledger, `${owner.token}.disposed.json`), JSON.stringify({ owner, disposedAt: new Date().toISOString() }), { flag: 'wx' });
        return null;
      }
      await sleep(500);
    }
    throw new Error('owned Chrome profile remained after cleanup deadline');
  } catch (error) { return error instanceof Error ? error.message : String(error); }
}
