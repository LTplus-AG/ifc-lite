/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

/**
 * Windows Chrome lifecycle for the real-GPU frame rig (#6960), driven from
 * WSL. WSL's own Chromium only ever gets SwiftShader, so real-GPU frame time
 * needs the Windows browser: it is started with a random free CDP port and a
 * throwaway profile, reached over 127.0.0.1 (WSL mirrored networking works
 * both ways), and afterwards killed BY PROFILE PATH and its profile deleted,
 * because that profile caches model geometry.
 *
 * A fresh port per sample matters: a fixed port can reconnect to the previous,
 * not-yet-exited Chrome, whose profile still holds a warm cache.
 */

import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { connect } from 'node:net';
import { setTimeout as sleep } from 'node:timers/promises';
import { createChromeOwner, disposeChromeOwner } from './frame-gpu-chrome-owner.js';

const CHROME_CANDIDATES = [
  '/mnt/c/Program Files/Google/Chrome/Application/chrome.exe',
  '/mnt/c/Program Files (x86)/Google/Chrome/Application/chrome.exe',
];

export function findWindowsChrome(override?: string | null): string {
  const found = [override, ...CHROME_CANDIDATES].find((path): path is string => Boolean(path) && existsSync(path!));
  if (!found) throw new Error('Windows Chrome not found; pass --chrome /mnt/c/.../chrome.exe');
  return found;
}

/**
 * A random port nothing answers on at 127.0.0.1, below Windows' dynamic range.
 * Probed by CONNECTING, never by binding: under mirrored networking a port a
 * WSL process has just bound stays unavailable to Windows for a while, and
 * Chrome then silently never opens its DevTools endpoint.
 */
export async function randomUnusedPort(): Promise<number> {
  for (let attempt = 0; attempt < 50; attempt++) {
    const port = 20000 + Math.floor(Math.random() * 25000);
    const answered = await new Promise<boolean>((resolve) => {
      const socket = connect({ port, host: '127.0.0.1' });
      socket.once('connect', () => { socket.destroy(); resolve(true); });
      socket.once('error', () => resolve(false));
      socket.setTimeout(1000, () => { socket.destroy(); resolve(true); });
    });
    if (!answered) return port;
  }
  throw new Error('no unused port found');
}

export interface WindowsChrome {
  cdpUrl: string;
  /** Windows path of the throwaway profile; the kill key. */
  profileWin: string;
  /** Kill every chrome.exe on this profile, then delete the profile. */
  dispose(): Promise<string | null>;
}

/**
 * Measured on this rig's host: roughly one fresh-profile launch in five never
 * opens its DevTools port (the browser process idles with only crashpad
 * beside it). A clean retry on a new port and profile recovers it.
 */
export async function launchWindowsChrome(exe: string, attempts = 3, ledger?: string): Promise<WindowsChrome> {
  let lastError: unknown = null;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await launchOnce(exe, ledger);
    } catch (error) {
      lastError = error;
      console.error(`frame-gpu-chrome: launch attempt ${attempt}/${attempts} failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  throw lastError;
}

async function launchOnce(exe: string, ledger?: string, windowSize = '1280,800'): Promise<WindowsChrome> {
  const owner = createChromeOwner(ledger);
  let disposed = false;
  const dispose = async () => {
    if (disposed) return null;
    const error = await disposeChromeOwner(owner, ledger);
    if (!error) disposed = true;
    return error;
  };
  try {
    const port = await randomUnusedPort();
    const child = spawn(exe, [
      `--remote-debugging-port=${port}`, `--user-data-dir=${owner.profileWin}`,
      '--no-first-run', '--no-default-browser-check', '--disable-extensions',
      '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows',
      '--enable-unsafe-webgpu', `--window-size=${windowSize}`, '--window-position=0,0',
      '--disable-features=BatterySaverModeAvailable,HighEfficiencyModeAvailable', 'about:blank',
    ], { detached: true, stdio: 'ignore' });
    let launchError: Error | undefined;
    child.once('error', (error) => { launchError = error; });
    child.unref();
    const chrome: WindowsChrome = { cdpUrl: `http://127.0.0.1:${port}`, profileWin: owner.profileWin, dispose };
    let lastError: unknown = null;
    for (let attempt = 0; attempt < 60; attempt++) {
      if (launchError) throw launchError;
      try {
        const response = await fetch(`${chrome.cdpUrl}/json/version`, { signal: AbortSignal.timeout(1000) });
        if (response.ok) return chrome;
        lastError = `HTTP ${response.status}`;
      } catch (error) {
        // Launch polling failures are retained in the final refusal.
        lastError = error instanceof Error && error.cause ? `${error.message}: ${String(error.cause)}` : error;
      }
      await sleep(500);
    }
    throw new Error(`Windows Chrome did not open CDP on ${chrome.cdpUrl}: ${String(lastError)}`);
  } catch (error) {
    const cleanup = await dispose();
    throw new Error(`${error instanceof Error ? error.message : String(error)}${cleanup ? `; cleanup: ${cleanup}` : ''}`);
  }
}
