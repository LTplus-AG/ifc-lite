import datetime, hashlib, json, os, pathlib, subprocess, sys

checkout = pathlib.Path('/home/louistrue/wt/6709-capture-79e78d12')
artifacts = pathlib.Path(__file__).parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout, text=True)
command = ['pnpm', 'build', '--filter=@ifc-lite/cli', '--filter=@ifc-lite/collab-server',
    '--filter=create-ifc-lite', '--filter=@ifc-lite/embed-sdk', '--filter=@ifc-lite/server-bin',
    '--concurrency=1', '--env-mode=loose']
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=6144', CARGO_BUILD_JOBS='1')
results = []
for name, args in [('api-prerequisite-build', command), ('api-surface-retry', ['pnpm', 'check:api-surface'])]:
    log = artifacts / f'corrected-{name}.log'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open('w') as output:
        code = subprocess.run(args, cwd=checkout, env=environment, stdout=output, stderr=subprocess.STDOUT).returncode
    results.append(dict(command=args, startedAt=started, finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        exitCode=code, log=str(log), logSha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (artifacts / 'corrected-api-surface-retry.json').write_text(json.dumps(dict(head=head, results=results), indent=2) + '\n')
    print(f'{name}: exit {code}', flush=True)
    if code: break
sys.exit(code)
