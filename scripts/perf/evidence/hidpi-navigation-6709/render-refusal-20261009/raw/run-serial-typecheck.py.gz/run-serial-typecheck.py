import datetime, hashlib, json, os, pathlib, subprocess, sys

checkout = pathlib.Path('/home/louistrue/wt/6709-capture-79e78d12')
artifacts = pathlib.Path(__file__).parent
run = sys.argv[1] if len(sys.argv) > 1 else '1'
config = checkout / 'turbo.json'
original = config.read_bytes()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout, text=True)
serial = json.loads(original)
serial['concurrency'] = '1'
override = (json.dumps(serial, indent=2) + '\n').encode()
(artifacts / 'typecheck-original-turbo.json').write_bytes(original)
(artifacts / 'typecheck-serial-turbo.json').write_bytes(override)
receipt = dict(head=head, command=['pnpm', 'typecheck'], startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    executionOnlyOverride='Supported top-level Turbo concurrency=1; dependency graph and all checks unchanged; restored in finally',
    originalConfigSha256=hashlib.sha256(original).hexdigest(), executionConfigSha256=hashlib.sha256(override).hexdigest())
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=6144', CARGO_BUILD_JOBS='1')
try:
    config.write_bytes(override)
    with (artifacts / f'corrected-root-typecheck-run-{run}.log').open('w') as output:
        code = subprocess.run(['pnpm', 'typecheck'], cwd=checkout, env=environment, stdout=output, stderr=subprocess.STDOUT).returncode
    receipt['exitCode'] = code
finally:
    config.write_bytes(original)
    receipt['restored'] = config.read_bytes() == original
    receipt['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (artifacts / f'corrected-root-typecheck-run-{run}.json').write_text(json.dumps(receipt, indent=2) + '\n')
sys.exit(code)
