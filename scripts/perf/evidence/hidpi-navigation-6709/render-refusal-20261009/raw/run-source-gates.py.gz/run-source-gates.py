import datetime, hashlib, json, os, pathlib, subprocess, sys

root = pathlib.Path('/home/louistrue/wt/6709-capture-79e78d12')
artifacts = pathlib.Path(__file__).parent
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True)
commands = [
    ['pnpm', 'check:module-size'],
    ['pnpm', 'check:source-text-assertions'],
    ['pnpm', 'check:unbounded-frame-wait'],
    ['pnpm', 'check:test-wiring'],
    ['pnpm', 'check:api-surface'],
    ['pnpm', 'api-surface:update'],
    ['pnpm', 'lint'],
    ['pnpm', 'docs:check-samples'],
    ['pnpm', 'docs:check-generated'],
    ['pnpm', 'docs:check-readmes'],
]
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=6144', CARGO_BUILD_JOBS='1', RAYON_NUM_THREADS='2')
results = []
for command in commands:
    name = command[1].replace(':', '-')
    log = artifacts / f'corrected-gate-{name}.log'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open('w') as output:
        code = subprocess.run(command, cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT).returncode
    results.append(dict(command=command, exitCode=code, startedAt=started,
        finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), log=str(log), logSha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (artifacts / 'corrected-source-gates.json').write_text(json.dumps(dict(head=head, serial=True, results=results), indent=2) + '\n')
    print(f'{name}: exit {code}', flush=True)
sys.exit(0 if all(result['exitCode'] == 0 for result in results) else 1)
