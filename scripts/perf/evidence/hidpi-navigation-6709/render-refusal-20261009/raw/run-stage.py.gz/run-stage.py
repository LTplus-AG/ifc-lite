import datetime, hashlib, json, os, pathlib, subprocess, sys
checkout = pathlib.Path('/home/louistrue/wt/6709-capture-79e78d12')
artifacts = pathlib.Path(__file__).parent
lock = pathlib.Path('/home/louistrue/.t3/artifacts/ifc-ready-campaign-heavy-57868bf7.lock/owner.json')
owner = json.loads(lock.read_text())
assert owner['reservationId'] == '3b6a17dd-6965-4a8d-9c37-f0b58c87edf2' and owner['agentThread'] == '79e78d12' and owner['state'] == 'active'
name, expected, *command = sys.argv[1:]
assert command
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
assert head == expected
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout, text=True)
environment = dict(os.environ, NODE_OPTIONS='--max-old-space-size=6144', CARGO_BUILD_JOBS='1')
if name.startswith('baseline'):
    environment['TEST_PATTERN'] = 'useAnimationLoop[.]capture-refusal'
if name.startswith('corrected-tests'):
    environment['TEST_PATTERN'] = 'useAnimationLoop|useBCF|useClash|idsBcf|export-filenames|export-ui-ribbon|commandPaletteExports|basketSave|chatViewportCapture|ExecutableCodeBlock'
cpus = sorted(os.sched_getaffinity(0))[:2]
os.sched_setaffinity(0, cpus)
receipt = dict(name=name, head=head, command=command, startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), cpuAffinity=cpus, heapMiB=6144, rustBuildJobs=1, reservationId=owner['reservationId'], testPattern=environment.get('TEST_PATTERN'), physicalGPU=False)
(artifacts / (name + '.started.json')).write_text(json.dumps(receipt, indent=2) + '\n')
with (artifacts / (name + '.log')).open('w') as output:
    code = subprocess.run(command, cwd=checkout, env=environment, stdout=output, stderr=subprocess.STDOUT).returncode
receipt.update(exitCode=code, finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
receipt['logSha256'] = hashlib.sha256((artifacts / (name + '.log')).read_bytes()).hexdigest()
(artifacts / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
sys.exit(code)
