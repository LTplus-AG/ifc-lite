// #6709 untimed diagnostic: canonical published geometry + Scene CPU placement.
// No second geometry decoder, GPU readback, picker or native-JSON certificate.
export function snapshotValue(value, ancestry = new Set()) {
    if (value === undefined) return { kind: 'undefined' };
    if (value === null) return { kind: 'null' };
    if (typeof value === 'number') {
        const bytes = new ArrayBuffer(8); new DataView(bytes).setFloat64(0, value, false);
        return { kind: 'number', bits: hex(new Uint8Array(bytes)) };
    }
    if (typeof value === 'bigint') return { kind: 'bigint', value: value.toString() };
    if (typeof value === 'string' || typeof value === 'boolean') return { kind: typeof value, value };
    if (typeof value !== 'object' || ancestry.has(value)) throw Error('Unsupported/cyclic geometry field');
    if (ArrayBuffer.isView(value)) {
        if (value instanceof DataView) throw Error('Unsupported DataView geometry field');
        return { kind: value.constructor.name, length: value.length, byteLength: value.byteLength,
            bytes: hex(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) };
    }
    ancestry.add(value);
    try {
        if (Array.isArray(value)) return { kind: 'array', values: value.map(v => snapshotValue(v, ancestry)) };
        if (value instanceof Map) return { kind: 'map', entries: [...value].map(([k,v]) =>
            [snapshotValue(k, ancestry), snapshotValue(v, ancestry)]) };
        if (![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
            throw Error('Unsupported geometry object (including unresolved/resolved images)');
        }
        return { kind: 'object', fields: Reflect.ownKeys(value).map(key => {
            if (typeof key !== 'string') throw Error('Unsupported symbol geometry field');
            const descriptor = Object.getOwnPropertyDescriptor(value, key);
            if (!Object.hasOwn(descriptor, 'value')) throw Error('Geometry accessor is not a byte witness');
            return [key, snapshotValue(descriptor.value, ancestry)];
        }) };
    } finally { ancestry.delete(value); }
}
function hex(bytes) { return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join(''); }
export async function sha256(text) {
    return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))));
}
function ownerRows(state, model, pieces) {
    const ids = new Set(model.ifcDataStore.entities.expressId);
    const resolve = id => {
        if (!Number.isSafeInteger(id) || id <= 0) throw Error('Invalid geometry entity identifier');
        const ref = state.resolveGlobalIdFromModels(id);
        if (!ref || ref.modelId !== model.id || !ids.has(ref.expressId)) throw Error('Geometry identifier not published by canonical owner');
        return { globalId: id, modelOrdinal: 0, expressId: ref.expressId };
    };
    return pieces.map((piece, ordinal) => ({ ordinal,
        expressId: resolve(piece.expressId),
        entityIds: piece.entityIds ? [...piece.entityIds].map(resolve) : null,
        geometryItemId: piece.geometryItemId === undefined ? null : resolve(piece.geometryItemId),
        materialId: piece.materialId === undefined ? null : resolve(piece.materialId) }));
}
function requiredData(object, key) {
    const field = object && Object.getOwnPropertyDescriptor(object, key);
    if (!field || !Object.hasOwn(field, 'value')) throw Error(`Required coordinate data field unavailable: ${key}`);
    return field.value;
}
function requireVector(vector) {
    if (!['x', 'y', 'z'].every(key => Number.isFinite(requiredData(vector, key)))) {
        throw Error('Coordinate vector must contain finite original values');
    }
}
function requireCoordinateInfo(info) {
    requireVector(requiredData(info, 'originShift'));
    for (const name of ['originalBounds', 'shiftedBounds']) {
        const bounds = requiredData(info, name);
        requireVector(requiredData(bounds, 'min'));
        requireVector(requiredData(bounds, 'max'));
    }
    if (typeof requiredData(info, 'hasLargeCoordinates') !== 'boolean') throw Error('Coordinate shift flag missing');
    const scale = requiredData(info, 'lengthUnitScale');
    if (!Number.isFinite(scale) || scale <= 0) throw Error('Actual positive file-to-metre unit scale unavailable');
    if (info.boundsRecoveryFallbackCount !== undefined
        && (!Number.isSafeInteger(info.boundsRecoveryFallbackCount) || info.boundsRecoveryFallbackCount < 0)) {
        throw Error('Coordinate recovery count malformed');
    }
    if (info.wasmRtcOffset !== undefined) requireVector(info.wasmRtcOffset);
    if (info.wasmRtcFrame !== undefined) {
        requireVector(info.wasmRtcFrame);
        if (typeof requiredData(info.wasmRtcFrame, 'needsShift') !== 'boolean') throw Error('Exact RTC shift flag malformed');
    }
    if (info.buildingRotation !== undefined && !Number.isFinite(info.buildingRotation)) throw Error('Building rotation malformed');
}
export function captureCanonicalGeometry(renderer, state, trace, selectedFile) {
    const rows = [...state.models.entries()];
    if (rows.length !== 1 || state.loading || state.geometryStreamingActive) throw Error('Expected settled primary model');
    const [id, model] = rows[0], scene = renderer.getScene();
    if (model.id !== id || model.sourceFile !== selectedFile || model.fileSize !== selectedFile.size
        || model.loadPath !== 'wasm' || model.loadState !== 'complete' || model.loadError
        || !model.ifcDataStore || !model.geometryResult || scene.isGeometryDataReleased()) throw Error('Incomplete/released primary publication');
    if (!trace || !Number.isFinite(trace.end) || trace.attrs?.loadPath !== 'wasm'
        || trace.spans.some(span => span.name === 'parser.failed' || span.attrs?.error === true)
        || !['parser.complete','geometry.streamComplete','scene.finalize'].every(name =>
            trace.spans.some(span => span.name === name && Number.isFinite(span.end)))) throw Error('Actual successful finalized cold epoch unavailable');
    requireCoordinateInfo(model.geometryResult.coordinateInfo);
    const placed = []; scene.forEachMeshData(piece => placed.push(piece));
    if (!placed.length) throw Error('Actual placed CPU geometry absent');
    for (const piece of [...model.geometryResult.meshes, ...placed]) {
        if (!(piece.positions instanceof Float32Array) || piece.positions.length === 0 || piece.positions.length % 3
            || !(piece.normals instanceof Float32Array) || piece.normals.length !== piece.positions.length
            || !(piece.indices instanceof Uint32Array) || piece.indices.length === 0 || piece.indices.length % 3) {
            throw Error('Required original/placed geometry arrays missing or malformed');
        }
    }
    const indices = new Set(placed.map(piece => piece.modelIndex ?? 0));
    const placement = [...indices].map(modelIndex => ({ modelIndex,
        translation: snapshotValue(scene.getModelTranslation(modelIndex)),
        yaw: snapshotValue(scene.getModelRotation(modelIndex)) }));
    return { schema: '6709-primary-source-and-placed-cpu-v1', source: snapshotValue(model.geometryResult),
        sourceOwners: ownerRows(state, model, model.geometryResult.meshes),
        placed: snapshotValue(placed), placedOwners: ownerRows(state, model, placed), placement,
        counts: { sourceMeshes: model.geometryResult.meshes.length, placedMeshes: placed.length,
            triangles: model.geometryResult.totalTriangles, vertices: model.geometryResult.totalVertices },
        exclusions: ['GPU-buffer readback', 'raw IFNS backing/provenance', 'full metadata equivalence', 'overlays', 'native JSON metadata'] };
}
export async function captureStableIdentity(renderer, getState, latestTrace, selectedFile, fixture, captureLoadedSession) {
    const initialState = getState(), initialTrace = latestTrace(), scene = renderer.getScene();
    if (typeof captureLoadedSession !== 'function') throw Error('Qualified loaded-session guard unavailable');
    const session = captureLoadedSession(renderer, initialState, initialTrace, selectedFile, fixture);
    session.assert(initialState, initialTrace);
    const generation = scene.authoredGeneration, mutation = initialState.mutationVersion;
    if (!Number.isInteger(generation) || !Number.isInteger(mutation)) throw Error('Canonical publication revisions unavailable');
    const first = JSON.stringify(captureCanonicalGeometry(renderer, initialState, initialTrace, selectedFile));
    const digest = await sha256(first);
    const now = getState(), trace = latestTrace();
    session.assert(now, trace);
    if (renderer.getScene() !== scene || generation !== scene.authoredGeneration || mutation !== now.mutationVersion
        || trace?.loadId !== initialTrace.loadId || trace?.start !== initialTrace.start
        || trace?.end !== initialTrace.end || trace?.timeOrigin !== initialTrace.timeOrigin) throw Error('Publication/epoch changed during capture');
    const second = JSON.stringify(captureCanonicalGeometry(renderer, now, trace, selectedFile));
    if (second !== first) throw Error('Geometry bytes/owner/placement changed during capture');
    return { schema: '6709-primary-source-and-placed-cpu-v1', digest, bytes: first.length,
        manifest: JSON.parse(first), session: session.receipt(), runtimeScope: 'Untimed actual source and canonical placed/materialized CPU domain only' };
}
export function compareArms(base, candidate) {
    if (base?.schema !== '6709-primary-source-and-placed-cpu-v1' || candidate?.schema !== base.schema
        || JSON.stringify(base.manifest) !== JSON.stringify(candidate.manifest) || base.digest !== candidate.digest) {
        throw Error('Frozen BASE/candidate geometry/ownership/units/placement differs');
    }
    return { equal: true, schema: base.schema, digest: base.digest };
}
