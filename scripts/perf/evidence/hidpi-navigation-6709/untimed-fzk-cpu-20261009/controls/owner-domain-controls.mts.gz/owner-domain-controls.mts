import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { IfcParser } from '/tmp/ifc-6881-main-integration-4b/packages/parser/src/index.ts';
import { createModelSlice } from '/tmp/ifc-6881-main-integration-4b/apps/viewer/src/store/slices/modelSlice.ts';
import { createStore } from '/tmp/ifc-6881-main-integration-4b/apps/viewer/node_modules/zustand/vanilla.js';
import { federationRegistry } from '/tmp/ifc-6881-main-integration-4b/packages/renderer/src/index.ts';
const subjectPath = process.env.OWNER_SUBJECT ?? '/home/louistrue/.t3/artifacts/6709-owner-domain-proposal-20261009/proposed-geometry-identity.mjs';
// Exact artifact subject bytes plus a test-only export; no function-body substitution.
const source = readFileSync(subjectPath, 'utf8');
const { ownerRows } = await import('data:text/javascript;base64,' + Buffer.from(source + '\nexport { ownerRows };\n').toString('base64'));
const fixture = readFileSync('/tmp/ifc-shepherd-7024/tests/models/ara3d/AC20-FZK-Haus.ifc');
assert.equal(fixture.length, 2526511);
assert.equal(createHash('sha256').update(fixture).digest('hex'), 'd42ab0dee01173106c16cd823b4614efe188fa15dd65195d95b9879bec59acc5');
const parsed = await new IfcParser().parseColumnar(fixture.buffer.slice(fixture.byteOffset, fixture.byteOffset + fixture.byteLength), { disableWorkerScan: true });
const byId = parsed.entityIndex.byId;
let maximum = 0; for (const id of byId.keys()) maximum = Math.max(maximum, id);
const primary = { id: 'actual-fzk', name: 'actual-fzk', idOffset: 0, maxExpressId: maximum, ifcDataStore: parsed, sourceFile: { size: fixture.length } };
const secondary = { ...primary, id: 'actual-fzk-second' };
const makeState = (models) => createStore((set, get, api) => ({ ...createModelSlice(set, get, api), models: new Map(models.map(model => [model.id, model])), mutationViews: new Map() })).getState();
const single = makeState([primary]);
const product = [...parsed.entities.expressId].find(id => id > 0);
assert.ok(product);
const material = parsed.entityIndex.byType.get('IFCMATERIAL')?.[0];
assert.ok(material, 'actual FZK must contain an authored IfcMaterial for this control');
let gap = 1; while (byId.has(gap)) gap++;
assert.ok(gap < maximum);
const piece = { expressId: product, geometryItemId: 174 };
const withIndex = (get) => ({ ...primary, ifcDataStore: { ...parsed, entityIndex: { ...parsed.entityIndex, byId: { get } } } });
console.log(JSON.stringify({ evidence: 'actual-canonical-parser-and-modelSlice', sourceSHA256: createHash('sha256').update(source).digest('hex'), indexedCount: byId.size, semanticCount: parsed.entities.count, product, material, gap, maximum, helper174: byId.get(174) }));

test('#6709 representation helper174 uses complete source index, preserving canonical original identity', () => {
  assert.equal(byId.get(174).type, 'IFCFACETEDBREP');
  assert.ok(!new Set(parsed.entities.expressId).has(174));
  const result = ownerRows(single, primary, [piece])[0];
  assert.equal(result.geometryItemId.globalId, 174);
  assert.equal(result.geometryItemId.expressId, 174);
  assert.equal(result.geometryItemId.sourceType, 'IFCFACETEDBREP');
  assert.equal(result.geometryItemId.entityTableMember, false);
  const ref = byId.get(174);
  assert.equal(fixture.subarray(ref.byteOffset, ref.byteOffset + ref.byteLength).toString(), '#174= IFCFACETEDBREP(#172);');
  assert.equal(result.expressId.entityTableMember, true);
});
test('#6709 actual authored material ID retains source existence and distinct helper field', () => {
  const result = ownerRows(single, primary, [{ expressId: product, materialId: material }])[0];
  assert.equal(result.materialId.expressId, material);
  assert.equal(result.materialId.sourceType, 'IFCMATERIAL');
  assert.equal(result.geometryItemId, null);
});
test('#6709 canonical resolver at N models qualifies helper and refuses foreign model', () => {
  federationRegistry.clear();
  federationRegistry.registerModel(primary.id, maximum);
  const registration = federationRegistry.registerModel(secondary.id, maximum);
  const other = { ...secondary, idOffset: registration };
  const state = makeState([primary, other]);
  const otherGlobal = state.toGlobalId(other.id, 174);
  assert.equal(state.resolveGlobalIdFromModels(otherGlobal).modelId, other.id);
  const otherProduct = state.toGlobalId(other.id, product);
  assert.equal(ownerRows(state, other, [{ expressId: otherProduct, geometryItemId: otherGlobal }])[0].geometryItemId.expressId, 174);
  assert.throws(() => ownerRows(state, primary, [{ expressId: product, geometryItemId: otherGlobal }]), /canonical owner/);
  federationRegistry.clear();
});
test('#6709 in-range unresolved source gap refuses despite canonical range ownership', () => {
  assert.equal(single.resolveGlobalIdFromModels(gap).modelId, primary.id);
  assert.ok(!byId.has(gap));
  assert.throws(() => ownerRows(single, primary, [{ expressId: product, geometryItemId: gap }]), /source index/);
});
test('#6709 actual representation helper174 cannot masquerade as semantic picking owner (inverse target)', () => {
  assert.throws(() => ownerRows(single, primary, [{ expressId: 174 }]), /semantic EntityTable/);
  assert.throws(() => ownerRows(single, primary, [{ expressId: product, entityIds: new Uint32Array([174]) }]), /semantic EntityTable/);
});
test('#6709 original source index metadata malformed range/type/ID refuses', () => {
  for (const change of [{ byteOffset: -1 }, { byteLength: 0 }, { byteOffset: fixture.length }, { byteLength: 0.5 }, { type: '' }, { type: undefined }, { expressId: 175 }]) {
    const damaged = withIndex(id => id === 174 ? { ...byId.get(id), ...change } : byId.get(id));
    assert.throws(() => ownerRows(single, damaged, [piece]), /source index/);
  }
});
test('#6709 unavailable index and defined invalid IDs fail without invented defaults', () => {
  const noIndex = { ...primary, ifcDataStore: { ...parsed, entityIndex: undefined } };
  assert.throws(() => ownerRows(single, noIndex, [piece]), /source index unavailable/);
  for (const geometryItemId of [0, -1, 0.5, NaN, Infinity]) {
    assert.throws(() => ownerRows(single, primary, [{ expressId: product, geometryItemId }]), /Invalid geometry/);
  }
  assert.equal(ownerRows(single, primary, [{ expressId: product }])[0].geometryItemId, null);
});
