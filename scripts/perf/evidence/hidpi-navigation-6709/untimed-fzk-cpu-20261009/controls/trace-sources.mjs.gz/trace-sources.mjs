import { registerHooks } from 'node:module';
import { readFileSync, appendFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const observed = new Set();
registerHooks({ load(url, context, nextLoad) {
  const result = nextLoad(url, context);
  if (url.startsWith('file:') && !observed.has(url)) {
    observed.add(url);
    const path = fileURLToPath(url), bytes = readFileSync(path);
    appendFileSync(process.env.OWNER_SOURCE_TRACE, JSON.stringify({ pid: process.pid, path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') }) + '\n');
  }
  return result;
} });
