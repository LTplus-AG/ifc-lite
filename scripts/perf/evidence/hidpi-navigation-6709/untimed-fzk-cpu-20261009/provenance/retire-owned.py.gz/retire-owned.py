"""Retire only the exact artifact server identity; retain bounded raw outcome."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import time

parser = argparse.ArgumentParser()
parser.add_argument('--receipt', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
receipt = json.loads(args.receipt.read_bytes())
pid = receipt['pid']
assert isinstance(pid, int) and pid > 1 and pid != os.getpid()
assert receipt['bootID'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
assert receipt['script'] == str(Path(__file__).resolve().with_name('serve-pinned.py'))
assert hashlib.sha256(Path(receipt['script']).read_bytes()).hexdigest() == receipt['scriptSHA256']


def same_process():
    try:
        stat = Path('/proc', str(pid), 'stat').read_text()
        fields = stat[stat.rindex(')') + 2:].split()
        if fields[19] != receipt['startTicks']:
            raise RuntimeError('PID reused; refusing signal')
        if fields[0] == 'Z':
            return False
        argv = Path('/proc', str(pid), 'cmdline').read_bytes().rstrip(b'\0').split(b'\0')
        expected = [x.encode() for x in receipt['argv']]
        if argv[1:] != expected:
            raise RuntimeError('Owned argv mismatch; refusing signal')
        return True
    except FileNotFoundError:
        return False


result = {'pid': pid, 'receipt': str(args.receipt), 'signals': []}
# Kernel-held identity avoids sending to a reused numeric PID after validation.
owned_pidfd = os.pidfd_open(pid) if same_process() else None
for selected, seconds in [(signal.SIGTERM, 5), (signal.SIGKILL, 2)]:
    if not same_process():
        break
    if owned_pidfd is None:
        raise RuntimeError('Missing kernel process identity; refusing signal')
    signal.pidfd_send_signal(owned_pidfd, selected)
    result['signals'].append(selected.name)
    end = time.monotonic() + seconds
    while time.monotonic() < end and same_process():
        time.sleep(0.1)
if owned_pidfd is not None:
    os.close(owned_pidfd)
result['exactOwnedProcessGoneOrZombie'] = not same_process()
result['scope'] = 'Root must separately await original exec session terminal and verify listener gone; no browser/device/import retirement inferred'
with args.output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
if not result['exactOwnedProcessGoneOrZombie']:
    raise SystemExit(1)
