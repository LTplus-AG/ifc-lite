"""#6709 artifact-only immutable static transport. No viewer/load implementation."""
import argparse
import hashlib
import json
import mimetypes
import os
from pathlib import Path
import signal
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

HERE = Path(__file__).resolve().parent
SHA256 = lambda data: hashlib.sha256(data).hexdigest()


def verified_bytes(row):
    source = Path(row['sourcePath'])
    if source.is_symlink() or not source.is_file():
        raise ValueError('Pinned source unavailable: ' + str(source))
    data = source.read_bytes()
    if len(data) != row['bytes'] or SHA256(data) != row['sha256']:
        raise ValueError('Pinned source changed: ' + str(source))
    return data


def pid_start(pid):
    stat = Path('/proc', str(pid), 'stat').read_text()
    return stat[stat.rindex(')') + 2:].split()[19]


def write_exclusive(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


parser = argparse.ArgumentParser()
parser.add_argument('--role', choices=['base', 'candidate'], required=True)
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
contract_path = HERE / 'transport-contract.json'
contract = json.loads(contract_path.read_bytes())
role = contract['roles'][args.role]
routes = dict(role['routes'])
manifest_bytes = verified_bytes(role['manifest'])
for row in routes.values():
    verified_bytes(row)
port = role['port']


class Handler(BaseHTTPRequestHandler):
    def reply(self, include_body):
        try:
            split = urlsplit(self.path)
            if split.scheme or split.netloc:
                self.send_error(400, 'Origin-relative path required')
                return
            path = unquote(split.path, errors='strict')
            if ('\\' in path or '%' in path or '\x00' in path
                    or any(piece in ['.', '..'] for piece in path.split('/'))):
                self.send_error(400, 'Unsafe path')
                return
            if path == '/__6709_diagnostic__/provenance.json':
                data = verified_bytes(role['manifest'])
                content_type = 'application/json; charset=utf-8'
            else:
                row = routes.get(path)
                if row is None:
                    self.send_error(404, 'Unpinned route')
                    return
                data = verified_bytes(row)
                suffix = Path(row['sourcePath']).suffix
                content_type = {
                    '.mjs': 'text/javascript', '.js': 'text/javascript',
                    '.wasm': 'application/wasm', '.html': 'text/html; charset=utf-8',
                    '.ifc': 'application/octet-stream',
                }.get(suffix, mimetypes.guess_type(row['sourcePath'])[0] or 'application/octet-stream')
            self.send_response(200)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
            self.send_header('Cross-Origin-Embedder-Policy', 'credentialless')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            if include_body:
                self.wfile.write(data)
        except (OSError, ValueError, UnicodeError) as error:
            print(json.dumps({'refused': str(error), 'request': self.path}), file=sys.stderr, flush=True)
            self.send_error(409, 'Pinned transport refused')

    def do_GET(self):
        self.reply(True)

    def do_HEAD(self):
        self.reply(False)


server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
server.daemon_threads = True
server.block_on_close = False
server.timeout = 1
identity = {
    'status': 'bound', 'role': args.role, 'pid': os.getpid(),
    'startTicks': pid_start(os.getpid()),
    'bootID': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    'argv': sys.argv, 'script': str(Path(__file__).resolve()),
    'scriptSHA256': SHA256(Path(__file__).read_bytes()),
    'contractSHA256': SHA256(contract_path.read_bytes()),
    'binding': '127.0.0.1', 'port': port, 'routeCount': len(routes),
    'manifestSHA256': SHA256(manifest_bytes),
}


def stop_owned_server(signum, frame):
    raise KeyboardInterrupt


signal.signal(signal.SIGTERM, stop_owned_server)
signal.signal(signal.SIGINT, stop_owned_server)
try:
    write_exclusive(args.receipt, identity)
    print(json.dumps(identity), flush=True)
    server.serve_forever(poll_interval=0.25)
except KeyboardInterrupt:
    print(json.dumps({'status': 'retiring', 'pid': os.getpid()}), flush=True)
finally:
    server.server_close()
    print(json.dumps({'status': 'terminal-server-close', 'pid': os.getpid()}), flush=True)
