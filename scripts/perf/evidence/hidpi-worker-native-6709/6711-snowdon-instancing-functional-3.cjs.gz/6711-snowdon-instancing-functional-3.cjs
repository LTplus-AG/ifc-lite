'use strict';
// Real public IFCx first-load controls; functional evidence only, no timing claim.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {chromium}=require('/home/louistrue/wt/6882-aspect-pick-session6503/node_modules/@playwright/test');
const root='/tmp/6232-takeover/perf-reset-20261004';
const out=path.join(root,'6711-snowdon-instancing-functional-3');
if(fs.existsSync(out))throw Error('Preserve prior attempts');fs.mkdirSync(out);
const fixture='/home/louistrue/wt/hidpi-pick-fixed-refresh-session6503/tests/models/various/01_Snowdon_Towers_Sample_Structural(1).ifc';
const bytes=fs.readFileSync(fixture),sha=crypto.createHash('sha256').update(bytes).digest('hex');
if(sha!=='fab102eb5f9152bc7053d7e4920a8b75d0d34683c834078f0735c88308eb00a4')throw Error('Fixture identity changed');
fs.writeFileSync(path.join(out,'protocol.json'),JSON.stringify({sha,fixture,scope:'Target a real purely GPU-instanced owner (exclude every flat-mesh ID), isolate through canonical store action and frame through actual camera callback before the declared CSS grid. This is an isolated entity control, not whole-model/federation coverage. Broad unisolated grid failures retained. Production COOP/credentiallessCOEP and asserted worker capability restored after the default-server omission. No observer bootstrap or generated WASM/API modification. Repeat original real-model positive instancing behavior control; old zero-instance and failed observer setup attempts retained. Declared stronger visual control: attempts1/2 passedbehavior but Home and UI Fit All use broaddefaultcamera despite actual2.3m rendererbounds. Use existing publicRenderer.fitToView for realcloudappearance; no claimaboutUI Fit All correctness. Two declared real Revit Snowdon first-load A/B controls at DPR2. Positive instanced entity/template counts required. Only real instanced owner hit accepted in fixed CSS grid. No timing or annotation/instanced claim. Native GPU instanced owner/template counts, fixed-pose CSS pick, cap dimensions, trusted orbit and full-resolution restoration/capture. Initial 8GiB functional-only safety floor distinct from unchanged40GiB performance protocol.'},null,2));
const assert=(v,m)=>{if(!v)throw Error(m);};const rows=[];
(async()=>{
 for(const mode of ['instanced-mesh'])for(const variant of ['A','B']){
  const row={mode,variant,errors:[]};let browser,context;
  try{
   const available=Number(fs.readFileSync('/proc/meminfo','utf8').match(/MemAvailable:\s+(\d+)/)[1]);assert(available>=8388608,'Functional8GiB Linux safety floor');
   browser=await chromium.connectOverCDP('http://127.0.0.1:9343',{timeout:15000});context=await browser.newContext({viewport:{width:2234,height:1203},deviceScaleFactor:2});const page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',e=>row.errors.push(e.message));
   await page.goto(variant==='A'?'http://localhost:5430':'http://localhost:5429',{waitUntil:'domcontentloaded'});await page.bringToFront();
   row.environment=await page.evaluate(()=>({crossOriginIsolated,sharedArrayBuffer:typeof SharedArrayBuffer,cores:navigator.hardwareConcurrency}));
   assert(row.environment.crossOriginIsolated&&row.environment.sharedArrayBuffer==='function','Actual production worker capability required');
   await page.waitForFunction(()=>globalThis.__6709_bench__?.store&&globalThis.__6709_bench__?.getRenderer);
   await page.locator('input[type=file][accept^=".ifc"]').first().setInputFiles({name:path.basename(fixture),mimeType:'application/x-step',buffer:bytes});
   await page.waitForFunction(()=>{const b=globalThis.__6709_bench__,s=b.store.getState(),r=b.getRenderer();return s.models.size===1&&!s.loading&&!s.geometryStreamingActive&&r?.isReady()&&[...s.models.values()].every(m=>m.loadState==='complete')&&!r.getScene().hasQueuedMeshes()&&!r.getScene().hasStreamingFragments()&&!r.getScene().isFinalizeInProgress()&&!r.getScene().hasPendingBatches();},null,{timeout:90000});
   await page.evaluate(mode=>{const b=globalThis.__6709_bench__,s=b.store.getState();s.setActiveTool('select');s.setNavigationPreset('default');s.setProjectionMode('perspective');const r=b.getRenderer();r.fitToView();const original=r.render;const h={r,original,options:null};r.render=function(...a){h.options=a[0];return original.apply(this,a);};globalThis.__6711_point_control=h;r.requestRender();},mode);
   await page.waitForTimeout(900);await page.waitForFunction(()=>globalThis.__6711_point_control.options);
   const state=()=>page.evaluate(()=>{const r=globalThis.__6711_point_control.r,c=r.getCanvas(),b=c.getBoundingClientRect(),cam=r.getCamera();return {css:[b.width,b.height],buffer:[c.width,c.height],points:r.getScene().getInstancedEntityCount(),assets:r.getScene().getInstancedTemplates().length,gpu:r.getScene().getResidentGpuBytes(),meshCounts:[...globalThis.__6709_bench__.store.getState().models.values()].map(m=>({meshes:m.geometryResult?.meshes.length,triangles:m.geometryResult?.totalTriangles})),adapter:r.getAdapterInfo(),bounds:r.getModelBounds(),pose:{position:cam.getPosition(),target:cam.getTarget(),up:cam.getUp()}};});
   const dimensions=(s,d)=>assert(s.buffer.every((n,i)=>Math.abs(n-s.css[i]*d)<=1),'Unexpected physical canvas dimensions');
   row.initial=await state();dimensions(row.initial,2);assert(row.initial.points>0&&row.initial.assets>0,'No positive native GPU mesh instances; this public control is unqualified, no inference about a lost transport');
   row.isolatedOwner=await page.evaluate(()=>{const b=globalThis.__6709_bench__,s=b.store.getState(),r=b.getRenderer(),scene=r.getScene(),flat=new Set(scene.getAllMeshDataExpressIds());const id=[...scene.getInstancedEntityIds()].sort((a,b)=>a-b).find(id=>!flat.has(id));if(id===undefined)throw Error('No purely instanced owner; retain unqualified control');if(typeof s.cameraCallbacks.frameEntities!=='function')throw Error('Actual frameEntities callback unavailable');s.isolateEntities([id]);s.cameraCallbacks.frameEntities([id]);r.requestRender();return{id,ref:b.resolveEntityRef(id),GlobalId:b.resolveGlobalId(id),hasFlatGeometry:flat.has(id)};});
   await page.waitForTimeout(900);row.framed=await state();
   row.target=await page.evaluate(async()=>{const r=globalThis.__6711_point_control.r,b=r.getCanvas().getBoundingClientRect();for(const fy of [.5,.4,.6,.3,.7,.2,.8])for(const fx of [.5,.4,.6,.3,.7,.2,.8]){const hit=await r.pick(b.width*fx,b.height*fy);if(hit&&r.getScene().isInstancedEntity(hit.expressId)&&!new Set(r.getScene().getAllMeshDataExpressIds()).has(hit.expressId))return{x:b.width*fx,y:b.height*fy,hit};}throw Error('No real GPU-instanced owner CSS pick in fixed grid');});
   assert(row.target.hit.expressId===row.isolatedOwner.id,'Actual isolated pure-instanced owner must be hit');
   const pick=()=>page.evaluate(p=>globalThis.__6711_point_control.r.pick(p.x,p.y),row.target);
   row.hits=[await pick()];
   await page.evaluate(()=>{const h=globalThis.__6711_point_control;h.r.render({...h.options,isInteracting:false,maxPixelRatio:1});});row.capped=await state();dimensions(row.capped,variant==='B'?1:2);row.hits.push(await pick());
   await page.evaluate(()=>{const h=globalThis.__6711_point_control;h.r.render({...h.options,isInteracting:false,maxPixelRatio:undefined,restoreEvictedForCapture:true});});row.restored=await state();dimensions(row.restored,2);row.hits.push(await pick());
   assert(row.hits.every(h=>h&&h.expressId===row.target.hit.expressId&&h.modelIndex===row.target.hit.modelIndex),'Instanced owner pick changed across fixed-pose cap/restoration');
   const rect=await page.locator('canvas[data-viewport="main"]').boundingBox();assert(rect,'Canvas absent');const x=rect.x+rect.width/2,y=rect.y+rect.height/2;
   await page.mouse.move(x,y);await page.mouse.down({button:'left'});await page.mouse.move(x+rect.width*.04,y+rect.height*.02,{steps:8});await page.waitForTimeout(100);row.moving=await state();dimensions(row.moving,variant==='B'?1:2);assert(JSON.stringify(row.moving.pose)!==JSON.stringify(row.initial.pose),'Trusted orbit did not move camera');await page.mouse.up({button:'left'});
   await page.waitForFunction(()=>{const c=globalThis.__6711_point_control.r.getCanvas(),b=c.getBoundingClientRect();return Math.abs(c.width-b.width*2)<=1&&Math.abs(c.height-b.height*2)<=1;},null,{timeout:15000});row.settled=await state();dimensions(row.settled,2);
   await page.evaluate(async()=>{const r=globalThis.__6711_point_control.r;await r.getGPUDevice().queue.onSubmittedWorkDone();});await page.screenshot({path:path.join(out,variant+'-'+mode+'.png')});
   const uri=await page.evaluate(()=>globalThis.__ifc_lite_capture_color_frame__());assert(uri?.startsWith('data:image/png;base64,'),'Color capture absent');fs.writeFileSync(path.join(out,variant+'-'+mode+'-color.png'),Buffer.from(uri.split(',')[1],'base64'));assert(!row.errors.length,'Page errors');row.passed=true;
  }catch(e){row.passed=false;row.failure={message:e.message,stack:e.stack};}
  finally{if(context)await context.close();if(browser)await browser.close();rows.push(row);fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(rows,null,2));}
 }
 if(!rows.every(r=>r.passed))process.exitCode=1;
})().catch(e=>{fs.writeFileSync(path.join(out,'fatal.json'),JSON.stringify({message:e.message,stack:e.stack}));process.exitCode=1;});
