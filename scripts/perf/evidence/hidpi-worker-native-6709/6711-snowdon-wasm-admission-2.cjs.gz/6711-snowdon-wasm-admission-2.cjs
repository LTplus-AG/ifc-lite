'use strict';
// Diagnostic only: observe delegated WASM calls, never synthesize geometry.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pathToFileURL } = require('node:url');
const { chromium } = require('/home/louistrue/wt/6882-aspect-pick-session6503/node_modules/@playwright/test');
const root = '/tmp/6232-takeover/perf-reset-20261004';
const wt = '/home/louistrue/wt/hidpi-pick-fixed-refresh-session6503';
const out = path.join(root, '6711-snowdon-wasm-admission-2');
const assert = (value, message) => { if (!value) throw Error(message); };
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
assert(!fs.existsSync(out), 'Preserve previous observations');
fs.mkdirSync(out);
const fixture = path.join(wt, 'tests/models/various/01_Snowdon_Towers_Sample_Structural(1).ifc');
const bytes = fs.readFileSync(fixture);
assert(sha(bytes) === 'fab102eb5f9152bc7053d7e4920a8b75d0d34683c834078f0735c88308eb00a4', 'Fixture drift');
const workerPath = '/assets/geometry.worker-BHEPbN4N.js';
const decoderPath = path.join(wt, 'packages/geometry/dist/packed-instanced-decoder.js');
fs.writeFileSync(path.join(out, 'declaration.json'), JSON.stringify({
  declaredAt: new Date().toISOString(), fixture, fixtureSHA: sha(bytes),
  scriptSHA: sha(fs.readFileSync(__filename)), decoderSHA: sha(fs.readFileSync(decoderPath)),
  sourceHead: '4d2b84faf624f644277d65e5d3cc1a1d2d4b2a94',
  wasmSHA: 'a8216da63bd0d2eaa9652c91ce95a934268a080d6b35ed682910cc9e49824b02',
  scope: 'One fresh public-model production load. Observe the original WASM call result before take-once ownership/free. Dynamic worker bootstrap delegates to unchanged compiled worker and original native functions. Functional diagnostic only, no performance/positive-instancing/private6516 claim.',
  bounds: { functionalMemoryKiB: 8388608, batchesPerWorker: 4096, shardBytesPerWorker: 134217728, loadTimeoutMs: 90000 },
  previousUnobservedControl: '6711-snowdon-instancing-functional-1: both complete17380meshes865980triangles;0instances/templates',
}, null, 2));

function installWorkerProbe() {
  const state = { batches: [], errors: [], rawShardBytes: 0 };
  globalThis.__ifclite_native_admission_probe__ = state;
  const seen = new WeakMap();
  function wrap(instance) {
    if (seen.has(instance)) return seen.get(instance);
    const nativeExports = instance.exports;
    const batchHandles = new Map(), meshHandles = new Map();
    const observedExports = Object.create(null);
    for (const key of Object.keys(nativeExports)) {
      const original = nativeExports[key];
      const watched = typeof original === 'function' &&
        (/^ifcapi_processGeometryBatch/.test(key) || /^partitionedbatch_(takeMeshes|takeShard|instancedOccurrences)$/.test(key) || key === 'meshcollection_length' || key === '__wbg_meshcollection_free');
      observedExports[key] = watched ? function (...args) {
        const result = original(...args);
        try {
          if (/^ifcapi_processGeometryBatch/.test(key)) {
            if (state.batches.length >= 4096) throw Error('Declared batch observation bound');
            const row = { index: state.batches.length, api: key, jobs: args[/FromSource/.test(key) ? 2 : 4] / 3, needsShift: Boolean(args[/FromSource/.test(key) ? 7 : 9]), nativeHandle: result };
            state.batches.push(row);
            if (/Partitioned/.test(key)) batchHandles.set(result, row);
            else meshHandles.set(result, row);
          } else if (key === 'partitionedbatch_takeMeshes') {
            const row = batchHandles.get(args[0]);
            if (row) { row.flatHandle = result; if (result) meshHandles.set(result, row); }
          } else if (key === 'meshcollection_length') {
            const row = meshHandles.get(args[0]);
            if (row) row.flatMeshes = result;
          } else if (key === 'partitionedbatch_instancedOccurrences') {
            const row = batchHandles.get(args[0]);
            if (row) { row.instancedOccurrences = result >>> 0; if (typeof document === 'undefined') globalThis.postMessage({ __ifclite_native_probe_batch__: true, row }); }
          } else if (key === '__wbg_meshcollection_free') {
            const row = meshHandles.get(args[0]);
            if (row && !/Partitioned/.test(row.api) && typeof document === 'undefined') globalThis.postMessage({ __ifclite_native_probe_batch__: true, row });
          } else if (key === 'partitionedbatch_takeShard') {
            const row = batchHandles.get(args[1]);
            if (row) {
              const view = new DataView(nativeExports.memory.buffer);
              const pointer = view.getUint32(args[0], true), length = view.getUint32(args[0] + 4, true);
              row.shardBytes = length;
              if (length) {
                state.rawShardBytes += length;
                if (state.rawShardBytes > 134217728) throw Error('Declared raw-shard observation bound');
                const copy = new Uint8Array(nativeExports.memory.buffer, pointer, length).slice();
                let text = '';
                for (let i = 0; i < copy.length; i += 8192) text += String.fromCharCode(...copy.subarray(i, i + 8192));
                row.shardBase64 = btoa(text);
              }
            }
          }
        } catch (error) {
          state.errors.push({ api: key, message: String(error?.message || error) });
        }
        return result;
      } : original;
    }
    const proxy = new Proxy(instance, { get(target, property) {
      return property === 'exports' ? observedExports : Reflect.get(target, property, target);
    } });
    seen.set(instance, proxy); seen.set(proxy, proxy);
    return proxy;
  }
  const NativeInstance = WebAssembly.Instance;
  WebAssembly.Instance = new Proxy(NativeInstance, { construct(target, args) { return wrap(Reflect.construct(target, args)); } });
  for (const method of ['instantiate', 'instantiateStreaming']) {
    const original = WebAssembly[method];
    WebAssembly[method] = async function (...args) {
      const result = await original.apply(WebAssembly, args);
      return result instanceof NativeInstance ? wrap(result) : { ...result, instance: wrap(result.instance) };
    };
  }
}

(async () => {
  const result = { errors: [], workers: [] };
  let browser, context;
  try {
    assert(Number(fs.readFileSync('/proc/meminfo', 'utf8').match(/MemAvailable:\s+(\d+)/)[1]) >= 8388608, 'Functional8GiB memory floor');
    browser = await chromium.connectOverCDP('http://127.0.0.1:9343', { timeout: 15000 });
    assert(browser.version() === '154.0.8037.93', 'Owned browser identity changed');
    context = await browser.newContext({ viewport: { width: 2234, height: 1203 }, deviceScaleFactor: 2 });
    await context.addInitScript(installWorkerProbe);
    await context.addInitScript(({ workerPath, installer }) => {
      const OriginalWorker = globalThis.Worker;
      globalThis.__native_probe_workers__ = [];
      globalThis.Worker = class extends OriginalWorker {
        constructor(url, options) {
          const originalURL = new URL(String(url), location.href);
          if (originalURL.pathname !== workerPath) { super(url, options); return; }
          if (options?.type !== 'module') throw Error('Expected original module worker');
          const bootstrap = '(' + installer + ')(); await import(' + JSON.stringify(originalURL.href) + ');';
          const observedURL = URL.createObjectURL(new Blob([bootstrap], { type: 'text/javascript' }));
          super(observedURL, options);
          const record = { original: originalURL.href, observed: observedURL, batches: [], configuration: [] };
          globalThis.__native_probe_workers__.push(record);
          this.__nativeRecord = record;
          this.addEventListener('message', event => {
            if (event.data?.__ifclite_native_probe_batch__ === true) { event.stopImmediatePropagation(); record.batches.push(event.data.row); }
          }, { capture: true });
        }
        postMessage(...args) {
          const message = args[0];
          if (this.__nativeRecord && ['init', 'set-instancing-enabled'].includes(message?.type))
            this.__nativeRecord.configuration.push({ type: message.type, enabled: message.enabled, sharedModule: !!message.wasmModule });
          return super.postMessage(...args);
        }
      };
    }, { workerPath, installer: installWorkerProbe.toString() });
    const page = await context.newPage();
    page.on('pageerror', error => result.errors.push(error.message));
    await page.goto('http://localhost:5429', { waitUntil: 'domcontentloaded' });
    await page.bringToFront();
    result.environment = await page.evaluate(() => ({ crossOriginIsolated, sharedArrayBuffer: typeof SharedArrayBuffer, cores: navigator.hardwareConcurrency }));
    assert(result.environment.crossOriginIsolated && result.environment.sharedArrayBuffer === 'function', 'Production worker-capable isolation prerequisite');
    result.sourceWitness = await page.evaluate(async () => (await fetch('/__source-witness.json')).json());
    await page.waitForFunction(() => globalThis.__6709_bench__?.store && globalThis.__6709_bench__?.getRenderer);
    await page.locator('input[type=file][accept^=".ifc"]').first().setInputFiles({ name: path.basename(fixture), mimeType: 'application/x-step', buffer: bytes });
    await page.waitForFunction(() => {
      const b = globalThis.__6709_bench__, s = b.store.getState(), r = b.getRenderer();
      return s.models.size === 1 && !s.loading && !s.geometryStreamingActive && r?.isReady() &&
        [...s.models.values()].every(m => m.loadState === 'complete') && !r.getScene().hasQueuedMeshes() &&
        !r.getScene().hasStreamingFragments() && !r.getScene().isFinalizeInProgress() && !r.getScene().hasPendingBatches();
    }, null, { timeout: 90000 });
    await page.evaluate(async () => { const r = globalThis.__6709_bench__.getRenderer(); await r.getGPUDevice().queue.onSubmittedWorkDone(); });
    result.final = await page.evaluate(() => {
      const b = globalThis.__6709_bench__, s = b.store.getState(), r = b.getRenderer();
      return { models: s.models.size, meshCounts: [...s.models.values()].map(m => ({ meshes: m.geometryResult.meshes.length, triangles: m.geometryResult.totalTriangles })), instances: r.getScene().getInstancedEntityCount(), templates: r.getScene().getInstancedTemplates().length, adapter: r.getAdapterInfo(), diagnostics: r.getDiagnostics() };
    });
    const { decodeInstancedShard } = await import(pathToFileURL(decoderPath).href);
    const records = await page.evaluate(() => [{ realm: 'main', ...globalThis.__ifclite_native_admission_probe__ }, ...globalThis.__native_probe_workers__.map(record => ({ realm: 'worker', ...record, errors: [] }))]);
    for (const record of records) {
      const ordinal = result.workers.length;
      for (const batch of record.batches) if (batch.shardBase64) {
        const bytes = Buffer.from(batch.shardBase64, 'base64');
        const payload = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
        const decoded = decodeInstancedShard(payload);
        batch.decoded = { templates: decoded.templates.length, instances: decoded.instances.length, sha256: sha(bytes) };
        fs.writeFileSync(path.join(out, 'worker-' + ordinal + '-batch-' + batch.index + '.ifns'), bytes);
        delete batch.shardBase64;
      }
      result.workers.push(record);
    }
    assert(result.workers.length > 0, 'No observed original geometry worker');
    assert(result.workers.some(w => w.batches.length > 0), 'No actual native batch observation');
    assert(result.workers.every(w => w.errors.length === 0), 'Observer failed; retain unqualified diagnostic');
    assert(result.final.models === 1 && result.final.meshCounts[0].meshes + result.final.instances === 17380, 'Total flat+instanced occurrence count differs from original public load');
    assert(result.errors.length === 0, 'Application error during observed load');
    result.completed = true;
  } catch (error) { result.completed = false; result.failure = { message: error.message, stack: error.stack }; }
  finally {
    if (context) await context.close();
    if (browser) await browser.close();
    fs.writeFileSync(path.join(out, 'result.json'), JSON.stringify(result, null, 2));
  }
  console.log(JSON.stringify({ completed: result.completed, failure: result.failure?.message, final: result.final, workers: result.workers.length, batches: result.workers.reduce((n, w) => n + w.batches.length, 0) }));
  if (!result.completed) process.exitCode = 1;
})().catch(error => { fs.writeFileSync(path.join(out, 'fatal.json'), JSON.stringify({ message: error.message, stack: error.stack })); process.exitCode = 1; });
