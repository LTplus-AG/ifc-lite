from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import threading

ROOT = Path('/tmp/6232-takeover/perf-reset-20261004')

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        directory = self.roots[args[2].server_address[1]]
        super().__init__(*args, directory=str(directory), **kwargs)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'credentialless')
        super().end_headers()

    def log_message(self, format, *args):
        if self.path == '/':
            print(self.server.server_port, format % args, flush=True)

Handler.roots = {
    5430: ROOT / '6711-pick-fixed-static-A',
    5429: ROOT / '6711-pick-fixed-static-B',
}
for port in Handler.roots:
    server = ThreadingHTTPServer(('0.0.0.0', port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
print('Own frozen A/B bytes served with production COOP/credentialless COEP; no runtime edits', flush=True)
threading.Event().wait()
