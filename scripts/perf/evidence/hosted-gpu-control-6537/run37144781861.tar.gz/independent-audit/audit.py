import pathlib,json,hashlib,subprocess,re,shlex,datetime,struct,zlib
art=pathlib.Path('/tmp/6232-takeover/6537-hosted-gpu-remote-v1/artifacts/gpu-control-37144781861-1')
wt=pathlib.Path('/home/louistrue/wt/6537-hosted-gpu-control-session6503'); out=pathlib.Path(__file__).parent
head='4a1a750028f33a075de4d1c1ba695bad785a7135'
report=json.loads((art/'report.json').read_text()); original=json.loads((art/'original.json').read_text()); corrected=json.loads((art/'corrected.json').read_text())
raw={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(art.iterdir()) if p.is_file()}
source={}
for path,claimed in report['harness']['sources'].items():
 data=subprocess.check_output(['git','show',head+':'+path],cwd=wt); actual=hashlib.sha256(data).hexdigest()
 source[path]={'claimed':claimed,'gitBlobSHA256':actual,'matches':actual==claimed}
assert report['harness']['head']==head and all(x['matches'] for x in source.values())
for name in ['gpu-sample.mjs','gpu-control.mjs','gpu-page.mjs','gpu-run.mjs']:
 (out/name).write_bytes(subprocess.check_output(['git','show',head+':scripts/perf/'+name],cwd=wt))
def decode_png(path):
 data=path.read_bytes(); assert data[:8]==b'\x89PNG\r\n\x1a\n'; pos=8; compressed=[]; header=None; ended=False
 while pos<len(data):
  size=struct.unpack('>I',data[pos:pos+4])[0]; kind=data[pos+4:pos+8]; payload=data[pos+8:pos+8+size]
  assert len(payload)==size
  crc=struct.unpack('>I',data[pos+8+size:pos+12+size])[0]; assert zlib.crc32(kind+payload)&0xffffffff==crc
  if kind==b'IHDR': header=struct.unpack('>IIBBBBB',payload)
  elif kind==b'IDAT': compressed.append(payload)
  elif kind==b'IEND': ended=True; pos+=12+size; break
  pos+=12+size
 assert ended and pos==len(data) and header
 w,h,depth,color,compression,filtering,interlace=header
 assert (w,h)==(715,743) and depth==8 and color in [2,6] and (compression,filtering,interlace)==(0,0,0)
 channels=3 if color==2 else 4; stride=w*channels; expected=(stride+1)*h
 inflater=zlib.decompressobj(); decoded=inflater.decompress(b''.join(compressed),expected+1)
 assert len(decoded)==expected and inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail
 prev=bytearray(stride); center=None; minima=[255]*4; maxima=[0]*4; filters={}
 for y in range(h):
  start=y*(stride+1); f=decoded[start]; assert f in range(5); filters[f]=filters.get(f,0)+1
  row=bytearray(decoded[start+1:start+1+stride])
  for x in range(stride):
   left=row[x-channels] if x>=channels else 0; above=prev[x]; diagonal=prev[x-channels] if x>=channels else 0
   if f==1: predict=left
   elif f==2: predict=above
   elif f==3: predict=(left+above)//2
   elif f==4:
    p=left+above-diagonal; a,b,c=abs(p-left),abs(p-above),abs(p-diagonal)
    predict=left if a<=b and a<=c else above if b<=c else diagonal
   else: predict=0
   row[x]=(row[x]+predict)&255
  for x in range(w):
   pixel=list(row[x*channels:(x+1)*channels]); pixel=pixel+[255] if channels==3 else pixel
   if x==w//2 and y==h//2: center=pixel
   for channel,value in enumerate(pixel): minima[channel]=min(minima[channel],value); maxima[channel]=max(maxima[channel],value)
  prev=row
 return {'decoder':'Independent Python stdlib PNG IHDR/CRC/IDAT zlib + filters0..4; bounded exact image payload',
  'width':w,'height':h,'bitDepth':depth,'colorType':color,'rowFilters':filters,'centerRGBA':center,'channelExtrema':list(zip(minima,maxima)),
  'sha256':hashlib.sha256(data).hexdigest()}
images={}
for name,expected in [('red',[255,0,0,255]),('blue',[0,0,255,255]),('terminal',[0,0,255,255])]:
 path=art/f'corrected-{name}.png'; result=decode_png(path); result['expectedRGBA']=expected
 assert result['centerRGBA']==expected and all(list(pair)==[expected[i],expected[i]] for i,pair in enumerate(result['channelExtrema']))
 images[path.name]=result
flags=['--enable-gpu','--enable-webgpu','--enable-unsafe-webgpu','--use-angle=swiftshader','--ignore-gpu-blocklist','--use-vulkan=swiftshader','--use-webgpu-adapter=swiftshader','--enable-features=CDPScreenshotNewSurface,Vulkan']
argv=corrected['commandLine']['arguments']; stderr=(art/'corrected.stderr.log').read_text()
launched=int(re.search(r'<launched> pid=(\d+)',stderr).group(1))
raw_launch=shlex.split(next(line.split('<launching> ',1)[1] for line in stderr.splitlines() if '<launching> ' in line))
assert raw_launch==argv and launched==corrected['commandLine']['identity']['pid']==corrected['chrome']['identity']['pid']
assert corrected['commandLine']['identity']['ppid']==corrected['rootIdentity']['pid']
assert all(flag in argv for flag in flags) and '--enable-automation' not in argv and not any(arg.startswith('--type=') for arg in argv)
assert corrected['commandLine']['sha256']==corrected['chrome']['sha256']=='4d2512ae84986bf987e6ea8ef14ca1af555ae574fbaff5b5a8c78a8dd73fa36f'
errors={}
for role,row in [('original',original),('corrected',corrected)]:
 logs='\n'.join((art/f'{role}.{kind}.log').read_text() for kind in ['stdout','stderr'])
 events=[json.loads(x) for x in (art/f'{role}.events.jsonl').read_text().splitlines() if x]
 gpu_errors=[line for line in logs.splitlines() if re.search(r'SharedImage|SkSurface|VK_ERROR|DEVICE_LOST|device lost|Dawn.*(?:fail|error)|GPU.*(?:crash|exit.*unexpected)',line,re.I)]
 other_errors=[line for line in logs.splitlines() if ':ERROR:' in line]
 errors[role]={'independentGraphicsErrorLines':gpu_errors,'allChromeErrorLines':other_errors,'rawEventCount':len(events),'sourceReportedEventCount':len(row['events']),
  'rawLogBytes':[raw[f'{role}.{kind}.log']['bytes'] for kind in ['stdout','stderr']],
  'matchesRecordedLogBytes':row['logBytes']==[raw[f'{role}.{kind}.log']['bytes'] for kind in ['stdout','stderr']],
  'normalChromeExit':bool(re.search(r'<process did exit: exitCode=0, signal=null>',logs)),
  'cleanup':row['ownedCleanup'],'teardown':row['teardown'],'logFlushes':row['logFlushes'],'exit':row['exit']}
 assert not gpu_errors and not events and errors[role]['matchesRecordedLogBytes'] and errors[role]['normalChromeExit']
 assert row['ownedCleanup']['status']=='complete' and not row['ownedCleanup']['remaining'] and all(v['status']=='complete' for v in row['logFlushes'])
assert original['status']=='refused' and 'commandLine' not in original and 'context' not in original and original['reason']=='Error: Control operation deadline 5000ms'
assert corrected['status']=='pixels-observed' and corrected['exit']['code']==0 and corrected['context']['usage']==17 and corrected['context']['format']=='rgba8unorm'
assert corrected['context']['adapter']['architecture']=='swiftshader' and corrected['context']['adapter']['isFallbackAdapter'] is True
assert corrected['systemInfo']['gpu']['auxAttributes']['skiaBackendType']=='GaneshVulkan' and corrected['systemInfo']['gpu']['featureStatus']['vulkan']=='enabled_on'
for capture,expected in zip(corrected['colors'],[[255,0,0,255],[0,0,255,255]]):
 assert capture['gpu']['rawCenter']==expected and capture['gpu']['rgba']==expected and capture['gpu']['stride']==3072 and capture['gpu']['submitted'] and capture['presentationFrames']==2
receipt={'status':'INDEPENDENT_RETAINED_ARTIFACT_AUDIT_COMPLETE','run':37144781861,'immutableHead':head,'auditedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'artifacts':str(art),'auditProducerSHA256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
 'decoderAttempt':{'Pillow':'Unavailable ModuleNotFoundError; no installation; final verification uses stdlib decoder'},
 'rawInventory':raw,'headSourceSHA256Mapping':source,'independentPNGDecode':images,
 'actualArgv':{'matchesRawLaunchLine':True,'arguments':argv,'pid':launched,'ownedProducerIdentity':corrected['commandLine']['identity'],'rootIdentity':corrected['rootIdentity'],
  'executable':corrected['chrome'],'scope':'Retained fenced producer and matching raw launch witness; not a fresh remote proc or executable reread'},
 'backend':{'reportedSkiaBackend':corrected['systemInfo']['gpu']['auxAttributes']['skiaBackendType'],'reportedGLRenderer':corrected['systemInfo']['gpu']['auxAttributes']['glRenderer'],
  'reportedWebGPUAdapter':corrected['context']['adapter'],'systemInfoFeatureStatus':corrected['systemInfo']['gpu']['featureStatus'],
  'note':'SystemInfo webgpu=unavailable_software is retained, not normalized; actual fallback adapter and GPU+PNG pixels demonstrate this permitted unsafe software control only'},
 'rawErrorsEventsCleanup':errors,'gpuReadback':{'format':corrected['context']['format'],'usage':corrected['context']['usage'],'colors':corrected['colors'],
  'scope':'Retained real device producer records cross-checked against immutable source and independently decoded PNG; no new GPU execution'},
 'observation':corrected['observation'],'originalAttribution':{'recordedReason':original['reason'],'stage':'ownedChrome pending executable SHA capture',
  'evidence':'No commandLine field: assignment occurs only after bounded(ownedChrome(),5000) resolves and before SystemInfo. The async function has only one await: fileHash(/proc/<ownedChrome>/exe); synchronous proc checks finish before bounded installs its timeout. Original closed at18:36:29.037Z after startup logs through18:36:24.081Z.',
  'limits':'No I/O/CPU scheduling cause inferred; no graphics/canvas operation reached; not a SharedImage reproduction.'},
 'verdict':'Corrected standalone graphics profile qualifies red/blue readback and real screenshot pixels on recorded Chrome154 SwiftShader/Vulkan; no original-versus-corrected graphics causality, IFC/viewer/fidelity/performance or all-model claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out/'receipt.json'),'sourcesMatching':len(source),'pngs':images,'originalStage':receipt['originalAttribution']['stage'],
 'backend':receipt['backend'],'errorSummary':{k:{'graphicsErrors':len(v['independentGraphicsErrorLines']),'chromeErrors':len(v['allChromeErrorLines']),'events':v['rawEventCount'],'normalChromeExit':v['normalChromeExit']} for k,v in errors.items()}},indent=2))
