# Single-Haus WebGL admission observatory

SOURCE ONLY / UNRUN. No parser, typecheck, test, browser, build, runtime-lease
acceptance, or production edits were performed. Root v2/v3/v4 sources and
actual failure records are preserved. This scratch packet requires root review.

`gl-observer.mjs` is an 89-line self-contained `addInitScript` callback. It wraps
HTMLCanvasElement.getContext and WebGL2 compileShader/getShaderParameter with
the original receiver/arguments, preserving the native result or thrown object.
Observation failures refuse only the diagnostic; they do not change native calls.
It records numeric weak context/shader identities, native-call duration, observer
duration, and context-loss/restoration events without preventDefault. It only
observes the application's COMPILE_STATUS queries; it does not introduce another
compile-status query. False status records retain bounded getShaderSource,
getShaderInfoLog and isContextLost witnesses. Null status retains the original
query result and loss state without further invalid-shader queries. No getError, compile retry, GL state
mutation, or program substitution occurs.

Limits: 20,000 rows, 16 MiB encoded records, 64 contexts, 4,096 shaders, 4 MiB
cumulative failure GLSL/log text, 512 KiB per source/log. Bound exhaustion makes
the diagnostic incomplete/refused. Contexts have WeakRef terminal probes; shader
payloads are never retained. Listener cleanup and native descriptors are restored
once; foreign method replacements are retained and reported, never overwritten.
Call stop twice returns the same final snapshot. Prototype shape incompatibility
refuses rather than weakening observation. WebGL1/OffscreenCanvas-only rendering
is outside this observer's scope.

`runner.mjs` derives from root v4 with its genuine qualification, fixed graphics
profile, canonical loader, strict readiness, normal request errors, strict
pageerror abort, PID/starttime-fenced cleanup and finite server close. It admits
one fresh Chrome process and Haus first, without model substitutions or feature
overrides. Haus load deadline is 180 s; setup 60 s, launch 30 s, fixture wall cap
275 s, terminal GL capture <=2 s (including a declared 100 ms event tail), shared
owned teardown 30 s, server teardown 30 s, sampled own-tree RSS <=5 GiB. A page
error remains terminal even when a later event explains it. Reports persist before
teardown, and missing/refused observer capture cannot qualify a completed run.

The copied qualification still validates the four original public fixture files
as an existing common admission prerequisite; only Haus is loaded. It requires a
new root-owned graph2 lease with scope `map-gl-admission-untimed-diagnostic`, actual
baseline source/assets/build receipts, qualified Chrome bytes and a fresh actual
root preview_status receipt. This packet supplies no runtime lease. Do not reuse
the previous output-pressure lease to execute it.

After source review and explicit runtime allocation, root can prospectively run
from the qualified baseline root through its guardian:

```sh
pnpm exec tsx /tmp/6232-takeover/6537-map-gl-admission-source-v1/runner.mjs /absolute/qualification.json /absolute/new-gl-runtime-lease.json /absolute/output
```

This is an intrusive graphics admission diagnostic, not the 48-sample performance
cohort or a geometry identity verdict. Optional device/adapter metadata is not
invented. Existing MapLibre failure records establish a fragment compile page
error; they do not distinguish initial driver compile failure from context loss.
Even lost=true and a later event establish only observed ordering, not loss cause.
The 100 ms event tail is finite and cannot prove an event never arrived later.
