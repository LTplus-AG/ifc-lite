// SOURCE ONLY / UNRUN. Intrusive untimed WebGL2 observatory; no getError calls.
export function installMapGlObservatory(limits) {
  const host = globalThis, rows = [], contextIds = new WeakMap(), shaderIds = new WeakMap(), refs = new Map(), undo = [];
  const encoder = new TextEncoder(), proto = host.WebGL2RenderingContext?.prototype;
  let nextContext = 0, nextShader = 0, bytes = 0, sourceBytes = 0, refusal = null, stopped = false, final;
  const now = () => performance.now(), fail = error => { refusal ??= String(error); };
  function safe(fn) { if (!stopped && !refusal) { try { fn(); } catch (error) { fail(error); } } }
  function record(kind, fields = {}) {
    if (stopped || refusal) return;
    const row = { kind, atMs: now(), ...fields }, size = encoder.encode(JSON.stringify(row)).byteLength;
    if (rows.length >= limits.records || bytes + size > limits.recordBytes) { fail('GL record bound'); return; }
    rows.push(row); bytes += size;
  }
  if (!proto || typeof host.WeakRef !== 'function') { fail('WebGL2/WeakRef unavailable'); }
  const native = proto && Object.fromEntries(['isContextLost', 'getShaderInfoLog', 'getShaderSource'].map(name => [name, proto[name]]));
  function lost(gl) { return Reflect.apply(native.isContextLost, gl, []); }
  function context(gl, canvas) {
    let id = contextIds.get(gl); if (id !== undefined) return id;
    if (nextContext >= limits.contexts) throw new Error('GL context-ID bound');
    id = ++nextContext; contextIds.set(gl, id); refs.set(id, new WeakRef(gl));
    record('context-observed', { context: id, lost: lost(gl), lifecycleAttached: !!canvas });
    if (canvas) {
      const onLost = event => safe(() => record('webglcontextlost', { context: id, lost: lost(gl), statusMessage: event.statusMessage ?? null }));
      const onRestored = () => safe(() => record('webglcontextrestored', { context: id, lost: lost(gl) }));
      canvas.addEventListener('webglcontextlost', onLost); canvas.addEventListener('webglcontextrestored', onRestored);
      undo.push(() => { canvas.removeEventListener('webglcontextlost', onLost); canvas.removeEventListener('webglcontextrestored', onRestored); });
    }
    return id;
  }
  function shader(value) {
    if (!value || typeof value !== 'object') return null;
    let id = shaderIds.get(value); if (id !== undefined) return id;
    if (nextShader >= limits.shaders) throw new Error('GL shader-ID bound');
    id = ++nextShader; shaderIds.set(value, id); return id;
  }
  function failure(gl, value, status) {
    const source = Reflect.apply(native.getShaderSource, gl, [value]), info = Reflect.apply(native.getShaderInfoLog, gl, [value]);
    const sourceSize = typeof source === 'string' ? encoder.encode(source).byteLength : 0;
    const logSize = typeof info === 'string' ? encoder.encode(info).byteLength : 0;
    if (sourceSize > limits.oneSourceBytes || logSize > limits.oneSourceBytes || sourceBytes + sourceSize + logSize > limits.failureBytes) {
      fail('Failure GLSL/log bound; incomplete diagnostic'); return;
    }
    sourceBytes += sourceSize + logSize;
    record('compile-status-failure', { context: context(gl), shader: shader(value), status, lost: lost(gl), source, info });
  }
  function wrap(target, name, observe) {
    const descriptor = Object.getOwnPropertyDescriptor(target, name), original = descriptor?.value;
    if (typeof original !== 'function' || !descriptor.configurable) throw new Error(`Unsupported descriptor: ${name}`);
    const wrapped = function (...args) {
      const began = now(); let result, error, threw = false;
      try { result = Reflect.apply(original, this, args); } catch (caught) { error = caught; threw = true; }
      const originalMs = now() - began, observerAt = now();
      safe(() => observe(this, args, result, threw, error, originalMs));
      safe(() => record('hook-cost', { method: name, observerMs: now() - observerAt }));
      if (threw) throw error; return result;
    };
    Object.defineProperty(target, name, { ...descriptor, value: wrapped });
    undo.push(() => { if (target[name] === wrapped) Object.defineProperty(target, name, descriptor); else fail(`Foreign replacement retained: ${name}`); });
  }
  safe(() => {
    wrap(host.HTMLCanvasElement.prototype, 'getContext', (canvas, args, result, threw, error, originalMs) => {
      const kind = typeof args[0] === 'string' ? args[0] : '[non-string]';
      record('getContext', { contextType: kind, returned: result !== null && result !== undefined, threw, originalMs,
        ...(threw ? { error: String(error) } : {}) });
      if (result instanceof host.WebGL2RenderingContext) context(result, canvas);
    });
    wrap(proto, 'compileShader', (gl, args, _result, threw, error, originalMs) => {
      record('compileShader', { context: context(gl), shader: shader(args[0]), lost: lost(gl), threw, originalMs,
        ...(threw ? { error: String(error) } : {}) });
    });
    wrap(proto, 'getShaderParameter', (gl, args, result, threw, error, originalMs) => {
      if (args[1] !== 0x8b81) return; // COMPILE_STATUS: observe the application's actual query.
      record('compile-status', { context: context(gl), shader: shader(args[0]), status: result, lost: lost(gl), threw, originalMs,
        ...(threw ? { error: String(error) } : {}) });
      // A null result is retained above, but extra invalid-shader queries could set GL errors.
      if (!threw && result === false) failure(gl, args[0], result);
    });
  });
  host.__mapGlDiagnostic = { status: () => ({ refusal, records: rows.length, recordBytes: bytes, failureBytes: sourceBytes }),
    stop: () => {
      if (final) return final;
      for (const [id, reference] of refs) safe(() => { const gl = reference.deref(); record('terminal-context', { context: id, collected: !gl, lost: gl ? lost(gl) : null }); });
      for (const restore of undo.reverse()) { try { restore(); } catch (error) { fail(error); } }
      stopped = true;
      final = { refusal, rows, recordBytes: bytes, failureBytes: sourceBytes, contexts: nextContext, shaders: nextShader,
        timeOrigin: performance.timeOrigin, metric: 'Actual application GL calls plus intrusive read-only diagnostics; no driver/lifecycle cause inferred' };
      return final;
    } };
}
