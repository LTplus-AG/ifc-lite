// Scratch admission only. Nothing here builds, downloads or launches a browser.
import { readFileSync, statSync } from 'node:fs';
import { resolve, join, isAbsolute } from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileHash, inventory } from './vendor/interleaved-assets.mjs';
import { FIXTURES } from './vendor/interleaved-plan.mjs';
export const BASELINE = 'baa7d34db1be4bc8bf0b3479df33275da3130fc6';
export const OWN_ROOT = '/home/louistrue/wt/6537-initial-reserve-base-baa-session6503';
const json = path => JSON.parse(readFileSync(path, 'utf8'));
const refuse = reason => { throw new Error(`REFUSE qualification: ${reason}`); };
const git = args => execFileSync('git', args, { cwd: OWN_ROOT, encoding: 'utf8' }).trim();
export async function qualify(qualificationPath, runtimeLeasePath) {
  if (process.platform !== 'linux') refuse('Linux-only owned diagnostic');
  const q = json(qualificationPath), lease = json(runtimeLeasePath);
  if (q.head !== BASELINE || q.root !== OWN_ROOT || git(['rev-parse', 'HEAD']) !== BASELINE) refuse('immutable baseline mismatch');
  if (git(['status', '--porcelain', '--untracked-files=no'])) refuse('tracked baseline source changed');
  if (q.sourceTree !== git(['rev-parse', 'HEAD^{tree}'])) refuse('source tree mismatch');
  const receipt = json(q.rootBuildReceiptPath);
  if (receipt.exit !== 0 || receipt.childExit !== 0 || receipt.cwd !== OWN_ROOT || receipt.budgetAbort) refuse('baseline root build receipt missing/failed');
  const command = receipt.command;
  if (!Array.isArray(command) || command[0] !== 'pnpm' || !((command[1] === 'build') || (command[1] === 'turbo' && command[2] === 'build'))) refuse('build did not run through baseline root Turbo');
  const sourceRecord = q.rootBuildStartPath ? json(q.rootBuildStartPath)
    : q.rootBuildPostSnapshotPath ? json(q.rootBuildPostSnapshotPath) : null;
  if (!sourceRecord || sourceRecord.head !== BASELINE || !sourceRecord.inputSHA256) refuse('source snapshot missing');
  if (q.rootBuildStartPath) {
    if (!sourceRecord.startedUTC || !receipt.startedUTC) refuse('source build freeze missing');
  } else if (sourceRecord.provenanceKind !== 'postbuild-git-object-snapshot'
    || sourceRecord.sourceTree !== q.sourceTree || !Number.isFinite(Date.parse(sourceRecord.capturedUTC))) {
    refuse('explicit postbuild snapshot missing; this is not a prebuild freeze');
  }
  const tracked = git(['ls-files']).split('\n').filter(path => /^(?:apps\/|packages\/|rust\/|scripts\/|\.cargo\/)/.test(path)
    || /^(?:Cargo\.(?:toml|lock)|rust-toolchain\.toml|package\.json|pnpm-lock\.yaml|pnpm-workspace\.yaml|turbo\.json|tsconfig.*\.json)$/.test(path));
  // Compare Git's content-addressed immutable tree in one bounded read rather
  // than spawning a process per tracked input. SHA256 also pins the snapshot.
  const treeRows = execFileSync('git', ['ls-tree', '-rz', BASELINE], { cwd: OWN_ROOT, maxBuffer: 64 * 1024 ** 2 }).toString().split('\0').filter(Boolean);
  const immutableBlobs = new Map(treeRows.map(row => {
    const match = /^(\d+) (\w+) ([0-9a-f]+)\t([\s\S]+)$/.exec(row);
    if (!match || match[2] !== 'blob') refuse('unsupported immutable source tree entry');
    return [match[4], { mode: match[1], oid: match[3] }];
  }));
  for (const path of tracked) {
    const actual = readFileSync(join(OWN_ROOT, path));
    const immutable = immutableBlobs.get(path);
    const blobId = createHash('sha1').update(`blob ${actual.byteLength}\0`).update(actual).digest('hex');
    if (!immutable || immutable.mode === '120000' || blobId !== immutable.oid) refuse(`workspace differs from immutable git object: ${path}`);
    if (typeof sourceRecord.inputSHA256[path] !== 'string' || createHash('sha256').update(actual).digest('hex') !== sourceRecord.inputSHA256[path]) refuse(`source snapshot missing/changed: ${path}`);
  }
  const wasmReceipt = json(q.wasmBuildReceiptPath);
  const expectedWasm = wasmReceipt.artifacts?.['ifc-lite_bg.wasm']?.SHA256;
  if (wasmReceipt.head !== BASELINE || wasmReceipt.actualBuild?.exit !== 0 || !wasmReceipt.allFrozenInputsUnchanged
    || !/^[a-f0-9]{64}$/.test(expectedWasm ?? '')) refuse('qualified source WASM receipt missing');
  const wasmPath = join(OWN_ROOT, 'packages/wasm/pkg/ifc-lite_bg.wasm');
  if (await fileHash(wasmPath) !== expectedWasm) refuse('actual baseline WASM changed');
  const dist = join(OWN_ROOT, 'apps/viewer/dist'), assets = await inventory(dist);
  if (JSON.stringify(assets) !== JSON.stringify(q.viewerAssets)) refuse('qualified production assets absent/changed');
  const defaultWasmPaths = assets.filter(asset => asset.path.endsWith('.wasm') && asset.sha256 === expectedWasm).map(asset => `/${asset.path}`);
  if (!defaultWasmPaths.length) refuse('production viewer serves no qualified source WASM');
  if (lease.owner !== '/root' || lease.graph !== 'graph1' || lease.scope !== 'map-gl-admission-untimed-diagnostic'
    || lease.baselineHead !== BASELINE || !lease.linuxChromeAuthorized || !(Date.parse(lease.expiresUTC) > Date.now())
    || !(lease.rssCeilingBytes > 0 && lease.rssCeilingBytes <= 5 * 1024 ** 3)) refuse('current root graph1/runtime allocation unavailable');
  const preview = json(lease.previewStatusReceiptPath);
  if (!preview.capturedUTC || !Number.isFinite(Date.parse(preview.capturedUTC)) || Date.now() - Date.parse(preview.capturedUTC) > 120_000 || Date.parse(preview.capturedUTC) > Date.now()
    || typeof preview.available !== 'boolean' || typeof preview.visible !== 'boolean') refuse('fresh actual root preview_status receipt missing');
  if (!isAbsolute(lease.chromeExecutable) || await fileHash(lease.chromeExecutable) !== lease.chromeExecutableSha256) refuse('qualified Linux Chrome executable mismatch');
  const manifestPath = join(OWN_ROOT, 'tests/models/manifest.json'), manifest = json(manifestPath), fixtures = [];
  for (const fixture of FIXTURES) {
    const entry = manifest.files.find(item => item.path === fixture.path), file = join(OWN_ROOT, 'tests/models', fixture.path);
    if (!entry || statSync(file).size !== entry.size || await fileHash(file) !== entry.sha256) refuse(`fixed public fixture absent/changed: ${fixture.path}`);
    fixtures.push({ ...fixture, ...entry, file });
  }
  return { head: BASELINE, sourceTree: q.sourceTree, root: OWN_ROOT, dist, assets, expectedWasm, defaultWasmPaths, fixtures,
    lease, preview, qualificationPath: resolve(qualificationPath), runtimeLeasePath: resolve(runtimeLeasePath),
    sourceEvidence: q.rootBuildStartPath ? 'genuine-prebuild-snapshot' : 'explicit-postbuild-snapshot-and-immutable-git-object-comparison; not historical build-time proof',
    manifestSha256: await fileHash(manifestPath), release: manifest.release_tag, baseUrl: manifest.base_url };
}
