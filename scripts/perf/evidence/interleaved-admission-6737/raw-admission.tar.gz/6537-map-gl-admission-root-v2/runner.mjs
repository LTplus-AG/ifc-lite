// UNRUN scratch runner proposal. Execute only after root reviews genuine leases.
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { qualify, OWN_ROOT } from './qualification.mjs';
import { installMapGlObservatory } from './gl-observer.mjs';
import { ViewerBenchmarkPage } from './vendor/viewer-benchmark-page.ts';
import { LIMITS } from './vendor/interleaved-plan.mjs';
import { inventory, fileHash } from './vendor/interleaved-assets.mjs';
import { serveFrozen } from './vendor/interleaved-server.mjs';
import { processIdentity, stopWitnessedProcesses } from './vendor/interleaved-cleanup.mjs';

const observerLimits = { records: 20_000, recordBytes: 16 * 1024 ** 2, contexts: 64, shaders: 4096,
  failureBytes: 4 * 1024 ** 2, oneSourceBytes: 512 * 1024 };
const [qualificationPath, runtimeLeasePath, outputPath] = process.argv.slice(2);
if (!qualificationPath || !runtimeLeasePath || !outputPath) throw new Error('Expected qualification.json runtime-lease.json output-directory');
const output = resolve(outputPath);
mkdirSync(output, { recursive: true });
const report = { status: 'admission-pending', samples: [], verdict: 'UNRUN until actual root leases qualify; diagnostic only, no performance verdict',
  unknownStages: ['driver compiler cause', 'context-loss initiation cause', 'loss/event ordering before observation'], observerLimits };
const save = () => writeFileSync(join(output, 'report.json'), JSON.stringify(report, null, 2));
save();
report.protocol = 'One fixed Haus fresh Chrome process, untimed GL admission diagnostic; strict readiness and page errors retained. No identity or performance verdict.';
let qualification, server;
const cohortStarted = Date.now();
function bounded(promise, milliseconds, label) {
  let timer;
  return Promise.race([promise, new Promise((_resolve, reject) => {
    timer = setTimeout(() => reject(new Error(`REFUSE: ${label} deadline`)), milliseconds);
  })]).finally(() => clearTimeout(timer));
}
function descendantSnapshot() {
  const identities = [];
  for (const name of readdirSync('/proc')) if (/^\d+$/.test(name)) {
    const identity = processIdentity(Number(name));
    if (identity) identities.push(identity);
  }
  const owned = new Set([process.pid]);
  for (let depth = 0; depth < 32; depth++) {
    const before = owned.size;
    for (const identity of identities) if (owned.has(identity.ppid)) owned.add(identity.pid);
    if (owned.size === before) break;
    if (depth === 31) throw new Error('REFUSE: descendant depth bound');
  }
  if (owned.size > 4096) throw new Error('REFUSE: own process count bound');
  let bytes = 0;
  for (const pid of owned) {
    try {
      const match = readFileSync(`/proc/${pid}/status`, 'utf8').match(/^VmRSS:\s+(\d+) kB$/m);
      if (match) bytes += Number(match[1]) * 1024;
    } catch (error) { if (error.code !== 'ENOENT' && error.code !== 'ESRCH') throw error; }
  }
  return { at: Date.now(), bytes, members: identities.filter(identity => owned.has(identity.pid) && identity.pid !== process.pid) };
}
async function oneFixture(fixture, chromium) {
  const arm = 'gl-observed';
  const row = { arm, family: fixture.family, file: fixture.path, status: 'started', startedUTC: new Date().toISOString(),
    observations: 'Intrusive single-Haus GL failure/lifecycle observatory; no timing/identity/driver-cause claim',
    logs: [], errors: [], requestFailures: [], wasmResponses: [], rss: [] };
  const path = join(output, `${fixture.family}-${arm}.json`), owned = new Map();
  let browser, page, monitor, abortReason, rejectAbort, logBytes = 0, workPromise, workSettled = false;
  const abortPromise = new Promise((_resolve, reject) => { rejectAbort = reject; });
  // Attach immediately; the guarded work races this rejection below.
  abortPromise.catch(error => { row.abortWitness = String(error); });
  function abort(reason) { abortReason ??= String(reason); rejectAbort(new Error(abortReason)); }
  const persist = () => writeFileSync(path, JSON.stringify(row, null, 2));
  persist();
  try {
    if (!(Date.parse(qualification.lease.expiresUTC) > Date.now())) throw new Error('REFUSE: graph1 lease expired');
    if (Date.now() - cohortStarted >= LIMITS.cohortMs) throw new Error('REFUSE: fixed cohort deadline');
    monitor = setInterval(() => {
      try {
        const snapshot = descendantSnapshot();
        for (const witness of snapshot.members) owned.set(witness.pid, witness);
        if (row.rss.length >= 20_000 || snapshot.bytes > qualification.lease.rssCeilingBytes) abort('REFUSE: own-tree RSS/sample ceiling');
        else row.rss.push({ at: snapshot.at, bytes: snapshot.bytes });
        if (!(Date.parse(qualification.lease.expiresUTC) > Date.now())) abort('REFUSE: graph1 lease expired');
        if (Date.now() - cohortStarted >= LIMITS.cohortMs) abort('REFUSE: fixed cohort deadline');
      } catch (error) { abort(`REFUSE: own-tree monitor failed: ${error}`); }
    }, 100);
    const work = async () => {
      browser = await chromium.launch({ executablePath: qualification.lease.chromeExecutable, timeout: 30_000,
        headless: true, args: ['--enable-gpu', '--enable-webgpu', '--enable-unsafe-webgpu', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
      if (abortReason) throw new Error(abortReason);
      const context = await browser.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1 });
      await context.addInitScript(installMapGlObservatory, observerLimits);
      page = await context.newPage();
      page.on('console', message => {
        const text = message.text(); logBytes += Buffer.byteLength(text);
        if (logBytes > 64 * 1024 ** 2 || row.logs.length >= 250_000) abort('REFUSE: console capture bound'); else row.logs.push(text);
      });
      page.on('pageerror', error => {
        if (row.errors.length < 256) row.errors.push({ message: String(error), stack: error.stack });
        else row.errorCaptureRefusal = 'Page-error capture bound';
        abort(`REFUSE: page error: ${error}`);
      });
      page.on('crash', () => abort('REFUSE: page crash'));
      page.on('requestfailed', request => {
        if (row.requestFailures.length >= 1024) abort('REFUSE: request-failure capture bound');
        else row.requestFailures.push({ url: request.url(), method: request.method(), failure: request.failure() });
      });
      page.on('response', response => {
        if (/\.wasm(?:[?#]|$)/.test(response.url())) {
          if (row.wasmResponses.length >= 256) abort('REFUSE: WASM response bound');
          else row.wasmResponses.push({ url: response.url(), status: response.status() });
        }
      });
      const benchmark = new ViewerBenchmarkPage(page, server.origin);
      const performanceSession = await context.newCDPSession(page);
      await performanceSession.send('Performance.enable');
      await bounded(benchmark.setup(), 60_000, 'viewer setup');
      row.runtime = await page.evaluate(() => ({ hardwareConcurrency: navigator.hardwareConcurrency,
        crossOriginIsolated, sharedArrayBuffer: typeof SharedArrayBuffer !== 'undefined', visibility: document.visibilityState }));
      row.runtime.browserVersion = browser.version();
      if (!row.runtime.crossOriginIsolated || !row.runtime.sharedArrayBuffer || row.runtime.hardwareConcurrency <= 1) throw new Error('REFUSE: default SAB pool unavailable');
      row.mainThreadMetricsBeforeLoad = await performanceSession.send('Performance.getMetrics');
      const glStatus = await page.evaluate(() => globalThis.__mapGlDiagnostic?.status());
      if (!glStatus || glStatus.refusal) throw new Error(`REFUSE: GL observer unavailable/refused ${glStatus?.refusal}`);
      await benchmark.loadFile(fixture.file, false);
      await benchmark.waitForCompletion(fixture.timeoutMs, true);
      row.readyUTC = new Date().toISOString();
      row.readinessMetricsInformationalOnly = benchmark.getMetrics();
      row.mainThreadMetricsAtReadiness = await performanceSession.send('Performance.getMetrics');
      const logs = benchmark.getConsoleLogs().join('\n');
      const starts = [...logs.matchAll(/processParallel start, fileSizeMB=[\d.]+ workerCount=(\d+)/g)];
      row.workerCount = starts.length === 1 ? Number(starts[0][1]) : null;
      row.workerIds = [...new Set([...logs.matchAll(/\[stream\] worker\[(\d+)\]/g)].map(match => Number(match[1])))].sort((a, b) => a - b);
      if (!row.workerCount || row.workerIds.length !== row.workerCount) throw new Error('REFUSE: actual default worker census absent');
      if (!row.wasmResponses.some(response => response.status === 200 && new URL(response.url).origin === server.origin
        && qualification.defaultWasmPaths.includes(new URL(response.url).pathname))
        || row.wasmResponses.some(response => response.status !== 200 || new URL(response.url).origin !== server.origin)) throw new Error('REFUSE: qualified WASM response witness absent/foreign/failed');
      row.status = 'pending-owned-cleanup';
    };
    workPromise = work();
    workPromise.then(() => { workSettled = true; }, () => { workSettled = true; });
    await bounded(Promise.race([workPromise, abortPromise]), fixture.timeoutMs + 95_000, 'finite diagnostic fixture');
  } catch (error) {
    row.status = 'refused'; row.reason = String(error); row.firstWorkFailure = String(error); row.firstWorkFailureStack = error instanceof Error ? error.stack : null;
  } finally {
    const deadline = Date.now() + LIMITS.teardownMs;
    if (abortReason) { row.status = 'refused'; row.abortRefusal = abortReason; row.reason ??= abortReason; }
    if (page && !row.glTrace) {
      try { row.glTrace = await bounded(page.evaluate(async () => {
        // Allow one bounded event tail to observe asynchronous loss/restoration delivery.
        await new Promise(resolve => setTimeout(resolve, 100));
        return globalThis.__mapGlDiagnostic?.stop();
      }), Math.max(1, Math.min(2000, deadline - Date.now())), 'bounded terminal GL retention'); }
      catch (error) { row.glTraceRetention = String(error); }
    }
    if (!row.glTrace || row.glTrace.refusal) { row.status = 'refused'; row.glAdmissionRefusal = row.glTrace?.refusal ?? 'No retained GL observatory'; }
    if (row.glTrace && (!row.glTrace.contexts || !row.glTrace.shaders)) { row.status = 'refused'; row.glAdmissionRefusal ??= 'No observed WebGL2 context/shader census'; }
    persist(); // Retain strict failure and GL result before owned teardown.
    if (browser) {
      try { await bounded(browser.close(), Math.max(1, deadline - Date.now()), 'owned browser teardown'); row.browserCleanup = 'complete'; }
      catch (error) { row.browserCleanup = String(error); row.status = 'refused'; }
    }
    if (!workSettled && workPromise) {
      try {
        await bounded(workPromise.then(() => 'settled', error => String(error)), Math.max(1, deadline - Date.now()), 'owned work settlement');
      } catch (error) { row.workCleanup = String(error); row.status = 'refused'; }
    }
    row.workSettledAtCleanup = workSettled;
    if (!workSettled) row.status = 'refused';
    clearInterval(monitor);
    row.ownedCleanup = await stopWitnessedProcesses([...owned.values()], Math.max(1, deadline - Date.now()));
    if (row.ownedCleanup.status !== 'complete') row.status = 'refused';
    if (!row.rss.length) { row.status = 'refused'; row.rssRefusal = 'REFUSE: no owned RSS observations'; row.reason ??= row.rssRefusal; }
    if (row.status === 'pending-owned-cleanup') row.status = 'complete';
    row.finishedUTC = new Date().toISOString(); persist();
  }
  return row;
}
try {
  for (const name of Object.keys(process.env)) if (name.startsWith('VIEWER_BENCHMARK_')) throw new Error(`REFUSE: default override ${name}`);
  qualification = await qualify(qualificationPath, runtimeLeasePath);
  report.qualification = qualification;
  report.verdict = 'Qualified source baseline, GL admission diagnostic only; no timing/identity/performance verdict';
  save();
  const require = createRequire(join(OWN_ROOT, 'package.json'));
  const { chromium } = require('@playwright/test');
  if (!chromium || typeof chromium.launch !== 'function') throw new Error('REFUSE: qualified Playwright Chromium launch adapter absent');
  server = await serveFrozen(qualification.dist, qualification.assets);
  const fixture = qualification.fixtures.find(item => item.family === 'house');
  if (!fixture || fixture.timeoutMs !== 180_000) throw new Error('REFUSE: fixed Haus plan absent/changed');
  const row = await oneFixture(fixture, chromium);
  report.samples.push({ family: row.family, arm: row.arm, status: row.status, path: `${row.family}-${row.arm}.json` }); save();
  if (row.status !== 'complete') throw new Error('REFUSE: fixed Haus incomplete; no replacement');
  report.status = 'pending-server-cleanup';
} catch (error) {
  report.status = 'refused'; report.reason = String(error); process.exitCode = 1;
} finally {
  save();
  if (server) {
    report.serverCleanup = await server.close(LIMITS.teardownMs);
    if (report.serverCleanup.status !== 'complete') { report.status = 'refused'; process.exitCode = 1; }
    try {
      if (JSON.stringify(await inventory(qualification.dist)) !== JSON.stringify(qualification.assets)) throw new Error('Production viewer assets changed');
      for (const fixture of qualification.fixtures) if (await fileHash(fixture.file) !== fixture.sha256) throw new Error(`Fixture changed: ${fixture.path}`);
      report.finalAssetVerification = 'complete';
    } catch (error) { report.status = 'refused'; report.reason = String(error); process.exitCode = 1; }
  }
  if (report.status === 'pending-server-cleanup') report.status = 'complete';
  save();
}
