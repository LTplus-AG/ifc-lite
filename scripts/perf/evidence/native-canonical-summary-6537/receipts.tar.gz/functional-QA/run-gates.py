import json,hashlib,pathlib,subprocess
root=pathlib.Path('/home/louistrue/wt/6537-native-canonical-stderr-session6503');out=pathlib.Path('/tmp/6232-takeover/6537-native-canonical-summary-qa-v1')
paths=['scripts/perf/native-probe-summary.mjs','scripts/perf/native-probe-summary.test.mjs','scripts/perf/native-hosted-cohort.mjs']
commands=[('lint',['/home/louistrue/.t3/worktrees/ifc-lite/t3code-6503fe2a/node_modules/.bin/oxlint','--deny-warnings','--format','default',*paths]),('module',['node','scripts/check-module-size.mjs']),('wiring',['node','scripts/check-test-wiring.mjs']),('source-text',['node','scripts/check-source-text-assertions.mjs']),('license',['node','scripts/add-license-headers.mjs','--check']),('diff',['git','diff','--check'])]
commands += [('syntax-'+str(i),['node','--check',p]) for i,p in enumerate(paths)]
rows=[]
for name,args in commands:
 r=subprocess.run(args,cwd=root,capture_output=True,timeout=120);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);rows.append({'name':name,'command':args,'exit':r.returncode,'stdoutSHA256':hashlib.sha256(r.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(r.stderr).hexdigest()})
(out/'gates.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps([{'name':x['name'],'exit':x['exit']} for x in rows]))
