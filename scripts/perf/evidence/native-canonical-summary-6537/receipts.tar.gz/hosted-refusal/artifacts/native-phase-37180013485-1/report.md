Native attribution: refused. Error: FD probe diagnostics refused

Explicit compile-once/held-FD protocol: original arm probes qualified separately. Canonical phases remain the best-total iteration with five raw totals/walls and ordered mesh FNVs. No Cargo in timed processes; FD intent alone is not execution proof. No browser or full-output identity claim.
