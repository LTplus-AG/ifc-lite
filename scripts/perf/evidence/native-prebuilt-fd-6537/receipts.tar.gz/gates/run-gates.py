import ast
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/louistrue/wt/6537-native-fd-prebuilt-session6503')
output = Path('/tmp/6232-takeover/6537-native-prebuilt-fd-source-gates-v1')
paths = ['scripts/perf/native-hosted-cohort.mjs', 'scripts/perf/native-hosted-plan.mjs',
    'scripts/perf/native-hosted-prepare.mjs', 'scripts/perf/native-hosted-process.mjs',
    'scripts/perf/native-prebuilt.mjs', 'scripts/perf/native-prebuilt.test.mjs', 'scripts/perf/native-prebuilt-startup-control.mjs']
commands = [
    ('lint', ['/home/louistrue/.t3/worktrees/ifc-lite/t3code-6503fe2a/node_modules/.bin/oxlint', '--deny-warnings', '--format', 'default', *paths]),
    ('module', ['node', 'scripts/check-module-size.mjs']),
    ('wiring', ['node', 'scripts/check-test-wiring.mjs']),
    ('source-text', ['node', 'scripts/check-source-text-assertions.mjs']),
    ('license', ['node', 'scripts/add-license-headers.mjs', '--check']),
    ('bash-syntax', ['bash', '-n', 'scripts/perf/probe.sh']),
    ('diff', ['git', 'diff', '--check']),
]
commands.extend(('node-syntax-' + str(index), ['node', '--check', path]) for index, path in enumerate(paths))
rows = []
for name, command in commands:
    value = subprocess.run(command, cwd=root, capture_output=True, timeout=120)
    (output / (name + '.stdout')).write_bytes(value.stdout)
    (output / (name + '.stderr')).write_bytes(value.stderr)
    rows.append({'name': name, 'command': command, 'exit': value.returncode,
        'stdoutSHA256': hashlib.sha256(value.stdout).hexdigest(),
        'stderrSHA256': hashlib.sha256(value.stderr).hexdigest()})
for path in ['scripts/perf/native-prebuilt-launcher.py', 'scripts/perf/native-prebuilt-control.py']:
    ast.parse((root / path).read_text(), filename=path)
    rows.append({'name': 'python-ast', 'path': path, 'status': 'PASS', 'noPycache': True})
(output / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows))
