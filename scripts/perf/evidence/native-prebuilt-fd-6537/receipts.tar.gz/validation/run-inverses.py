import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess

root = Path('/home/louistrue/wt/6537-native-fd-prebuilt-session6503')
output = Path('/tmp/6232-takeover/6537-native-prebuilt-fd-validation-v1')
source = root / 'scripts/perf/native-prebuilt-launcher.py'
original = source.read_bytes()
expected = '5e1735b43bdff16fab601a5cb4ff6aa7d81ff5eda8fcb9776d390319a8adbca0'
hash_bytes = lambda value: hashlib.sha256(value).hexdigest()
assert hash_bytes(original) == expected
mutations = [
    ('fd-to-path', b'os.execve(fd, arguments, environment)', b'os.execve(arguments[0], arguments, environment)'),
    ('binary-sha-bypass', b'and digest(data) == binary["sha256"], "actual held probe differs")', b'and True, "actual held probe differs")'),
]
def interrupt(signum, frame):
    raise SystemExit(128 + signum)
for selected in (signal.SIGTERM, signal.SIGINT):
    signal.signal(selected, interrupt)
summary = {'originalSHA256': expected, 'mutations': [], 'scope': 'unchanged registered real ELF oracle; no model/timing'}
try:
    for name, old, new in mutations:
        assert original.count(old) == 1
        changed = original.replace(old, new)
        (output / (name + '.mutant.py')).write_bytes(changed)
        source.write_bytes(changed)
        try:
            prefix = output / ('inverse-' + name)
            value = subprocess.run(['python3', '/tmp/6232-takeover/functional-budget-guardian-v3-disk-session6503.py',
                str(root), str(prefix), 'node', '--test', 'scripts/perf/native-prebuilt.test.mjs'],
                env={**os.environ, 'NATIVE_FD_CONTROL_REQUIRED': '1'}, capture_output=True, text=True, timeout=90)
            (output / ('inverse-' + name + '.guardian-stdout')).write_text(value.stdout)
            (output / ('inverse-' + name + '.guardian-stderr')).write_text(value.stderr)
            log = prefix.with_suffix('.log').read_text()
            row = {'name': name, 'mutantSHA256': hash_bytes(changed), 'exit': value.returncode,
                'assertionError': 'AssertionError' in log, 'oracleInput': 'unchanged scripts/perf/native-prebuilt.test.mjs',
                'guardian': json.loads(prefix.with_suffix('.json').read_text())}
            summary['mutations'].append(row)
            assert value.returncode == 1 and row['assertionError'], (name, value.returncode, log)
            assert not any(error in log for error in ['SyntaxError', 'ModuleNotFoundError', 'ERR_MODULE_NOT_FOUND', 'ImportError'])
        finally:
            source.write_bytes(original)
            assert source.read_bytes() == original
    prefix = output / 'restored-final-control'
    value = subprocess.run(['python3', '/tmp/6232-takeover/functional-budget-guardian-v3-disk-session6503.py',
        str(root), str(prefix), 'node', '--test', 'scripts/perf/native-prebuilt.test.mjs'],
        env={**os.environ, 'NATIVE_FD_CONTROL_REQUIRED': '1'}, capture_output=True, text=True, timeout=90)
    (output / 'restored-final-control.guardian-stdout').write_text(value.stdout)
    (output / 'restored-final-control.guardian-stderr').write_text(value.stderr)
    summary['restorationExit'] = value.returncode
    assert value.returncode == 0, value.stdout + value.stderr
finally:
    source.write_bytes(original)
    summary['finalSHA256'] = hash_bytes(source.read_bytes())
    summary['byteExactRestore'] = source.read_bytes() == original
    (output / 'inverse-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
