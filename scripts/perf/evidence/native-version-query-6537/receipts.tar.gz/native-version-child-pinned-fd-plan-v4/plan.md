# Prospective pinned live executable observation — #6537

PLAN ONLY; no source edits/execution/commit/publication. Preserve actual V2 missing-child refusal and V3 captured19/20 refusal. The current helper/process/tests remain exact reviewedV3. Benchmark250ms and startup-only2ms policies remain fixed, as do all resource/source/output/log/cleanup limits.

Problem observed, not assumed: V3 actually observed frozen rustc-vV PID81371 under directly admitted Cargo81362 and common owned ancestry. Actual compiler+parent inode/SHA and18 other predicates passed; the child disappeared before final live read during30ms correctness capture. This is not a child lifetime measurement. We can retain a contemporaneous positive proof by hashing an executable FD pinned while the observed process is still live; hashing need not require the process to outlive that work.

Minimum prospective paths:
- native-version-probe.mjs: add pin/hash helpers using openSync(proc-exe), fstatSync(bigint) regular-file dev+ino, actual SHA256 from held FD, repeated fstat integrity, deterministic close. Keep nativeExecutableProof(path) compatibility for existing real-file controls if useful, DRY underlying FD proof. No executable byte-copy cache.
- native-hosted-process.mjs: acquire compiler+parent executable FDs after fresh common census and current exact live records; immediately re-observe BOTH after all FD opens, requiring same PID/start/PPID/group/cwd/argv/executable/inode. Only then hash pinned FDs and compare frozen SHA. Finally observe parent strictly as before and separately classify final child disposition. Close both FDs in guaranteedfinally, preserving closure errors as refusal.
- native-version-probe.test.mjs: update real record-invariant fixtures for two distinct mandatory post-open live records+FD identity/hash proofs; add missing/reused/reparent/foreign/fd mismatch boundaries. No relaxed fake-success fixture without stated provenance.
- startup-control unchanged except receipt interpretation if needed: still requires one actual admitted version child; one run only after root reviews.

Chronological proof:
1. Existing candidate exact rustc path and argv[frozenrustc,-vV]. Existing parent admission+witness, fresh common owned parent/child snapshot, initial/current identities unchanged.
2. Open /proc/child/exe and /proc/parent/exe synchronously, fstat both (regular files only), retain actual dev/ino. Any exit/access/unknown/open failure is REFUSAL. Do not retry open against a reused PID.
3. Immediately re-observe both processes AFTER BOTH opens. Require exact same original/current PID/start/PPID/group/cwd/argv/executable/inode, parent still exact frozenCargo/Rustup with unchanged freshness predicates. If either disappears before these observations, REFUSAL. This is the contemporaneous binding of observed process to held FD, not merely a file-path hash.
4. Hash actual pinned child+parent FD contents; before/after fstat unchanged and equal frozen inode. Both SHA equal exact frozen compiler/parent. Source/hash metadata unchanged and verified externally as currentV3.
5. Parent remains strictly current and owned after hashing, as currentV3. No parent-completion shortcut is proposed. Child either still has exact same live full record, or is specifically absent at a final /proc/stat identity observation (ENOENT/ESRCH only), with explicit disposition exited-after-pinned-observation. Any current PID with different start/identity, missing permission, partially unobservable live process, changed/reparented record or arbitrary third executable REFUSES.

Absence semantics: processObservation null alone is insufficient: it can mean a vanished exe during a race. Use separate final processIdentity stat result to distinguish genuinely absent PID from still-present/changed/zombie/unobservable process. A final live child needs full exact record plus same start fence. An identity reading that still exists but lacks observable exe is conservative refusal (including zombies) in the minimal proposal. A PID that is absent at the explicit final identity observation is a contemporaneous absence claim only; do not claim captured exit code or normal-exit status. The frozen trusted compiler-vV exact-byte executable and observed exact args establish the no-op classification; raw canonical Cargo completion/no-compile log oracle remains independently required by the caller.

Safety: a later reused PID cannot manufacture a positive earlier observation; any PID present at final check must match original start and full record. We do not assert historical absence beyond that final observation. The process must survive FD acquisition and post-open observations, so this can still refuse very short queries. No wrappers, pauses, ptrace, compiler flags, permission/argv/path fallback, lower floors or skipped unknown graphs.

Meaningful prospective controls (UNRUN):
- real temporary executable copy: open/fstat while live, prove changed source pathname/unlinked file cannot change held FD byte witness; equal byte copy distinct inode refuses; pinned bad SHA/inode/nonregularfd refuses.
- stated record invariants for positive observed-live and explicit final-stat-absent dispositions; omission of post-open child/parent record or FD proof refuses; childmissingatopen refuses.
- exact final reusedPID/start, changedparent/childPPID/group/cwd/argv/path/inode, unknowncompiler, compileflags, reverseparenttransition, permission/unobserved/missingcensus/staleadmission all refuse.
- preserve current final-live positive control; no arbitrary record-null→success.
- useful FD-hash and final-reuse inverse mutations with unchanged controls, guaranteed exact restoration, only after root approves normals.
- ONE required actual dependency-free startup using existing2ms entrypoint and original commands; no retries if witness/proof still refuses.

This proposal replaces only the impossible post-hash child-live requirement with stronger contemporaneous pinned-FD binding plus explicit final-disposition checks. All remaining ownership/parent/hash/resource/log/cleanup predicates stay. No correctness or performance claim until actual execution and independent review.
