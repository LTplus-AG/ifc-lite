from pathlib import Path
import subprocess,json,hashlib,os,signal,sys
w=Path('/home/louistrue/wt/6537-native-version-child-session6503');root=Path('/tmp/6232-takeover');f=root/'6537-native-version-child-source-v3';out=root/'6537-native-version-child-validation-v3';out.mkdir(exist_ok=False)
guard=root/'functional-budget-guardian-v3-disk-session6503.py'
m=json.loads((f/'source-manifest.json').read_text());source=[]
for x in m['files']:
 p=w/x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'];source.append(x)
(out/'pre-run-source.json').write_text(json.dumps({'base':m['base'],'files':source,'equalFrozenV3':True},indent=2)+'\n')
active=None
class Interrupted(Exception):pass
def interrupted(sig,frame):
 if active and active.poll() is None:
  try:os.killpg(active.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 raise Interrupted(sig)
for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
def run(name,command):
 global active
 args=['python3',str(guard),str(w),str(out/name),*command]
 with (out/(name+'-guardian.stdout')).open('wb') as log:
  active=subprocess.Popen(args,cwd=w,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=active.wait()
  except BaseException:
   try:os.killpg(active.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:active.wait(timeout=35)
   except subprocess.TimeoutExpired:
    try:os.killpg(active.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    active.wait()
   raise
  finally:active=None
 print(json.dumps({'phase':name,'exit':code}),flush=True)
 return code
summary={'scope':'Finite correctness only; normal benchmark250ms fixed, startup-only2ms; no models/app build/browser/timings.'}
# Re-read frozen executable bytes/identities before any required controls.
prior=json.loads((root/'6537-native-version-child-validation-v2/startup-control/control.json').read_text())['tools']
tools=[]
for name in ['rustc','cargo','rustup']:
 p=Path(prior[name]);st=p.stat();identity={'dev':str(st.st_dev),'ino':str(st.st_ino)}
 assert identity==prior[name+'FileIdentity']
 actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==prior[name+'Sha256']
 tools.append({'name':name,'path':str(p),'sha256':actual,'fileIdentity':identity})
(out/'pre-run-tools.json').write_text(json.dumps({'equalActualV2':True,'files':tools},indent=2)+'\n')
files=['scripts/perf/native-observation-policy.test.mjs','scripts/perf/native-version-probe.test.mjs','scripts/perf/native-hosted.test.mjs','scripts/perf/native-cargo-resolution.test.mjs','scripts/perf/native-compiler.test.mjs','scripts/perf/sdk-resources.test.mjs']
summary['normalExit']=run('normal-controls',['env','NATIVE_COMPILER_CONTROL_REQUIRED=1','node','--test',*files])
if summary['normalExit']==0:
 helper=w/'scripts/perf/native-hosted-process.mjs';original=helper.read_bytes();(out/'reviewed-native-hosted-process.mjs').write_bytes(original)
 before=b"{ scope: 'normal-native-execution', intervalMs: 250 }";after=b"{ scope: 'normal-native-execution', intervalMs: 2 }"
 assert original.count(before)==1
 mutant=original.replace(before,after);(out/'policy-mutated-native-hosted-process.mjs').write_bytes(mutant)
 summary['policyMutation']={'originalSha256':hashlib.sha256(original).hexdigest(),'mutatedSha256':hashlib.sha256(mutant).hexdigest()}
 try:
  helper.write_bytes(mutant)
  summary['policyMutation']['exit']=run('policy-inverse',['node','--test','scripts/perf/native-observation-policy.test.mjs'])
 finally:
  helper.write_bytes(original);assert helper.read_bytes()==original
  summary['policyMutation']['byteExactRestored']=True
 summary['restoredExit']=run('restored-controls',['node','--test','scripts/perf/native-observation-policy.test.mjs'])
 if summary['restoredExit']==0 and summary['policyMutation']['exit']!=0:
  summary['startupExit']=run('real-startup',['env','NATIVE_COMPILER_CONTROL_REQUIRED=1','NATIVE_STARTUP_CONTROL_OUTPUT='+str(out/'startup-control'),'node','scripts/perf/native-startup-control.mjs'])
assert all(hashlib.sha256((w/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in source)
summary['allSevenSourceFinallyEqualV3']=True
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
