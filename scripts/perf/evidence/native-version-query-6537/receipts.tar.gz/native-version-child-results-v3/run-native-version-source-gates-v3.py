from pathlib import Path
import subprocess,json
w=Path('/home/louistrue/wt/6537-native-version-child-session6503');out=Path('/tmp/6232-takeover/6537-native-version-child-validation-v3');rows=[]
files=['scripts/perf/native-hosted-prepare.mjs','scripts/perf/native-hosted-process.mjs','scripts/perf/native-startup-control.mjs','scripts/perf/native-version-probe.mjs','scripts/perf/native-version-probe.test.mjs','scripts/perf/native-observation-policy.test.mjs']
commands=[('syntax-'+Path(x).stem,['node','--check',x]) for x in files]+[
 ('module',['node','scripts/check-module-size.mjs','--base','9baab5249df8dbce2ae3f461ef9a95ba5d726f7e']),
 ('wiring',['node','scripts/check-test-wiring.mjs']),('license',['node','scripts/add-license-headers.mjs','--check']),('diff',['git','diff','--check'])]
for name,args in commands:
 p=subprocess.run(args,cwd=w,capture_output=True,text=True);(out/(name+'.log')).write_text(p.stdout+p.stderr);rows.append({'name':name,'command':args,'exit':p.returncode})
(out/'source-gate-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows));raise SystemExit(0 if all(x['exit']==0 for x in rows) else 1)
