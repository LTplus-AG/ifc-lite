# Frozen native version-child proposal (#6537)

Source-only; all six new behavioral controls and the strengthened real startup control are UNRUN. No installation, Rust/model build, browser, benchmark, commit, push or dispatch followed the frozen predecessor refusal.

The original run37167463547 has zero completed samples/pairs. Its first Haus BASE sample observed exact rustc `-vV` PID6372/parent6361/group6358/source cwd; it was conservatively refused by the existing Cargo-only admission. Original raw receipts remain untouched.

Only fully observed `[expected.rustc, "-vV"]` can be a candidate. The guard first applies existing Cargo freshness fences to any parents; other compile/test work still refuses. Candidate proof requires an independently fresh common bounded root ancestry census, the directly admitted Cargo parent/witness, matching current PID/start/group/cwd/argv/path, actual current compiler and parent file dev/inode+SHA, and final live observations after hashing. Missing/permission fallback/disappeared/reused/reparented/stale/untracked processes refuse. Cargo directed Rustup→Cargo semantics remain unchanged. New version admissions have a separate receipt array and owned cleanup witness. Source/log/final-freeze/CPU/RSS/memory/cohort/noise limits and the benchmark's250ms sampling interval remain unchanged.

Proposed finite controls:

```sh
node --test scripts/perf/native-version-probe.test.mjs scripts/perf/native-hosted.test.mjs scripts/perf/native-cargo-resolution.test.mjs scripts/perf/native-compiler.test.mjs scripts/perf/sdk-resources.test.mjs
NATIVE_COMPILER_CONTROL_REQUIRED=1 node scripts/perf/native-startup-control.mjs
```

The new six controls assert independently stated ownership/argv/identity/ancestry invariants and real file copy/change identities. They are not real Cargo qualification; the mandatory startup path separately must observe the actual frozen Cargo→rustc child. It removes only the owned dependency-free temp crate's `target/.rustc_info.json` after warming, with hash/deletion receipt; no wrapper/compile flags change. It requires a real version exception, else explicitly REFUSED even if sample execution completes. The tiny version child may naturally finish between250ms polls. No observation is fabricated and no missing child can qualify.

Prospective control-only observability option (NOT IMPLEMENTED): an explicitly named startup-only shorter observation poll could retain the same full proof while leaving every real benchmark invocation at250ms. This improves witness probability rather than guaranteeing observation. A genuinely deterministic syscall/exec hold would need a separate reviewed control harness/prerequisite; none is claimed available. Root should choose this before execution if the strict current control cannot observe the actual short-lived process. No broad compiler wrapper/permission/path exception is proposed.

Meaningful inverse proposals (UNRUN): remove only the exact version argv equality in `rustcVersionCandidate`, so its altered-argv/compile-flag controls must genuinely assert; separately ignore only `actual===expected` in the frozen hash predicate, so changed current compiler/Cargo byte controls must genuinely assert. Keep tests and all other fences unchanged; exact finally restoration plus same controls must pass. Full-root source gates should include workflow test wiring, denied-warning scoped lint, size, source-assert and license.
