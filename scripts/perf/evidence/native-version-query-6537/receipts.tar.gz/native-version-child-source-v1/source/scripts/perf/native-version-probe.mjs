/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { isDeepStrictEqual } from 'node:util';
import { nativeFileIdentity, sameNativeFile } from './native-file-identity.mjs';
import { freshnessException, cargoWitnessRefreshPredicates } from './native-hosted-plan.mjs';

export function nativeExecutableProof(path) {
  const before = nativeFileIdentity(path);
  const sha256 = createHash('sha256').update(readFileSync(path)).digest('hex');
  const fileIdentity = nativeFileIdentity(path);
  if (!sameNativeFile(before, fileIdentity)) throw new Error('native executable changed while hashing');
  return { fileIdentity, sha256 };
}
export function rustcVersionCandidate(record, expected) {
  return Boolean(record && record.executableObserved === true && record.executable === expected.rustc
    && isDeepStrictEqual(record.argv, [expected.rustc, '-vV']));
}
const sameProcess = (left, right) => Boolean(left && right && left.pid === right.pid
  && left.startTime === right.startTime && left.pgrp === right.pgrp && left.ppid === right.ppid);
const sameObservedRecord = (left, right) => Boolean(sameProcess(left, right)
  && left.executableObserved === true && right.executableObserved === true
  && left.cwd === right.cwd && left.executable === right.executable
  && isDeepStrictEqual(left.argv, right.argv)
  && sameNativeFile(left.executableFileIdentity, right.executableFileIdentity));
const frozenHash = (actual, expected) => Boolean(/^[a-f0-9]{64}$/.test(expected ?? '') && actual === expected);

// A version query is the only admitted compiler child. A fresh common ancestry
// census and current live parent/child observations are mandatory, even when a
// previous scan already admitted the Cargo parent. No argv/permission fallback.
export function versionProbePredicates(record, expected, proof = {}) {
  const { snapshot, admittedParent, parentWitness, currentParent, currentChild,
    finalParent, finalChild } = proof;
  const childMember = snapshot?.members?.find(item => item.pid === record.pid);
  const parentMember = snapshot?.members?.find(item => item.pid === record.ppid);
  const parentTool = currentParent?.executable === expected.cargo ? 'cargo'
    : currentParent?.executable === expected.rustup ? 'rustup' : null;
  const refresh = admittedParent && currentParent && snapshot
    ? cargoWitnessRefreshPredicates(admittedParent, expected, snapshot, currentParent) : null;
  return {
    freshCommonCensus: Boolean(Number.isSafeInteger(proof.captureStartedAt) && Number.isSafeInteger(snapshot?.at)
      && Number.isSafeInteger(proof.captureCompletedAt) && proof.captureStartedAt <= snapshot.at
      && snapshot.at <= proof.captureCompletedAt),
    initialExactVersion: rustcVersionCandidate(record, expected),
    initialCompilerFileIdentity: sameNativeFile(record.executableFileIdentity, expected.rustcFileIdentity),
    currentExactVersion: rustcVersionCandidate(currentChild, expected),
    childSamePidStartGroupParent: sameProcess(record, currentChild),
    childSourceCwd: record.cwd === expected.directory && currentChild?.cwd === expected.directory,
    childOwnGroup: record.pgrp === expected.group && currentChild?.pgrp === expected.group,
    childFreshAncestry: sameProcess(record, childMember),
    parentFreshAncestry: Boolean(parentMember && currentParent && sameProcess(parentMember, currentParent)),
    directParent: Boolean(currentParent && currentChild && currentChild.ppid === currentParent.pid),
    parentPreviouslyAdmitted: Boolean(admittedParent && parentWitness
      && freshnessException(admittedParent, parentWitness, expected)),
    parentStillAdmitted: Boolean(currentParent && parentMember
      && freshnessException(currentParent, parentMember, expected)),
    parentSamePidStartGroupParent: sameProcess(admittedParent, currentParent),
    parentDirectedCargoContinuation: Boolean(refresh && Object.values(refresh).every(Boolean)),
    currentCompilerFileIdentity: sameNativeFile(currentChild?.executableFileIdentity, expected.rustcFileIdentity),
    currentCompilerHash: frozenHash(currentChild?.executableSha256, expected.rustcSha256),
    currentParentFileIdentity: Boolean(parentTool
      && sameNativeFile(currentParent.executableFileIdentity, expected[`${parentTool}FileIdentity`])),
    currentParentHash: Boolean(parentTool
      && frozenHash(currentParent.executableSha256, expected[`${parentTool}Sha256`])),
    childStillLiveAfterHashes: sameObservedRecord(currentChild, finalChild),
    parentStillLiveAfterHashes: sameObservedRecord(currentParent, finalParent),
  };
}
export function versionProbeAdmission(record, expected, proof) {
  const predicates = versionProbePredicates(record, expected, proof);
  if (!Object.values(predicates).every(Boolean)) return null;
  return { ...proof.currentChild, admission: 'exact-frozen-rustc-version-child', predicates,
    parent: proof.currentParent, previouslyAdmittedParent: proof.admittedParent,
    parentWitness: proof.parentWitness, finalParent: proof.finalParent, finalChild: proof.finalChild,
    ancestry: { at: proof.snapshot.at, captureStartedAt: proof.captureStartedAt, captureCompletedAt: proof.captureCompletedAt,
      child: proof.snapshot.members.find(item => item.pid === record.pid),
      parent: proof.snapshot.members.find(item => item.pid === record.ppid), depthBound: 32, processBound: 4096 },
    frozenRustc: { path: expected.rustc, sha256: expected.rustcSha256, fileIdentity: expected.rustcFileIdentity } };
}
