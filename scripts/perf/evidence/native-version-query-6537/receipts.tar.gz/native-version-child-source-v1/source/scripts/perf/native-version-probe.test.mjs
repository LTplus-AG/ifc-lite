/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, copyFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { cargoArgs } from './native-hosted-plan.mjs';
import { nativeExecutableProof, rustcVersionCandidate, versionProbeAdmission, versionProbePredicates } from './native-version-probe.mjs';

// Recorded OS-observation invariants; the separate real Cargo startup control
// must also witness the live version child. These do not stand in for that run.
function ownership() {
  const expected = { rustc: '/frozen/rustc', cargo: '/frozen/cargo', rustup: '/selected/rustup',
    directory: '/source/base', group: 20, rustcFileIdentity: { dev: '10', ino: '100' },
    cargoFileIdentity: { dev: '10', ino: '200' }, rustupFileIdentity: { dev: '10', ino: '300' },
    rustcSha256: 'a'.repeat(64), cargoSha256: 'b'.repeat(64), rustupSha256: 'c'.repeat(64) };
  const parent = { pid: 21, ppid: 20, pgrp: 20, startTime: '90', cwd: expected.directory,
    executableObserved: true, executable: expected.cargo, executableFileIdentity: expected.cargoFileIdentity,
    executableSha256: expected.cargoSha256, argv: [expected.cargo, ...cargoArgs] };
  const child = { pid: 22, ppid: 21, pgrp: 20, startTime: '99', cwd: expected.directory,
    executableObserved: true, executable: expected.rustc, executableFileIdentity: expected.rustcFileIdentity,
    executableSha256: expected.rustcSha256, argv: [expected.rustc, '-vV'] };
  const identity = ({ pid, ppid, pgrp, startTime }) => ({ pid, ppid, pgrp, startTime });
  return { expected, record: structuredClone(child), proof: { captureStartedAt: 100, captureCompletedAt: 102,
    admittedParent: structuredClone(parent), parentWitness: identity(parent),
    currentParent: structuredClone(parent), currentChild: structuredClone(child),
    finalParent: structuredClone(parent), finalChild: structuredClone(child),
    snapshot: { at: 101, members: [identity(parent), identity(child)] } } };
}
test('#6537 only the exact frozen rustc version child of a still-admitted live Cargo can qualify', () => {
  const { expected, record, proof } = ownership();
  assert.ok(Object.values(versionProbePredicates(record, expected, proof)).every(Boolean));
  const admitted = versionProbeAdmission(record, expected, proof);
  assert.equal(admitted.admission, 'exact-frozen-rustc-version-child');
  assert.deepEqual(admitted.argv, [expected.rustc, '-vV']);
  assert.equal(admitted.ancestry.parent.pid, admitted.ppid);
  assert.equal(versionProbeAdmission(record, expected, undefined), null, 'missing fresh proof must refuse');
});
test('#6537 compilation, alternate argv0, permission fallback and foreign compiler paths never become version queries', () => {
  const { expected, record, proof } = ownership();
  for (const changes of [{ argv: [expected.rustc, '-vV', '--crate-name', 'work'] },
    { argv: [expected.rustc, '-V'] }, { argv: ['rustc', '-vV'] },
    { executable: '/unknown/rustc' }, { executableObserved: false }]) {
    const altered = { ...record, ...changes };
    assert.equal(rustcVersionCandidate(altered, expected), false);
    assert.equal(versionProbeAdmission(altered, expected, proof), null);
  }
});
test('#6537 child/parent PID reuse, reparenting, group/cwd/argv/executable drift and missing observations refuse', () => {
  const original = ownership();
  const mutations = [
    p => { p.currentChild.pid++; }, p => { p.currentChild.startTime = '100'; },
    p => { p.currentChild.ppid++; }, p => { p.currentChild.pgrp++; }, p => { p.currentChild.cwd = '/foreign'; },
    p => { p.currentChild.argv.push('--emit=metadata'); }, p => { p.currentChild.executableObserved = false; },
    p => { p.currentChild = null; }, p => { p.currentParent = null; },
    p => { p.currentParent.pid++; }, p => { p.currentParent.startTime = '91'; },
    p => { p.currentParent.ppid++; }, p => { p.currentParent.pgrp++; }, p => { p.currentParent.cwd = '/foreign'; },
    p => { p.currentParent.argv.push('--locked'); }, p => { p.currentParent.executable = '/foreign/cargo'; },
    p => { p.currentParent.executableObserved = false; }, p => { p.admittedParent = null; },
    p => { p.admittedParent.startTime = '89'; }, p => { p.parentWitness = null; },
    p => { p.parentWitness.startTime = '89'; }, p => { p.finalChild = null; }, p => { p.finalParent = null; },
    p => { p.finalChild.startTime = '100'; }, p => { p.finalParent.executable = '/foreign/cargo'; },
  ];
  for (const mutate of mutations) {
    const { record, expected, proof } = structuredClone(original); mutate(proof);
    assert.equal(versionProbeAdmission(record, expected, proof), null, 'every live ownership fence is required');
  }
});
test('#6537 both parent and child must occur in the same fresh census with their exact identities', () => {
  for (const alter of [p => { p.snapshot.members = []; }, p => { p.snapshot.members.pop(); },
    p => { p.snapshot.members.shift(); }, p => { p.snapshot.members[0].startTime = '89'; },
    p => { p.snapshot.members[1].ppid = 23; }, p => { p.snapshot.members[1].pgrp = 19; },
    p => { p.snapshot.at = 99; }, p => { p.snapshot.at = 103; }]) {
    const { record, expected, proof } = ownership(); alter(proof);
    assert.equal(versionProbeAdmission(record, expected, proof), null);
  }
});
test('#6537 current compiler and Cargo hashes/file identities are mandatory even with correct paths and ancestry', () => {
  for (const alter of [p => { delete p.currentChild.executableSha256; },
    p => { p.currentChild.executableSha256 = 'f'.repeat(64); }, p => { p.currentChild.executableFileIdentity = { dev: '10', ino: '101' }; },
    p => { delete p.currentParent.executableSha256; }, p => { p.currentParent.executableSha256 = 'f'.repeat(64); },
    p => { p.currentParent.executableFileIdentity = { dev: '10', ino: '201' }; },
    p => { p.finalChild.executableFileIdentity = { dev: '10', ino: '101' }; }]) {
    const { record, expected, proof } = ownership(); alter(proof);
    assert.equal(versionProbeAdmission(record, expected, proof), null);
  }
  const { record, expected, proof } = ownership(); delete expected.rustcSha256;
  assert.equal(versionProbeAdmission(record, expected, proof), null);
});
test('#6537 frozen executable proof detects real copied-file identity and changed executable bytes', () => {
  const directory = mkdtempSync(join(tmpdir(), 'version-executable-proof-'));
  try {
    const path = join(directory, 'rustc'), copy = join(directory, 'copy');
    writeFileSync(path, 'independent exact executable content\n'); copyFileSync(path, copy);
    const original = nativeExecutableProof(path), copied = nativeExecutableProof(copy);
    assert.equal(copied.sha256, original.sha256, 'same bytes do not establish file identity');
    assert.notDeepEqual(copied.fileIdentity, original.fileIdentity);
    writeFileSync(path, 'changed executable content\n');
    assert.notEqual(nativeExecutableProof(path).sha256, original.sha256);
  } finally { rmSync(directory, { recursive: true, force: true }); }
});
