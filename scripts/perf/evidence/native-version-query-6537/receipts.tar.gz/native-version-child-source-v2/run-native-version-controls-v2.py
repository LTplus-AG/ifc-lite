from pathlib import Path
import subprocess,json,hashlib,os,signal,sys
w=Path('/home/louistrue/wt/6537-native-version-child-session6503');root=Path('/tmp/6232-takeover');f=root/'6537-native-version-child-source-v1';out=root/'6537-native-version-child-validation-v2';out.mkdir(exist_ok=False)
guard=root/'functional-budget-guardian-v3-disk-session6503.py'
m=json.loads((f/'source-manifest.json').read_text());source=[]
for x in m['files']:
 p=w/x['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'];source.append(x)
(out/'pre-run-source.json').write_text(json.dumps({'base':m['base'],'files':source,'equalFrozenV1':True},indent=2)+'\n')
active=None
class Interrupted(Exception):pass
def interrupted(sig,frame):
 if active and active.poll() is None:
  try:os.killpg(active.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 raise Interrupted(sig)
for sig in [signal.SIGINT,signal.SIGTERM]:signal.signal(sig,interrupted)
def run(name,command):
 global active
 args=['python3',str(guard),str(w),str(out/name),*command]
 with (out/(name+'-guardian.stdout')).open('wb') as log:
  active=subprocess.Popen(args,cwd=w,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=active.wait()
  except BaseException:
   try:os.killpg(active.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:active.wait(timeout=35)
   except subprocess.TimeoutExpired:
    try:os.killpg(active.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    active.wait()
   raise
  finally:active=None
 print(json.dumps({'phase':name,'exit':code}),flush=True)
 return code
summary={'scope':'Finite correctness only; no models/app build/browser/timings; fixed guardian and250ms startup polling.'}
files=['scripts/perf/native-version-probe.test.mjs','scripts/perf/native-hosted.test.mjs','scripts/perf/native-cargo-resolution.test.mjs','scripts/perf/native-compiler.test.mjs','scripts/perf/sdk-resources.test.mjs']
summary['normalExit']=run('normal-controls',['env','NATIVE_COMPILER_CONTROL_REQUIRED=1','node','--test',*files])
if summary['normalExit']==0:
 summary['startupExit']=run('real-startup',['env','NATIVE_COMPILER_CONTROL_REQUIRED=1','NATIVE_STARTUP_CONTROL_OUTPUT='+str(out/'startup-control'),'node','scripts/perf/native-startup-control.mjs'])
 helper=w/'scripts/perf/native-version-probe.mjs';original=helper.read_bytes();(out/'reviewed-native-version-probe.mjs').write_bytes(original)
 mutations={'argv':(b"&& isDeepStrictEqual(record.argv, [expected.rustc, '-vV'])",b'&& true'),
  'hash':(b'&& actual === expected',b'&& true')}
 summary['mutations']={}
 for name,(before,after) in mutations.items():
  assert original.count(before)==1
  mutant=original.replace(before,after);summary['mutations'][name]={'originalSha256':hashlib.sha256(original).hexdigest(),'mutatedSha256':hashlib.sha256(mutant).hexdigest()}
  (out/(name+'-mutated-native-version-probe.mjs')).write_bytes(mutant)
  try:
   helper.write_bytes(mutant)
   summary['mutations'][name]['exit']=run(name+'-inverse',['node','--test','scripts/perf/native-version-probe.test.mjs'])
  finally:
   helper.write_bytes(original)
   assert helper.read_bytes()==original
   summary['mutations'][name]['byteExactRestored']=True
 summary['restoredExit']=run('restored-controls',['node','--test','scripts/perf/native-version-probe.test.mjs'])
 summary['allSixSourceRestored']=all(hashlib.sha256((w/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in source)
assert all(hashlib.sha256((w/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in source)
summary['allSixSourceFinallyEqual']=True
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
