# V3 native startup observation proposal — #6537

SOURCE ONLY / UNRUN. V2 is immutable: normal30 PASS, argv/hash inverses genuine assertions, restored6 PASS, but ONE real250ms startup REFUSED because no version child was observed. It remains unqualified. V3 has not executed a child, compiler, model or browser.

The private shared execution implementation receives a wrapper-selected policy. Public execute fixes250ms. Separately named executeStartupControl fixes2ms and is used only by the real dependency-free startup sample. The warm control and ALL existing preparation/cohort calls remain public execute. Both reject unknown options (including every polling-policy key) before creating logs or spawning. No environment or caller option changes these intervals. The receipt reports the selected scope and interval. The same resource/observation/evidence/log/wall/cleanup bounds apply; no fences are removed.

All20 version ownership/hash/current/final proof predicates, actual executable hashes, fresh common ancestry and full raw error/cleanup retention remain exactV2. No wrapper, argv, toolchain, source, probe, fixture, retry or canonical benchmark schedule change.2ms is a nominal timer registration, not a guaranteed actual observation cadence: synchronous process scans and hashes may delay it. A captured child still must survive full ancestry/current/hash/final proof. Any missing child or failed final proof remains actualREFUSAL and ends the one attempt.

Two new functional controls are wired in the native workflow. The first uses actual finite Node children, real census/log pipes/cleanup, and a forwarding timer spy to observe the actual interval registration of both entrypoints; it also asserts exact policy receipts and real complete logs. The second submits polling overrides to both real entrypoints and requires rejection before log-file creation/child launch. No source-text assertions or fabricated process records are used by these two controls.

Prospective bounded validation commands (NOT EXECUTED):

```sh
NATIVE_COMPILER_CONTROL_REQUIRED=1 node --test scripts/perf/native-observation-policy.test.mjs scripts/perf/native-version-probe.test.mjs scripts/perf/native-hosted.test.mjs scripts/perf/native-cargo-resolution.test.mjs scripts/perf/native-compiler.test.mjs scripts/perf/sdk-resources.test.mjs
NATIVE_COMPILER_CONTROL_REQUIRED=1 NATIVE_STARTUP_CONTROL_OUTPUT=/tmp/6232-takeover/6537-native-version-child-validation-v3/startup-control node scripts/perf/native-startup-control.mjs
```

Use existing guardian with start24GiB/live8GiB/owned12GiB/diskstart10GB/live2GB, unchanged. Proposed normal32controls (prior30 plus2) then ONE real startup; no automatic retry. No installation expected (Node builtins, actual repository-pinned Rust toolchain already usedV2). Cheap syntax/module/wiring/license/diff source gates follow root authorization. Current gitdiffcheck exits0; all new runtime/gates remain UNRUN.

Potential prospective scheduling inverse: changing only normal wrapper policy250→2 must fail the real registered-timer+receipt invariant; changing only startup2→250 must fail the same unchanged control. These are unexecuted proposals, not approved additional runs.
