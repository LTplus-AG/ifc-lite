from pathlib import Path
w=Path('/home/louistrue/wt/6537-native-version-child-session6503')
p=w/'scripts/perf/native-version-probe.mjs';s=p.read_text()
s=s.replace("import { readFileSync } from 'node:fs';", "import { openSync, closeSync, fstatSync, readSync } from 'node:fs';")
s=s.replace("import { nativeFileIdentity, sameNativeFile }", "import { sameNativeFile }")
a=s.index('export function nativeExecutableProof(');b=s.index('export function rustcVersionCandidate',a)
s=s[:a]+'''function pinnedStat(fd) {
  const stat = fstatSync(fd, { bigint: true });
  if (!stat.isFile()) throw new Error('pinned native executable is not a regular file');
  const bytes = Number(stat.size);
  if (!Number.isSafeInteger(bytes) || bytes <= 0) throw new Error('pinned native executable size refused');
  return { fileIdentity: { dev: String(stat.dev), ino: String(stat.ino) }, bytes };
}
function pinExecutable(source) {
  const fd = openSync(source.path, 'r');
  try {
    const actual = pinnedStat(fd);
    if (!Number.isSafeInteger(source.bytes) || source.bytes <= 0 || actual.bytes !== source.bytes
      || !sameNativeFile(actual.fileIdentity, source.fileIdentity)) throw new Error('pinned native executable frozen binding refused');
    return { fd, ...actual };
  } catch (error) { closeSync(fd); throw error; }
}
// The caller observes live process binding after BOTH opens and before hashing.
// Closing the first FD is mandatory even if opening the second fails.
export function withPinnedNativeExecutables(sources, capture) {
  const pins = [], errors = []; let result;
  try {
    if (sources.length !== 2) throw new Error('two pinned native executables required');
    for (const source of sources) pins.push(pinExecutable(source));
    result = capture(pins);
  } catch (error) { errors.push(error); }
  finally { for (const pin of pins) { try { closeSync(pin.fd); } catch (error) { errors.push(error); } } }
  if (errors.length) throw new AggregateError(errors, 'pinned native executable capture/close refused');
  return result;
}
export function hashPinnedNativeExecutable(pin) {
  const before = pinnedStat(pin.fd);
  if (before.bytes !== pin.bytes || !sameNativeFile(before.fileIdentity, pin.fileIdentity)) throw new Error('pinned native executable changed before hashing');
  const hash = createHash('sha256'), chunk = Buffer.alloc(Math.min(65536, pin.bytes));
  let offset = 0;
  while (offset < pin.bytes) {
    const count = readSync(pin.fd, chunk, 0, Math.min(chunk.length, pin.bytes - offset), offset);
    if (count === 0) throw new Error('pinned native executable ended before frozen size');
    hash.update(chunk.subarray(0, count)); offset += count;
  }
  const extra = readSync(pin.fd, chunk, 0, 1, pin.bytes), after = pinnedStat(pin.fd);
  if (extra !== 0 || after.bytes !== pin.bytes || !sameNativeFile(before.fileIdentity, after.fileIdentity)) {
    throw new Error('pinned native executable changed while hashing');
  }
  return { ...after, sha256: hash.digest('hex') };
}
''' +s[b:]
a=s.index('// A version query')
s=s[:a]+'''export function versionPostOpenBindings(record, expected, proof) {
  return Boolean(proof.currentChild && proof.currentParent && proof.postOpenChild && proof.postOpenParent
    && sameObservedRecord(proof.currentChild, proof.postOpenChild)
    && sameObservedRecord(proof.currentParent, proof.postOpenParent)
    && sameProcess(record, proof.postOpenChild)
    && rustcVersionCandidate(proof.postOpenChild, expected)
    && freshnessException(proof.postOpenParent, proof.parentWitness, expected)
    && Number.isSafeInteger(proof.pinsOpenedAt) && Number.isSafeInteger(proof.postOpenObservedAt)
    && proof.snapshot?.at <= proof.pinsOpenedAt && proof.pinsOpenedAt <= proof.postOpenObservedAt);
}
export function versionChildDisposition(record, proof) {
  const stat = proof.finalChildStat;
  if (!stat?.observed || (stat.before && !sameProcess(record, stat.before))
    || (stat.after && !sameProcess(record, stat.after))) return null;
  if (proof.finalChild && stat.after && sameObservedRecord(proof.postOpenChild, proof.finalChild)
    && sameProcess(record, stat.after)) return 'still-live-after-pinned-hash';
  if (proof.finalChild === null && stat.after === null) return 'exited-after-pinned-observation';
  return null;
}
const frozenPin = (pin, expected, name) => Boolean(pin && Number.isSafeInteger(expected[`${name}FileBytes`])
  && expected[`${name}FileBytes`] > 0 && pin.bytes === expected[`${name}FileBytes`]
  && sameNativeFile(pin.fileIdentity, expected[`${name}FileIdentity`])
  && frozenHash(pin.sha256, expected[`${name}Sha256`]));

''' +s[a:]
s=s.replace('finalParent, finalChild } = proof;', 'finalParent } = proof;')
s=s.replace('    currentCompilerHash: frozenHash(currentChild?.executableSha256, expected.rustcSha256),', '    pinnedCompilerBytesHashIdentity: frozenPin(proof.pinnedChild, expected, \'rustc\'),')
s=s.replace("    currentParentHash: Boolean(parentTool\n      && frozenHash(currentParent.executableSha256, expected[`${parentTool}Sha256`])),\n    childStillLiveAfterHashes: sameObservedRecord(currentChild, finalChild),", "    pinnedParentBytesHashIdentity: Boolean(parentTool && frozenPin(proof.pinnedParent, expected, parentTool)),\n    liveBindingsAfterBothFdOpens: versionPostOpenBindings(record, expected, proof),\n    childFinalDispositionObserved: versionChildDisposition(record, proof) !== null,")
s=s.replace('parentWitness: proof.parentWitness, finalParent: proof.finalParent, finalChild: proof.finalChild,', 'parentWitness: proof.parentWitness, postOpenParent: proof.postOpenParent, postOpenChild: proof.postOpenChild,\n    pinnedParent: proof.pinnedParent, pinnedChild: proof.pinnedChild, finalParent: proof.finalParent, finalChild: proof.finalChild,\n    finalChildStat: proof.finalChildStat, childDisposition: versionChildDisposition(record, proof),')
s=s.replace('sha256: expected.rustcSha256, fileIdentity:', 'sha256: expected.rustcSha256, bytes: expected.rustcFileBytes, fileIdentity:')
p.write_text(s)
p=w/'scripts/perf/native-hosted-process.mjs';s=p.read_text().replace('nativeExecutableProof, rustcVersionCandidate,', 'withPinnedNativeExecutables, hashPinnedNativeExecutable, versionPostOpenBindings, rustcVersionCandidate,')
a=s.index('    const childFile = nativeExecutableProof(');b=s.index('  proof.captureCompletedAt =',a)
s=s[:a]+'''    withPinnedNativeExecutables([
      { path: `/proc/${child.pid}/exe`, fileIdentity: expected.rustcFileIdentity, bytes: expected.rustcFileBytes },
      { path: `/proc/${parent.pid}/exe`, fileIdentity: expected[`${parentTool}FileIdentity`], bytes: expected[`${parentTool}FileBytes`] },
    ], ([childPin, parentPin]) => {
      proof.pinsOpenedAt = Date.now();
      proof.pinnedChild = { fileIdentity: childPin.fileIdentity, bytes: childPin.bytes };
      proof.pinnedParent = { fileIdentity: parentPin.fileIdentity, bytes: parentPin.bytes };
      proof.postOpenChild = liveRecord(record.pid); proof.postOpenParent = liveRecord(record.ppid);
      proof.postOpenObservedAt = Date.now();
      if (!versionPostOpenBindings(record, expected, proof)) throw new Error('live process binding after both FD opens refused');
      proof.pinnedChild = hashPinnedNativeExecutable(childPin);
      proof.pinnedParent = hashPinnedNativeExecutable(parentPin);
      proof.finalParent = liveRecord(record.ppid);
      const before = processIdentity(record.pid);
      proof.finalChild = before ? liveRecord(record.pid) : null;
      proof.finalChildStat = { observed: true, before, after: processIdentity(record.pid) };
    });
  }
''' +s[b:]
p.write_text(s)
p=w/'scripts/perf/native-hosted-prepare.mjs';s=p.read_text().replace("|| provenance.files[provenance.tools[name]] !== provenance.tools[`${name}Sha256`])", "|| provenance.files[provenance.tools[name]] !== provenance.tools[`${name}Sha256`]\n      || statSync(provenance.tools[name]).size !== provenance.tools[`${name}FileBytes`])")
s=s.replace('tools[`${name}Sha256`] = files[tools[name]];', 'tools[`${name}Sha256`] = files[tools[name]];\n    tools[`${name}FileBytes`] = statSync(tools[name]).size;')
p.write_text(s)
p=w/'scripts/perf/native-startup-control.mjs';s=p.read_text().replace('rmSync }', 'rmSync, statSync }')
s=s.replace('tools[`${name}Sha256`] = hash(readFileSync(tools[name]));', 'tools[`${name}Sha256`] = hash(readFileSync(tools[name]));\n      tools[`${name}FileBytes`] = statSync(tools[name]).size;')
s=s.replace('for (const name of [\'cargo\', \'rustc\']) {', 'for (const name of [\'rustup\', \'cargo\', \'rustc\']) {\n        assert.equal(statSync(report.tools[name]).size, report.tools[`${name}FileBytes`], `frozen ${name} size changed`);')
p.write_text(s)
