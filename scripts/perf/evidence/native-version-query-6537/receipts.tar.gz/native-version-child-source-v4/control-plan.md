# V4 pinned executable observation — SOURCE ONLY, UNRUN

ActualV2 missing-child refusal and V3 captured19/20 final-child-liveness refusal are immutable. This new source has not executed controls/compiler/startup/models/browser/builds. No publication. Normal execute250ms/startup-only2ms source+timer controls+workflow wiring remain byte-exactV3.

Changed5paths: native-version-probe helper150lines; native-hosted-process213; native-hosted-prepare150; native-startup-control138; native-version-probe.test166. All productionmodules<400. Freeze metadata now carries actual rustc/Cargo/Rustup file byte sizes bound to existing inode/hash frozenfiles and verified at final gate. Extra metadata is added only AFTER string-path tool iteration; no library walker/schema regression.

The single FD proof helper opens exactly two regular executable FDs, requiring actual fstatdev/inode and positive frozen filesize before capture. Failure openingsecond or callback/hash closes first/allFDs; aggregate close errors remain refusal. Hash reads use64KiB chunks and exactly frozen filesize, with EOF probe and pre/post fstatbounds; hash+fileidentity+bytes allmustmatch independently frozen tool. There is no dev/inode-only or same-byte-copy shortcut/cache/compatibility duplicate.

Actual process proof acquires BOTH FDs after initiallive+freshcommoncensus, then re-observes BOTH beforehash. Exact post-open PID/start/PPID/group/cwd/argv/path/inode required and parentstilladmitted. Only then reads pinnedFDhashes. Finalparent muststillbeexactliveowned asV3. Finalchild musteitherremain exactlive or beexplicitlyabsent in finalstatreading. A currentlypresentPIDwithchangedstart/reparent/ownership, unobservable/zombie/permission fallback, missingstat evidence/afterfield or missingpostopenbinding refuses. Receipt named exited-after-pinned-observation asserts observed finalPIDabsence only; no exitcode/normalexitstatus claim. Successful actual canonical no-compile log and samplecompletion remain separate mandatory oracles.

21sourcepredicates now include actualpinnedhash/size/inode and post-open livebinding, replacing impossible post-hash childliveness with explicit finaldisposition. Existing exactargs/source/current/commoncensus/priorparent/witness/reuse/no-permission/finalparent/resource/source/log/cleanup fences remain. The childstillmustsurvive bothFDopens+postopenobservation; veryshortqueries canstillconservativelyrefuse.

Prospective controls UNRUN: versionprobe file now8controls (prior6 replaced real-fileproof with3focusedcontrols): realheldFDreads surviving actualunlink/pathreplacement +EBADFafterclosure; actualsecondopen/callback/copiedinode/nonregular/wrongsize/growth refusals withFDleak checks; stated fullprovenance finalabsent-vsPIDreuse/missingpostopen/zombie/missingcensus/parentdrift/FDhash+bytebounds. Existing ownership/args/commoncensus/hashnegatives retained. Newnormalpolicy controls remain previouslyqualifiedV3unchanged. No source-text assertions.

Proposed required six-file suite total34 controls then ONE realdependencyfree startup at same2ms (UNRUN):

```sh
NATIVE_COMPILER_CONTROL_REQUIRED=1 node --test scripts/perf/native-observation-policy.test.mjs scripts/perf/native-version-probe.test.mjs scripts/perf/native-hosted.test.mjs scripts/perf/native-cargo-resolution.test.mjs scripts/perf/native-compiler.test.mjs scripts/perf/sdk-resources.test.mjs
NATIVE_COMPILER_CONTROL_REQUIRED=1 NATIVE_STARTUP_CONTROL_OUTPUT=/tmp/6232-takeover/6537-native-version-child-validation-v4/startup-control node scripts/perf/native-startup-control.mjs
```

Sameguardian fixedstart24GiB/live8GiB/owned12GiB/diskstart10GB/live2GB. No installation expected; originalpinnedtoolsalreadyavailable. No retry/wrapper/pause/changedversioncommand/fixture/model/benchmark. Any missingatFDacquisition/livepostopen/hash/finalprooffailure preservedasREFUSAL. Prospective narrow hashcomparison/final-reuse inverses onlyafterrootapproval, unchangedtests/exactfinallyrestore. Source/header/module/wiring/diff cheapgates remainUNRUN fornewsource exceptgitdiffcheck0.
