/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import '@/test/setup-dom.js';
import { afterEach, it } from 'node:test';
import assert from 'node:assert/strict';
import type { MeshData, GeometryResult } from '@ifc-lite/geometry';
import { appearanceSourceTriangle } from '@ifc-lite/renderer';
import { splitMeshForStreaming } from '../../../../packages/renderer/src/scene-stream-split.js';
import { useViewerStore } from '@/store';
import { fixtureModel } from '@/test/store-fixture.js';
import { carryReleasedMesh, meshGeometryCounts, hasMeshGeometryProvenance } from './released-mesh-provenance.js';

afterEach(() => useViewerStore.getState().clearAllModels());

function seed(): MeshData {
  const indices = new Uint32Array([0, 1, 2, 0, 2, 3]);
  const source: MeshData = { expressId: 10, geometryItemId: 20, color: [1, 1, 1, 1],
    positions: new Float32Array([0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0]),
    normals: new Float32Array([0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1]), indices,
    appearanceSource: { kind: 'canonical-item', indices, sourceIndices: indices } };
  const bounds = { min: { x: 0, y: 0, z: 0 }, max: { x: 1, y: 1, z: 0 } };
  const geometry: GeometryResult = { meshes: [source], totalVertices: 4, totalTriangles: 2,
    coordinateInfo: { originShift: { x: 0, y: 0, z: 0 }, originalBounds: bounds, shiftedBounds: bounds, hasLargeCoordinates: false } };
  const model = { ...fixtureModel('cpu-appearance'), geometryResult: geometry };
  useViewerStore.setState({ models: new Map([[model.id, model]]), activeModelId: model.id,
    geometryResult: geometry, boundedGeometryMode: true });
  return source;
}

it('canonical stream fragments release appearance-only aliases while retaining their independent topology (#6584)', () => {
  const source = seed();
  const fragments = splitMeshForStreaming(source, 3, 1000).map(fragment => carryReleasedMesh(source, fragment));
  assert.equal(fragments.length, 2);
  assert.deepEqual(fragments.map(fragment => appearanceSourceTriangle(fragment, 0)), [0, 1]);
  const live = fragments.map(fragment => ({ positions: fragment.positions, normals: fragment.normals,
    indices: fragment.indices, cornerIndices: fragment.appearanceSource!.cornerIndices }));
  assert.ok(fragments.every(fragment => fragment.positions !== source.positions && fragment.indices !== source.indices));
  useViewerStore.getState().releaseGeometryMemory();
  for (const [index, fragment] of fragments.entries()) {
    assert.equal(fragment.appearanceSource!.sourceIndices.byteLength, 0, 'a separate provenance object cannot pin the released full surface');
    assert.equal(fragment.positions, live[index].positions);
    assert.equal(fragment.normals, live[index].normals);
    assert.equal(fragment.indices, live[index].indices);
    assert.equal(fragment.appearanceSource!.indices, live[index].indices, 'independent topology identity fence survives');
    assert.equal(fragment.appearanceSource!.cornerIndices, live[index].cornerIndices, 'independent corner remapping survives');
    assert.equal(appearanceSourceTriangle(fragment, 0), undefined, 'released source topology is no longer editable provenance');
    assert.deepEqual(meshGeometryCounts(fragment), { triangles: 1, vertices: 3 });
  }
  assert.equal(source.appearanceSource, undefined);
  assert.deepEqual(meshGeometryCounts(source), { triangles: 2, vertices: 4 });
  assert.equal(hasMeshGeometryProvenance(source), true);
});

it('separately spread appearance metadata clears only fields sharing a released backing buffer (#6584)', () => {
  const source = seed();
  const copied = carryReleasedMesh(source, { ...source, appearanceSource: { ...source.appearanceSource! } });
  const independentSource = source.indices.slice(), independentCorners = new Uint32Array([0, 1, 2, 3, 4, 5]);
  const partial = carryReleasedMesh(source, { ...source, appearanceSource: { ...source.appearanceSource!,
    indices: source.indices.subarray(), sourceIndices: independentSource, cornerIndices: independentCorners } });
  // All main fields are independent. Only a zero-length view of the populated
  // source allocation keeps it alive, so array identity/byteLength are insufficient.
  const viewOnly = carryReleasedMesh(source, { ...source, positions: source.positions.slice(), normals: source.normals.slice(),
    indices: source.indices.slice(), appearanceSource: { kind: 'canonical-item', indices: independentSource,
      sourceIndices: source.indices.subarray(0, 0), cornerIndices: independentCorners } });
  const counts = meshGeometryCounts(viewOnly);
  assert.ok(viewOnly.appearanceSource!.sourceIndices.buffer.byteLength > 0);
  useViewerStore.getState().releaseGeometryMemory();
  assert.equal(copied.appearanceSource, undefined, 'fully shared provenance is dropped even when its object was spread');
  assert.equal(partial.appearanceSource!.indices.buffer.byteLength, 0, 'a distinct view cannot retain the source allocation');
  assert.equal(partial.appearanceSource!.sourceIndices, independentSource);
  assert.equal(partial.appearanceSource!.cornerIndices, independentCorners);
  assert.equal(viewOnly.appearanceSource!.sourceIndices.buffer.byteLength, 0, 'an appearance-only empty view must release its backing allocation');
  assert.equal(viewOnly.appearanceSource!.indices, independentSource);
  assert.equal(viewOnly.appearanceSource!.cornerIndices, independentCorners);
  assert.deepEqual(meshGeometryCounts(viewOnly), counts);
  assert.deepEqual(meshGeometryCounts(partial), { triangles: 2, vertices: 4 });
});
