# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import hashlib, json, subprocess, struct, re

root = Path(__file__).resolve().parent
src = root / 'artifacts/gpu-control-37161075655-1'
repo = '/home/louistrue/wt/6537-post-timer-gpu-readback-session6503'
head = 'dfd4dcc3e590c9eeacd420a373f9fb5d5ae4ec0b'
report = json.loads((src / 'post-timer-inputs-report.json').read_text())
child = report['control']; gpu = child['gpu']; checks = []
def check(ok, label): checks.append({'label': label, 'passed': bool(ok)})
def sha(data): return hashlib.sha256(data).hexdigest()
run = json.loads((root / 'run.json').read_text())
check(run['status'] == 'completed' and run['conclusion'] == 'failure' and run['head_sha'] == head, 'actual exact first run terminal failure')
check(report['status'] == 'refused' and report['retries'] == 0 and not report.get('outerRefusal'), 'control refusal preserved; no runtime retry')
check(report['harness'] == report['finalHarness'] and report['harness']['head'] == head, 'unchanged final source/head/Node freeze')
for path, digest in report['harness']['sources'].items():
    actual = subprocess.check_output(['git', 'show', head + ':' + path], cwd=repo)
    check(sha(actual) == digest, 'literal committed runtime source ' + path)
expected_child = {'scripts/perf/' + p for p in ['post-timer-gpu-child.mjs', 'post-timer-gpu-readback.mjs', 'post-timer-gpu-readback-control.mjs', 'post-timer-gpu-qualification.mjs', 'gpu-control.mjs', 'interleaved-cleanup.mjs']} | {'package.json', 'pnpm-lock.yaml'}
check(set(child['harness']['files']) == expected_child, 'exact eight child inputs')
check(child['harness']['head'] == head and child['harness']['node'] == report['harness']['node'], 'actual child source/Node agree')
check(all(report['harness']['sources'][p] == h for p, h in child['harness']['files'].items()), 'all child source hashes agree')
for fence in ['branch-ref-before', 'branch-ref-post-dispatch', 'branch-ref-end']:
    check(json.loads((root / (fence + '.json')).read_text())['object']['sha'] == head if (root / (fence + '.json')).exists() else json.loads((root / (fence + '.stdout')).read_text())['object']['sha'] == head, 'actual remote ref fence ' + fence)
limits = gpu['deviceLimits']; roles = ['vertex-multiple-rows', 'uniform-window-boundary', 'atlas-all-channels-alpha', 'atlas-subrectangle']
check([c['label'] for c in gpu['controls']] == roles, 'all four actual role readbacks retained')
tile_count = 0
for i, control in enumerate(gpu['controls']):
    if i < 2:
        size = 20012 if i == 0 else limits['maxUniformBufferBindingSize'] + 256
        expected = b''.join(struct.pack('<I', (0x80000000 + (j + 3) * 0x1020304) & 0xffffffff) for j in range(size // 4))
    else:
        width, height, ox, oy = (67, 35, 0, 0) if i == 2 else (61, 31, 3, 2)
        expected = bytes(v for y in range(height) for x in range(width) for v in (((y + oy) * 67 + x + ox) % 256, (((y + oy) * 67 + x + ox) * 37 + 19) % 256, (((y + oy) * 67 + x + ox) * 71 + 5) % 256, (((y + oy) * 67 + x + ox) * 13) % 256))
    raw = bytes(control['rawBytes']); p = control['plan']; label = roles[i]
    check(raw == expected and len(raw) == p['length'], 'independent complete live bytes ' + label)
    check(control['sha256'] == control['expectedSha256'] == sha(expected), 'recalculated actual hash ' + label)
    changed = bytearray(raw); changed[len(raw) // 2] ^= 1
    check(control['mutationRejected'] is True and len(set(raw)) > 1 and sha(changed) != sha(raw), 'changed-byte refusal/diversity ' + label)
    tile_count += len(p['tiles'])
    for t in p['tiles']:
        check(t['pitch'] % 256 == 0 and t['pitch'] >= t['width'] * 4 and t['stagingBytes'] == t['pitch'] * t['height'] and t['stagingBytes'] <= 4 * 1024 * 1024, 'actual padded row/staging limits ' + label)
    if i < 2:
        source_size = 20032 if i == 0 else limits['maxUniformBufferBindingSize'] + 512
        check(p['source'] == {'size': source_size, 'usage': 40 if i == 0 else 72} and p['offset'] == 12, 'original live buffer usage/range ' + label)
        cursor = 0
        for t in p['tiles']:
            check(t['consumed'] == cursor and t['bindOffset'] + t['prefixWords'] * 4 == 12 + cursor and t['bindingSize'] >= t['prefixWords'] * 4 + t['bytes'] and t['bindOffset'] + t['bindingSize'] <= source_size, 'contiguous actual binding coverage ' + label)
            check(t['bindOffset'] % limits['minUniformBufferOffsetAlignment'] == 0 and t['bindingSize'] <= limits['maxUniformBufferBindingSize'] and t['bindingSize'] % 16 == 0 if i else t['prefixWords'] == 0 and t['bindingSize'] == t['bytes'], 'actual original binding alignment ' + label)
            cursor += t['bytes']
        check(cursor == len(expected), 'whole used word range ' + label)
    else:
        check(p['source'] == {'width': 67, 'height': 35, 'usage': 22, 'format': 'rgba8unorm', 'mipLevelCount': 1, 'sampleCount': 1, 'dimension': '2d', 'depthOrArrayLayers': 1}, 'original single-mip atlas descriptor ' + label)
        check(all(t['x'] == ox + t['dx'] and t['y'] == oy + t['dy'] for t in p['tiles']), 'actual source atlas coordinates ' + label)
        for row in range(height):
            intervals = sorted((t['dx'], t['dx'] + t['width']) for t in p['tiles'] if t['dy'] <= row < t['dy'] + t['height'])
            cursor = 0; valid = True
            for start, end in intervals: valid &= start == cursor; cursor = end
            check(valid and cursor == width, 'complete atlas row coverage ' + label + '/' + str(row))
reader = gpu['reader']
check(reader['status'] == 'complete' and reader['operations'] == 4 and reader['tiles'] == tile_count == 5 and not reader['cleanupFailures'] and not reader.get('prefixRefusal') and not reader.get('deviceLoss'), 'all reader operations/resources completed')
check(len(reader['shaderDiagnostics']) == 5 and all(x == {'totalMessages': 0, 'messages': []} for x in reader['shaderDiagnostics']), 'five actual shader compilations zero diagnostics')
check(gpu['deviceLoss'] == {'reason': 'destroyed', 'message': 'Device was destroyed.', 'ending': True}, 'only intentional final device loss')
check(gpu['nativeMethodsUnchanged'] and gpu['wrongUsageRejected'], 'original native methods/policy guards')
check(child['exit'] == {'code': 1, 'signal': None} and child['browserClose'] == 'complete', 'genuine child failure with browser closed')
cleanup = child['ownedCleanup']
check(cleanup['status'] == 'complete' and cleanup['zombies'] == 0 and cleanup['remaining'] == [] and cleanup['witnessed'] == 11, 'all eleven external owned process witnesses closed')
check(len(child['logFlushes']) == 2 and all(x['status'] == 'complete' for x in child['logFlushes']), 'two complete raw log drains')
for i, channel in enumerate(['stdout', 'stderr']): check((src / ('post-timer-inputs.child.' + channel + '.log')).stat().st_size == child['logBytes'][i], 'complete raw log bytes ' + channel)
log = (src / 'post-timer-inputs.child.stderr.log').read_text(); chrome = child['chrome']
check(f"<launched> pid={chrome['identity']['pid']}" in log and chrome['identity']['ppid'] == child['rootIdentity']['pid'], 'actual Chrome child PID/start witness')
flags = ['--enable-gpu', '--enable-webgpu', '--enable-unsafe-webgpu', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--use-vulkan=swiftshader', '--use-webgpu-adapter=swiftshader', '--enable-features=CDPScreenshotNewSurface,Vulkan']
launch = next(line for line in log.splitlines() if '<launching>' in line)
check(all(x in chrome['arguments'] and x in launch for x in flags), 'actual corrected Chrome profile in proc and raw launch')
check(chrome['sha256'] == '4d2512ae84986bf987e6ea8ef14ca1af555ae574fbaff5b5a8c78a8dd73fa36f' and chrome['version'] == '154.0.8037.57', 'observed Chrome hash/version')
check(not child['backendErrors'], 'no outer graphics backend fault')
warnings = [e['text'] for e in child['events'] if e['kind'] == 'console-warning']; errors = [e for e in child['events'] if e['kind'] == 'console-error']
check(len(errors) == 1 and gpu['errors'] == ['[object GPUValidationError]'] and gpu['cleanup'] == 'refused', 'actual uncaptured GPU error strictly refuses')
check(any('MapRead|CopyDst|Vertex' in x and 'only other allowed usage' in x and 'CreateBuffer' in x for x in warnings), 'exact initiating invalid negative descriptor evidence')
result = {'status': 'AUDITED_REFUSAL_WITH_FOUR_MATCHING_READBACKS' if all(x['passed'] for x in checks) else 'REFUSED_AUDIT_INCONSISTENCY', 'acceptedGPUQualification': False, 'run': run['html_url'], 'head': head, 'checks': checks, 'failedChecks': [x for x in checks if not x['passed']], 'initiatingRefusal': 'Negative fixture creates invalid MAP_READ|COPY_DST|VERTEX buffer usage41. Actual uncaptured validation error/console error preserves strict refusal, after four matching byte readbacks.', 'scope': 'Raw/source/byte diagnostic audit only. Overall control remains REFUSED; no IFC, complete annotation/atlas/frame, pixels or timing qualification. Remote executable hashes/ownership are observed witnesses not independently rehashed after runner termination. Declared source inputs are not whole machine/dependency closure.'}
(root / 'independent-qualification.json').write_text(json.dumps(result, indent=2) + '\n')
manifest = {str(p.relative_to(src)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(src.rglob('*')) if p.is_file()}
(root / 'artifact-hashes.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'checks': len(checks), 'failedChecks': result['failedChecks'], 'qualificationSha256': sha((root / 'independent-qualification.json').read_bytes()), 'artifactManifestSha256': sha((root / 'artifact-hashes.json').read_bytes())}, indent=2))
if result['failedChecks']: raise SystemExit(1)
