Adds bounded live GPU vertex/uniform and single-mip RGBA8 atlas byte readback without changing source usages or intercepting writes. A separate four-role hosted control reconstructs independent expected bytes and checks coverage, source/Chrome identity, diagnostics and owned cleanup through the existing GPU outer harness.

Validation: 10 new controls plus 12 existing GPU/outer controls and relevant source gates pass. First hosted run37161075655 remains **REFUSED**: its negative fixture created invalid MAP_READ|VERTEX usage41 after four independently byte-matching readbacks. The corrected fixture uses legal augmented usage44; the audit now requires observed44/23 descriptors, and GPU errors retain their type/message. Corrected-source GPU execution is **UNRUN**.

No IFC/glyph completeness, rendered pixels, atlas/frame readiness, comparator eligibility, timing benefit or whole-machine closure is established. Existing six-role controls and authored-text guard remain unchanged.

Refs #6537
