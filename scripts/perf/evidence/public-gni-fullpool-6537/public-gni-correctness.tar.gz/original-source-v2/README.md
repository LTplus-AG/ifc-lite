# Public GNI single default-pool source packet — UNRUN

Exact production source d5 remains untouched. All8original client files are copied
from Git controller4d; only scratch contracts.ts adds gni's pinned600s entry.
Consumer/identity/retention/entry/vite config/tests/HTML remain byte-exact.
Runner-side SDKsample changes only automation import resolution from the actual
producer-qualified installed module. Root c328 shared process-observation code is
borrowed; only its live-reserve message names this distinct8GiB inspection.
New code: gni qualification, producer, finite runner and diagnostic limits module.
No four-family schedule, globalmanifest, original package or worker option changes.

Producer template intentionally REFUSES until root fills actual installedChrome
path/version and sets actual configuration status. Command after approval:
`node gni-producer.mjs ACTUAL_CONFIG NEW_PRODUCER_OUTPUT`
Run under existing correctness guardian, sourceRoot as cwd. Produces one bounded
Vitebundle via existingSDKbuild source aliases, not a new Rust build. Validate
root's genuine fresh officialWASM receipt/log and every pkg pin before reuse;
rehash wholetrackedsource, archive/model/research pins, scratchinputs, installed
Vite/plugins/Playwright/tsx/TypeScript/Tauri closure and Node/Chrome before/after.
Raw producing command/exit/log/hash, child cleanup and final input fence retained.
This records a post-Rust-build literal-source snapshot plus actual prior producing
receipt, not a fabricated pre-Rust-build input freeze. No fullOS/linker/sysroot/
Cargo-registry/toolchain closure or fresh performance-binary claim is made.
The runtime Vite source aliases consume source, not old geometrydist; the explicit
noEmit tsconfig separately checks the client/tests against root-built declarations.

Root functional qualification commands, all UNRUN here:
- root `pnpm typecheck` through Turbo in d5WT, preserving required sibling graph;
- root `pnpm exec tsc --project /tmp/6232-takeover/6537-public-gni-pool-diagnostic-source-v2/tsconfig.gni.json`;
- bounded `node --check` of scratch modules and narrow functional selector/lease/
  source-freeze/cleanup controls (root reviews before execution).
The original21CPUidentity controls are retained source; no new gate or CI wiring.
Any missing real dependency/DIST/source provenance is a refusal, not a package-local
bypass. No local build/typecheck/test/browser has run for this packet.

Runtime template intentionally REFUSES pending actual producer receiptSHA, fresh
rootpreview-status receipt+SHA, actualNode/Chrome and bounded expiry. After explicit
rootallocation only: `node gni-runner.mjs PRODUCER_JSON ACTUAL_ROOT_LEASE NEW_OUTPUT`.
Fresh isolated headlessChrome, args[], firstuploadedFile; defaultpublic init and
processParallel onlycancellation. Actualworker count/reason/hardware/SAB/COI and
complete workerMemoryIDs recorded; >=2contiguousIDs, no fixedcount or override.
Defaultfile-size/memory/cores tiers may constrain count; never infer it before run.
Strict semantic warning producer grammar, allunknownwarning/error, page/crash,
transport/recovery/panic/skipped/incomplete and immutable-origin verification stay.

Independent approved inspection:24GiBinitial/8GiBlive/8GiBownRSS,10GiBinitialdisk/
2GiBlivedisk,600sgeometry+120shash+30scleanup,250krecords/64MiB,2GiBretention,
threefresh>=1s<=10%CPU intervals before/after; no timedcohort/no A/A/speedverdict.
900stotal outerdeadline includes firstupload/prepare+cleanup, no retry/substitute.
Coarse100ms RSS includes perPID/start/browserrole and observerduration; no mesh
traversal/upload interception. Sum/maxobservation cost is disclosed, so this cannot
support causal phase/physicalpeak or optimization claims. MainNode logs and Chrome
request/console/pageerror records remain separated, preteardown receipt retained.
All signals/abort/refusal sticky through final server/owned/log/source cleanup.

Known prior proof: actual10906295entries and970canonical jobs (2910packedwords),
no geometry. This next single drain can establish supported producedCPU identity
and untouchedcomplete diagnostics, not an independent model geometryoracle.
Keep any partialfailure and every semantic approximation. Metadata/properties/
canonical viewer load/renderer/authoredappearance are a separate later stage via
useIfcLoader.loadFile; no viewer completion from SDKcomplete. Do not identify
anonymized authors or add this562MB file to the global all-CI corpus.

V2 successor preserves immutable source-v1. Added actual Node/Chrome observed ldd library hashes and pure fixture/config/lease/cleanup contracts, exercised by narrow real-file/PID controls. Syntax/tests/typecheck/build remain UNRUN at source freeze. Root will execute only the bounded correctness preparation approved on this successor.
