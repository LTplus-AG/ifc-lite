import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { fixture, subject, selectFixture, requireProducerConfiguration, requireCleanup,
  requireLease, sourceSnapshot, verifyFrozen } from './gni-qualification.mjs';
import { processIdentity, stopWitnessedProcesses } from './interleaved-cleanup.mjs';

test('separate GNI selector cannot substitute one of the original four families', () => {
  assert.deepEqual(selectFixture('gni'), { family: 'gni', id: 'gni-single-d5', arm: 'candidate',
    path: '2026_BIMprojects/model_6_arc.ifc', bytes: 561838129,
    sha256: '7850c4d909b41dc439feed2e76ffe507c0b472b04513b1ede9e1deec90c503c1', timeoutMs: 600000 });
  for (const selector of ['house', 'csg', 'architecture', '', undefined]) assert.throws(() => selectFixture(selector), /only separately/);
});
test('actual configuration refuses empty prospective and unresolved dependency paths', () => {
  assert.throws(() => requireProducerConfiguration({}), /unfilled/);
  const value = { status: 'GNI_ACTUAL_PRODUCER_CONFIGURATION', head: subject, sourceRoot: '/source', fixtureFile: '/fixture',
    freshWasmReceipt: '/receipt', freshWasmLog: '/log', chromeExecutable: '/chrome', fixtureArchive: '/archive', researchManifest: '/manifest', chromeVersion: 'Google Chrome 153' };
  requireProducerConfiguration(value);
  assert.throws(() => requireProducerConfiguration({ ...value, sourceRoot: null }), /unfilled/);
  assert.throws(() => requireProducerConfiguration({ ...value, chromeVersion: null }), /unfilled/);
});
test('root lease binds actual producer SHA and rejects empty or expired templates', () => {
  const value = { status: 'ROOT_GNI_SINGLE_CORRECTNESS_LEASE', head: subject, qualificationPath: '/q', qualificationSha256: 'a'.repeat(64),
    chromeExecutable: '/chrome', chromeVersion: '153', nodeExecutable: process.execPath, expiresUTC: new Date(Date.now() + 60000).toISOString(),
    initialAvailableBytes: 24 * 1024 ** 3, liveAvailableBytes: 8 * 1024 ** 3, ownedRSSBytes: 8 * 1024 ** 3, sampleCount: 1,
    fixtureSha256: fixture.sha256, previewStatus: { available: true }, previewStatusReceipt: '/actual-preview', previewStatusSha256: 'b'.repeat(64) };
  const qualification = { chromeExecutable: '/chrome', chromeVersion: '153' };
  requireLease(value, qualification, '/q', 'a'.repeat(64));
  assert.throws(() => requireLease({}, qualification, '/q', 'a'.repeat(64)), /refused/);
  assert.throws(() => requireLease(value, qualification, '/q', 'c'.repeat(64)), /refused/);
  assert.throws(() => requireLease({ ...value, expiresUTC: null }, qualification, '/q', 'a'.repeat(64)), /refused/);
  assert.throws(() => requireLease({ ...value, sampleCount: 2 }, qualification, '/q', 'a'.repeat(64)), /refused/);
});
test('a real frozen file hash mismatch refuses even with exact clean subject snapshot', async () => {
  const folder = mkdtempSync(join(tmpdir(), '6537-gni-pin-'));
  try {
    const file = join(folder, 'pin'); writeFileSync(file, 'actual bytes');
    const sourceRoot = '/home/louistrue/wt/6537-prepass-owned-columns-session6503';
    const value = { head: subject, sourceRoot, source: await sourceSnapshot(sourceRoot), frozenFiles: { [file]: '0'.repeat(64) } };
    await assert.rejects(verifyFrozen(value, false), /frozen file changed/);
  } finally { rmSync(folder, { recursive: true }); }
});
test('completion refuses nonzero owned census, zombies, flush loss and uncertified pipe', () => {
  const complete = { status: 'complete', remaining: [], zombies: 0 }, flush = { status: 'complete' };
  requireCleanup(complete, flush, true);
  for (const bad of [{ ...complete, remaining: [123] }, { ...complete, zombies: 1 }, { ...complete, status: 'refused' }]) assert.throws(() => requireCleanup(bad, flush, true), /refused/);
  assert.throws(() => requireCleanup(complete, { status: 'refused' }, true), /refused/);
  assert.throws(() => requireCleanup(complete, flush, false), /refused/);
});
test('real owned process cleanup ignores a reused-start witness and kills only the matching child', async () => {
  const child = spawn(process.execPath, ['-e', 'setTimeout(() => {}, 60000)'], { detached: true, stdio: 'ignore' });
  const ended = new Promise((accept, reject) => { child.once('close', accept); child.once('error', reject); });
  const identity = processIdentity(child.pid); assert.ok(identity);
  try {
    const skipped = await stopWitnessedProcesses([{ ...identity, startTime: String(BigInt(identity.startTime) + 1n) }], 1000);
    assert.equal(skipped.status, 'complete'); assert.equal(processIdentity(child.pid)?.startTime, identity.startTime);
    const cleanup = await stopWitnessedProcesses([identity], 1000); await ended;
    assert.equal(cleanup.status, 'complete'); assert.deepEqual(cleanup.remaining, []); assert.equal(processIdentity(child.pid), null);
  } finally { if (processIdentity(child.pid)?.startTime === identity.startTime) { child.kill('SIGKILL'); await ended; } }
});
