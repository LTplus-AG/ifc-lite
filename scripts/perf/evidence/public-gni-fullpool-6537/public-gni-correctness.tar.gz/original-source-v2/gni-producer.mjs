/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, createWriteStream, statSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { sourceSnapshot, scratchFiles, verifyFrozen, readJSON, subject, fixture, newOutput, requireProducerConfiguration, requireCleanup } from './gni-qualification.mjs';
import { fileHash, inventory } from './interleaved-assets.mjs';
import { installedClosure } from './sdk-tools.mjs';
import { finishLog, processIdentity, stopWitnessedProcesses } from './interleaved-cleanup.mjs';
const [configurationPath, outputPath] = process.argv.slice(2);
if (!configurationPath || !outputPath) throw new Error('actual config and new producer output required');
const config = readJSON(configurationPath), output = newOutput(outputPath);
requireProducerConfiguration(config);
if (output.startsWith(`${resolve(config.sourceRoot)}/`) || output.startsWith(`${import.meta.dirname}/`)) throw new Error('producer output must be outside frozen source roots');
mkdirSync(output); const logPath = join(output, 'bundle.log'), receiptPath = join(output, 'producer.json');
const receipt = { status: 'started', head: subject, sourceRoot: config.sourceRoot, startedUTC: new Date().toISOString(),
  scope: 'Scratch endpoint correctness producer; reused genuine source-matched official WASM, not a fresh performance build', fixture };
const save = () => writeFileSync(receiptPath, JSON.stringify(receipt, null, 2)); save();
let child, identity, refusal, log, timer, closeTimer, settle, forced = false;
const signalHandlers = new Map(['SIGINT', 'SIGTERM'].map(signal => [signal, () => { refusal ??= `received ${signal}`; stop(); }]));
function stop() {
  if (!identity) return;
  const current = processIdentity(identity.pid);
  if (current?.startTime === identity.startTime && current.pgrp === identity.pid) {
    try { process.kill(-identity.pid, 'SIGKILL'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  }
  if (refusal && child) closeTimer ??= setTimeout(() => {
    forced = true; child.stdout.destroy(); child.stderr.destroy(); child.unref(); settle?.({ code: null, signal: 'owned-close-deadline' });
  }, 30000);
}
for (const [signal, handler] of signalHandlers) process.on(signal, handler);
try {
  const wasm = readJSON(config.freshWasmReceipt);
  if (wasm.head !== subject || wasm.trackedDirty || wasm.guardian?.exit !== 0 || wasm.guardian?.childExit !== 0
    || JSON.stringify(wasm.guardian.command) !== JSON.stringify(['bash', 'scripts/build-wasm.sh']) || !wasm.wasmNewerThanRust) throw new Error('actual official WASM producing receipt refused');
  if (statSync(config.fixtureFile).size !== fixture.bytes || await fileHash(config.fixtureFile) !== fixture.sha256) throw new Error('pinned GNI member changed');
  if (statSync(config.fixtureArchive).size !== 221053555 || await fileHash(config.fixtureArchive) !== '72aa9c584d1ccbc8ccc69dccbb32d91047cc15cc2631f4a6fcac3bef89e34781'
    || await fileHash(config.researchManifest) !== 'ee46a8e126be4306e187141d98c5121a1ff467ea8900e144ad0f1a57c0766777') throw new Error('original GNI archive/research manifest changed');
  const source = await sourceSnapshot(config.sourceRoot), frozenFiles = await scratchFiles(import.meta.dirname);
  frozenFiles[configurationPath] = await fileHash(configurationPath);
  frozenFiles[config.fixtureFile] = fixture.sha256;
  frozenFiles[config.fixtureArchive] = '72aa9c584d1ccbc8ccc69dccbb32d91047cc15cc2631f4a6fcac3bef89e34781';
  frozenFiles[config.researchManifest] = 'ee46a8e126be4306e187141d98c5121a1ff467ea8900e144ad0f1a57c0766777';
  frozenFiles[config.freshWasmReceipt] = await fileHash(config.freshWasmReceipt);
  frozenFiles[config.freshWasmLog] = await fileHash(config.freshWasmLog);
  for (const pin of wasm.files) {
    if (!pin.path.startsWith(join(config.sourceRoot, 'packages/wasm/pkg') + '/') || await fileHash(pin.path) !== pin.sha256) throw new Error('qualified pkg bytes differ');
    frozenFiles[pin.path] = pin.sha256;
  }
  const closure = await installedClosure([
    ...['vite', 'vite-plugin-wasm', 'vite-plugin-top-level-await'].map(name => ({ name, from: join(config.sourceRoot, 'apps/viewer/package.json') })),
    ...['@playwright/test', 'tsx', 'typescript'].map(name => ({ name, from: join(config.sourceRoot, 'package.json') })),
    { name: '@tauri-apps/api', from: join(config.sourceRoot, 'packages/geometry/package.json') },
  ]);
  Object.assign(frozenFiles, closure.files);
  frozenFiles[process.execPath] = await fileHash(process.execPath);
  frozenFiles[config.chromeExecutable] = await fileHash(config.chromeExecutable);
  const linkedLibraries = {};
  for (const path of [process.execPath, config.chromeExecutable]) {
    const observed = spawnSync('ldd', [path], { encoding: 'utf8', timeout: 30000, maxBuffer: 1024 ** 2 });
    if (observed.error) throw observed.error;
    const raw = `${observed.stdout}${observed.stderr}`.trim();
    if (observed.status !== 0 && !(observed.status === 1 && /^(?:statically linked|not a dynamic executable)$/.test(raw))) throw new Error('runtime linked-library observation refused');
    if (/not found/.test(raw)) throw new Error('runtime linked library absent');
    linkedLibraries[path] = raw;
    for (const match of raw.matchAll(/(?:=>\s+|^\s*)(\/[^\s]+)\s/gm)) {
      const library = realpathSync(match[1]); frozenFiles[library] = await fileHash(library);
    }
  }
  const requireRoot = createRequire(join(config.sourceRoot, 'package.json'));
  const automationModuleURL = pathToFileURL(requireRoot.resolve('@playwright/test')).href;
  const dist = join(output, 'endpoint'), command = [process.execPath, '--import', pathToFileURL(requireRoot.resolve('tsx')).href,
    join(import.meta.dirname, 'sdk-build.mjs'), config.sourceRoot, subject, dist];
  Object.assign(receipt, { source, frozenFiles, installedClosure: closure, linkedLibraries, dist, command, automationModuleURL,
    chromeExecutable: config.chromeExecutable, chromeVersion: config.chromeVersion, nodeExecutable: process.execPath });
  save(); writeFileSync(join(output, 'input-freeze.json'), JSON.stringify(receipt, null, 2));
  log = createWriteStream(logPath, { flags: 'wx' });
  child = spawn(command[0], command.slice(1), { cwd: config.sourceRoot, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  identity = processIdentity(child.pid);
  if (!identity) { child.kill('SIGKILL'); throw new Error('own bundle PID/start witness missing'); }
  child.stdout.pipe(log, { end: false }); child.stderr.pipe(log, { end: false });
  log.on('error', error => { refusal ??= `producer log: ${error}`; stop(); });
  timer = setTimeout(() => { refusal ??= 'endpoint build180s bound'; stop(); }, 180000);
  receipt.exit = await new Promise((accept, reject) => { settle = accept; child.once('error', reject); child.once('close', (code, signal) => accept({ code, signal })); });
  if (receipt.exit.code !== 0 || refusal) throw new Error(refusal ?? 'actual endpoint build exit refused');
  receipt.assets = await inventory(dist);
  if (!receipt.assets.some(a => a.path.endsWith('.wasm') && a.sha256 === wasm.files.find(f => f.path.endsWith('.wasm')).sha256)
    || !receipt.assets.some(a => /geometry\.worker.*\.js$/.test(a.path))) throw new Error('served WASM/worker producer identity missing');
  await verifyFrozen(receipt);
  receipt.status = 'pending-cleanup';
} catch (error) { receipt.status = 'refused'; receipt.reason = String(error); process.exitCode = 1; }
finally {
  clearTimeout(timer); clearTimeout(closeTimer); stop(); clearTimeout(closeTimer);
  receipt.pipeTailCertified = !forced;
  receipt.cleanup = await stopWitnessedProcesses(identity ? [identity] : [], 30000);
  if (log) receipt.logFlush = await finishLog(log, 30000);
  if (log) receipt.logSha256 = await fileHash(logPath);
  if (receipt.status === 'pending-cleanup') {
    try {
      await verifyFrozen(receipt);
      requireCleanup(receipt.cleanup, receipt.logFlush, !forced);
      if (refusal) throw new Error(refusal);
      receipt.status = 'GNI_ENDPOINT_SOURCE_BUILT_COMPLETE';
    } catch (error) { receipt.status = 'refused'; receipt.reason = String(error); process.exitCode = 1; }
  }
  receipt.endedUTC = new Date().toISOString(); save();
  for (const [signal, handler] of signalHandlers) process.off(signal, handler);
}
