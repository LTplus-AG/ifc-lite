/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { execFileSync } from 'node:child_process';
import { readFileSync, readdirSync, lstatSync, realpathSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { fileHash, inventory } from './interleaved-assets.mjs';
export const subject = 'd5ff79746aa420dd7712ba8c7ff127eae5a65593';
export const fixture = Object.freeze({ family: 'gni', id: 'gni-single-d5', arm: 'candidate',
  path: '2026_BIMprojects/model_6_arc.ifc', bytes: 561838129,
  sha256: '7850c4d909b41dc439feed2e76ffe507c0b472b04513b1ede9e1deec90c503c1', timeoutMs: 600000 });
export function selectFixture(value) {
  if (value !== 'gni') throw new Error('only separately declared gni diagnostic selector permitted');
  return fixture;
}
export function requireProducerConfiguration(config) {
  if (config.status !== 'GNI_ACTUAL_PRODUCER_CONFIGURATION' || config.head !== subject
    || ![config.sourceRoot, config.fixtureFile, config.freshWasmReceipt, config.freshWasmLog, config.chromeExecutable, config.fixtureArchive, config.researchManifest].every(path => typeof path === 'string' && path.startsWith('/'))
    || typeof config.chromeVersion !== 'string' || !config.chromeVersion.includes('Chrome')) throw new Error('unfilled producer configuration refused');
}
export function requireCleanup(receipt, logFlush, pipeTailCertified) {
  if (receipt?.status !== 'complete' || !Array.isArray(receipt.remaining) || receipt.remaining.length
    || receipt.zombies !== 0 || logFlush?.status !== 'complete' || pipeTailCertified !== true) throw new Error('owned cleanup/flush/tail refused');
}
export async function sourceSnapshot(root) {
  const git = args => execFileSync('git', ['-C', root, ...args], { encoding: 'utf8', timeout: 30000, maxBuffer: 16 * 1024 ** 2 });
  if (git(['rev-parse', 'HEAD']).trim() !== subject || git(['status', '--porcelain', '--untracked-files=no']).trim()) throw new Error('literal clean d5 source required');
  const files = {};
  for (const path of git(['ls-files', '-z']).split('\0').filter(Boolean)) files[join(root, path)] = await fileHash(join(root, path));
  return { root, head: subject, tree: git(['rev-parse', 'HEAD^{tree}']).trim(), files };
}
export async function scratchFiles(directory, depth = 0, census = { count: 0 }) {
  if (depth > 20) throw new Error("scratch depth bound");
  const files = {};
  for (const item of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, item.name);
    if (item.isSymbolicLink()) throw new Error('scratch source symlink refused');
    if (item.isDirectory()) Object.assign(files, await scratchFiles(path, depth + 1, census));
    else if (item.isFile()) {
      if (++census.count > 2000) throw new Error("scratch file count bound");
      files[path] = await fileHash(path);
    }
  }
  return files;
}
export async function verifyFrozen(value, includeAssets = true) {
  if (value.head !== subject || !isDeepStrictEqual(await sourceSnapshot(value.sourceRoot), value.source)) throw new Error('source census/head changed');
  for (const [path, hash] of Object.entries(value.frozenFiles)) if (await fileHash(path) !== hash) throw new Error(`frozen file changed: ${path}`);
  if (includeAssets && !isDeepStrictEqual(await inventory(value.dist), value.assets)) throw new Error('served asset inventory changed');
}
export function requireLease(value, qualification, qualificationPath, hash) {
  if (value.status !== 'ROOT_GNI_SINGLE_CORRECTNESS_LEASE' || value.head !== subject
    || value.qualificationPath !== qualificationPath || value.qualificationSha256 !== hash
    || value.chromeExecutable !== qualification.chromeExecutable || value.chromeVersion !== qualification.chromeVersion
    || value.nodeExecutable !== process.execPath || !Number.isFinite(Date.parse(value.expiresUTC)) || Date.parse(value.expiresUTC) <= Date.now()
    || value.initialAvailableBytes !== 24 * 1024 ** 3 || value.liveAvailableBytes !== 8 * 1024 ** 3
    || value.ownedRSSBytes !== 8 * 1024 ** 3 || value.sampleCount !== 1 || value.fixtureSha256 !== fixture.sha256
    || value.previewStatus?.available !== true || typeof value.previewStatusReceipt !== 'string'
    || !/^[a-f0-9]{64}$/.test(value.previewStatusSha256 ?? '')) throw new Error('root actual qualification/runtime lease refused');
}
export function newOutput(path) {
  const absolute = resolve(path);
  try { lstatSync(absolute); throw new Error('new output path must not exist'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  if (realpathSync(resolve(absolute, '..')) !== resolve(absolute, '..')) throw new Error('output parent symlink refused');
  return absolute;
}
export function readJSON(path) { return JSON.parse(readFileSync(path, 'utf8')); }
