/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync, createWriteStream, statfsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { fileHash } from './interleaved-assets.mjs';
import { serveFrozen } from './interleaved-server.mjs';
import { finishLog, processIdentity, stopWitnessedProcesses } from './interleaved-cleanup.mjs';
import { limits } from './sdk-plan.mjs';
import { available, quiet, noBuildGraphs, ownedSnapshot } from './sdk-resources.mjs';
import { fixture, subject, verifyFrozen, requireLease, newOutput, readJSON, selectFixture, requireCleanup } from './gni-qualification.mjs';
const [qualificationArgument, leaseArgument, outputArgument, selector] = process.argv.slice(2);
selectFixture(selector ?? 'gni');
if (!qualificationArgument || !leaseArgument || !outputArgument) throw new Error('actual producer, root lease and new output required');
const qualificationPath = resolve(qualificationArgument), leasePath = resolve(leaseArgument);
const qualification = readJSON(qualificationPath), lease = readJSON(leasePath), output = newOutput(outputArgument);
mkdirSync(output);
const report = { status: 'started', scope: 'ONE publicGNI canonical default-pool correctness inspection; no performance admission',
  subject, fixture, expectedSamples: 1, samples: [], resourceSamples: [], budget: limits,
  limitations: 'No independent geometry oracle, faithfulIFC, native/viewer/GPU/metadata, isolated phase cost, physicalpeak or speed/RSS claim. Coarse process RSS may count shared pages repeatedly.' };
const owned = new Map(); let server, child, childIdentity, abortChild, monitor, refusal, records = 0, bytes = 0;
const began = Date.now(), save = () => writeFileSync(join(output, 'report.json'), JSON.stringify(report, null, 2));
function appendResource(value) {
  const cost = Buffer.byteLength(JSON.stringify(value));
  if (++records > limits.records || (bytes += cost) > limits.recordBytes) throw new Error('resource records/64MiB bound');
  report.resourceSamples.push(value);
}
function stop() {
  if (!childIdentity) return;
  const current = processIdentity(childIdentity.pid);
  if (current?.startTime === childIdentity.startTime && current.pgrp === childIdentity.pid) {
    try { process.kill(-childIdentity.pid, 'SIGKILL'); } catch (error) { if (error.code !== 'ESRCH') throw error; }
  }
}
const signalHandlers = new Map(['SIGINT', 'SIGTERM'].map(signal => [signal, () => {
  refusal ??= `received ${signal}`; if (abortChild) abortChild(refusal); else stop();
}]));
for (const [signal, handler] of signalHandlers) process.on(signal, handler);
async function verify() {
  requireCleanup(qualification.cleanup, qualification.logFlush, qualification.pipeTailCertified);
  if (qualification.status !== 'GNI_ENDPOINT_SOURCE_BUILT_COMPLETE' || qualification.exit?.code !== 0 || !qualification.pipeTailCertified
    || qualification.cleanup?.status !== 'complete' || qualification.cleanup.remaining?.length || qualification.cleanup.zombies !== 0 || qualification.logFlush?.status !== 'complete') throw new Error('actual producing status/exit/cleanup missing');
  requireLease(lease, qualification, qualificationPath, await fileHash(qualificationPath));
  if (await fileHash(join(qualification.dist, '..', 'bundle.log')) !== qualification.logSha256
    || await fileHash(lease.previewStatusReceipt) !== lease.previewStatusSha256) throw new Error('build log/actualpreview receipt changed');
  await verifyFrozen(qualification);
  if (refusal) throw new Error(refusal);
}
function resources() {
  const start = performance.now(), snapshot = ownedSnapshot(process.pid), allocations = [];
  for (const identity of snapshot.members) {
    owned.set(`${identity.pid}:${identity.startTime}`, identity);
    try {
      if (processIdentity(identity.pid)?.startTime !== identity.startTime) continue;
      const raw = readFileSync(`/proc/${identity.pid}/status`, 'utf8'), match = /^VmRSS:\s+(\d+) kB$/m.exec(raw);
      const args = readFileSync(`/proc/${identity.pid}/cmdline`, 'utf8').split('\0');
      allocations.push({ pid: identity.pid, startTime: identity.startTime, rssBytes: match ? Number(match[1]) * 1024 : 0,
        role: args.find(x => x.startsWith('--type='))?.slice(7) ?? 'browser-or-launcher',
        comm: readFileSync(`/proc/${identity.pid}/comm`, 'utf8').trim() });
    } catch (error) { if (!['ENOENT', 'ESRCH'].includes(error.code)) throw error; }
  }
  const disk = statfsSync(output), row = { at: snapshot.at, bytes: snapshot.bytes, availableBytes: available(),
    diskFreeBytes: disk.bavail * disk.bsize, allocations, observerDurationMs: performance.now() - start };
  appendResource(row);
  if (row.bytes > limits.rssBytes || row.availableBytes < limits.liveBytes || row.diskFreeBytes < 2 * 1024 ** 3) throw new Error('distinct8GiBinspection RSS/live/disk budget');
  if (Date.now() - began > limits.cohortMs) throw new Error('single inspection total900s wall');
  noBuildGraphs();
  if (Date.parse(lease.expiresUTC) <= Date.now()) throw new Error('runtime lease expired');
  return snapshot;
}
async function runSample() {
  const sample = { ...fixture }, resultPath = join(output, 'gni.json'), inputPath = join(output, 'gni.input.json');
  const file = Object.keys(qualification.frozenFiles).find(path => qualification.frozenFiles[path] === fixture.sha256);
  if (!file) throw new Error('qualified exact fixture file missing');
  writeFileSync(inputPath, JSON.stringify({ sample, file, assets: qualification.assets, origin: server.origin,
    chromeExecutable: qualification.chromeExecutable, chromeVersion: qualification.chromeVersion,
    automationModuleURL: qualification.automationModuleURL }, null, 2));
  const log = createWriteStream(`${resultPath}.runner.log`, { flags: 'wx' });
  let wallTimer, closeTimer, settle, forced = false, initialOwnedSnapshot;
  child = spawn(process.execPath, [join(import.meta.dirname, 'sdk-sample.mjs'), inputPath, resultPath], { detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  childIdentity = processIdentity(child.pid);
  if (childIdentity) owned.set(`${childIdentity.pid}:${childIdentity.startTime}`, childIdentity);
  child.stdout.pipe(log, { end: false }); child.stderr.pipe(log, { end: false });
  const abort = reason => {
    refusal ??= String(reason); stop();
    closeTimer ??= setTimeout(() => {
      forced = true; child.stdout.destroy(); child.stderr.destroy(); child.unref(); settle?.({ code: null, signal: 'owned-close-deadline' });
    }, limits.cleanupMs);
  };
  abortChild = abort; log.on('error', error => abort(`runner log: ${error}`));
  wallTimer = setTimeout(() => abort('600sdrain+120shash+30scleanup+90sload/prepare wall'), 840000);
  let exit;
  try {
    initialOwnedSnapshot = resources();
    if (!childIdentity) { child.kill('SIGKILL'); throw new Error('spawn PID/start witness missing'); }
    exit = await new Promise((accept, reject) => { settle = accept; child.once('error', reject); child.once('close', (code, signal) => accept({ code, signal })); });
  } catch (error) { abort(error); exit = { code: null, reason: String(error) }; }
  finally { clearTimeout(wallTimer); clearTimeout(closeTimer); stop(); child = undefined; childIdentity = undefined; abortChild = undefined; }
  const [cleanup, logFlush] = await Promise.all([stopWitnessedProcesses([...owned.values()], limits.cleanupMs), finishLog(log, limits.cleanupMs)]);
  let row;
  try { row = readJSON(resultPath); }
  catch (error) { row = { ...fixture, status: 'refused', reason: `no complete child receipt: ${error}` }; }
  Object.assign(row, { exit, cleanup, logFlush, pipeTailCertified: !forced, initialOwnedSnapshot });
  if (refusal || exit.code !== 0 || row.status !== 'complete' || cleanup.status !== 'complete' || logFlush.status !== 'complete' || forced) {
    row.status = 'refused'; row.reason = refusal ?? row.reason ?? 'sample/cleanup/flush refused';
  }
  writeFileSync(resultPath, JSON.stringify(row, null, 2)); report.samples.push(row); save();
  if (row.status !== 'complete') throw new Error(row.reason);
}
save();
try {
  if (process.platform !== 'linux') throw new Error('Linux inspection only');
  const disk = statfsSync(output);
  report.initial = { availableBytes: available(), diskFreeBytes: disk.bavail * disk.bsize };
  if (report.initial.availableBytes < limits.initialBytes || report.initial.diskFreeBytes < 10 * 1024 ** 3) throw new Error('24GiBstart/10GiBdisk admission refused');
  await verify();
  server = await serveFrozen(qualification.dist, qualification.assets);
  await new Promise(accept => setTimeout(accept, limits.drainMs)); report.beforeCPU = await quiet(); await verify();
  monitor = setInterval(() => {
    try { resources(); if (server.refusal) throw new Error(server.refusal); }
    catch (error) { refusal ??= String(error); if (abortChild) abortChild(error); else stop(); }
  }, 100);
  await runSample(); clearInterval(monitor);
  await new Promise(accept => setTimeout(accept, limits.drainMs)); report.afterCPU = await quiet(); await verify();
  report.status = 'pending-cleanup';
} catch (error) { report.status = 'refused'; report.reason = String(error); if (error.receipt) report.cpuRefusal = error.receipt; process.exitCode = 1; }
finally {
  clearInterval(monitor); stop(); report.ownedCleanup = await stopWitnessedProcesses([...owned.values()], limits.cleanupMs);
  try { await verify(); report.finalFrozenVerification = 'complete'; }
  catch (error) { report.status = 'refused'; report.finalFrozenVerification = 'refused'; report.finalVerificationError = String(error); process.exitCode = 1; }
  if (server) {
    try { report.serverCleanup = await server.close(limits.cleanupMs); }
    catch (error) { report.serverCleanup = { status: 'refused', reason: String(error) }; }
    writeFileSync(join(output, 'served-assets.json'), JSON.stringify(server.requests, null, 2));
  }
  if (refusal || report.ownedCleanup.status !== 'complete' || report.ownedCleanup.remaining.length || report.ownedCleanup.zombies !== 0
    || report.serverCleanup?.status !== 'complete' || report.serverCleanup.remainingSockets !== 0
    || report.finalFrozenVerification !== 'complete' || report.samples.length !== 1 || report.samples[0].status !== 'complete') {
    report.status = 'refused'; report.reason ??= refusal ?? 'final inspection census/cleanup/freeze refused'; process.exitCode = 1;
  } else if (report.status === 'pending-cleanup') report.status = 'complete-single-GNI-CPU-output-correctness-inspection';
  report.observer = { observations: report.resourceSamples.length, sumDurationMs: report.resourceSamples.reduce((sum, row) => sum + row.observerDurationMs, 0),
    maxDurationMs: report.resourceSamples.reduce((max, row) => Math.max(max, row.observerDurationMs), 0),
    limitation: 'Recorded main-process observation cost; does not measure CPU attribution or physicalpeak. No performance/causal opportunity conclusion from this instrumented inspection.' };
  save(); for (const [signal, handler] of signalHandlers) process.off(signal, handler);
}
