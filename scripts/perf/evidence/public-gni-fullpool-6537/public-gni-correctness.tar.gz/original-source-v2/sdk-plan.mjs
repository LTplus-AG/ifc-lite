/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { canonicalReasons } from './sdk-semantic-warnings.mjs';
// Separate correctness-only inspection; no hosted5GiB timing admission waiver.
export const limits = Object.freeze({ initialBytes: 24 * 1024 ** 3, liveBytes: 8 * 1024 ** 3,
  rssBytes: 8 * 1024 ** 3, cleanupMs: 30000, drainMs: 3000, cohortMs: 900000,
  records: 250000, recordBytes: 64 * 1024 ** 2 });
export function requireDiagnostics(value) {
  if (!value || value.schemaVersion !== 3 || !Array.isArray(value.failuresByReason)
    || !Number.isSafeInteger(value.totalCsgFailures) || value.totalCsgFailures < 0
    || value.failuresByReason.some(item => !canonicalReasons.has(item.reason) || !Number.isSafeInteger(item.count) || item.count < 1)
    || value.failuresByReason.reduce((sum, item) => sum + item.count, 0) !== value.totalCsgFailures) throw new Error('canonical complete diagnostic schema/reason/count refused');
}
export function poolCensus(count, memory) {
  const ids = memory.map(item => item.workerIndex).sort((a, b) => a - b);
  if (!Number.isSafeInteger(count) || count < 2 || ids.length !== count
    || ids.some((id, index) => id !== index)) throw new Error('actual pool-start/memory census mismatch');
  return ids;
}
