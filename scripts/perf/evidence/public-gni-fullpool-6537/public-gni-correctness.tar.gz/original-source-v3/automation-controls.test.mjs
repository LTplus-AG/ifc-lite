/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { dirname, join } from 'node:path';
import { loadChromiumFromRequireEntry } from './gni-automation.mjs';
const sourceRequire = createRequire('/home/louistrue/wt/6537-prepass-owned-columns-session6503/package.json');
const entry = sourceRequire.resolve('@playwright/test');
const entryURL = pathToFileURL(entry).href;
test('#6537 actual installed require entry loads Chromium contract without browser launch', () => {
  const chromium = loadChromiumFromRequireEntry(entryURL);
  assert.equal(chromium.name(), 'chromium');
  assert.equal(typeof chromium.launch, 'function');
});
test('#6537 actual installed package metadata is not a Chromium entry', () => {
  const metadata = sourceRequire.resolve('@playwright/test/package.json');
  assert.throws(() => loadChromiumFromRequireEntry(pathToFileURL(metadata).href), /lacks Chromium launch/);
});
test('#6537 nonexistent require entry preserves module-load refusal', () => {
  const missing = join(dirname(entry), 'gni-nonexistent-qualified-entry-6537.js');
  assert.throws(() => loadChromiumFromRequireEntry(pathToFileURL(missing).href), { code: 'MODULE_NOT_FOUND' });
});
test('#6537 non-file or decorated require entry refuses before loading', () => {
  for (const value of ['https://example.invalid/index.js', entryURL + '?changed=1', entryURL + '#changed']) {
    assert.throws(() => loadChromiumFromRequireEntry(value), /qualified file require entry required/);
  }
});
