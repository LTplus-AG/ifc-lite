/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
// The producer qualifies the package's require entry, so consume that same contract.
export function loadChromiumFromRequireEntry(entryURL) {
  const url = new URL(entryURL);
  if (url.protocol !== 'file:' || url.search || url.hash) throw new Error('qualified file require entry required');
  const automation = createRequire(url)(fileURLToPath(url));
  if (typeof automation?.chromium?.launch !== 'function') throw new Error('qualified require entry lacks Chromium launch');
  return automation.chromium;
}
