The new public large-model control now completes actual full default-worker-pool geometry processing, beyond the earlier prepass-only check.

Input: TUM's author-consented [GNI BIM Dataset](https://zenodo.org/records/19722012), CC BY 4.0; `2026_BIMprojects.zip` → `2026_BIMprojects/model_6_arc.ifc`. The actual header identifies Autodesk Revit 2026 (ENU), IFC2X3. File size is 561,838,129 bytes; SHA-256 `7850c4d909b41dc439feed2e76ffe507c0b472b04513b1ede9e1deec90c503c1`.

One first-file load in a fresh Linux Chrome 153 process used the public GeometryProcessor initialization and unmodified default `processParallel` pool, with full generator drain and disposal. Literal subject: `d5ff79746aa420dd7712ba8c7ff127eae5a65593` (#6743). The official source-matched WASM, served worker/consumer bytes and input closure were verified before and after execution.

- Actual four geometry workers, IDs 0–3; four scans stitched 10,906,295 records; eight style slices; 970 geometry jobs.
- Complete output: 2,007 flat meshes and 3,496,659 triangles. Canonical CPU geometry identity SHA-256: `135ca43d397f325532851620be9b480f56d0c2b45dfdd4d1eb345195bfcb3d78`.
- Canonical diagnostics: zero CSG failures, unsupported items, oversized-reference drops, silent no-ops and bounds-recovery fallbacks. No page errors, unexpected warnings, retries or skips were observed.
- All six one-second quiet CPU intervals and the fixed correctness inspection budgets passed; source/output receipts, all owned-process cleanup and server closure completed. The observed summed process RSS exceeded the separate, unchanged 5 GiB timing-cohort ceiling, so this run is not admitted as a performance comparison.

The first attempt stopped before browser launch because the harness consumed the installed CommonJS require entry as a named ESM export. That original refusal is retained. The corrected explicit require-entry contract passed actual installed-package positive and wrong/missing-entry controls before this new attempt; emitted endpoint assets remained byte-identical.

This is one public-model completion and diagnostic control, not an A/B speed or memory reduction claim, an independent geometry oracle, native or full viewer/metadata/GPU qualification, or reproduction of the unidentified 1,778 MB Windows Edge failure. Raw receipts and root's independent 27-check audit are retained; durable repository evidence and the remaining viewer/native comparisons are still in progress.
