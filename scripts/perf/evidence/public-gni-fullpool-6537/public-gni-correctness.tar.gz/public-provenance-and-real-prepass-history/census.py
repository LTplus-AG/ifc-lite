import collections, datetime, hashlib, json, pathlib, re

root=pathlib.Path(__file__).parent
path=root/'model_6_arc.ifc'
counts=collections.Counter(); count=0; maximum=0; max_id=0; unmatched=0; longest=[]
start=re.compile(rb'^#([0-9]+)\s*=\s*(IFC[A-Z0-9]+)\s*\(')
sha=hashlib.sha256(); total=0; tail=b''
with path.open('rb') as handle:
    while line:=handle.readline(64*1024*1024+1):
        if len(line)>64*1024*1024: raise RuntimeError('line work/memory bound exceeded')
        sha.update(line); total+=len(line); maximum=max(maximum,len(line)); tail=(tail+line)[-256:]
        match=start.match(line)
        if match:
            eid=int(match[1]); kind=match[2].decode('ascii'); counts[kind]+=1; count+=1; max_id=max(max_id,eid)
            if not line.rstrip().endswith(b');'): unmatched+=1
            longest.append((len(line),eid,kind)); longest=sorted(longest,reverse=True)[:10]
        elif line.lstrip().startswith(b'#'): unmatched+=1
receipt=json.loads((root/'fetch-receipt.json').read_bytes())['ifc']
if sha.hexdigest()!=receipt['sha256'] or total!=receipt['bytes']: raise RuntimeError('source changed during census')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha.hexdigest(),'sourceBytes':total,
    'scope':'Streaming lexical one-record-per-line screen, NOT canonical parser/geometry correctness or performance measurement.',
    'recognizedRecordStartLines':count,'maximumObservedExpressId':max_id,'ambiguousRecordLines':unmatched,
    'maximumLineBytes':maximum,'longestRecords':longest,'typeRecordStartCounts':dict(counts.most_common()),
    'stepTerminatorPresentInTail':b'END-ISO-10303-21;' in tail}
(root/'lexical-census.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='typeRecordStartCounts'},indent=2))
print(json.dumps(counts.most_common(15),indent=2))
