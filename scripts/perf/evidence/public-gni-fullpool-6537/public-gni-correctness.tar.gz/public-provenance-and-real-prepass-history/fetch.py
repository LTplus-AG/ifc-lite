import datetime, hashlib, json, os, pathlib, shutil, urllib.request, zipfile

root=pathlib.Path(__file__).parent
record=json.loads((root/'record.json').read_bytes())
item=next(x for x in record['files'] if x['key']=='2026_BIMprojects.zip')
member=next(x for x in json.loads((root/'central-members.json').read_bytes()) if x['name']=='2026_BIMprojects/model_6_arc.ifc')
if shutil.disk_usage(root).free < 10*1024**3 + item['size'] + member['expandedBytes']:
    raise RuntimeError('10GiB reserve plus full archive and member unavailable')
checks=[]
for name in ['README.md','LICENSE','other_online_BIM_model_resources.csv']:
    meta=next(x for x in record['files'] if x['key']==name)
    with urllib.request.urlopen(meta['links']['self'],timeout=30) as response:
        raw=response.read(meta['size']+1)
    if len(raw)!=meta['size'] or 'md5:'+hashlib.md5(raw).hexdigest()!=meta['checksum']:
        raise RuntimeError(f'metadata integrity mismatch {name}')
    with (root/name).open('xb') as handle: handle.write(raw)
    checks.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'recordChecksumVerified':True})
archive=root/'2026_BIMprojects.zip'
sha=hashlib.sha256(); md5=hashlib.md5(); total=0
with urllib.request.urlopen(item['links']['self'],timeout=60) as response, archive.open('xb') as handle:
    while block:=response.read(1024*1024):
        total+=len(block)
        if total>item['size']: raise RuntimeError('archive exceeds recorded size')
        handle.write(block); sha.update(block); md5.update(block)
        if shutil.disk_usage(root).free<10*1024**3: raise RuntimeError('reserve breached')
if total!=item['size'] or 'md5:'+md5.hexdigest()!=item['checksum']:
    raise RuntimeError('archive integrity mismatch')
output=root/'model_6_arc.ifc'
sha_ifc=hashlib.sha256(); extracted=0
with zipfile.ZipFile(archive) as z:
    matches=[i for i in z.infolist() if i.filename==member['name']]
    if len(matches)!=1 or matches[0].file_size!=member['expandedBytes'] or matches[0].CRC!=member['crc32']:
        raise RuntimeError('member census/integrity disagreement')
    with z.open(matches[0]) as src, output.open('xb') as dst:
        while block:=src.read(1024*1024):
            extracted+=len(block)
            if extracted>member['expandedBytes']: raise RuntimeError('member bound exceeded')
            dst.write(block); sha_ifc.update(block)
            if shutil.disk_usage(root).free<10*1024**3: raise RuntimeError('reserve breached')
if extracted!=member['expandedBytes']: raise RuntimeError('member length mismatch')
with output.open('rb') as handle: header=handle.read(16384)
(root/'model-header-prefix.txt').write_bytes(header)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'record':'https://zenodo.org/records/19722012',
    'archive':{'path':str(archive),'bytes':total,'sha256':sha.hexdigest(),'md5':md5.hexdigest(),'recordChecksumVerified':True},
    'ifc':{'path':str(output),'bytes':extracted,'sha256':sha_ifc.hexdigest(),'zipCRCVerified':True},
    'metadata':checks,'noParseOrGeometryRun':True,'diskFreeBytes':shutil.disk_usage(root).free}
(root/'fetch-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
