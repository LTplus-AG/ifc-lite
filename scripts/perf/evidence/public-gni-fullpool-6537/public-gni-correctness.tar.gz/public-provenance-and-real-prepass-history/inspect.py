import datetime, hashlib, json, pathlib, struct, urllib.request

root = pathlib.Path(__file__).parent
def get(url, cap, headers=None):
    request = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(cap + 1)
        if len(data) > cap:
            raise RuntimeError('bounded download exceeded')
        return data, response.status, dict(response.headers)

record_raw, _, _ = get('https://zenodo.org/api/records/19722012', 1024*1024)
(root/'record.json').write_bytes(record_raw)
record = json.loads(record_raw)
item = next(x for x in record['files'] if x['key'] == '2026_BIMprojects.zip')
size = item['size']
url = item['links']['self']
receipts = []
def fetch_range(start, end, name):
    data, status, headers = get(url, end-start+1, {'Range': f'bytes={start}-{end}'})
    content_range = next((v for k,v in headers.items() if k.lower()=='content-range'), None)
    if status != 206 or content_range != f'bytes {start}-{end}/{size}' or len(data)!=end-start+1:
        raise RuntimeError(f'range mismatch: {status} {content_range}')
    (root/name).write_bytes(data)
    receipts.append({'start':start,'end':end,'status':status,'headers':headers,'sha256':hashlib.sha256(data).hexdigest(),'path':name})
    return data
tail = fetch_range(size-min(size,65557), size-1, 'archive-tail.bin')
eocd = tail.rfind(b'PK\x05\x06')
if eocd < 0: raise RuntimeError('EOCD absent')
_, disk, cd_disk, count_disk, count, cd_size, cd_offset, comment = struct.unpack_from('<4s4H2IH', tail,eocd)
if disk or cd_disk or count!=count_disk or count==65535 or cd_size>1024*1024 or eocd+22+comment!=len(tail):
    raise RuntimeError('unsupported ZIP layout')
central = fetch_range(cd_offset, cd_offset+cd_size-1, 'archive-central.bin')
members=[]; at=0
while at<len(central):
    values = struct.unpack_from('<4s6H3I5H2I',central,at)
    if values[0]!=b'PK\x01\x02': raise RuntimeError('bad member signature')
    _,made,needed,flags,method,mtime,mdate,crc,compressed,expanded,nlen,elen,clen,ndisk,iattrs,eattrs,offset=values
    if compressed==0xffffffff or expanded==0xffffffff or offset==0xffffffff or flags&1 or ndisk: raise RuntimeError('unsupported member')
    name=central[at+46:at+46+nlen].decode('utf-8' if flags&2048 else 'cp437')
    members.append({'name':name,'compressedBytes':compressed,'expandedBytes':expanded,'method':method,'crc32':crc,'localOffset':offset})
    at+=46+nlen+elen+clen
if at!=len(central) or len(members)!=count: raise RuntimeError('central census mismatch')
(root/'central-members.json').write_text(json.dumps(members,indent=2)+'\n')
(root/'ranges.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':item,'receipts':receipts,'wholeArchiveVerified':False},indent=2)+'\n')
print(json.dumps({'archiveBytes':size,'members':len(members),'largestIFC':sorted([x for x in members if x['name'].lower().endswith('.ifc')],key=lambda x:x['expandedBytes'],reverse=True)[:4]},indent=2))
