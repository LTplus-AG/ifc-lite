Additional public reproduction candidate found and downloaded with integrity verification: TUM's [GNI BIM Dataset](https://zenodo.org/records/19722012), `2026_BIMprojects.zip` → `2026_BIMprojects/model_6_arc.ifc`.

The authors' [README](https://zenodo.org/records/19722012/files/README.md?download=1) explicitly says their parser could not load one 536 MB architectural submission. The actual ZIP entry is **561,838,129 bytes (535.8 MiB)**. Its STEP header is IFC2X3 and the retained `IfcApplication` identifies Autodesk Revit 2026 (ENU); identifying project/author metadata has been anonymized by the dataset publisher. The release is CC BY 4.0 with authors' consent.

Reproduction provenance:

- [Download archive](https://zenodo.org/records/19722012/files/2026_BIMprojects.zip?download=1): 221,053,555 bytes; publisher MD5 `bc4bfb90313162c68a3ec4e24a0d33cf` matches the complete download; SHA-256 `72aa9c584d1ccbc8ccc69dccbb32d91047cc15cc2631f4a6fcac3bef89e34781`.
- Extract only the named member above. Its CRC verifies against the ZIP directory and SHA-256 is `7850c4d909b41dc439feed2e76ffe507c0b472b04513b1ede9e1deec90c503c1`.
- A bounded streaming lexical screen finds 10,906,295 entity-record start lines, including 3,070,957 `IFCFACE`, 3,070,957 `IFCFACEOUTERBOUND`, 3,071,158 `IFCPOLYLOOP`, and 1,661,907 `IFCCARTESIANPOINT` lines. This is a faceted, entity-heavy architectural stress case rather than another copy of the existing fixtures. These are lexical observations, not canonical parser/geometry counts.

No ifc-lite parse/geometry run, elapsed-time comparison, memory verdict or faithful-rendering claim has been made on it yet. It does not identify the unavailable private models in #6516 or #6542. The existing four-family hosted comparison remains immutable; this new model will need a separately declared bounded run.
