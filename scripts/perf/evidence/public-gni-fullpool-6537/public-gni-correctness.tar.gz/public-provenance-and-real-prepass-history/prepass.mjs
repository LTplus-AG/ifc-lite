import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';

const root='/tmp/6232-takeover/6537-public-gni-research-v1';
const expected=JSON.parse(readFileSync(`${root}/fresh-wasm-receipt.json`,'utf8'));
const sourceReceipt=JSON.parse(readFileSync(`${root}/fetch-receipt.json`,'utf8')).ifc;
const lexical=JSON.parse(readFileSync(`${root}/lexical-census.json`,'utf8'));
const hash=value=>createHash('sha256').update(value).digest('hex');
const report={scope:'ONE real-WASM sharded-prepass correctness diagnostic; not worker-pool, browser, geometry, timing or memory verdict',
  status:'started',sourceHead:expected.head,source:sourceReceipt,phases:[],events:[],cleanup:[]};
const save=()=>writeFileSync(`${root}/prepass-receipt.json`,JSON.stringify(report,null,2)+'\n');
save();
let api;
try {
  for (const pin of expected.files) assert.equal(hash(readFileSync(pin.path)),pin.sha256,'frozen official WASM binding bytes');
  const runtime=expected.files.find(p=>p.path.endsWith('.wasm'));
  const js=expected.files.find(p=>p.path.endsWith('.js'));
  assert.ok(statSync(runtime.path).mtimeMs/1000>expected.latestRustMtime,'fresh official WASM required');
  const {initSync,IfcAPI}=await import(pathToFileURL(js.path).href);
  initSync({module:readFileSync(runtime.path)});
  const bytes=readFileSync(sourceReceipt.path);
  assert.equal(bytes.length,sourceReceipt.bytes);assert.equal(hash(bytes),sourceReceipt.sha256);
  api=new IfcAPI();
  const columns=api.scanEntityIndexShard(bytes,0,bytes.length);
  for (const key of ['ids','starts','lengths']) assert.ok(columns[key] instanceof Uint32Array,key);
  assert.ok(columns.classes instanceof Uint8Array);
  assert.equal(columns.ids.length,lexical.recognizedRecordStartLines,'canonical scanner versus independent line-record screen');
  for (const key of ['starts','lengths','classes']) assert.equal(columns[key].length,columns.ids.length);
  const columnHashes=Object.fromEntries(['ids','starts','lengths','classes'].map(key=>[key,hash(columns[key]) ]));
  report.phases.push({name:'canonical-scan-complete',records:columns.ids.length,handoff:columns.handoff,
    columnHashes,oversizedIdStarts:columns.oversizedIdStarts?.length});save();
  api.clearPrePassCache();api.free();api=undefined;report.cleanup.push('scanner-api-freed');save();
  api=new IfcAPI();let complete=0,jobs=0;
  const result=api.buildPrePassStreamingShardedWithSourceFingerprint(bytes,event=>{
    assert.ok(report.events.length<10000,'finite callback event budget');
    const row={};
    for (const [key,value] of Object.entries(event)) {
      if (ArrayBuffer.isView(value)) row[key]={type:value.constructor.name,elements:value.length,bytes:value.byteLength,sha256:hash(value)};
      else if (key==='diagnostics') row[key]=value;
      else if (value===null||['string','number','boolean'].includes(typeof value)) row[key]=value;
      else if (Array.isArray(value)) row[key]={type:'Array',elements:value.length};
      else row[key]={type:typeof value,keys:Object.keys(value??{})};
    }
    if(event.type==='jobs') jobs+=event.jobs.length;
    if(event.type==='complete') complete++;
    report.events.push(row);save();
  },1024,null,false,columns.ids,columns.starts,columns.lengths,columns.classes);
  assert.equal(result,undefined);assert.equal(complete,1);assert.equal(report.events.at(-1).type,'complete');
  assert.ok(jobs>0,'real authored model must discover jobs');
  for (const key of ['ids','starts','lengths','classes']) assert.equal(hash(columns[key]),columnHashes[key],'JS column inputs preserved');
  report.phases.push({name:'canonical-sharded-prepass-complete',jobs,completeEvents:complete,events:report.events.length});
  report.status='prepass-complete-correctness-only';
}catch(error){report.status='failed';report.error={name:error.name,message:error.message,stack:error.stack};process.exitCode=1;
}finally{
  if(api){try{api.clearPrePassCache();report.cleanup.push('prepass-cache-cleared');}finally{api.free();report.cleanup.push('prepass-api-freed');}}
  report.finalBindings=expected.files.map(pin=>({path:pin.path,unchanged:hash(readFileSync(pin.path))===pin.sha256}));
  assert.ok(report.finalBindings.every(pin=>pin.unchanged));save();
  console.log(JSON.stringify({status:report.status,phases:report.phases,error:report.error,cleanup:report.cleanup}));
}
