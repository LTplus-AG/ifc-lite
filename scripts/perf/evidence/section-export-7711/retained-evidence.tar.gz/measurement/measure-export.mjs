import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {IfcParser} from '@ifc-lite/parser';
import {StepExporter as Base} from './base-step-exporter.mjs';
import {StepExporter as Branch} from './branch-step-exporter.mjs';
import {exportSectionedStep} from './branch-section-export.mjs';
const root='/home/louistrue/.t3/worktrees/ifc-lite/t3-aa41e555';
const out='/home/louistrue/.t3/artifacts/ifc-issue-resolution-bc9e57fa/7711-section-export/perf-current-main/ready-4bf77c';
if(!process.env.IFC_WORKER_ACTIVE_STATE)throw Error('Benchmark admission required');
const jobs=process.env.IFC_WORKER_ACTIVE_STATE+'/jobs';
const active=readdirSync(jobs).map(id=>{try{return JSON.parse(readFileSync(jobs+'/'+id+'/receipt.json','utf8'));}catch(error){if(error.code==='ENOENT')return null;throw error;}}).some(r=>r?.kind==='benchmark'&&r.state==='running'&&r.command.includes(out+'/measure.py'));
if(!active)throw Error('No active benchmark EX receipt for the combined cohort');
const source=new Uint8Array(readFileSync(root+'/tests/models/ara3d/AC20-FZK-Haus.ifc'));
const evidence=JSON.parse(readFileSync('/home/louistrue/.t3/artifacts/ifc-issue-resolution-bc9e57fa/7711-section-export/browser-current-main-root/haus-evidence.json','utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
if(sha(source)!==evidence.sourceSha256)throw Error('Source fixture hash mismatch');
const body=bytes=>{const text=new TextDecoder().decode(bytes);const start=text.indexOf('\nDATA;'),end=text.lastIndexOf('\nENDSEC;');if(start<0||end<=start)throw Error('Missing canonical STEP DATA boundaries');return text.slice(start+6,end);};
async function run(variant){
 const start=performance.now();
 const store=await new IfcParser().parseColumnar(source.slice().buffer,{disableWorkerScan:true});
 const parsed=performance.now();
 const exported=new (variant==='base'?Base:Branch)(store).export({schema:'IFC4', ...(variant==='trim'?{}:{visibleOnly:true,hiddenEntityIds:new Set(evidence.outside)})});
 const serialized=performance.now();
 const result=variant==='trim'?await exportSectionedStep(exported.content,{planes:[{normal:[1,0,0],offset:evidence.offset}]}):exported;
 return {variant,parseMs:parsed-start,serializeMs:serialized-parsed,sectionMs:performance.now()-serialized,totalMs:performance.now()-start,bytes:result.content.length,bodySha256:sha(body(result.content))};
}
// Warm module/JIT state equally; warm-ups are excluded and explicitly retained.
const warmups=[await run('base'),await run('branch')];
const runs=[];
for(const order of [['base','branch'],['branch','base'],['base','branch'],['branch','base']])for(let i=0;i<5;i++)for(const name of order)runs.push(await run(name));
const hashes=new Set(runs.map(r=>r.bodySha256));if(hashes.size!==1)throw Error('Ordinary STEP DATA output changed between base/branch');
const trims=[];for(let i=0;i<5;i++)trims.push(await run('trim'));
const median=values=>{const sorted=[...values].sort((a,b)=>a-b);return (sorted[Math.floor((sorted.length-1)/2)]+sorted[Math.floor(sorted.length/2)])/2;};
const summary={};for(const variant of ['base','branch','trim']){const set=variant==='trim'?trims:runs.filter(r=>r.variant===variant);summary[variant]={};for(const key of ['parseMs','serializeMs','sectionMs','totalMs','bytes'])summary[variant][key]=median(set.map(r=>r[key]));}
const result={fixtureSha256:sha(source),pin:JSON.parse(readFileSync(out+'/source-manifest.json','utf8')),exportBuildManifestSha256:sha(readFileSync(out+'/export-build-manifest.json')),warmups,runs,trims,summary,ordinarySelection:'visibleOnly with outside IDs from final FZK receipt hidden; identical base/branch selection',ordinaryDataByteIdentity:true,ordinaryDataSha256:[...hashes][0],scope:'actual base/branch StepExporter source against identical shared parser dependencies; full parse + serialization; branch trim includes public WASM remesh/cut/rewrite. Native worker-pool load measured separately.'};
writeFileSync(out+'/measured-export-result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({summary,ordinarySelection:'visibleOnly with outside IDs from final FZK receipt hidden; identical base/branch selection',ordinaryDataByteIdentity:true,ordinaryDataSha256:result.ordinaryDataSha256}));
