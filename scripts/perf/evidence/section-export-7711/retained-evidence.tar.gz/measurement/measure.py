import hashlib,json,os,statistics,subprocess,time
from pathlib import Path
ROOT=Path('/home/louistrue/.t3/worktrees/ifc-lite/t3-aa41e555')
OUT=Path(__file__).resolve().parent
M=json.loads((OUT/'source-manifest.json').read_text()); BASE=Path(M['baseSource'])
subprocess.run(['python3',str(OUT/'verify-ready.py')],check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==M['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
assert os.environ.get('IFC_WORKER_ACTIVE_STATE'),'measurement requires worker admission'
# The caller must request benchmark EX; do not infer safety from CPU limits.
state=Path(os.environ['IFC_WORKER_ACTIVE_STATE'])
active=[json.loads(p.read_text()) for p in state.glob('jobs/*/receipt.json')]
assert any(r.get('kind')=='benchmark' and r.get('state')=='running' and str(Path(__file__)) in r.get('command',[]) for r in active),'no active benchmark receipt for this exact driver'
for name in ['base','branch']:
 h=json.loads((OUT/(name+'-build-handle.json')).read_text());r=json.loads(Path(h['receipt']).read_text())
 assert r['state']=='completed' and r['exitCode']==0,(name,r)
files=M['nativeLoadDependencyInputPaths']
assert all((ROOT/f).read_bytes()==(BASE/f).read_bytes() for f in files)
def hashfile(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cpu():
 return [int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
def idle_receipt():
 a=cpu();time.sleep(2);b=cpu();delta=[y-x for x,y in zip(a,b)];busy=1-(delta[3]+delta[4])/max(1,sum(delta))
 r={'busyFraction':busy,'loadavg':Path('/proc/loadavg').read_text().strip(),'at':time.time()}
 if busy>.10:
  (OUT/'measurement-refusal.json').write_text(json.dumps(r,indent=2)+'\n')
  raise SystemExit('Host busy: cohort refused, no performance verdict. '+json.dumps(r))
 return r
fixtures=['tests/models/ara3d/AC20-FZK-Haus.ifc','tests/models/ara3d/ISSUE_129_N1540_17_EXE_MOD_448200_02_09_11SMC_IGC_V17.ifc','tests/models/ara3d/ISSUE_053_20181220Holter_Tower_10.ifc']
fixture_manifest=json.loads((ROOT/'tests/models/manifest.json').read_text())
expected={f['path']:f['sha256'] for f in fixture_manifest['files']}
for fixture in fixtures:
 assert (ROOT/fixture).is_file() and hashfile(ROOT/fixture)==expected[fixture.removeprefix('tests/models/')],('fixture provenance',fixture)
results={'base':M['base'],'head':M['head'],'sourceManifestSha256':hashfile(OUT/'source-manifest.json'),'driverSha256':hashfile(Path(__file__)),'rayonThreads':os.environ.get('RAYON_NUM_THREADS'),'cohort':'interleaved multi-thread native process_geometry worker pool; no browser/GPU measurement','variants':{name:{'binarySha256':hashfile(OUT/(name+'-perf_probe')),'root':str(p)} for name,p in [('base',BASE),('branch',ROOT)]},'fixtures':{}}
for fixture in fixtures:
 try:
  path=ROOT/fixture
  if not path.exists():
   results['fixtures'][fixture]={'skipped':'missing fixture; pnpm fixtures'};continue
  runs=[];guards=[]
  for pair,order in enumerate([['base','branch'],['branch','base']]):
   guards.append(idle_receipt())
   for name in order:
    checkout=BASE if name=='base' else ROOT
    env=os.environ.copy();env['CARGO_TARGET_DIR']=str(checkout/'target');env['CARGO_BUILD_JOBS']='2';env['RAYON_NUM_THREADS']='2'
    label=path.stem+'-'+str(pair)+'-'+name
    command=[str(OUT/(name+'-perf_probe')),str(path),'--iters','5','--fingerprint','--json']
    with (OUT/(label+'.json')).open('wb') as output,(OUT/(label+'.stderr.log')).open('wb') as error:
     proc=subprocess.run(command,cwd=checkout,env=env,stdout=output,stderr=error,timeout=600)
    assert proc.returncode==0,(label,proc.returncode)
    data=json.loads((OUT/(label+'.json')).read_text());assert len(data)==1
    item={'variant':name,'pair':pair,'command':command,'outputSha256':hashfile(OUT/(label+'.json')),'measurement':data[0]};runs.append(item)
    print(json.dumps({'fixture':fixture,'variant':name,'pair':pair,'parseMs':data[0]['parseMs'],'geometryMs':data[0]['geometryMs'],'totalMs':data[0]['totalMs']}),flush=True)
  fingerprints={fp for run in runs for fp in run['measurement']['meshFingerprintsFnv1a64']}
  counts={(run['measurement']['meshes'],run['measurement']['vertices'],run['measurement']['triangles']) for run in runs}
  assert len(fingerprints)==1 and len(counts)==1,('payload/count drift',fixture,fingerprints,counts)
  summaries={name:{key:statistics.median(r['measurement'][key] for r in runs if r['variant']==name) for key in ['parseMs','geometryMs','totalMs']} for name in ['base','branch']}
  for name in summaries:summaries[name]['fullPipelineWallMedianMs']=statistics.median(v for r in runs if r['variant']==name for v in r['measurement']['allWallMs'])
  deltas={key:{'ms':summaries['branch'][key]-summaries['base'][key],'percent':(summaries['branch'][key]/summaries['base'][key]-1)*100 if summaries['base'][key] else None} for key in summaries['base']}
  results['fixtures'][fixture]={'fixtureSha256':hashfile(path),'idleGuards':guards,'runs':runs,'medianBestOfFive':summaries,'deltas':deltas,'orderedMeshFingerprint':next(iter(fingerprints)),'counts':list(next(iter(counts))),'geometryPayloadIdentity':True,'identityScope':'ordered geometry payload only; excludes text/material definitions/UVs/textures/instancing'}
  (OUT/'measured-result.json').write_text(json.dumps(results,indent=2)+'\n')
 except (AssertionError,subprocess.TimeoutExpired) as error:
  if 'Holter' not in fixture: raise
  results['fixtures'][fixture]={'qualified':False,'reason':str(error),'scope':'optional heavy CSG fixture unavailable; no heavy-fixture performance verdict','rawLogsRetained':True}
  (OUT/'measured-result.json').write_text(json.dumps(results,indent=2)+'\n')
  print('UNQUALIFIED_OPTIONAL_HEAVY_FIXTURE '+str(error),flush=True)
print('COMPLETED_NATIVE_LOAD_COHORT',flush=True)

# Both prepared measurements share the same explicit benchmark EX ownership.
subprocess.run(['node',str(OUT/'measure-export.mjs')],cwd=ROOT,env=os.environ|{'NODE_OPTIONS':'--max-old-space-size=8192'},check=True)
print('COMPLETED_STEP_AND_SECTION_EXPORT_COHORT',flush=True)

subprocess.run(['python3',str(OUT/'verify-ready.py')],check=True)
print('FROZEN_INPUTS_VERIFIED_AFTER_COHORT',flush=True)
