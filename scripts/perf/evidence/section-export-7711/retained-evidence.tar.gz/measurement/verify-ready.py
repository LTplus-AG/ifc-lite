from pathlib import Path
import hashlib,json,subprocess
OUT=Path(__file__).resolve().parent
M=json.loads((OUT/'readiness.json').read_text())
root=Path(M['checkout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==M['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
for path,expected in M['inputs'].items():
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 assert h.hexdigest()==expected,('FROZEN_INPUT_CHANGED',path)
print('READY_INPUTS_VERIFIED',M['head'],len(M['inputs']))
