import hashlib,json,subprocess,signal,sys,os,time
from pathlib import Path
root=Path('/home/louistrue/wt/6537-symbolic-parse-outcome-session6503')
out=Path('/tmp/6232-takeover/6537-symbolic-parse-false-success-inverse-v1')
source=Path('/tmp/6232-takeover/6537-symbolic-parse-outcome-source-v3')
manifest=json.loads((source/'source-manifest.json').read_text())
target=root/'apps/viewer/src/lib/overlay-parse/index.ts'
original=target.read_bytes();original_sha=hashlib.sha256(original).hexdigest()
expected=next(x['sha256'] for x in manifest['members'] if x['path']=='apps/viewer/src/lib/overlay-parse/index.ts')
needle=b": { kind: 'failure', flat: createEmptyFlatSymbolic() };"
replacement=b": { kind: 'success', flat: createEmptyFlatSymbolic() };"
if original_sha!=expected or original.count(needle)!=1: raise RuntimeError('Refused source mutation: frozen source or unique helper branch mismatch')
mutated=original.replace(needle,replacement,1)
(out/'reviewed-index.ts').write_bytes(original)
(out/'mutated-index.ts').write_bytes(mutated)
command=['python3','/tmp/6232-takeover/functional-budget-guardian-v3-disk-session6503.py',str(root)]
task=['env','WASM_BUILD_MODE=fetch',r'TEST_PATTERN=symbolic-parse-outcomes\.test','pnpm','test','--filter=@ifc-lite/viewer','--env-mode=loose','--concurrency=1']
runner=None
receipts={'originalSha256':original_sha,'mutatedSha256':hashlib.sha256(mutated).hexdigest(),'scope':'False success kind only; same empty flat. Finite correctness inverse, no timings/browser/parser-fidelity claim.','command':task,'startHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
def interrupted(signum,frame):
 raise InterruptedError(f'coordinator received signal {signum}')
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
def phase(name):
 global runner
 cmd=[*command,str(out/name),*task]
 with (out/(name+'-guardian.stdout')).open('w') as handle:
  runner=subprocess.Popen(cmd,stdout=handle,stderr=subprocess.STDOUT)
  try: result=runner.wait()
  except BaseException:
   # Stop only this guardian's child process tree before exact source restoration.
   ids={runner.pid};rows={}
   for path in Path('/proc').iterdir():
    if not path.name.isdigit(): continue
    try:
     fields=(path/'stat').read_text().rsplit(')',1)[1].split();rows[int(path.name)]=(int(fields[1]),int(fields[2]))
    except (FileNotFoundError,ProcessLookupError,PermissionError): continue
   while True:
    expanded=ids|{pid for pid,(parent,_) in rows.items() if parent in ids}
    if expanded==ids: break
    ids=expanded
   groups={rows[pid][1] for pid in ids if pid in rows and rows[pid][1]==pid and pid!=os.getpgrp()}
   for group in groups:
    try: os.killpg(group,signal.SIGTERM)
    except ProcessLookupError: pass
   for pid in ids:
    try: os.kill(pid,signal.SIGTERM)
    except ProcessLookupError: pass
   try: runner.wait(timeout=5)
   except subprocess.TimeoutExpired:
    for pid in ids:
     try: os.kill(pid,signal.SIGKILL)
     except ProcessLookupError: pass
    runner.wait()
   raise
  finally: runner=None
 return result
try:
 target.write_bytes(mutated)
 receipts['inverseExit']=phase('inverse')
except BaseException as error:
 receipts['coordinatorFailure']={'type':type(error).__name__,'message':str(error)}
finally:
 target.write_bytes(original)
 receipts['restoredSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
 receipts['byteExactRestored']=target.read_bytes()==original
 receipts['allNineSourceRestored']=all(hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['members'])
 (out/'restoration-before-control.json').write_text(json.dumps(receipts,indent=2)+'\n')
 if not receipts['byteExactRestored']: raise RuntimeError('Exact restoration failed')
if 'coordinatorFailure' not in receipts:
 receipts['restorationExit']=phase('restored')
receipts['finalSha256']=hashlib.sha256(target.read_bytes()).hexdigest()
receipts['allNineSourceFinallyEqual']=all(hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in manifest['members'])
(out/'summary.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts))
sys.exit(0 if receipts.get('inverseExit')==1 and receipts.get('restorationExit')==0 and receipts['allNineSourceFinallyEqual'] else 1)
