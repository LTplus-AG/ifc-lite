import json,subprocess
from pathlib import Path
out=Path('/tmp/6232-takeover/6537-symbolic-parse-outcome-validation-v3')
paths=['apps/viewer/src/hooks/symbolic-parse-cache.ts','apps/viewer/src/hooks/symbolic-parse-source-key.ts','apps/viewer/src/hooks/symbolic-parse-outcomes.ts','apps/viewer/src/hooks/symbolic-parse-outcomes.test.ts','apps/viewer/src/lib/overlay-parse/index.ts','apps/viewer/src/store/createViewerActions.ts','apps/viewer/src/store/symbolic-parse-observer.ts','scripts/perf/symbolic-parse-census.mjs']
commands=[
 ('scoped-lint',['pnpm','exec','oxlint','--deny-warnings',*paths]),
 ('module-size',['node','scripts/check-module-size.mjs','--base','8570465acd2f68ef9b6f6e180d86af4636f52454']),
 ('test-wiring',['node','scripts/check-test-wiring.mjs']),
 ('source-assert',['node','scripts/check-source-text-assertions.mjs']),
 ('license',['node','scripts/add-license-headers.mjs','--check']),
 ('syntax',['node','--check','scripts/perf/symbolic-parse-census.mjs']),
 ('diff-check',['git','diff','--check']),
]
rows=[]
for name,command in commands:
 with (out/(name+'.log')).open('w') as handle:
  result=subprocess.run(command,stdout=handle,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':command,'exit':result.returncode,'log':name+'.log'})
(out/'source-gate-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows))
raise SystemExit(1 if any(row['exit'] for row in rows) else 0)
