import hashlib,json,subprocess,sys,re
from pathlib import Path
root=Path('/home/louistrue/wt/6537-symbolic-parse-outcome-session6503')
version=sys.argv[1];out=Path('/tmp/6232-takeover/6537-symbolic-parse-outcome-source-'+version);out.mkdir(exist_ok=True)
src1=Path('/tmp/6232-takeover/6537-symbolic-parse-outcome-source-v1');old=json.loads((src1/'source-manifest.json').read_text());rows=[]
for row in old['members']:
 name=row['path'];raw=(root/name).read_bytes();target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 rows.append({**row,'bytes':len(raw),'lines':raw.count(b'\n'),'sha256':hashlib.sha256(raw).hexdigest(),'equalV1':hashlib.sha256(raw).hexdigest()==row['sha256']})
(out/'source-manifest.json').write_text(json.dumps({'base':old['base'],'worktree':str(root),'members':rows},indent=2)+'\n')
(out/'modified.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=root))
run=Path('/tmp/6232-takeover/6537-symbolic-parse-outcome-validation-'+version)
# Keep guardian source-gates.json unchanged; obtain exact gate rows from its retained stdout.
commands=json.loads((run/'source-gates.log').read_text().splitlines()[0])
(out/'gate-results.json').write_text(json.dumps(commands,indent=2)+'\n')
raws=[]
for file in sorted(run.iterdir()):
 if file.is_file():
  raw=file.read_bytes();raws.append({'path':str(file),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
(out/'validation-manifest.json').write_text(json.dumps({'files':raws},indent=2)+'\n')
tests=(run/'selected-tests-corrected.log').read_text()
logvalues={name:int(re.search(r'ℹ '+name+r' (\d+)',tests).group(1)) for name in ['tests','pass','fail','skipped']}
production=[row for row in rows if not row['path'].endswith('.test.ts') and not row['path'].endswith('.md')]
receipt=json.loads((src1/'packet.json').read_text());receipt.update({
 'state':'UNCOMMITTED finite correctness prototype; publication held for root review',
 'totalSourceBytes':sum(row['bytes'] for row in rows),
 'sourceManifestSha256':hashlib.sha256((out/'source-manifest.json').read_bytes()).hexdigest(),
 'predecessor':{'path':str(src1),'packetSha256':hashlib.sha256((src1/'packet.json').read_bytes()).hexdigest(),'originalFrozenBytesUnchanged':True},
 'controls':{'new':18,'existing':34,'actualFinal':logvalues,'rawLog':str(run/'selected-tests-corrected.log'),'firstActual':{'tests':52,'pass':50,'fail':2,'skipped':0,'classification':'/tmp/6232-takeover/6537-symbolic-parse-outcome-validation-v2/first-red-classification.json'},'realPassivePageConsumer':'actual callback/store consumer PASS','WasmParserOrGpuOracle':False},
 'rootTypecheck':{'guardian':str(run/'root-typecheck.json'),'log':str(run/'root-typecheck.log'),'exit':0,'mandatoryAuditTestFiles':3365,'packages':57,'viewerTestFiles':1791},
 'gates':commands,
 'requiredGraphDisclosure':{'testDependency':'current turbo.json test.dependsOn=[build]','viewerBuild':'necessary prerequisite of approved root test; explicitly authorized by root after observed graph','wasm':'fetch only; no Rust compilation','noExtraStandaloneBuild':True},
 'changesAfterV1':{'productionBytesEqual':all(row['equalV1'] for row in production),'testOnly':'real target private-field proxy delegation/method binding; callback URL depth; distinct storey-table elevations for valid 4097-bucket fixture; assertions unchanged','docOnly':'current finite validation status and retained first refusal/setup failures'},
 'validationManifestSha256':hashlib.sha256((out/'validation-manifest.json').read_bytes()).hexdigest(),
 'prerequisites':{'installedDependencies':True,'installReceipt':'/tmp/6232-takeover/6537-symbolic-parse-outcome-validation-v2/install.json','lockfileUnchanged':True,'Rust':'fetch only; no compile'},
 'currentRetentionFix':'Observation holds only scalar tokens; producer assigns WeakMap<object,number> identities, passive getter gets only; absent refs use0. Source/map/view/room objects are not retained by old observations.',
 'historicalV2PacketErratum':'v2 packet totalSourceBytes accidentally retained v1 aggregate76470; authoritative frozen v2 member manifest sum is77365. All source/member hashes and raw test/gate receipts unchanged; v3 uses actual sum.',
 'noMutation':'Only authorized source/test/doc edits and guarded correctness install/root prerequisite builds/tests/typecheck/gates. No Rust compilation, standalone app build, browser, benchmark, commit, push, PR, published package API, renderer/comparator/authored guard changes.',
 'limits':['Finite lifecycle/dispatch controls only, held worker seam is not a real WASM parser or authored IFC semantic oracle','Successful parse is only producer success, not complete authored IFC text','No glyph/atlas/natural-frame/renderer integration','No timing/performance/browser/pixel verdict','No commit/push/PR before root review']})
(out/'packet.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'current-status.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=root,text=True))
print(json.dumps({'packet':str(out/'packet.json'),'packetSha256':hashlib.sha256((out/'packet.json').read_bytes()).hexdigest(),'sourceManifestSha256':receipt['sourceManifestSha256'],'validationManifestSha256':receipt['validationManifestSha256'],'productionEqualV1':receipt['changesAfterV1']['productionBytesEqual'],'actualTests':logvalues,'allSourceGatesZero':all(row['exit']==0 for row in commands),'changedPaths':len(rows)},indent=2))
