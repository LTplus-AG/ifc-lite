# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
from pathlib import Path
import json, hashlib, subprocess, struct, re
root=Path(__file__).resolve().parent
src=root/'artifacts/gpu-control-37157226416-1'
repo='/home/louistrue/wt/6537-symbolic-upload-gpu-qualification-session6503'
head='88e26da7f9bc02eb0add8aabb010af98f380b3c2'
r=json.loads((src/'symbolic-upload-report.json').read_text());c=r['control'];g=c['gpu'];checks=[]
def check(ok,label): checks.append({'label':label,'passed':bool(ok)})
def sha(b):return hashlib.sha256(b).hexdigest()
run=json.loads((root/'run.json').read_text())
check(run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==head,'actual terminal exact hosted controller')
check(r['status']=='qualified-symbolic-upload-input-control' and r['retries']==0 and r['finalSourceVerification']=='complete','one prospective qualified control')
check(r['harness']==r['finalHarness'] and r['harness']['head']==head,'source/head/Node final freeze equality')
for name,h in r['harness']['sources'].items():
 b=subprocess.check_output(['git','show',head+':'+name],cwd=repo)
 check(sha(b)==h,'literal committed source bytes '+name)
check(c['harness']['node']==r['harness']['node'] and c['harness']['head']==head,'actual child Node/head agrees')
expected_inputs={'scripts/perf/symbolic-upload-recorder.mjs','scripts/perf/symbolic-upload-gpu-page.mjs','scripts/perf/symbolic-upload-gpu-control.mjs','scripts/perf/symbolic-upload-qualification.mjs','scripts/perf/interleaved-cleanup.mjs','scripts/perf/gpu-control.mjs','package.json','pnpm-lock.yaml'}
check(set(c['harness']['files'])==expected_inputs,'exact eight child inputs')
check(all(r['harness']['sources'][k]==v for k,v in c['harness']['files'].items()),'all child source hashes agree with outer freeze')
abi=[('symbolic-fill-vbuf',28,40),('symbolic-fill-partition-camera',160,72),('symbolic-text-corner',16,40),('symbolic-text-camera',208,72),('symbolic-text-instances',108,40),('symbolic-text-rte-deltas',32,40)]
check(len(g['controls'])==len(g['shaderCompilations'])==6,'all six actual resource readbacks and diagnostics')
changes={0:(4,[0x80000000]),1:(8,[0x7fc12345,0x80000000]),4:(12,[0x80000000,13]),5:(4,[91,92])}
for i,(label,size,usage) in enumerate(abi):
 words=[(0x80000000+n*0x1020304+i)&0xffffffff for n in range(size//4)]
 expected=bytearray(struct.pack('<'+'I'*len(words),*words))
 if i in changes:
  offset,payload=changes[i];expected[offset:offset+4*len(payload)]=struct.pack('<'+'I'*len(payload),*payload)
 actual=g['controls'][i];d=g['shaderCompilations'][i]
 check((actual['label'],actual['size'],actual['usage'])==(label,size,usage),'exact original usage/ABI '+label)
 for key in ['rawBytes','capturedBytes','declaredInputBytes']:
  check(actual[key]==list(expected),'independent seeded and partial-write destination bytes '+label+'/'+key)
 check(len(set(actual['rawBytes']))>1 and actual['mutationRejected'] is True,'nonzero diversity and changed-byte refusal '+label)
 check((d['label'],d['size'],d['usage'])==(label,size,usage) and d['totalMessages']==0 and d['messages']==[] and d['truncated'] is False,'actual complete shader compilation diagnostics '+label)
check(g['sourceMutation']=={'before':[9,0x7fc12345,0x80000000,13,17],'after':[0x55555555]*5,'mutationValue':0x55555555},'source mutation cannot overwrite already-written payload')
check(g['gpuEvents']==[{'kind':'device-lost','reason':'destroyed','message':'Device was destroyed.','ending':True}] and g['deviceLossCompletion']=='owned-destruction-observed','only intentional final device loss')
check(g['cleanup']=='complete' and not g['failures'] and not g['cleanupFailures'],'all GPU completion and resource destruction')
check(g['recorderDisposals']==[{'phase':'active-buffers','status':'disposed','reason':None},{'phase':'empty-text','status':'disposed','reason':None}],'both recorder restorations')
empty=g['emptyText'];check(empty['census']['fillPartitions']==empty['census']['textInstances']==0,'empty initialized text census')
check(len(empty['buffers'])==2 and all(x['active'] is False and x['bytes'] is None for x in empty['buffers']) and [x['completeObservedCoverage'] for x in empty['buffers']]==[True,False],'inactive/unwritten bytes not claimed')
check(c['exit']['code']==0 and c['exit']['signal'] is None and c['browserClose']=='complete' and not c['backendErrors'] and not r.get('outerRefusal'),'actual outer exit/backend/browser closure')
for name in ['ownedCleanup','childOwnedCleanup']:
 x=c[name];check(x['status']=='complete' and x['zombies']==0 and x['remaining']==[],'complete actual PID/start witnesses '+name)
check(len(c['logFlushes'])==2 and all(x['status']=='complete' for x in c['logFlushes']),'complete two-stream drain')
for i,name in enumerate(['stdout','stderr']):check((src/('symbolic-upload.child.'+name+'.log')).stat().st_size==c['logBytes'][i],'full retained actual log byte count '+name)
log=(src/'symbolic-upload.child.stderr.log').read_text()
chrome=c['chrome'];check(f"<launched> pid={chrome['identity']['pid']}" in log and chrome['identity']['ppid']==c['rootIdentity']['pid'],'actual Chrome raw launch/PID parent evidence')
flags=['--enable-gpu','--enable-webgpu','--enable-unsafe-webgpu','--use-angle=swiftshader','--ignore-gpu-blocklist','--use-vulkan=swiftshader','--use-webgpu-adapter=swiftshader','--enable-features=CDPScreenshotNewSurface,Vulkan']
launch=next(line for line in log.splitlines() if '<launching>' in line)
check(all(flag in chrome['arguments'] and flag in launch for flag in flags),'all corrected flags both proc argv and actual launch log')
check(chrome['sha256']=='4d2512ae84986bf987e6ea8ef14ca1af555ae574fbaff5b5a8c78a8dd73fa36f' and chrome['version']=='154.0.8037.57','retained observed Chrome executable/version')
backend=re.findall(r'^.*(?:Could not find a SharedImageBackingFactory|Unable to create SkSurface|VK_ERROR|GPU process.*(?:crash|exited unexpectedly)|(?:Dawn|SharedImage|Vulkan).*(?:failed|failure|error)|(?:ERROR|failed|failure).*(?:Dawn|SharedImage|Vulkan)).*$',log,re.M|re.I)
check(not backend and not any(e['kind'] in ['pageerror','crash','console-error','diagnostic-refusal'] for e in c['events']),'full raw graphics-backend and page error scan; ordinary DBus stderr retained')
manifest={str(p.relative_to(src)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(src.rglob('*')) if p.is_file()}
result={'status':'QUALIFIED_STANDALONE_SYMBOLIC_BUFFER_INPUT_CONTROL' if all(x['passed'] for x in checks) else 'REFUSED_INDEPENDENT_AUDIT','run':run['html_url'],'head':head,'checks':checks,'failedChecks':[x for x in checks if not x['passed']],'scope':'Six real GPU buffer readbacks match independent literal seeded and partial-write plans, recorder shadows, actual mutation controls and original GPU usages. Source/Chrome/PID/log/cleanup receipts retained. Remote executable hashes/ownership are observed witnesses, not rehashed after runner termination. Source/Node inventory is declared inputs, not whole dependency/machine closure. No IFC/parser/renderer completeness, atlas texel, screenshot, model/performance or full appearance qualification.'}
(root/'independent-qualification.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'artifact-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failedChecks':result['failedChecks'],'qualificationSha256':sha((root/'independent-qualification.json').read_bytes()),'artifactManifestSha256':sha((root/'artifact-hashes.json').read_bytes())},indent=2))
if result['failedChecks']:raise SystemExit(1)
