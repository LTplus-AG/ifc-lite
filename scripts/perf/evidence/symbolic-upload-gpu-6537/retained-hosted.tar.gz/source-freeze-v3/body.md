Refs #6537

Add a standalone hosted GPU experiment for symbolic upload inputs. Six original-usage vertex/uniform buffers are read through uint32 shaders and compared against recorder shadows and independent varied write plans, including partial writes and source mutation. The shared outer harness requires actual Chrome/source identity, complete bounded logs, owned-process cleanup, shader/error/loss diagnostics and prototype restoration. Existing graphics profiles retain their default behavior.

29 functional controls and scoped syntax/lint/size/wiring/source-assertion/license gates pass. Actual hosted GPU qualification is UNRUN. No IFC/renderer completeness, authored-text appearance, atlas-texel, pixel-fidelity or performance verdict is claimed; this stays outside the timed comparator.
