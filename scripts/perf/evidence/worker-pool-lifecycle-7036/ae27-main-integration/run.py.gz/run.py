import subprocess,pathlib,json,hashlib,datetime,os,time,sys
w=pathlib.Path('/tmp/ifc-7180-main-restack');r=pathlib.Path('/tmp/7180-ae27-qualified-20261008')
head='396a9c4d6c8bce9d7e926c167142d3ee28404cae'
paths=['tests/benchmark/load-trace-metrics.ts','scripts/viewer-benchmark-span-metrics.test.mjs','scripts/perf/tsconfig.frames.json','package.json','scripts/unused-locals-baseline.json','apps/viewer/src/lib/assistant/adapters/selection-materials.test.tsx','apps/viewer/src/utils/serverDataModel.test.ts','apps/viewer/src/utils/serverMaterialNullPresence.test.ts','apps/viewer/src/lib/charts/element-fields.test.ts','apps/viewer/src/lib/charts/element-field-unit-overlay.test.ts','packages/parser/src/material-definitions.ts','apps/viewer/src/lib/charts/element-field-reader.ts','apps/viewer/src/lib/charts/element-field-families.ts']
def pins():return {p:hashlib.sha256((w/p).read_bytes()).hexdigest() for p in paths}
def runtime():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None for p in [w/'packages/wasm/pkg/ifc-lite_bg.wasm',w/'packages/wasm/pkg/ifc-lite.js',w/'packages/wasm/pkg/ifc-lite.d.ts']}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True)
source=pins();baseenv={**os.environ,'NODE_OPTIONS':'--max-old-space-size=6144','TURBO_CONCURRENCY':'1','CARGO_BUILD_JOBS':'1'}
tests=['scripts/browser-ab-report.test.mjs','scripts/browser-metadata-readiness.test.mjs','scripts/viewer-benchmark-span-metrics.test.mjs','scripts/perf/frame-gpu-chrome-lifecycle.test.mjs','scripts/perf/frame-gpu-owned-profile.test.mjs','scripts/perf/worker-pool-lifecycle-invariants.test.mjs']
actions=[('prerequisite-controls',['node','--test','--test-concurrency=1',*tests],{}),('affected-viewer-controls',['pnpm','test','--env-mode=loose','--filter=@ifc-lite/viewer','--concurrency=1'],{'TEST_PATTERN':'selection-materials|serverDataModel|serverMaterialNullPresence|element-fields|element-field-unit-overlay'}),('full-root-typecheck',['pnpm','typecheck'],{}),('full-root-lint',['pnpm','lint'],{})]
pre={'head':head,'frozenMain':'ae27edc77b596700595ce0fc13f03e416af179c2','sourcePins':source,'runtimePre':runtime(),'commands':actions,'scope':'fresh normal-main integration qualification; no native/performance claim','status':'PREPARED_UNRUN'};(r/'preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
for name,cmd,extra in actions:
 assert pins()==source
 before=runtime();start=time.time()
 with (r/(name+'.log')).open('w') as f:code=subprocess.call(cmd,cwd=w,env={**baseenv,**extra},stdout=f,stderr=subprocess.STDOUT)
 receipt={'name':name,'command':cmd,'environmentAdditions':extra,'head':head,'exitCode':code,'startedUnix':start,'endedUnix':time.time(),'sourceBefore':source,'sourceAfter':pins(),'runtimeBefore':before,'runtimeAfter':runtime(),'logSHA256':hashlib.sha256((r/(name+'.log')).read_bytes()).hexdigest()};(r/(name+'-terminal.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'stage':name,'exitCode':code}),flush=True)
 assert pins()==source
 if code:sys.exit(code)
print('All four integration qualification stages terminal0.',flush=True)
