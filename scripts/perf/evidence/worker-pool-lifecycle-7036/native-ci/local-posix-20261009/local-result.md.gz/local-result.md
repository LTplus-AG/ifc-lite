# Actual local qualification

Private normal-history head `58c9511476414f1ee5d746a2eb17204a0060705c` is clean and descends from published `fef2a3a5ac411973a4c1840dad2356bb6bb1719c`. No push occurred.

Ten syntax checks and five source/workflow gates passed after direct top-level aggregate wiring correction. All83 existing oracle tests passed. The API-preserving routing inverse ran four focused controls: two passed and two failed on actual wrong routing assertions; byte-exact restoration passed all four.

Actual POSIX no-start qualification passed original2 and canonical baseline2. The surgical production getter mutation preserved imports/APIs and caused both actual ENOENT/EACCES assertions to fail. The canonical observer recorded OBSERVED with V8 exact-file attribution and verified restoration; restored2 passed. All four invocation scopes preserve both actual OS receipts and fixture metadata; all copied file pins were independently verified. Five native controls were deliberately delegated to Windows and skipped, and confer no native acceptance.

The initial UNWATCHED_JOB failure and initial trailing-separator planner setup refusal remain actual preserved failures. Neither counts as inverse proof. Original fef2 checkout remains untouched. Hosted native Windows9 plus independent native inverses/restoration and exact-head CI remain pending. Local qualification precedes draft publication; hosted Windows CI necessarily follows draft publication and precedes ready/merge. No Chrome/GPU/focus/timing or broad #7036 acceptance claim.
