# Pending source qualification

The isolated implementation is unrun and uncommitted. Original fef2 checkout remains clean. Root review must precede execution; the #6975 agent currently owns the heavy typecheck lane.

1. Bounded Node syntax checks for modified/new executable modules, plus source gates for test wiring, module budgets and forbidden source-text assertions. These provide source validity only.
2. Execute actual classifier/platform/CLI invariants in the existing oracle test file. Remove or invert the canonical native partition behavior while preserving the classifier API: assert actual routing failures, restore bytes and rerun positives. Do not count an absent API/import as an inverse.
3. On actual POSIX, execute the existing two genuine ENOENT/EACCES controls with explicit scope, actual evidence archive, surgical no-start mutation and restored positives. Require attributed execution and both receipts; no skipped-native claim.
4. On supported native Windows with actual powershell.exe Desktop5.1, execute all nine native controls, separate changed-file canonical oracle runs of the surgical native mutation, and all nine restored positives. Require meaningful assertion failure in each selected file and canonical OBSERVED plus verified restoration; inspect raw compilation and exact-identity/process cleanup receipts. Windows evidence cannot be replaced by WSL availability.
5. Fresh exact-head CI must run the ordinary Linux observer, required Windows and POSIX qualifiers and preserved aggregate. Review actual ruleset contexts and unanswered comments before ready/merge. Source/local qualification precedes draft publication; hosted Windows CI necessarily follows draft publication and precedes ready/merge. Ordinary changed tests retain baseline/whole-production inverse, and uncovered input fails closed.

Every actual invocation uses an exclusive external actual-fixtures scope allocated by runPlan. The original/raw/compiler/native/OS receipts and original failure remain preserved. This source qualification does not confer Chrome, GPU, focused physical-session, timing or full #7036 acceptance.
