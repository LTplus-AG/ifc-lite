from pathlib import Path
import subprocess,json,hashlib,re,sys,shutil
w=Path('/tmp/ifc-7221-supervisor-no-start');a=Path(__file__).parent
native=w/'scripts/perf/frame-gpu-process-identity.cs';helper=w/'scripts/perf/frame-gpu-cpu-fixture.mjs';test='scripts/perf/frame-gpu-job-controller.test.mjs'
paths=[native,helper,w/test];base={p:p.read_bytes() for p in paths};results=[]
def pins():return {str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(a/'source-pins.json').write_text(json.dumps(pins(),indent=2)+'\n')
def stage(name,args):
 print(json.dumps({'stage':name,'status':'running'}),flush=True)
 with (a/(name+'.stdout.log')).open('wb') as out,(a/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(args,cwd=w,stdout=out,stderr=err);code=p.wait(timeout=240)
 raw=(a/(name+'.stdout.log')).read_text();summary={k:int(m[-1]) if(m:=re.findall(r'^(?:#|ℹ) '+k+r' (\d+)$',raw,re.M))else None for k in ['tests','pass','fail','skipped']}
 fixtures=[]
 for path in re.findall(r'Owned CPU fixture (/tmp/ifc-job-controller-cpu-[A-Za-z0-9_-]+)',raw):
  src=Path(path);dest=a/'actual-fixtures'/name/src.name;dest.mkdir(parents=True,exist_ok=True)
  for f in src.iterdir():
   if f.is_file():shutil.copy2(f,dest/f.name)
  receipt=json.loads((dest/'native-identity-receipt.json').read_text());fixtures.append({'dir':path,'receipt':receipt})
 r={'stage':name,'exit':code,'summary':summary,'pins':pins(),'fixtures':fixtures};results.append(r);(a/'stage-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['pins','fixtures']}),flush=True);return r,raw
cmd=['node','--test','--test-reporter=tap','--test-concurrency=1'];both=cmd+['--test-name-pattern=#7221 native',test]
try:
 r,raw=stage('native-positive-2',both)
 if r['exit']!=0 or r['summary']!={'tests':2,'pass':2,'fail':0,'skipped':0}:sys.exit(1)
 s=native.read_text();native.write_text(s.replace('started != expected','long.Parse(started) / 10 != long.Parse(expected) / 10'))
 r,raw=stage('rounded-inverse-2',both);native.write_bytes(base[native])
 if r['exit']==0 or r['summary']['fail']!=2 or 'Missing expected exception' not in raw:sys.exit(2)
 if any(f['receipt']['observerFailure'] is not None for f in r['fixtures']):sys.exit(3)
 s=helper.read_text();old='[IfcProcessIdentity]::ObserveExact(${identity.pid},${literal(identity.created)})|ConvertTo-Json -Compress'
 bad="$rows=@(Get-CimInstance Win32_Process -Filter 'ProcessId=${identity.pid}');if($rows.Count -ne 1){throw 'CIM observation unproved'};@{pid=${identity.pid};started=$rows[0].CreationDate.ToUniversalTime().Ticks.ToString();state='live'}|ConvertTo-Json -Compress"
 assert s.count(old)==1;helper.write_text(s.replace(old,bad))
 r,raw=stage('cim-inverse-1',cmd+['--test-name-pattern=#7221 native observe',test]);helper.write_bytes(base[helper])
 if r['exit']==0 or r['summary']['fail']!=1 or 'Expected values to be strictly equal' not in raw:sys.exit(4)
 if any(f['receipt']['observerFailure'] is not None for f in r['fixtures']):sys.exit(5)
 r,raw=stage('native-restored-2',both)
 if r['exit']!=0 or r['summary']!={'tests':2,'pass':2,'fail':0,'skipped':0}:sys.exit(6)
 for name,args in [('syntax-controller-test',['node','--check',test]),('source-text',['node','scripts/check-source-text-assertions.mjs']),('touched-lint',['pnpm','exec','oxlint',test]),('diff-check',['git','diff','--check'])]:
  r,_=stage(name,args)
  if r['exit']!=0:sys.exit(7)
finally:
 for p,b in base.items():
  if p.read_bytes()!=b:p.write_bytes(b)
 (a/'restored-source-pins.json').write_text(json.dumps(pins(),indent=2)+'\n');print(json.dumps({'terminal':True,'restored':all(p.read_bytes()==b for p,b in base.items())}),flush=True)
