from pathlib import Path
import subprocess,json,hashlib,re,datetime,sys
w=Path('/tmp/ifc-7221-supervisor-no-start');a=Path(__file__).parent
native=w/'scripts/perf/frame-gpu-process-identity.cs';helper=w/'scripts/perf/frame-gpu-cpu-fixture.mjs';controller=w/'scripts/perf/frame-gpu-job-controller.ts'
paths=[native,helper,controller,w/'scripts/perf/frame-gpu-cpu-fixture.cs',w/'scripts/perf/frame-gpu-job-controller.test.mjs',w/'scripts/perf/frame-gpu-job.test.mjs',w/'scripts/perf/frame-gpu-job.cs',w/'scripts/perf/frame-gpu-job-input.cs',w/'scripts/perf/frame-gpu-job-supervisor.ps1']
def pins():return {str(p.relative_to(w)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths}
base={p:p.read_bytes() for p in paths};(a/'execution-source-pins.json').write_text(json.dumps(pins(),indent=2)+'\n')
results=json.loads((a/'stage-results.json').read_text()) if '--resume-reporter-correction' in sys.argv else []
def stage(name,args,timeout=600):
 print(json.dumps({'stage':name,'status':'running','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
 with (a/(name+'.stdout.log')).open('wb') as out,(a/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(args,cwd=w,stdout=out,stderr=err)
  try:code=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   p.terminate()
   try:code=p.wait(timeout=30)
   except subprocess.TimeoutExpired:p.kill();code=p.wait()
   code=124
 raw=(a/(name+'.stdout.log')).read_text(errors='replace');summary={key:int(m[-1]) if (m:=re.findall(r'^(?:#|ℹ) '+key+r' (\d+)$',raw,re.M)) else None for key in ['tests','pass','fail','skipped']}
 r={'stage':name,'args':args,'exit':code,'summary':summary,'pins':pins()};results.append(r);(a/'stage-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='pins'}),flush=True);return r,raw
cmd=['node','--test','--test-reporter=tap','--test-concurrency=1'];test='scripts/perf/frame-gpu-job-controller.test.mjs';job='scripts/perf/frame-gpu-job.test.mjs'
try:
 if '--resume-reporter-correction' in sys.argv:
  raw=(a/'initial-11-controls.stdout.log').read_text();r=results[0];r['summary']={key:int(re.findall(r'^(?:#|ℹ) '+key+r' (\d+)$',raw,re.M)[-1]) for key in ['tests','pass','fail','skipped']}
  (a/'reporter-correction.json').write_text(json.dumps({'initialActualExit':r['exit'],'correctedSummary':r['summary'],'initialWasNotRerun':True,'firstControllerExit':1},indent=2)+'\n')
 else:
  r,raw=stage('initial-11-controls',cmd+[test,job])
 if r['exit']!=0 or r['summary']!={'tests':11,'pass':11,'fail':0,'skipped':0}:sys.exit(1)
 source=native.read_text();old='started != expected';assert source.count(old)==1
 native.write_text(source.replace(old,'long.Parse(started) / 10 != long.Parse(expected) / 10'))
 r,raw=stage('inverse-rounded-native',cmd+['--test-name-pattern=#7221 native',test])
 native.write_bytes(base[native])
 if r['exit']==0 or r['summary']['fail']!=2 or 'Missing expected exception' not in raw:sys.exit(2)
 source=helper.read_text();old='[IfcProcessIdentity]::ObserveExact(${identity.pid},${literal(identity.created)})|ConvertTo-Json -Compress';assert source.count(old)==1
 bad="$rows=@(Get-CimInstance Win32_Process -Filter 'ProcessId=${identity.pid}');if($rows.Count -ne 1){throw 'CIM observation unproved'};@{pid=${identity.pid};started=$rows[0].CreationDate.ToUniversalTime().Ticks.ToString();state='live'}|ConvertTo-Json -Compress"
 helper.write_text(source.replace(old,bad))
 r,raw=stage('inverse-lossy-cim',cmd+['--test-name-pattern=#7221 native observe',test])
 helper.write_bytes(base[helper])
 if r['exit']==0 or r['summary']['fail']!=1 or ('Expected values to be strictly equal' not in raw and 'AssertionError' not in raw):sys.exit(3)
 source=controller.read_text();old="this.noStart = { executable: 'powershell.exe', code, errno, syscall: 'spawn powershell.exe' };";assert source.count(old)==1
 controller.write_text(source.replace(old,'// Controlled inverse: omitted actual OS no-start proof.'))
 r,raw=stage('inverse-no-start-proof',cmd+['--test-name-pattern=#7221 actual supervisor',test])
 controller.write_bytes(base[controller])
 if r['exit']==0 or r['summary']['fail']!=2 or 'AssertionError' not in raw:sys.exit(4)
 r,raw=stage('restored-11-controls',cmd+[test,job])
 if r['exit']!=0 or r['summary']!={'tests':11,'pass':11,'fail':0,'skipped':0}:sys.exit(5)
 for name,args in [('syntax-helper',['node','--check',str(helper)]),('syntax-controller-test',['node','--check',test]),('syntax-job-test',['node','--check',job]),('module-size',['node','scripts/check-module-size.mjs']),('test-wiring',['node','scripts/check-test-wiring.mjs']),('source-text',['node','scripts/check-source-text-assertions.mjs']),('diff-check',['git','diff','--check']),('touched-lint',['pnpm','exec','oxlint',str(helper),test,job])]:
  r,_=stage(name,args,120)
  if r['exit']!=0:sys.exit(6)
finally:
 for p,b in base.items():
  if p.read_bytes()!=b:p.write_bytes(b)
 (a/'restoration-pins.json').write_text(json.dumps(pins(),indent=2)+'\n')
 print(json.dumps({'terminal':True,'restored':all(p.read_bytes()==b for p,b in base.items())}),flush=True)
