from pathlib import Path
import subprocess,json,os,datetime
w=Path('/tmp/ifc-7221-supervisor-no-start');a=Path(__file__).parent
env=dict(os.environ,TURBO_CONCURRENCY='1',CARGO_BUILD_JOBS='1',NODE_OPTIONS='--max-old-space-size=6144')
with (a/'root-typecheck.stdout.log').open('wb') as out,(a/'root-typecheck.stderr.log').open('wb') as err:
 p=subprocess.Popen(['pnpm','typecheck'],cwd=w,env=env,stdout=out,stderr=err)
 print(json.dumps({'stage':'plain-root-typecheck','pid':p.pid,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'TURBO_CONCURRENCY':'1','rootScript':'turbo typecheck && node scripts/typecheck-tests.mjs --audit && tsc --project scripts/perf/tsconfig.frames.json','noAppendedArguments':True}),flush=True)
 code=p.wait()
(a/'root-typecheck-result.json').write_text(json.dumps({'args':['pnpm','typecheck'],'exit':code,'envOverrides':{k:env[k] for k in ['TURBO_CONCURRENCY','CARGO_BUILD_JOBS','NODE_OPTIONS']}},indent=2)+'\n')
print(json.dumps({'terminal':True,'exit':code}),flush=True)
raise SystemExit(code)
