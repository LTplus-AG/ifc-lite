import pathlib,json,hashlib,subprocess,os,sys,time,re
root=pathlib.Path('/tmp/ifc-7180-main-restack');d=pathlib.Path(__file__).parent
pins=json.loads((d/'preflight.json').read_text())['pins']
def verify():
 for r in pins:assert hashlib.sha256((root/r['path']).read_bytes()).hexdigest()==r['afterSha256'],r['path']
def run(label,cmd):
 start=time.time()
 with (d/(label+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=6144','TURBO_CONCURRENCY':'1'})
 receipt={'command':cmd,'exitCode':r.returncode,'elapsedSeconds':time.time()-start};(d/(label+'-terminal.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,json.dumps(receipt),flush=True);return r.returncode
verify()
phase=sys.argv[1];focused=['node','--import','tsx','--test','scripts/perf/frame-gpu-chrome-lifecycle.test.mjs']
if phase=='focused':assert run('focused-green',focused)==0
elif phase=='inverse-restored':
 p=root/'scripts/perf/frame-gpu-chrome.ts';b=p.read_bytes();s=b.decode();line='      if (!spawnSucceeded && child.pid === undefined) spawned = false;';assert s.count(line)==1
 try:
  p.write_text(s.replace(line,'      // Inverse: retain possible-owner flag despite actual OS spawn failure.'));(d/'inverse-launcher.ts').write_bytes(p.read_bytes())
  assert run('cleanup-only-inverse',['node','--import','tsx','--test','--test-name-pattern','actual (ENOENT|EACCES) spawn failure','scripts/perf/frame-gpu-chrome-lifecycle.test.mjs'])!=0
  raw=(d/'cleanup-only-inverse.log').read_text()
  assert len(re.findall(r'AssertionError \[ERR_ASSERTION\]',raw))==2, 'Require exactly two actual assertions'
  assert re.search(r'(?:ℹ|#)\s+fail\s+2(?:\n|$)',raw), 'Require two failures in actual test summary'
  assert 'Known OS spawn failure permits bounded explicit diagnostic attempts' in raw, 'Require actual cleanup/retry contract failure'
  assert not any(marker in raw for marker in ['ERR_MODULE_NOT_FOUND','Cannot find module','SyntaxError:','TypeError:']), 'Setup/import failure is not inverse evidence'
  (d/'inverse-assertion-verification.json').write_text(json.dumps({'actualAssertionFailures':2,'failureContract':'Unknown cleanup blocks diagnostic attempts despite actual OS spawn failure','setupErrors':False},indent=2)+'\n')
 finally:p.write_bytes(b);verify()
 assert run('restored-green',focused)==0
elif phase=='typecheck':
 assert run('full-root-typecheck',['pnpm','typecheck'])==0
 assert run('permanent-frames-programme',['pnpm','exec','tsc','-p','scripts/perf/tsconfig.frames.json'])==0
elif phase=='lights':
 for label,cmd in [('touched-oxlint',['pnpm','exec','oxlint',*[r['path'] for r in pins]]),('source-text',['node','scripts/check-source-text-assertions.mjs']),('test-wiring',['node','scripts/check-test-wiring.mjs']),('module-size',['node','scripts/check-module-size.mjs']),('mpl',['node','scripts/add-license-headers.mjs','--check']),('diff',['git','diff','--check'])]:assert run(label,cmd)==0,label
else:raise ValueError(phase)
verify()
