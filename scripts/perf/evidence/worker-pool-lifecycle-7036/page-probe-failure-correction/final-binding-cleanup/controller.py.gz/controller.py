import pathlib,subprocess,json,hashlib,os,time
root=pathlib.Path('/tmp/ifc-7180-main-restack');d=pathlib.Path(__file__).parent
p=root/'tests/benchmark/viewer-benchmark-page.ts';assert hashlib.sha256(p.read_bytes()).hexdigest()=='cb97ac629091d4b11416cfa96251e78e91db31ed4000e5c3557f7b3575b9aacd'
for label,cmd in [('full-root-typecheck',['pnpm','typecheck']),('touched-oxlint',['pnpm','exec','oxlint','tests/benchmark/metadata-render-readiness.ts','tests/benchmark/viewer-benchmark-page.ts','scripts/browser-metadata-readiness.test.mjs']),('diff',['git','diff','--check'])]:
 start=time.time()
 with (d/(label+'.log')).open('wb') as f:r=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=6144','TURBO_CONCURRENCY':'1'})
 receipt={'command':cmd,'exitCode':r.returncode,'elapsedSeconds':time.time()-start};(d/(label+'-terminal.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(label,json.dumps(receipt),flush=True)
 assert r.returncode==0,label
assert hashlib.sha256(p.read_bytes()).hexdigest()=='cb97ac629091d4b11416cfa96251e78e91db31ed4000e5c3557f7b3575b9aacd'
