exec((__import__('pathlib').Path(__file__).parent/'qualification-controller.py').read_text().split("phase = sys.argv[1]")[0])
checks = [
 ('touched-oxlint',['pnpm','exec','oxlint','tests/benchmark/metadata-render-readiness.ts','tests/benchmark/viewer-benchmark-page.ts','scripts/browser-metadata-readiness.test.mjs']),
 ('source-text',['node','scripts/check-source-text-assertions.mjs']),
 ('test-wiring',['node','scripts/check-test-wiring.mjs']),
 ('module-size',['node','scripts/check-module-size.mjs']),
 ('mpl',['node','scripts/add-license-headers.mjs','--check']),
 ('diff',['git','diff','--check']),
]
for label, command in checks:
    assert run(label, command) == 0, label
verify()
