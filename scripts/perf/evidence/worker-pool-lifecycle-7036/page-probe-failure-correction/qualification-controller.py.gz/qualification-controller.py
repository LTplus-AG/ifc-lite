import hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path('/tmp/ifc-7180-main-restack')
archive = pathlib.Path(__file__).parent
pins = json.loads((archive / 'preflight.json').read_text())['pins']
def verify():
    for row in pins:
        assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['afterSha256'], row['path']
def run(label, command):
    start = time.time()
    with (archive / (label + '.log')).open('wb') as output:
        result = subprocess.run(command, cwd=root, stdout=output, stderr=subprocess.STDOUT,
                                env={**os.environ, 'NODE_OPTIONS': '--max-old-space-size=6144', 'TURBO_CONCURRENCY': '1'})
    receipt = {'command': command, 'exitCode': result.returncode, 'elapsedSeconds': time.time()-start}
    (archive / (label + '-terminal.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    print(label, json.dumps(receipt), flush=True)
    return result.returncode
verify()
command = ['node', '--import', 'tsx', '--test', 'scripts/browser-metadata-readiness.test.mjs']
phase = sys.argv[1]
if phase == 'focused':
    assert run('focused-green', command) == 0
elif phase == 'inverse-restored':
    target = root / 'tests/benchmark/metadata-render-readiness.ts'
    original = target.read_bytes()
    text = original.decode()
    corrected = "    if (span.name === 'parser.failed' || span.attrs?.error === true) failed.push(span.name);\n    if (span.end !== null && names.includes(span.name)) done.push(span.name);"
    old = "    if (span.end === null || !names.includes(span.name)) continue;\n    done.push(span.name);\n    if (span.attrs?.error === true) failed.push(span.name);"
    assert text.count(corrected) == 1
    try:
        target.write_text(text.replace(corrected, old))
        (archive / 'inverse-projection.ts').write_bytes(target.read_bytes())
        code = run('old-projection-inverse', command)
        assert code != 0, 'Old projection unexpectedly accepted new refusal controls'
    finally:
        target.write_bytes(original)
        verify()
    assert run('restored-green', command) == 0
elif phase == 'full-root':
    assert run('full-root-typecheck', ['pnpm', 'typecheck']) == 0
else:
    raise ValueError(phase)
verify()
