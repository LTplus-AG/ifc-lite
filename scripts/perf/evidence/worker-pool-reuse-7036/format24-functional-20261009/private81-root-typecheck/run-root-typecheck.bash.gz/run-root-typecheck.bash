#!/bin/bash
set -euo pipefail
export PATH=/home/louistrue/.t3/artifacts/7036-format24-source-audit-20261009/shared-validator-source-preparation/wasm-free-nodebin:/usr/bin:/bin
export NODE_OPTIONS=--max-old-space-size=6144
export CARGO_BUILD_JOBS=2
export TURBO_CACHE=local:w,remote:w
turbo() {
  /home/louistrue/wt/7036-shared-witness-validator-20261009/node_modules/turbo/bin/turbo "$@" --concurrency=1
}
export -f turbo
timeout 600s pnpm --script-shell=/bin/bash typecheck
