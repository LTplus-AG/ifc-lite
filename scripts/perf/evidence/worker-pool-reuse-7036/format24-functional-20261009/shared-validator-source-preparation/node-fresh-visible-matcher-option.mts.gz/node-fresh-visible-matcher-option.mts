import { expect } from '/home/louistrue/wt/7036-worker-cpu-20261009/node_modules/@playwright/test/index.mjs';
import { assertPoolReuseReport, assertHiddenBootAdmission } from '/home/louistrue/wt/7036-shared-witness-validator-20261009/tests/e2e/worker-pool-reuse-7036.assertions.ts';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const dir = '/home/louistrue/.t3/artifacts/7036-format24-source-audit-20261009/shared-validator-source-preparation';
const sha = (bytes: Buffer) => createHash('sha256').update(bytes).digest('hex');
const before = JSON.parse(readFileSync(`${dir}/before-node-pins.json`, 'utf8'));
const sourcePins = () => before.sourcePins.map((pin: {path: string}) => ({path: pin.path, sha256: sha(readFileSync(`${before.worktree}/${pin.path}`))}));
const runtimeRoot = '/home/louistrue/wt/7036-worker-cpu-20261009';
const runtimePaths = ['packages/wasm/pkg/ifc-lite_bg.wasm', 'packages/wasm/pkg/ifc-lite.js', 'tests/models/ara3d/AC20-FZK-Haus.ifc', 'tests/models/various/01_Snowdon_Towers_Sample_Structural(1).ifc'];
const runtimePins = () => runtimePaths.map(path => ({path, sha256: sha(readFileSync(`${runtimeRoot}/${path}`))}));
const initial = {sources: sourcePins(), runtimeAndFixtures: runtimePins()};
const rows: unknown[] = [];
const outcome = (run: () => void) => {
  try { run(); return {accepted: true}; }
  catch (error) { return {accepted: false, error: error instanceof Error ? {name: error.name, message: error.message, stack: error.stack} : {message: String(error)}}; }
};
function original(report: Parameters<typeof assertPoolReuseReport>[0]) {
  expect(report.outputs.first.meshes).toBeGreaterThan(0);
  expect(report.outputs.repeat).toEqual(report.outputs.first);
  expect(report.spawnedAfterRepeat).toBe(report.spawnedBeforeRepeat);
  expect(report.outputs.federated).toEqual(report.outputs.federatedFresh);
  expect(report.outputs.federated.geometryHashes).toBeGreaterThan(0);
  expect(report.outputs.restored).toEqual(report.outputs.restoredFresh);
  expect(report.outputs.restored.geometryHashes).toBe(0);
  expect(report.outputs.restored.digest).toBe(report.outputs.first.digest);
  expect(report.outputs.federated.digest).not.toBe(report.outputs.first.digest);
  expect(report.bootWorkerCreations).toBe(2);
  expect(report.bootAdmittedWorkers).toBe(2);
  expect(report.bootWarmingWorkers).toBe(0);
  expect(report.initialWorkerHeapBytes).toHaveLength(2);
  for (const heap of report.initialWorkerHeapBytes) { expect(heap).toBeGreaterThan(0); expect(heap).toBeLessThanOrEqual(9 * 1024 * 1024); }
  expect(report.parserHandoffDigest).toBe(report.parserScanDigest);
  expect(report.finalIdleBytes).toBeLessThanOrEqual(144 * 1024 * 1024);
  expect(report.federationIdsDistinct).toBe(true);
}
const bytes = readFileSync('/home/louistrue/.t3/artifacts/7036-format24-source-audit-20261009/shared-validator-source-preparation/v3-visible-actual-report.json');
expect(sha(bytes)).toBe('ccd063d95c83597fc3e0bd8f3eb423946c8c93297dabba2bec5a8ab0387938dc');
const report: Parameters<typeof assertPoolReuseReport>[0] = JSON.parse(bytes.toString('utf8'));
function check(name: string, candidate: typeof report, accepted: boolean) {
  const old = outcome(() => original(candidate)), shared = outcome(() => assertPoolReuseReport(candidate));
  rows.push({name, expectedAccepted: accepted, original: old, shared});
  expect(old.accepted, name).toBe(accepted); expect(shared.accepted, name).toBe(accepted);
}
let success = false;
try {
  check('fresh saved genuine visible report', report, true);
  const controls: Array<[string, (copy: typeof report) => void]> = [
    ['first empty', c => { c.outputs.first.meshes = 0; }],
    ['repeat digest', c => { c.outputs.repeat.digest += '-changed'; }],
    ['repeat IDs', c => { c.outputs.repeat.ids.push(-1); }],
    ['repeat coordinates', c => { c.outputs.repeat.coordinates += '-changed'; }],
    ['repeat triangles', c => { c.outputs.repeat.triangles++; }],
    ['extra defined field', c => { Object.assign(c.outputs.repeat, {unexpectedField: 1}); }],
    ['repeat spawning', c => { c.spawnedAfterRepeat++; }],
    ['federated pair differs', c => { c.outputs.federatedFresh.digest += '-changed'; }],
    ['federated hashes absent', c => { c.outputs.federated.geometryHashes = c.outputs.federatedFresh.geometryHashes = 0; }],
    ['restored pair differs', c => { c.outputs.restoredFresh.digest += '-changed'; }],
    ['restored hashes retained', c => { c.outputs.restored.geometryHashes = c.outputs.restoredFresh.geometryHashes = 1; }],
    ['restored differs from first', c => { c.outputs.restored.digest = c.outputs.restoredFresh.digest = 'changed'; }],
    ['federated equals first digest', c => { c.outputs.federated.digest = c.outputs.federatedFresh.digest = c.outputs.first.digest; }],
    ['boot creations', c => { c.bootWorkerCreations++; }], ['boot admissions', c => { c.bootAdmittedWorkers++; }], ['boot warming', c => { c.bootWarmingWorkers++; }],
    ['heap count', c => { c.initialWorkerHeapBytes.pop(); }], ['heap zero', c => { c.initialWorkerHeapBytes[0] = 0; }], ['heap exceeds bound', c => { c.initialWorkerHeapBytes[0] = 9*1024*1024+1; }],
    ['parser digest', c => { c.parserHandoffDigest += '-changed'; }], ['idle exceeds bound', c => { c.finalIdleBytes = 144*1024*1024+1; }], ['federation ID overlap', c => { c.federationIdsDistinct = false; }],
  ];
  for (const [name, mutate] of controls) { const copy = structuredClone(report); mutate(copy); check(name, copy, false); }
  for (const [name, output] of [ ['key insertion order', Object.fromEntries(Object.entries(report.outputs.first).reverse())], ['undefined extra key', {...report.outputs.first, omitted: undefined}] ] as const) {
    const copy = structuredClone(report); Reflect.set(copy.outputs, 'repeat', output); check(name, copy, true);
  }
  const arrays = [ {name:'sparse vs undefined',left:[1,,3],right:[1,undefined,3],accepted:true}, {name:'trailing undefined',left:[1],right:[1,undefined],accepted:true}, {name:'negative zero',left:[0],right:[-0],accepted:false}, {name:'array order',left:[1,2],right:[2,1],accepted:false} ];
  for (const entry of arrays) { const copy = structuredClone(report); Reflect.set(copy.outputs.first,'ids',entry.left); Reflect.set(copy.outputs.repeat,'ids',entry.right); check(entry.name,copy,entry.accepted); }
  const sharedKey = Symbol('shared');
  for (const sameKey of [true,false]) { const copy = structuredClone(report); Reflect.set(copy.outputs.first,sharedKey,1); Reflect.set(copy.outputs.repeat,sameKey ? sharedKey : Symbol('shared'),1); check(`enumerable symbol identity ${sameKey}`,copy,sameKey); }
  for (const [name, stats, accepted] of [['hidden stated-invariant positive control',{idle:0,spawned:0},true],['hidden idle',{idle:1,spawned:0},false],['hidden spawn',{idle:0,spawned:1},false]] as const) {
    const old = outcome(() => { expect(stats.idle).toBe(0); expect(stats.spawned).toBe(0); }), shared = outcome(() => assertHiddenBootAdmission(stats));
    rows.push({name,expectedAccepted:accepted,original:old,shared}); expect(old.accepted,name).toBe(accepted); expect(shared.accepted,name).toBe(accepted);
  }
  check('fresh saved report preserved',report,true);
  success = true;
} finally {
  const final = {sources:sourcePins(),runtimeAndFixtures:runtimePins()};
  const pinsUnchanged = JSON.stringify(initial) === JSON.stringify(final);
  writeFileSync(`${dir}/node-fresh-visible-matcher-results.json`, JSON.stringify({kind:'Saved actual visible report / matcher contract ONLY; no new Worker/WASM execution; constructed hidden controls do not replace refused hidden browser scenario',success,pinsUnchanged,playwrightVersion:'1.63.0',tsxVersion:'4.23.15',attachmentSha256:sha(bytes),initial,final,rows},null,2)+'\n');
  expect(pinsUnchanged).toBe(true);
}
console.log(JSON.stringify({success,cases:rows.length,pinsUnchanged:true}));
