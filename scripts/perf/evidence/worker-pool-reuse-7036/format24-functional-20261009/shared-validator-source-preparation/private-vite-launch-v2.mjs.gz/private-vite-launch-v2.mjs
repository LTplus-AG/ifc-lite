import { startViewerDevServer } from '/home/louistrue/wt/7036-shared-witness-validator-20261009/tests/e2e/viewer-dev-server.ts';
import { readFileSync, readdirSync, existsSync, writeSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const label = process.argv[2];
if (!['worker-pool-reuse-7036', 'worker-pool-hidden-7036'].includes(label)) throw new Error('Explicit original case label required');
const emit = event => writeSync(1, JSON.stringify(event) + '\n');
const stat = readFileSync(`/proc/${process.pid}/stat`, 'utf8');
const identity = { pid:process.pid, ppid:process.ppid, startTick:stat.slice(stat.lastIndexOf(')')+2).trim().split(/\s+/)[19], executable:process.execPath, execArgv:process.execArgv, argv:process.argv };
let finish;
const terminal = new Promise(resolve => { finish = resolve; });
const normal = () => finish('SIGUSR2');
const emergencyTerm = () => { emit({event:'emergency-signal',signal:'SIGTERM',...identity}); process.exitCode=143; finish('emergency-SIGTERM'); };
const emergencyInterrupt = () => { emit({event:'emergency-signal',signal:'SIGINT',...identity}); process.exitCode=130; finish('emergency-SIGINT'); };
process.once('SIGUSR2',normal);
process.prependOnceListener('SIGTERM',emergencyTerm);
process.once('SIGINT',emergencyInterrupt);
const cachePrefix = `ifc-${label}-`;
const cachesBefore = new Set(readdirSync(tmpdir()).filter(name=>name.startsWith(cachePrefix)));
let watchdog;
try {
  const server = await startViewerDevServer(label);
  const cacheDirectoriesObservedCreated = readdirSync(tmpdir()).filter(name=>name.startsWith(cachePrefix) && !cachesBefore.has(name)).map(name=>join(tmpdir(),name));
  emit({event:'ready',label,url:server.url,cacheDirectoriesObservedCreated,...identity});
  // Server lifetime only; actual original witness case bound remains240seconds.
  watchdog = setTimeout(()=>finish('server-lifetime-600s'),600_000);
  const reason = await terminal;
  emit({event:'close-start',label,reason,...identity});
  try { await server.close(); emit({event:'closed',label,reason,cacheDirectoriesObservedCreated,cacheDirectoriesAbsent:cacheDirectoriesObservedCreated.every(dir=>!existsSync(dir)),...identity}); }
  catch(error) { emit({event:'close-failed',label,reason,name:error?.name,message:error?.message,stack:error?.stack,...identity}); throw error; }
  if(reason !== 'SIGUSR2') process.exitCode ||= 1;
} finally {
  clearTimeout(watchdog);
  process.removeListener('SIGUSR2',normal);
  process.removeListener('SIGTERM',emergencyTerm);
  process.removeListener('SIGINT',emergencyInterrupt);
}
