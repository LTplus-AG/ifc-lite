import { startViewerDevServer } from '/home/louistrue/wt/7036-shared-witness-validator-20261009/tests/e2e/viewer-dev-server.ts';
import { readFileSync, readdirSync, existsSync, openSync, closeSync, writeSync, fsyncSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { tmpdir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
const [label,controlArg,lifecycleArg] = process.argv.slice(2);
if(!['worker-pool-reuse-7036','worker-pool-hidden-7036'].includes(label)) throw new Error('Explicit original case label required');
const artifactRoot='/home/louistrue/.t3/artifacts/7036-format24-source-audit-20261009/shared-validator-source-preparation';
const controlPath=resolve(controlArg),lifecyclePath=resolve(lifecycleArg);
if(dirname(controlPath)!==artifactRoot || dirname(lifecyclePath)!==artifactRoot || existsSync(controlPath)) throw new Error('Fresh own artifact control/log paths required');
const lifecycleFd=openSync(lifecyclePath,'ax',0o600);
const stat=readFileSync(`/proc/${process.pid}/stat`,'utf8');
const identity={pid:process.pid,ppid:process.ppid,startTick:stat.slice(stat.lastIndexOf(')')+2).trim().split(/\s+/)[19],nonce:randomBytes(16).toString('hex'),executable:process.execPath,execArgv:process.execArgv,argv:process.argv};
const emit=event=>{ const line=JSON.stringify({...event,...identity})+'\n'; writeSync(lifecycleFd,line); fsyncSync(lifecycleFd); try { writeSync(1,line); } catch(error) { writeSync(lifecycleFd,JSON.stringify({event:'stdout-write-failed',message:String(error),...identity})+'\n'); fsyncSync(lifecycleFd); process.exitCode ||= 1; } };
let finish;const terminal=new Promise(resolve=>{finish=resolve;});
const emergencyTerm=()=>{emit({event:'emergency-signal',signal:'SIGTERM'});process.exitCode=143;finish('emergency-SIGTERM');};
const emergencyInterrupt=()=>{emit({event:'emergency-signal',signal:'SIGINT'});process.exitCode=130;finish('emergency-SIGINT');};
process.prependOnceListener('SIGTERM',emergencyTerm);process.once('SIGINT',emergencyInterrupt);
const cachePrefix=`ifc-${label}-`,cachesBefore=new Set(readdirSync(tmpdir()).filter(name=>name.startsWith(cachePrefix)));
let watchdog,controlPoll;
try {
  emit({event:'startup',label,controlPath,lifecyclePath});
  const server=await startViewerDevServer(label);
  const cacheDirectoriesObservedCreated=readdirSync(tmpdir()).filter(name=>name.startsWith(cachePrefix)&&!cachesBefore.has(name)).map(name=>join(tmpdir(),name));
  controlPoll=setInterval(()=>{
    if(!existsSync(controlPath))return;
    clearInterval(controlPoll);
    try {
      const request=JSON.parse(readFileSync(controlPath,'utf8'));
      if(request.action!=='close'||request.pid!==identity.pid||request.startTick!==identity.startTick||request.nonce!==identity.nonce||request.label!==label)throw new Error('Control identity/action mismatch');
      emit({event:'control-accepted',label,controlPath});finish('owned-file-control');
    } catch(error) { emit({event:'control-refused',label,name:error?.name,message:error?.message,stack:error?.stack});process.exitCode ||= 1;finish('invalid-control-refusal'); }
  },200);
  watchdog=setTimeout(()=>{process.exitCode ||= 1;finish('server-lifetime-600s');},600_000);
  emit({event:'ready',label,url:server.url,controlPath,lifecyclePath,cacheDirectoriesObservedCreated});
  const reason=await terminal;clearInterval(controlPoll);emit({event:'close-start',label,reason});
  try { await server.close();emit({event:'closed',label,reason,cacheDirectoriesObservedCreated,cacheDirectoriesAbsent:cacheDirectoriesObservedCreated.every(path=>!existsSync(path))}); }
  catch(error) { emit({event:'close-failed',label,reason,name:error?.name,message:error?.message,stack:error?.stack});throw error; }
  if(reason!=='owned-file-control')process.exitCode ||= 1;
} catch(error) { emit({event:'launcher-failed',label,name:error?.name,message:error?.message,stack:error?.stack});throw error; }
finally { clearInterval(controlPoll);clearTimeout(watchdog);process.removeListener('SIGTERM',emergencyTerm);process.removeListener('SIGINT',emergencyInterrupt);closeSync(lifecycleFd); }
