import { startViewerDevServer } from '/home/louistrue/wt/7036-shared-witness-validator-20261009/tests/e2e/viewer-dev-server.ts';
const label = process.argv[2];
if (!['worker-pool-reuse-7036', 'worker-pool-hidden-7036'].includes(label)) throw new Error('Explicit original case label required');
const server = await startViewerDevServer(label);
console.log(JSON.stringify({event:'ready',label,pid:process.pid,url:server.url}));
let finish: (reason: string) => void;
const terminal = new Promise<string>(resolve => { finish = resolve; });
const term = () => finish('SIGTERM');
const interrupt = () => finish('SIGINT');
process.once('SIGTERM', term); process.once('SIGINT', interrupt);
// Server lifetime bound only. Original witness case bound remains 240 seconds.
const watchdog = setTimeout(() => finish('server-lifetime-600s'), 600_000);
const reason = await terminal;
try { await server.close(); console.log(JSON.stringify({event:'closed',label,pid:process.pid,reason})); }
finally { clearTimeout(watchdog); process.removeListener('SIGTERM',term); process.removeListener('SIGINT',interrupt); }
