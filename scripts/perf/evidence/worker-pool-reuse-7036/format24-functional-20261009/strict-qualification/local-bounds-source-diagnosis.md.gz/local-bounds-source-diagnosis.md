# Read-only diagnosis of the actual localBounds refusal

The frozen 75ab6e7e run passed new-head root typecheck (3851 test sources), all four original real-C20 observer controls, then failed the one strict route case at canonical piece 0 localBounds. The coordinate frame comparison completed before that failure; format-24 retained recovery count 0 and length-unit scale 1. Exact source/runtime/fixture pins were unchanged. No inverse, comparison-domain change, fix, waiver or rerun was performed.

## What the source establishes

MeshData.localBounds is a public optional pre-placement object-space AABB, not the world/render bounding box. MeshData.localToWorld is the resolved row-major 4x4 placement transform with absolute pre-RTC translation. Both are captured by the standard element pipeline and may be absent where not captured. See packages/geometry/src/types.ts:184–199.

The Rust WASM boundary converts original captured local_bounds and local_to_world into the viewer axis convention (rust/wasm-bindings/src/zero_copy/mesh.rs:328–335). Both the direct conversion (packages/geometry/src/geometry-coordinate.ts:101–123) and worker producer (packages/geometry/src/geometry.worker.ts:1010–1029) create new localBounds min/max arrays only when the actual getter supplies six numbers; localToWorld copies the actual sixteen-number getter. These are source metadata, not a later renderer-derived approximation.

The cache's shared writeMeshRecord, meshRecordByteLength and readMeshRecord in packages/cache/src/sections/geometry.ts encode/decode ids, positions/normals/indices, color, type, geometry class, source ids, origin, appearance provenance and authored finish. None contains localBounds or localToWorld. decodeGeometryChunk calls that shared reader directly (geometry-chunks.ts:288). Its chunk-directory AABB is derived from world/render positions and is neither a per-piece pre-placement AABB nor a replacement for the missing placement matrix.

The renderer exposes getEntityLocalBounds and getEntityTransform from these captured mesh fields (scene.ts:3867 onward). Its documented missing-metadata behavior returns null for older cached geometry. This demonstrates a meaningful source contract; it does not independently prove a particular browser UI defect for this C20 model. Reconstructing local bounds from placed vertex positions would lose the pre-placement frame and must not be mistaken for preserving the source metadata.

## Reference and mutability analysis

The fresh route uses structuredClone of the canonical final geometry before the cache reload; its copied mesh metadata is independent of later store mutations. The cached route structured-clones each original decoded chunk in the awaited observer before appendGeometryBatch consumes it. The store appends original mesh references to arrays but does not synthesize these fields. The canonical writer grouping appends the same mesh references into groups (geometry-chunks.ts:99–125), changes only traversal grouping/order and does not mutate metadata. The oracle's remainingFields includes localBounds and localToWorld; it neither serializes them away nor treats absence as an inferred value. Both sides receive fresh lossless payload snapshots before comparison.

Static reader inspection establishes that the decoded per-piece object has no own localBounds field. The failure plus the producer contract supports the inference that fresh piece 0 retained defined bounds while its cached counterpart omitted them. That is a source-supported inference, not an archived runtime descriptor/value measurement. localToWorld is another source-visible omission in the same pre-placement metadata class, but this run stopped at localBounds and did not independently observe its comparison result.

## Actual evidence limitation

The failing log preserved the exact domain and field but did not persist the two numerical localBounds snapshots or Object.hasOwn results. Its detailed diagnostics contain coordinates, source/runtime hashes and cleanup outcome only. Cleanup deleted the cache and the in-memory event witnesses died with the process. It is therefore impossible to honestly report the fresh piece-0 numeric bounds or actual captured own-property descriptors from this completed run. Source analysis must not be relabelled as that missing runtime measurement.

Before attributing/filing a fully reproduced omission or proposing a codec repair, root can review a narrowly scoped diagnostic-only change: expose the two already-computed lossless snapshots in equalProperties' existing failure error (and original/decoded mesh identity and own-property descriptors for the failing field). Keep the same comparator, ordering, coordinates, normalization and excluded domains. Authorize one bounded original-case diagnostic observation only after reviewing that change; preserve this failure receipt unchanged. Such a change/re-observation has not been performed in this task.

No meaningful geometryItemId inverse is proposed yet, because the unmodified strict positive has not passed. #7036 remains open and #7161 remains draft; no native/browser/performance or full-scene acceptance follows from these CPU prerequisites.
