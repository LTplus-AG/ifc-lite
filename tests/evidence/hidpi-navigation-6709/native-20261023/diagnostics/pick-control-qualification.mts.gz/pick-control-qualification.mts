/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

import { geometryWitnessExpression } from './geometry-witness.mts';
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, appendFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { launchNativeChrome, readPhysicalSession, isPhysicalConsole, readHostAdmission } from './native-platform.mts';
const root = process.env.IFC_6709_ROOT;
if (!root) throw Error('IFC_6709_ROOT required');
const { startStaticServer } = await import(`${root}/scripts/perf/browser-static-server.ts`);
const { closeBrowserWithTimeout } = await import(`${root}/scripts/perf/browser-cold-teardown.ts`);
const { frameProbeInitScript } = await import(`${root}/tests/benchmark/frames/frame-probe.ts`);
const { orbitGesture } = await import(`${root}/tests/benchmark/frames/frame-scenarios.ts`);
const { realGpuFrameRows } = await import(`${root}/tests/benchmark/frames/frame-stats.ts`);
const { interleavedSchedule, summarizeSamples } = await import(`${root}/scripts/perf/frame-gpu-summary.ts`);
const { probeMetadataRenderTrace, waitForMetadataRenderReadiness } = await import(`${root}/tests/benchmark/metadata-render-readiness.ts`);

const directory = process.env.IFC_6709_EVIDENCE;
if (!directory) throw Error('IFC_6709_EVIDENCE required');
const require = createRequire(`${root}/package.json`);
const { chromium } = require('@playwright/test');
const pairs = 5;
const smoke = process.argv.includes('--smoke');
const diagnostic = process.env.IFC_6709_DIAGNOSTIC === '1';
if (diagnostic && !smoke) throw Error('Diagnostic must be smoke only');
const schedule = smoke ? [{pair:0,side:'base',dpr:1},{pair:0,side:'base',dpr:2}] : [1, 2].flatMap(dpr => interleavedSchedule(pairs, true).map(sample => ({ ...sample, dpr })));
if (process.argv.includes('--plan')) { console.log(JSON.stringify(schedule)); process.exit(0); }
const output = `${directory}/cohort-${new Date().toISOString().replaceAll(':', '-')}`;
mkdirSync(output);
const manifests = Object.fromEntries(['base', 'branch'].map(side => [side,
  JSON.parse(readFileSync(`${directory}/${side === 'base' ? 'base' : 'candidate'}-build-manifest.json`, 'utf8'))]));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
for (const manifest of Object.values(manifests)) {
  const git = (...args) => execFileSync('git', args, { cwd: manifest.checkout, encoding: 'utf8', timeout: 10000 }).trim();
  if (git('rev-parse', 'HEAD') !== manifest.head || git('status', '--porcelain')) throw Error('Source pin or cleanliness changed');
  for (const artifact of manifest.artifacts) {
    if (digest(readFileSync(`${manifest.checkout}/${artifact.path}`)) !== artifact.sha256) throw Error(`Pinned artifact changed: ${artifact.path}`);
  }
}
let current = manifests.base.checkout;
const model = process.env.IFC_6709_MODEL;
if (!model || digest(readFileSync(model)) !== 'd42ab0dee01173106c16cd823b4614efe188fa15dd65195d95b9879bec59acc5') throw Error('Canonical public FZK fixture hash mismatch');
const server = await startStaticServer({ port: 0, host: '0.0.0.0', root: () => `${current}/apps/viewer/dist`, extra: new Map([['/__6709/model.ifc', model]]) });
const origin = `http://localhost:${server.address().port}`;
const observer = `(() => {
 const state = globalThis.__6709 = { presents:[], reads:[], downloads:[], errors:[], adapters:[] };
 addEventListener('error',event=>state.errors.push(String(event.error || event.message)));
 addEventListener('unhandledrejection',event=>state.errors.push(String(event.reason)));
 const getContext=HTMLCanvasElement.prototype.getContext;state.glContexts=[];
 HTMLCanvasElement.prototype.getContext=function(type,...args){
  const context=getContext.call(this,type,...args);
  if(type==='webgl2' || type==='webgl') { const ext=context?.getExtension('WEBGL_debug_renderer_info');state.glContexts.push({canvas:this,type,attributes:args,renderer:ext?context.getParameter(ext.UNMASKED_RENDERER_WEBGL):null,stack:new Error().stack}); }
  return context;
 };
 const requestDevice=GPUAdapter.prototype.requestDevice;
 GPUAdapter.prototype.requestDevice=async function(...args) {
  const info=this.info;state.adapters.push({vendor:info.vendor,architecture:info.architecture,fallback:info.isFallbackAdapter});
  const device=await requestDevice.apply(this,args);
  device.addEventListener('uncapturederror',event=>state.errors.push('GPU:'+event.error.message));
  device.lost.then(info=>{ if(info.reason!=='destroyed') state.errors.push('GPU lost:'+info.message); });
  return device;
 };
 const original = GPUCanvasContext.prototype.getCurrentTexture;
 GPUCanvasContext.prototype.getCurrentTexture = function() {
  const texture=original.call(this), canvas=this.canvas;
  if(canvas instanceof HTMLCanvasElement && canvas.dataset.viewport==='main') {
   const rect=canvas.getBoundingClientRect();
   state.presents.push({ts:performance.now(),width:texture.width,height:texture.height,cssWidth:rect.width,cssHeight:rect.height,dpr:devicePixelRatio,viewProjection:globalThis.__ifc_lite_view_projection__?.() ?? null});
  }
  return texture;
 };
 const dataURL=HTMLCanvasElement.prototype.toDataURL;
 HTMLCanvasElement.prototype.toDataURL=function(...args) {
  const value=dataURL.apply(this,args);
  if(this.dataset.viewport==='main') state.reads.push({width:this.width,height:this.height,ts:performance.now()});
  return value;
 };
 const click=HTMLAnchorElement.prototype.click;
 HTMLAnchorElement.prototype.click=function() {
  if(this.download.endsWith('.png') && this.href.startsWith('data:image/png')) state.downloads.push({filename:this.download,href:this.href});
  else click.call(this);
 };
})()`;
const take = page => page.evaluate('globalThis.__ifc_lite_frame_probe__.take()');
const dimensions = page => page.evaluate(`(() => { const c=document.querySelector('canvas[data-viewport="main"]'),r=c.getBoundingClientRect(); return {width:c.width,height:c.height,cssWidth:r.width,cssHeight:r.height,dpr:devicePixelRatio}; })()`);
function fullQuality(value, dpr) {
  if (Math.abs(value.width - Math.round(value.cssWidth * dpr)) > 1 || Math.abs(value.height - Math.round(value.cssHeight * dpr)) > 1) throw Error('Full-quality drawing-buffer dimensions not restored');
}
async function idle(page) {
  const deadline = Date.now() + 15000;
  let count = 0;
  const collected = [];
  while (count < 12) {
    if (Date.now() >= deadline) throw Error('Viewer did not reach idle');
    await sleep(100);
    const frames = await take(page);
    collected.push(...frames);
    for (const frame of frames) count = frame.presents ? 0 : count + 1;
  }
  return collected;
}
async function geometry(page) {
  return page.evaluate(geometryWitnessExpression());
}

const records = [];
let activeRecord=null,rejectActiveDriver=null;
const originalStderr=process.stderr.write.bind(process.stderr);
const gpuDriverFailure=/ERROR:gpu\/|GL_INVALID_|uninitialized SharedImage|GPU process.*crash/i;
process.stderr.write=function(chunk,...args){
 const line=String(chunk);
 if(activeRecord && gpuDriverFailure.test(line)){
  activeRecord.meta.gpuDriverErrors.push(line.trim());
  rejectActiveDriver?.(Error('Native GPU driver error; refuse sample'));
 }
 return originalStderr(chunk,...args);
};
const cohortStarted = Date.now();
try {
 for (const sample of schedule) {
  if (Date.now() >= Number(process.env.IFC_6709_DEADLINE)) { console.error('Admitted cohort deadline reached'); break; }
  if(Date.now()-cohortStarted>27*60*1000) { console.error('Cohort start budget exhausted; no further sample launched');break; }
  const name = `dpr${sample.dpr}-${sample.side}-p${sample.pair}`;
  console.log(name);
  const record = { ...sample, ok:false, rows:[], meta:{gpuDriverErrors:[]} };
  activeRecord=record;
  const driverFailure=new Promise((_,reject)=>{rejectActiveDriver=reject;});
  void driverFailure.catch(error=>{record.meta.driverRejection=String(error);});
  let browser, sampleTimer, page;
  try {
   record.meta.hostBefore=await readHostAdmission();
   if(!diagnostic && !record.meta.hostBefore.quiet) throw Error('Host pre-admission refused');
   record.meta.sessionBefore=readPhysicalSession();
   if(!isPhysicalConsole(record.meta.sessionBefore)) throw Error('Physical-console admission refused');
   current=manifests[sample.side].checkout;
   browser=await launchNativeChrome(chromium);
   const deadline=new Promise((_,reject)=>{sampleTimer=setTimeout(()=>reject(Error('Native sample exceeded four-minute deadline')),240000);});
   await Promise.race([(async()=>{
   const context=await browser.newContext({ viewport:{width:1440,height:900},deviceScaleFactor:sample.dpr });page=await context.newPage();
   const logs=[];record.meta.console=logs;page.on('console',message=>logs.push(message.text()));
   page.setDefaultTimeout(30000);
   const cdp=await context.newCDPSession(page);
   await cdp.send('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:sample.dpr,mobile:false});
   await context.addInitScript({content:frameProbeInitScript({workDone:true})});
   await context.addInitScript({content:observer});
   await page.goto(`${origin}/?perfTrace=1`,{timeout:30000});
   await page.getByRole('button',{name:'Collapse sidebar to icons',exact:true}).click();
   await page.waitForFunction('globalThis.__ifc_lite_viewer_store__.getState().sidebarMode==="collapsed"');
   record.meta.layout='Normal UI: sidebar collapsed to icons before first model load; location map unmounted';
   await page.locator('#file-input-open').waitFor({state:'attached'});
   await page.locator('#file-input-open').setInputFiles(model);
   await page.bringToFront();
   await waitForMetadataRenderReadiness({trace:async()=>{const value=await probeMetadataRenderTrace(page);record.meta.latestReadinessTrace=value;return value;},logs:()=>logs,
    canvasReady:()=>page.evaluate(`(() => {const c=document.querySelector('canvas[data-viewport="main"]');return !!c && c.width>0 && c.height>0 && globalThis.__ifc_lite_render_stats__?.().frame?.drawCalls>0;})()`),
    now:()=>performance.now(),pause:()=>sleep(50),timeoutMs:90000});
   record.meta.loadTrace=await probeMetadataRenderTrace(page);
   if(!record.meta.loadTrace?.ended || record.meta.loadTrace.failed.length) throw Error('Complete authoritative load trace missing or failed');
   record.meta.adapter=await page.evaluate('globalThis.__ifc_lite_render_stats__().adapter');
   record.meta.requestedAdapters=await page.evaluate('globalThis.__6709.adapters');
   if(!record.meta.requestedAdapters.length || record.meta.requestedAdapters.some(info=>info.vendor!=='nvidia' || info.fallback))throw Error('Actual device request did not use non-fallback NVIDIA hardware');
   if(!record.meta.adapter?.vendor || (record.meta.adapter.isFallbackAdapter || record.meta.adapter.fallback) || /swiftshader|software|llvmpipe/i.test(JSON.stringify(record.meta.adapter))) throw Error('Actual viewer hardware adapter missing or software');
   const observedDpr=await page.evaluate('devicePixelRatio');
   if(Math.abs(observedDpr-sample.dpr)>0.00001) throw Error('Requested DPR not observed');
   await idle(page);
   await page.keyboard.press('Home');
   await idle(page);
   record.meta.geometryBefore=await geometry(page);
   record.meta.settledBefore=await dimensions(page);
   fullQuality(record.meta.settledBefore,sample.dpr);
   await page.screenshot({path:`${output}/${name}-home.png`});
   const rect=await page.locator('canvas[data-viewport="main"]').boundingBox();
   if(!rect) throw Error('Main viewport missing');
   await page.evaluate('globalThis.__ifc_lite_frame_probe__.beginForegroundGuard()');
   await take(page);
   await page.evaluate('globalThis.__6709.presents=[]');
   const start=performance.now();
   const steps=orbitGesture(rect,240);
   for(let i=0;i<steps.length;i++) {
    const remaining=start+i*8.333333333-performance.now();
    if(remaining>0) await sleep(remaining);
    for(const input of steps[i]) await cdp.send(input.method,input.params);
   }
   const frames=await idle(page);
   record.rows=realGpuFrameRows(`FZK-DPR${sample.dpr}`,'orbit',frames);
   if (record.rows.some(row => !Number.isFinite(row.value))) throw Error('Native timing metrics missing or nonfinite');
   writeFileSync(`${output}/${name}-frames.json`,JSON.stringify(frames));
   const presents=await page.evaluate('globalThis.__6709.presents');
   writeFileSync(`${output}/${name}-presents.json`,JSON.stringify(presents));
   if(presents.length<10 || frames.length<10) throw Error('Navigation has insufficient actual frame observations');
   const ratios=presents.map(p=>p.width/p.cssWidth);
   record.meta.interactiveMinimumRatio=Math.min(...ratios);
   record.meta.distinctNavigationViews=new Set(presents.filter(p=>p.viewProjection).map(p=>JSON.stringify(p.viewProjection))).size;
   if(record.meta.distinctNavigationViews<2)throw Error('Driven gesture did not move the actual renderer camera');
   record.meta.transitions={first:presents[0],last:presents.at(-1),cssFrames:ratios.filter(r=>Math.abs(r-1)<0.01).length,fullFrames:ratios.filter(r=>Math.abs(r-sample.dpr)<0.01).length};
   fullQuality(presents.at(-1),sample.dpr);
   if(sample.side==='branch' && sample.dpr===2 && !ratios.some(r=>Math.abs(r-1)<0.01)) throw Error('Interactive frame never reached CSS resolution');
   if(sample.side==='base' && sample.dpr===2 && ratios.some(r=>r<1.9)) throw Error('Baseline unexpectedly changed resolution');
   record.meta.settledAfter=await dimensions(page);fullQuality(record.meta.settledAfter,sample.dpr);
   // Capture through the actual command palette while a real orbit drag is held.
   await page.mouse.move(rect.x+rect.width/2,rect.y+rect.height/2);
   await page.mouse.down();await page.mouse.move(rect.x+rect.width/2+60,rect.y+rect.height/2+20);
   await sleep(100);
   record.meta.captureRequestedDimensions=await dimensions(page);
   if(sample.side==='branch' && sample.dpr===2 && Math.abs(record.meta.captureRequestedDimensions.width/record.meta.captureRequestedDimensions.cssWidth-1)>0.01) throw Error('Capture was not requested from an interactive CSS-resolution frame');
   await page.screenshot({path:`${output}/${name}-held-navigation.png`});
   await page.keyboard.press('Control+k');
   await page.getByRole('textbox',{name:'Search commands',exact:true}).fill('Screenshot');
   await page.getByRole('option',{name:/Screenshot/}).waitFor({state:'visible'});
   await page.keyboard.press('Enter'); // Preserve the held canvas drag; no synthetic mouse release on the palette option.
   await page.waitForFunction('globalThis.__6709.downloads.length===1');
   await page.mouse.move(rect.x+rect.width/2+80,rect.y+rect.height/2+30);await sleep(100);
   record.meta.interactiveAfterCapture=await dimensions(page);
   if(sample.side==='branch' && sample.dpr===2 && Math.abs(record.meta.interactiveAfterCapture.width/record.meta.interactiveAfterCapture.cssWidth-1)>0.01) throw Error('Owned capture failed to resume the interactive frame policy');
   await page.mouse.up();await idle(page);
   record.meta.settledAfterCapture=await dimensions(page);fullQuality(record.meta.settledAfterCapture,sample.dpr);
   const capture=await page.evaluate('globalThis.__6709.downloads[0]');
   const png=Buffer.from(capture.href.split(',')[1],'base64');
   record.meta.capture={filename:capture.filename,width:png.readUInt32BE(16),height:png.readUInt32BE(20),bytes:png.length,sha256:digest(png)};
   fullQuality({...record.meta.settledBefore,...record.meta.capture},sample.dpr);
   writeFileSync(`${output}/${name}-capture.png`,png);
   record.meta.geometryAfter=await geometry(page);
   if(JSON.stringify(record.meta.geometryBefore)!==JSON.stringify(record.meta.geometryAfter)) throw Error('Loaded geometry changed during navigation/capture');
   await page.keyboard.press('Home');await idle(page);
   // Diagnostic matrix only: retain every CPU/UI disagreement, no accepted timing.
   const targets=await page.evaluate(`(() => {
    const s=globalThis.__ifc_lite_viewer_store__.getState(),c=document.querySelector('canvas[data-viewport="main"]').getBoundingClientRect(),m=[...s.models.values()][0];
    const ids=[...new Set(m.geometryResult.meshes.filter(m=>/IFCWALL|IFCROOF|IFCSLAB/i.test(m.ifcType)).map(m=>m.expressId))].sort((a,b)=>a-b);
    const result=[];
    for(const id of ids) for(const hit of globalThis.__ifc_lite_scene_face_hits__(id)) if(hit.screen.x>c.left+10 && hit.screen.x<c.right-10 && hit.screen.y>c.top+10 && hit.screen.y<c.bottom-10){result.push({id,x:hit.screen.x,y:hit.screen.y,type:m.ifcDataStore.entities.getTypeName(id),geometryItemId:hit.geometryItemId,sourceTriangleIndex:hit.sourceTriangleIndex});if(result.length>=24)return result;}
    return result;
   })()`);
   await page.evaluate(`document.querySelector('canvas[data-viewport="main"]').addEventListener('click',e=>{globalThis.__6709.clickPosition={x:e.clientX,y:e.clientY};},{capture:true})`);
   record.meta.pickTrials=[];
   for(const target of targets){
    await page.mouse.click(target.x,target.y);await sleep(200);
    const actual=await page.evaluate('(()=>{const s=globalThis.__ifc_lite_viewer_store__.getState(),m=[...s.models.values()][0];return {id:s.selectedEntityId,type:m.ifcDataStore.entities.getTypeName(s.selectedEntityId),event:globalThis.__6709.clickPosition};})()');
    record.meta.pickTrials.push({target,actual,matched:actual.id===target.id});
   }
   record.meta.pick={id:'diagnostic-matrix-not-acceptance'};
   record.meta.foreground=await page.evaluate('globalThis.__ifc_lite_frame_probe__.foreground()');
   if(record.meta.foreground.interruptions || record.meta.foreground.visibility!=='visible' || !record.meta.foreground.focused) throw Error('Foreground admission interrupted');
   record.meta.sessionAfter=readPhysicalSession();
   if(!isPhysicalConsole(record.meta.sessionAfter) || record.meta.sessionBefore.currentSession!==record.meta.sessionAfter.currentSession) throw Error('Physical-console session changed');
   record.meta.errors=await page.evaluate('globalThis.__6709.errors');
   if(record.meta.errors.length) throw Error('Unhandled page errors observed');
   await idle(page);record.meta.hostAfter=await readHostAdmission();if(!diagnostic && !record.meta.hostAfter.quiet) throw Error('Host post-admission refused');
   record.ok=true;
   })(),deadline,driverFailure]);
  } catch(error) { record.error=String(error);console.error(name,record.error);if(page && !page.isClosed()) { try {record.meta.glContexts=await page.evaluate('globalThis.__6709.glContexts.map(({canvas,...value})=>({...value,className:canvas.className,id:canvas.id,connected:canvas.isConnected}))');record.meta.failureDiagnostics=await page.evaluate('({trace:globalThis.__IFC_LITE_LOAD_TRACE__?.latest?.(),stats:globalThis.__ifc_lite_render_stats__?.(),canvas:!!document.querySelector("canvas[data-viewport=main]")})');await page.screenshot({path:`${output}/${name}-failure.png`,timeout:5000});} catch(screenshotError) {record.meta.screenshotError=String(screenshotError);} } }
  finally {
   clearTimeout(sampleTimer);
   if(browser?.isConnected()) {
    const failure=await closeBrowserWithTimeout(browser,15000);
    if(failure){record.ok=false;record.error=`${record.error||''} CDP disconnect: ${failure}`;}
   }
  }
  if(record.meta.gpuDriverErrors.length){record.ok=false;record.error=record.error||'Native GPU driver error observed';}
  activeRecord=null;rejectActiveDriver=null;
  if(diagnostic){record.rows=[];record.meta.diagnosticOnly=true;}
  records.push(record);appendFileSync(`${output}/runs.jsonl`,JSON.stringify(record)+'\n');
  if(!record.ok) break; // A refused/failed sample is retained; no replacement cohort.
 }
} finally { process.stderr.write=originalStderr;server.closeAllConnections();await new Promise(resolve=>server.close(resolve)); }
const identities=new Set(records.filter(r=>r.ok).map(r=>JSON.stringify(r.meta.geometryBefore)));
const pickIds=new Set(records.filter(r=>r.ok).map(r=>r.meta.pick.id));
const completedSuccessfully=records.length===schedule.length && records.every(r=>r.ok) && identities.size===1 && pickIds.size===1;
const summary={performanceVerdict:diagnostic?'DIAGNOSTIC ONLY; no exclusive host and no accepted timing':'REQUIRES_REVIEW; functional completion is not a frame-rate verdict',smoke,planned:schedule.length,completed:records.length,geometryIdentityAcrossCohort:identities.size===1,pickIdentityAcrossCohort:pickIds.size===1,completedSuccessfully,allAccepted:!smoke && completedSuccessfully,rows:smoke?[]:summarizeSamples(records),scope:smoke?'One native functional smoke. No A/B or performance verdict.':'Source-pinned current-main cap-only A/B; exact commit identities are in the frozen manifests. Native evidence and all issue acceptance still require review before closure.'};
writeFileSync(`${output}/summary.json`,JSON.stringify(summary,null,2));
console.log(JSON.stringify({output,...summary}));
process.exit(completedSuccessfully?0:1);
